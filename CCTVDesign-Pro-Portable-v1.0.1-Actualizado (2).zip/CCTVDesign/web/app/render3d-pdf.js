/**
 * CCTV DESIGN PRO — Renderizado de perspectiva 3D para documentación PDF y láminas
 * Genera planos de perspectiva 3D axonométrica isométrica de alta resolución con cajetín normalizado.
 */
import { construirEscena, carasAlOjo, ordenarPreparadas, matizar } from './render3d.js?v=b441e3fc';
import { nuevaCamara, encuadrarCaja, aplicarVista, baseDe, proyectar, ordenar, caraVisible, sombreado } from './core/view3d.js?v=b441e3fc';

export function drawPerspectivePdf(pdf, prj, catalog, rules, opts = {}) {
  const cat = catalog || prj.catalog || { items: [] };
  const rul = rules || prj.rules || {};
  const escena = construirEscena(prj, cat, rul, {
    mostrarHaz: opts.mostrarHaz !== false,
    degradadoHaz: true,
    sombraHaz: true,
    formasCamara: true
  });
  const cam = nuevaCamara();
  encuadrarCaja(cam, escena.caja);
  aplicarVista(cam, opts.vista || 'iso');
  const b = baseDe(cam);
  const ojo = b.ojo;

  const titleH = 46;
  const availW = pdf.contentWidth, availH = pdf.height - pdf.margin * 2 - titleH;
  const ox = pdf.margin, oy = pdf.margin + titleH;
  const w = availW, h = availH;

  // Fondo del recuadro 3D
  pdf.rect(ox, oy, w, h, { fill: '#f8fafc', stroke: '#94a3b8', width: 0.5 });

  // Suelo / recintos
  for (const l of carasAlOjo(escena.suelo || [], b)) {
    const pts = []; let ok = true;
    for (const p of l.cara.puntos) {
      const s = proyectar(p, cam, w, h);
      if (s.detras) { ok = false; break; }
      pts.push({ x: ox + s.x, y: oy + (h - s.y) });
    }
    if (ok && pts.length >= 3) {
      pdf.polyline(pts, { close: true, fill: '#e2e8f0', color: '#94a3b8', width: 0.4 });
    }
  }

  // Sombras del suelo y sombras proyectadas de haces
  const sombrasTotales = [...(escena.sombras || []), ...(escena.sombrasHaz || [])];
  for (const s of ordenarPreparadas(carasAlOjo(sombrasTotales, b), ojo)) {
    const pts = []; let ok = true;
    for (const p of s.puntos) {
      const pt = proyectar(p, cam, w, h);
      if (pt.detras) { ok = false; break; }
      pts.push({ x: ox + pt.x, y: oy + (h - pt.y) });
    }
    if (ok && pts.length >= 3) {
      pdf.polyline(pts, { close: true, fill: '#cbd5e1', color: '#94a3b8', width: 0.2 });
    }
  }

  // Volúmenes arquitectónicos (muros, obstáculos, tabiques)
  const preparadas = [];
  for (const prep of carasAlOjo((escena.caras || []).filter((c) => !c.plana), b)) {
    preparadas.push({ cara: prep.cara, prof: prep.prof });
  }
  const caras = ordenarPreparadas(preparadas, ojo);
  for (const c of caras) {
    const pts = []; let ok = true;
    for (const p of c.puntos) {
      const s = proyectar(p, cam, w, h);
      if (s.detras) { ok = false; break; }
      pts.push({ x: ox + s.x, y: oy + (h - s.y) });
    }
    if (ok && pts.length >= 3 && caraVisible(c, ojo)) {
      const luz = sombreado(c);
      const col = matizar(c.color || '#94a3b8', luz);
      pdf.polyline(pts, { close: true, fill: col, color: '#334155', width: 0.4 });
    }
  }

  // Conos y haces volumétricos 3D
  const haces = ordenar(escena.haces || [], ojo);
  for (const c of haces) {
    const pts = []; let ok = true;
    for (const p of c.puntos) {
      const s = proyectar(p, cam, w, h);
      if (s.detras) { ok = false; break; }
      pts.push({ x: ox + s.x, y: oy + (h - s.y) });
    }
    if (ok && pts.length >= 3) {
      pdf.polyline(pts, { close: true, fill: '#fed7aa', color: '#ea580c', width: 0.2 });
    }
  }

  // Cuerpos de cámaras y soportes
  const equipos = [...(escena.cuerpos || []), ...(escena.montajes || [])];
  for (const corp of equipos) {
    for (const c of ordenarPreparadas(carasAlOjo(corp.caras || [], b), ojo)) {
      const pts = []; let ok = true;
      for (const p of c.puntos) {
        const s = proyectar(p, cam, w, h);
        if (s.detras) { ok = false; break; }
        pts.push({ x: ox + s.x, y: oy + (h - s.y) });
      }
      if (ok && pts.length >= 3) {
        pdf.polyline(pts, { close: true, fill: c.color || '#475569', color: '#1e293b', width: 0.4 });
      }
    }
  }

  // Cajetín normalizado de ingeniería (UNE-EN ISO 7200 / DIN)
  const fmt = opts.formato || 'A3';
  const ty = pdf.margin + 4;
  const cw = pdf.contentWidth;
  // Marco exterior
  pdf.rect(pdf.margin - 4, pdf.margin - 4, cw + 8, pdf.height - pdf.margin * 2 + 8, { stroke: '#1e293b', width: 1.2 });
  // Marco cajetín
  pdf.rect(pdf.margin, ty, cw, titleH - 6, { stroke: '#334155', fill: '#f8fafc', width: 0.8 });
  const colDiv1 = Math.min(cw * 0.45, 340);
  const colDiv2 = Math.min(cw * 0.82, cw - 120);
  pdf.line(pdf.margin + colDiv1, ty, pdf.margin + colDiv1, ty + titleH - 6, { width: 0.6, color: '#64748b' });
  pdf.line(pdf.margin + colDiv2, ty, pdf.margin + colDiv2, ty + titleH - 6, { width: 0.6, color: '#64748b' });
  pdf.line(pdf.margin, ty + (titleH - 6) / 2, pdf.margin + colDiv2, ty + (titleH - 6) / 2, { width: 0.4, color: '#cbd5e1' });

  // Bloque 1: Proyecto y cliente
  pdf.text(pdf.margin + 8, ty + titleH - 18, prj.meta.name || 'Proyecto de Seguridad y CCTV', 12, { bold: true, color: '#0f172a' });
  pdf.text(pdf.margin + 8, ty + titleH - 28, `${prj.meta.client || 'Cliente confidencial'}  ·  ${prj.meta.address || 'Emplazamiento no especificado'}`, 8, { color: '#334155' });
  pdf.text(pdf.margin + 8, ty + 6, `Código: ${prj.meta.code || 'PRJ-01'}  ·  Proyectista: ${prj.meta.author || 'CCTV DESIGN PRO'}`, 8, { color: '#64748b' });

  // Bloque 2: Título y especificaciones
  pdf.text(pdf.margin + colDiv1 + 8, ty + titleH - 18, (opts.title || `PERSPECTIVA 3D ISOMÉTRICA DE COBERTURA Y CONOS (${fmt})`), 10.5, { bold: true, color: '#0f172a' });
  const numCams = (prj.entities || []).filter((e) => e.type === 'camera').length;
  pdf.text(pdf.margin + colDiv1 + 8, ty + titleH - 28, `Vista 3D: Axonométrica Isométrica (35°/35°)  ·  Dispositivos: ${numCams} cámaras con conos 3D`, 8, { color: '#334155' });
  pdf.text(pdf.margin + colDiv1 + 8, ty + 6, `Fecha: ${new Date().toLocaleDateString('es-ES')}  ·  Normativa: UNE-EN 62676 / RGPD / AI Act`, 7.5, { color: '#64748b' });

  // Bloque 3: Formato y sello
  pdf.text(pdf.margin + colDiv2 + 8, ty + titleH - 16, `LÁMINA 3D (${fmt})`, 11, { bold: true, color: '#1e3a8a' });
  pdf.text(pdf.margin + colDiv2 + 8, ty + titleH - 26, `Hoja 1 de 1`, 8, { color: '#475569' });
  pdf.text(pdf.margin + colDiv2 + 8, ty + 6, 'CCTV DESIGN PRO', 7, { color: '#94a3b8' });
}
