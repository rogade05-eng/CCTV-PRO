/**
 * CCTV DESIGN PRO — Motor CAD (CP CCTV §8, §10, §11)
 * Canvas 2D puro: sin WebGL, sin GPU dedicada (§36).
 */
import { distPointSeg, dist, rad, bbox, polyLength, cajaDe2, cajaDeEntidad, seleccionarEnCaja,
  seleccionarEnPoligono, entidadEnCaja, entidadEnPoligono, areaConSigno, simplify, pointInPoly }
  from './core/geometry.js?v=b441e3fc';
import { footprint, fieldOfView } from './core/dori.js?v=b441e3fc';
import { cameraPresets, isPtz } from './core/ptz.js?v=b441e3fc';
import { captureZone, isLpr } from './core/lpr.js?v=b441e3fc';
import { VistaNav, factorRueda, cajaDeEntidades, menuContextual, ACCIONES_VISTA } from './core/view.js?v=b441e3fc';
import { PREFS_POR_DEFECTO, normalizarPrefs, tamanoCruzPx, cajaMira, puntoForzado, coordenadasTexto,
  ETIQUETA_FORZADO } from './core/workspace.js?v=b441e3fc';
import { getItem } from './core/catalog.js?v=b441e3fc';
import { obstaculoDe, datosDe, AYUDA_DIBUJO } from './core/obstacles.js?v=b441e3fc';
import { nuevaCamara, orbitar, zoom3d, encuadrarCaja, aplicarVista, ojoDe, proyectar as proyectarPunto3d,
  camaraDesdeVigilancia } from './core/view3d.js?v=b441e3fc';
import { construirEscena, pintar3d, encuadrar as encuadrarEscena } from './render3d.js?v=b441e3fc';
import { tiradoresDe, aplicarTirador, rotarEntidad, escalarEntidad, espejarEntidad, espejarPorEje,
  trasladar, insertarVertice, borrarVertice, cerrarEntidad, resumenDe, longitudDe, areaDe, barridoDe,
  centroideDe, clonar, anguloDeg } from './core/edit.js?v=b441e3fc';

const LAYER_COLORS = {};

/** Capa con la que se dibuja un plano importado cuando se pide atenuarlo (§9). */
const LAYER_ATENUADA = { color: '#5c6b7a' };

/** `#38bdf8` + alfa 0,16 → `rgba(56,189,248,0.16)`. Acepta los dos formatos. */
function conAlfa(color, alfa) {
  const c = String(color || '').trim();
  if (c.startsWith('rgba') || c.startsWith('rgb')) return c;
  const h = c.replace('#', '');
  if (h.length !== 6) return c;
  const n = parseInt(h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alfa})`;
}

export class CadView {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.prj = null;
    // La escala (píxeles por metro) y el centro de la vista viven en `nav`, que es el módulo
    // de navegación estilo AutoCAD (§8): rueda, rueda pulsada, botón derecho, zoom anterior.
    this.nav = new VistaNav({ scale: 20 });
    this.tool = 'select';
    this.layer = 'ARQUITECTURA';
    this.selection = new Set();
    this.draft = null;
    this.hover = null;
    this.cursor = { x: 0, y: 0 };
    this.gridStep = 1;
    this.on = opts.on || {};
    this._raf = 0;
    this._heat = null;
    this._heatKey = '';
    this._planoIds = null;           // entidades del plano importado (para atenuar y encuadrar)
    this._atenuarPlano = false;
    this._menu = null;               // menú contextual abierto
    this._ventana = null;            // zoom ventana en curso {a}
    // Espacio de trabajo y puntero configurables (§8): tipo y tamaño de cruz, mira de selección,
    // colores del lienzo, forzados y tiradores. Los valores viven en las preferencias del usuario.
    this.prefs = normalizarPrefs(opts.prefs || PREFS_POR_DEFECTO);
    this._ratonDentro = false;       // el puntero dibujado solo se pinta dentro del lienzo
    this._raton = { x: 0, y: 0 };    // posición en píxeles de pantalla
    this._modoForzado = '';          // último modo aplicado (referencia, forzado, orto, polar…)
    // Vista 3D (§8): sencilla y sin WebGL. El motor 2D sigue mandando; el 3D es otra forma de
    // mirar el mismo proyecto, y por eso comparte selección, capas y herramientas.
    this.modo3d = false;
    this.cam3d = nuevaCamara();
    // Opciones de la vista 3D (§8): sombras en el suelo y niebla de profundidad dan la sensación
    // de volumen; ocultar techos deja ver el interior, que es lo que hace falta para colocar cámaras
    this.opciones3d = { rejilla: true, mostrarHaz: true, mostrarPersona: false, opacidadMuros: 1,
      referenciaAltura: true, sombras: true, niebla: true, ocultarTechos: false, rotulosSuelo: true,
      contactos: true, aristas: true, suelo: true, degradado: true, materiales: true, penumbra: true,
      rotulosCamaras: true, norte: true, cielo: true, juntas: true, escalaGrafica: true, nombresEstancias: true,
      atenuarHaz: true, soporteCamara: true, zocalo: true,
      degradadoHaz: true, sombraHaz: true, formasCamara: true };
    this._escena3d = null;
    this._escena3dKey = '';
    this.toolKind = null;            // qué obstáculo se está dibujando (muro, puerta, árbol…)
    this._orbitando = null;
    this.vistaCamara = null;             // id de la cámara desde la que se está mirando (§8)
    this._mirada = { az: 0, tilt: 0 };   // cuanto se ha girado la vista sin tocar la cámara real
    // Edición de objetos (§9): tiradores (grips) arrastrables, con su copia de seguridad para
    // poder cancelar el arrastre con Esc, igual que en AutoCAD.
    this._agarre = null;             // tirador que se está arrastrando {id, tirador, copia}
    this._tiradorHover = null;       // tirador bajo el cursor (se pinta más grande y con etiqueta)
    // Comandos de edición al estilo de AutoCAD (§8): MOVER, COPIAR, GIRAR, ESCALAR, ESPEJO y PEGAR
    // piden un punto base y luego el destino, con una vista previa en todo momento.
    this._comando = null;            // {tipo, fase, base, referencia, origen, fantasma}
    // Cámara recién colocada esperando que se le diga hacia dónde mira, igual que AutoCAD pide
    // el ángulo de giro al insertar un bloque (§8, §9).
    this._apunte = null;             // {id, original, destino}
    this._fantasma = false;          // se dibuja la vista previa del comando en curso
    this._bind();
    this._resize();
    new ResizeObserver(() => this._resize()).observe(canvas.parentElement || canvas);
  }

  /** Aplica preferencias del espacio de trabajo (normalizadas) y repinta. */
  setPrefs(prefs) {
    this.prefs = normalizarPrefs(prefs);
    this.gridStep = this.prefs.pasoRejilla;
    this._cursorNativo();
    this.draw();
    return this.prefs;
  }

  /**
   * El puntero del navegador se oculta cuando hay puntero propio dibujado (cruz, cruz con mira),
   * porque el sistema dibuja una flecha que no se puede configurar. Con «Flecha estándar» se
   * devuelve el control al navegador, como en AutoCAD con el puntero de sistema.
   */
  _cursorNativo() {
    const propio = this.prefs.tipoPuntero !== 'flecha' && this.tool !== 'pan';
    if (this.modo3d) { this.canvas.style.cursor = this._orbitando ? 'grabbing' : 'grab'; return; }
    if (this._panning || this._box || this._lazo) this.canvas.style.cursor = this._panning ? 'grabbing' : 'crosshair';
    else this.canvas.style.cursor = propio ? 'none' : (this.tool === 'pan' ? 'grab' : 'crosshair');
  }

  /* La escala y el centro se leen y escriben como siempre (`cad.scale`), pero los guarda `nav`. */
  get scale() { return this.nav.scale; }
  set scale(v) { this.nav.scale = v; }
  get center() { return this.nav.center; }
  set center(v) { this.nav.center = { x: v.x, y: v.y }; }

  setProject(prj, fit = true) {
    this.prj = prj;
    this.selection.clear();
    this._heatKey = '';
    if (fit) this.fit();
    this.draw();
  }

  _resize() {
    const dpr = window.devicePixelRatio || 1;
    const r = this.canvas.getBoundingClientRect();
    this.canvas.width = Math.max(320, r.width * dpr);
    this.canvas.height = Math.max(240, r.height * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.w = r.width; this.h = r.height;
    this.nav.setViewport(this.w, this.h);
    this.draw();
  }

  /* ------------------------- transformaciones ------------------------- */
  sx(wx) { return this.nav.sx(wx); }
  sy(wy) { return this.nav.sy(wy); }
  wx(sx) { return this.nav.wx(sx); }
  wy(sy) { return this.nav.wy(sy); }
  toWorld(p) { return { x: this.wx(p.x), y: this.wy(p.y) }; }

  /* ------------------------- navegación (§8) ------------------------- */

  /** Encuadra todo el dibujo (Zoom extensión). */
  fit(pad = 40) {
    if (!this.prj) return false;
    const caja = cajaDeEntidades(this.prj.entities);
    if (!caja) { this.nav.fijar(20, { x: 0, y: 0 }); this.draw(); return false; }
    this.nav.encuadrar(caja, { pad });
    this.draw();
    return true;
  }

  /** Zoom extensión: igual que el encuadre general, con el nombre de AutoCAD. */
  zoomExtents() { return this.fit(); }

  /** Zoom anterior: vuelve a la vista previa. */
  zoomAnterior() {
    const ok = this.nav.vistaAnterior();
    if (ok) this.draw();
    return ok;
  }

  /** Zoom ventana: dos clics definen el rectángulo, como en AutoCAD. */
  zoomVentana() {
    this._ventana = { a: null };
    this.canvas.style.cursor = 'crosshair';
    if (this.on.hint) this.on.hint('Zoom ventana: señale la primera esquina (Esc cancela).');
    return this;
  }

  /** Zoom 100 %: 1 píxel = 1 metro. */
  zoomReal() { this.nav.zoomReal(1); this.draw(); return true; }

  /** Encuadra una caja del mundo (se usa al importar un plano). */
  encuadrarCaja(caja, pad = 60) {
    const ok = this.nav.encuadrar(caja, { pad });
    if (ok) this.draw();
    return ok;
  }

  /** Encuadra el plano importado, no todo el proyecto (§9). */
  encuadrarPlano(pad = 60) {
    const caja = this._planoIds && this.prj
      ? cajaDeEntidades(this.prj.entities, (e) => this._planoIds.has(e.id))
      : null;
    if (!caja) return this.fit();
    return this.encuadrarCaja(caja, pad);
  }

  /** Marca (o desmarca) el plano importado: se usa para atenuarlo y para encuadrarlo. */
  setPlanoImportado(ids, atenuar) {
    this._planoIds = ids ? new Set(ids) : null;
    if (atenuar !== undefined) this._atenuarPlano = !!atenuar;
    this.draw();
  }

  get atenuarPlano() { return this._atenuarPlano; }
  set atenuarPlano(v) { this._atenuarPlano = !!v; this.draw(); }

  /** Caja envolvente del plano importado, para avisar de dónde está. */
  cajaPlano() {
    if (!this._planoIds || !this.prj) return null;
    return cajaDeEntidades(this.prj.entities, (e) => this._planoIds.has(e.id));
  }

  zoomAt(factor, px, py) {
    this.nav.zoomAt(factor, px, py);
    this.draw();
  }

  /**
   * Punto de trabajo del cursor: vértice de referencia → forzados del usuario (ortogonal, polar,
   * rejilla) → punto libre. Es la misma precedencia que aplica AutoCAD.
   * `base` es el punto de partida del segmento en curso (para orto y polar).
   */
  snap(p, base = null) {
    const tol = 8 / this.scale;
    // 1. Referencia a objetos (F3): el vértice más cercano dentro de la apertura
    let best = null, bd = tol;
    if (this.prefs.referenciaObjetos) {
      for (const e of this.prj.entities) {
        if (e.type === 'image' || !e.points) continue;
        for (const q of e.points) {
          const d = Math.hypot(q.x - p.x, q.y - p.y);
          if (d < bd) { bd = d; best = { x: q.x, y: q.y, kind: 'vertex' }; }
        }
      }
    }
    // El forzado a rejilla respeta además el interruptor del proyecto (compatibilidad §10)
    const forzado = this.prefs.forzadoRejilla && (!this.prj.settings || this.prj.settings.snapEnabled !== false);
    const r = puntoForzado(p, { base, referencia: best, prefs: this.prefs, forzado });
    this._modoForzado = r.modo;
    // `kind` se mantiene para el resto del motor; `modo` dice exactamente qué forzado ha actuado
    return { x: r.x, y: r.y, kind: r.modo === 'referencia' ? 'vertex' : r.modo === 'libre' ? 'free' : 'grid', modo: r.modo };
  }

  /** Apertura de selección en píxeles: el tamaño de mira elegido por el usuario (§8). */
  get apertura() { return this.prefs.tamanoMira || 6; }

  /**
   * ¿La herramienta activa selecciona objetos? La del **lazo** (§8) es la de selección con otra
   * forma de arrastre, así que comparte con ella el hover, los tiradores y el arrastre de objetos.
   */
  get seleccionando() { return this.tool === 'select' || this.tool === 'lasso'; }

  hitTest(p, tol = null) {
    tol = tol === null ? Math.max(2, this.apertura) : tol;
    const t = tol / this.scale;
    let best = null, bd = t;
    for (let i = this.prj.entities.length - 1; i >= 0; i--) {
      const e = this.prj.entities[i];
      const layer = this.prj.layers.find((l) => l.id === e.layer);
      if (layer && layer.visible === false) continue;
      let d = Infinity;
      if (e.type === 'camera' || e.type === 'device') d = Math.hypot(e.points[0].x - p.x, e.points[0].y - p.y) - 0.15;
      else if (e.type === 'circle') d = Math.abs(Math.hypot(e.points[0].x - p.x, e.points[0].y - p.y) - (e.radius || 0));
      else if (e.type === 'text') d = Math.hypot(e.points[0].x - p.x, e.points[0].y - p.y) - 0.3;
      else if (e.type === 'rect') {
        const [a, b] = e.points;
        const c = [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }];
        for (let k = 0; k < 4; k++) d = Math.min(d, distPointSeg(p, c[k], c[(k + 1) % 4]));
      } else if (e.points.length > 1) {
        for (let k = 1; k < e.points.length; k++) d = Math.min(d, distPointSeg(p, e.points[k - 1], e.points[k]));
        if (e.closed && e.points.length > 2) d = Math.min(d, distPointSeg(p, e.points[e.points.length - 1], e.points[0]));
      }
      if (d < bd) { bd = d; best = e; }
    }
    // Con el ajuste «seleccionar por el cono», un clic **dentro de la huella de cobertura** de una
    // cámara la coge, aunque el símbolo quede lejos (§8, como propone el método de AutoCAD para
    // los objetos inteligentes). Es opcional: con decenas de conos solapados molestaría.
    if (!best && this.prefs.seleccionarPorCono) {
      for (let i = this.prj.entities.length - 1; i >= 0; i--) {
        const e = this.prj.entities[i];
        if (e.type !== 'camera') continue;
        const capa = this.prj.layers.find((l) => l.id === e.layer);
        if (capa && capa.visible === false) continue;
        if (this._huellasDe(e).some((h) => pointInPoly(p, h))) return e;
      }
    }
    return best;
  }

  selected() { return this.prj.entities.filter((e) => this.selection.has(e.id)); }

  /* ---------------------------- eventos ---------------------------- */
  /**
   * Ratón y teclado con la navegación de AutoCAD (§8):
   *   rueda ................ zoom sobre el cursor (con Ctrl o Mayús, zoom fino)
   *   rueda pulsada ........ desplazar la vista; doble pulsación, encuadrar todo
   *   botón derecho ........ menú contextual; arrastrando, desplazar la vista
   *   rueda hacia los lados . desplazar la vista en horizontal
   */
  _bind() {
    const c = this.canvas;
    c.addEventListener('mouseenter', () => { this._ratonDentro = true; this._cursorNativo(); this.draw(); });
    c.addEventListener('mouseleave', () => { this._ratonDentro = false; this.draw(); });
    const pos = (ev) => { const r = c.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };

    c.addEventListener('wheel', (ev) => {
      ev.preventDefault();
      const p = pos(ev);
      if (this.modo3d) {                                    // en 3D la rueda cambia la distancia
        const fino = ev.ctrlKey || ev.shiftKey;
        if (this.vistaCamara) {
          // Mirando desde una cámara no se puede acercar la posición: se estrecha el campo visual,
          // que es lo que haría el zoom de la óptica de verdad.
          const paso = (fino ? ev.deltaY / 8 : ev.deltaY) * (ev.deltaMode === 1 ? 16 : 1);
          this._zoomOptico = Math.max(0.25, Math.min(4, (this._zoomOptico || 1) * (1 - paso / 900)));
          this._raton = { x: p.x, y: p.y };
          this.draw();
          return;
        }
        zoom3d(this.cam3d, (fino ? ev.deltaY / 8 : ev.deltaY) * (ev.deltaMode === 1 ? 16 : 1));
        this._raton = { x: p.x, y: p.y };
        this.draw();
        return;
      }
      if (Math.abs(ev.deltaX) > Math.abs(ev.deltaY)) {      // rueda lateral: desplazar
        this.nav.paneo(-ev.deltaX, 0);
        this.draw(); return;
      }
      const fino = ev.ctrlKey || ev.shiftKey;
      const f = factorRueda(ev.deltaY, ev.deltaMode);
      this.zoomAt(fino ? 1 + (f - 1) / 8 : f, p.x, p.y);
      if (this._ventana) this.draw();
    }, { passive: false });

    c.addEventListener('mousedown', (ev) => {
      const p = pos(ev);
      const w = this.toWorld(p);
      this._ultimoCliente = { x: ev.clientX, y: ev.clientY };
      if (ev.button !== 2) this._cerrarMenu();
      const ahora = Date.now();
      this._mouseDown = { p, w, button: ev.button, shift: ev.shiftKey, movido: false, t: ahora };

      // Doble pulsación de la rueda (botón central): Zoom extensión, como en AutoCAD
      if (ev.button === 1 && this._r1 && ahora - this._r1 < 400) {
        this._r1 = 0; this._panning = false;
        this.zoomExtents();
        if (this.on.hint) this.on.hint('Zoom extensión (doble pulsación de la rueda).');
        return;
      }
      if (ev.button === 1) this._r1 = ahora;

      // Vista 3D al estilo AutoCAD (3DORBIT y 3DPAN):
      // - Botón central (rueda) o botón 2 (derecho): Encuadre 3D (pan / desplazamiento)
      // - Shift + Botón central (o Shift + botón izquierdo, o botón izquierdo): Órbita 3D (rotación continua)
      if (this.modo3d) {
        if (ev.button === 0 || ev.button === 1 || ev.button === 2) {
          const panear = ev.button === 1 ? !ev.shiftKey : (ev.button === 2 ? !ev.shiftKey : (ev.shiftKey || this.tool === 'pan'));
          this._orbitando = { x: ev.clientX, y: ev.clientY, panear, movido: false, boton: ev.button };
          c.style.cursor = 'grabbing';
          if (ev.button === 2) ev.preventDefault();
        }
        this.draw(); return;
      }

      // Zoom ventana en curso: el primer clic fija la esquina, el segundo encuadra
      if (this._ventana && ev.button === 0) {
        if (!this._ventana.a) this._ventana.a = p;
        else {
          const ok = this.nav.zoomVentana(this._ventana.a, p);
          this._ventana = null;
          if (this.on.hint) this.on.hint(ok ? 'Zoom ventana aplicado.' : 'Ventana demasiado pequeña: se mantiene la vista.');
        }
        this.draw(); return;
      }

      // Rueda pulsada, herramienta de desplazamiento o botón derecho: desplazar la vista
      if (ev.button === 1 || this.tool === 'pan' || ev.button === 2) {
        this._panning = true; this._panArrastrado = false;
        c.style.cursor = 'grabbing';
        if (ev.button === 2) ev.preventDefault();
        return;
      }
      // Un comando de edición en curso se come el clic: primero el punto base y luego el destino
      if (this._comando) { this._puntoComando(w); return; }
      if (this.seleccionando) {
        const agarre = this._tiradorCerca(p);
        if (agarre) {
          const e = this.prj.entities.find((x) => x.id === agarre.id);
          if (e) {
            this._agarre = { id: e.id, tirador: this._tiradorDe(e, agarre), copia: JSON.parse(JSON.stringify(e)) };
            // El deshacer se guarda al empezar el arrastre, no al terminar: así Ctrl+Z devuelve
            // el objeto a como estaba antes de tocarlo (§8).
            if (this.on.editStart) this.on.editStart();
            this.draw();
            return;
          }
        }
        const hit = this.hitTest(w);
        if (hit) {
          if (!this.selection.has(hit.id) && !ev.shiftKey) this.selection.clear();
          this.selection.add(hit.id);
          this._dragStart = w;
          this._dragOrigin = this.selected().map((e) => ({ e, pts: e.points.map((q) => ({ ...q })) }));
        } else {
          // Arrastrar sobre el vacío abre la marquesina. Con Mayús, lo que se coja se **añade**
          // a la selección que ya hubiera; sin Mayús, la sustituye (como en AutoCAD).
          // Las dos esquinas se guardan en **coordenadas del mundo**, no en píxeles: así el
          // rectángulo sigue pegado al dibujo si se hace zoom o se desplaza la vista a media
          // pulsación, que es lo que hace AutoCAD.
          if (!ev.shiftKey) this.selection.clear();
          // LAZO (tercer modo de AutoCAD: WPOLYGON / lazo por arrastre). Con la herramienta Lazo,
          // o con la de Seleccionar manteniendo **Alt**, el arrastre dibuja un polígono libre en
          // vez de un rectángulo. Igual que el rectángulo, va en coordenadas del mundo.
          if (this.tool === 'lasso' || (this.tool === 'select' && ev.altKey) || this.prefs.lazoAlArrastrar === true) {
            this._lazo = { pts: [w], suma: !!ev.shiftKey };
          } else {
            this._box = { a: w, b: w, suma: !!ev.shiftKey };
          }
        }
        if (this.on.select) this.on.select(this.selected());
      } else if (this.tool === 'measure') {
        this._measure = this._measure && this._measure.a && !this._measure.b ? { a: this._measure.a, b: w } : { a: w };
        if (this._measure.b && this.on.measure) this.on.measure(dist(this._measure.a, this._measure.b));
      } else if (this.tool === 'camera' || this.tool === 'device') {
        if (this._apunte) { this._fijarApunte(w); return; }
        if (this.on.place) this.on.place(this.tool, w);
        // Al colocar una cámara el programa se queda esperando la orientación: el cono sigue al
        // ratón y el siguiente clic (o un ángulo escrito) la fija. Esc la deja como estaba.
        if (this.tool === 'camera') {
          const e = this.selected().find((x) => x.type === 'camera');
          if (e) this._empezarApunte(e);
        }
      } else if (this.tool === 'text') {
        if (this.on.placeText) this.on.placeText(w);
      } else if (this.tool === 'room' || this.tool === 'pzona' || this.tool === 'mascara') {
        this._poly = this._poly || { pts: [] };
        this._poly.pts.push(this.snap(w, this._poly.pts[this._poly.pts.length - 1]));
      } else if (this.tool === 'obstacle') {
        this._puntoObstaculo(w);
      } else {
        const s = this.snap(w);
        if (this.tool === 'line' || this.tool === 'rect') {
          if (!this.draft) this.draft = { type: this.tool, points: [s, s] };
          else { this.draft.points[1] = s; if (this.on.draw) this.on.draw(this.draft); this.draft = null; }
        } else if (this.tool === 'circle') {
          if (!this.draft) this.draft = { type: 'circle', points: [s, s], radius: 0 };
          else { this.draft.radius = dist(this.draft.points[0], s); if (this.on.draw) this.on.draw(this.draft); this.draft = null; }
        } else if (this.tool === 'arc') {
          // Tres clics, como en AutoCAD: centro, punto de inicio (radio y ángulo) y punto final
          if (!this.draft) {
            this.draft = { type: 'arc', points: [s], radius: 0, startAngle: 0, endAngle: 0, fase: 'radio' };
          } else if (this.draft.fase === 'radio') {
            this.draft.radius = Math.max(0.01, dist(this.draft.points[0], s));
            this.draft.startAngle = anguloDeg(this.draft.points[0], s);
            this.draft.fase = 'fin';
          } else {
            this.draft.endAngle = anguloDeg(this.draft.points[0], s);
            if (this.on.draw) this.on.draw(this.draft);
            this.draft = null;
          }
        } else if (this.tool === 'polyline') {
          this._poly = this._poly || { pts: [] };
          this._poly.pts.push(s);
        }
      }
      this.draw();
    });

    c.addEventListener('mousemove', (ev) => {
      const p = pos(ev);
      const w = this.toWorld(p);
      this.cursor = w;
      this._raton = { x: p.x, y: p.y };
      this._ultimoCliente = { x: ev.clientX, y: ev.clientY };
      if (this.modo3d && this._orbitando) {
        const dx = ev.clientX - this._orbitando.x, dy = ev.clientY - this._orbitando.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) this._orbitando.movido = true;
        if (this.vistaCamara) {
          // Mirar alrededor desde el sitio de la cámara: se acumula el giro para poder volver
          this._mirada.az += dx * 0.25;
          this._mirada.tilt = Math.max(-20, Math.min(70, this._mirada.tilt + dy * 0.2));
          this._orbitando.x = ev.clientX; this._orbitando.y = ev.clientY;
          this.draw(); return;
        }
        const pan = this._orbitando.panear;
        orbitar(this.cam3d, dx, dy, { panear: pan, sensibilidad: pan ? 0.35 : 0.4 });
        this._orbitando.x = ev.clientX; this._orbitando.y = ev.clientY;
        this.draw(); return;
      }
      if (this._panning && this._mouseDown) {
        // Arrastrar cancela el menú contextual: el gesto es de desplazamiento, no de menú
        if (this._menu) this._cerrarMenu();
        const d = { x: p.x - this._mouseDown.p.x, y: p.y - this._mouseDown.p.y };
        // Un botón derecho que se mueve es un desplazamiento de vista, no un menú (como en AutoCAD)
        if (this._mouseDown.button === 2 && Math.abs(d.x) + Math.abs(d.y) > 4) this._panArrastrado = true;
        this.nav.paneo(d.x, d.y);
        this._mouseDown.p = p;
        this.draw(); return;
      }
      if (this._ventana) { this._ventana.b = p; this.draw(); return; }
      if (this._lazo) {
        // Se van tomando puntos del recorrido, pero solo cuando el ratón se ha movido lo bastante:
        // así el polígono no crece sin control (3 px en pantalla, como el umbral del rectángulo).
        const ult = this._lazo.pts[this._lazo.pts.length - 1];
        if (Math.hypot(p.x - this.sx(ult.x), p.y - this.sy(ult.y)) >= 3) { this._lazo.pts.push(w); this.draw(); }
        return;
      }
      if (this._box) { this._box.b = w; this.draw(); return; }
      if (this._dragStart && this._dragOrigin) {
        const dx = w.x - this._dragStart.x, dy = w.y - this._dragStart.y;
        for (const o of this._dragOrigin) o.e.points = o.pts.map((q) => ({ x: q.x + dx, y: q.y + dy }));
        this.draw(); return;
      }
      if (this._apunte) { this._moverApunte(w); return; }
      if (this._comando) { this._moverComando(w); return; }
      if (this._agarre) {
        const e = this.prj.entities.find((x) => x.id === this._agarre.id);
        if (!e) { this._agarre = null; }
        else {
          const base = this._baseTirador(e, this._agarre.tirador);
          const destino = this.snap(w, base);
          this._agarre.tirador = aplicarTirador(e, this._agarre.tirador, destino, { alcanceMango: this._mangoCamara() });
          this._etiquetaTirador = this._textoTirador(e, this._agarre.tirador, destino);
          if (this.on.editLive) this.on.editLive(e);
          this.draw(); return;
        }
      }
      this._tiradorHover = this.seleccionando && !this._box && !this._lazo ? this._tiradorCerca(p) : null;
      this.hover = this.seleccionando ? this.hitTest(w) : null;
      // El punto de partida para orto y polar es el primer punto del segmento en curso
      const base = this.draft ? this.draft.points[0] : (this._poly && this._poly.pts.length ? this._poly.pts[this._poly.pts.length - 1] : null);
      if (this.draft) this.draft.points[1] = this.snap(w, base);
      if (this.draft && this.draft.type === 'circle') this.draft.radius = dist(this.draft.points[0], this.snap(w, base));
      if (this.draft && this.draft.type === 'arc') {
        const s = this.snap(w, base);
        if (this.draft.fase === 'radio') {
          this.draft.radius = Math.max(0.01, dist(this.draft.points[0], s));
          this.draft.startAngle = anguloDeg(this.draft.points[0], s);
        } else {
          this.draft.endAngle = anguloDeg(this.draft.points[0], s);
        }
      }
      if (this._poly) this._poly.cursor = this.snap(w, base);
      this._snapPoint = this.snap(w, base);
      if (this.on.cursor) this.on.cursor(w, this.hover);
      this.draw();
    });

    window.addEventListener('mouseup', (ev) => {
      const botonDerecho = !!(ev && ev.button === 2);
      if (this._lazo) {
        const traza = this._lazo.pts.map((q) => ({ x: this.sx(q.x), y: this.sy(q.y) }));
        const c = bbox(traza);
        const px = Math.max(c.maxX - c.minX, c.maxY - c.minY);
        if (this._lazo.pts.length >= 3 && px > 3) {
          // Sentido **visto en pantalla**: antihorario → ventana (solo lo que cabe dentro);
          // horario → cruce (todo lo que toque). Es la regla del lazo de AutoCAD. Con la Y de la
          // pantalla hacia abajo, el área con signo sale positiva cuando el giro es horario a la vista.
          const horario = areaConSigno(traza) > 0;
          const modo = horario ? 'cruce' : 'ventana';
          const poli = simplify(this._lazo.pts, Math.max(1e-6, 1.5 / this.scale));
          if (!this._lazo.suma) this.selection.clear();
          for (const id of this._idsEnPoligono(poli, modo)) this.selection.add(id);
          if (this.on.hint) {
            this.on.hint(`Lazo (${horario ? 'cruce' : 'ventana'}): ${this.selection.size} objeto(s).`);
          }
        }
        if (this.on.select) this.on.select(this.selected());
        this._lazo = null;
      }
      if (this._box) {
        const bb = cajaDe2(this._box.a, this._box.b);
        // El rectángulo se guarda en metros: el tamaño en píxeles es el ancho por la escala
        const px = Math.max(Math.abs(bb.maxX - bb.minX), Math.abs(bb.maxY - bb.minY)) * this.scale;
        if (px > 3) {
          // Hacia la derecha: ventana (solo lo que cabe entero). Hacia la izquierda: cruce
          // (todo lo que toque). Con Mayús se añade a la selección en vez de sustituirla.
          const cruce = this._box.b.x < this._box.a.x;
          if (!this._box.suma) this.selection.clear();
          for (const id of this._idsEnCaja(bb, cruce ? 'cruce' : 'ventana')) this.selection.add(id);
        }
        if (this.on.select) this.on.select(this.selected());
        this._box = null;
      }
      if (this._dragOrigin && this.on.change) this.on.change('mover');
      if (this._agarre) {
        const e = this.prj.entities.find((x) => x.id === this._agarre.id);
        if (e && this.on.hint) this.on.hint('Objeto modificado: ' + resumenDe(e) + '.');
        this._agarre = null; this._etiquetaTirador = '';
        if (this.on.change) this.on.change('editar');
      }
      // En 3D, un clic sin arrastrar selecciona el elemento que hay debajo (para cambiar su altura)
      if (this._orbitando && !this._orbitando.movido) {
        const r = this.canvas.getBoundingClientRect();
        const id = this._pick3d(ev.clientX - r.left, ev.clientY - r.top);
        this.selection = id ? new Set([id]) : new Set();
        if (this.on.select) this.on.select(this.selected());
      }
      this._orbitando = null;
      this._dragOrigin = null; this._dragStart = null; this._panning = false;
      c.style.cursor = this.tool === 'pan' ? 'grab' : 'crosshair';
      // El menú del botón derecho se abre AL SOLTAR, y solo si el gesto no ha sido un arrastre.
      // Hace falta así porque en Linux el navegador manda `contextmenu` al pulsar: si se abriera
      // entonces, el menú se colocaría bajo el cursor y se comería el desplazamiento de la vista.
      if (botonDerecho && this._ctxPedido && !this._panArrastrado && !this._ventana) {
        const p = this._ultimoCliente || { x: ev.clientX, y: ev.clientY };
        this._abrirMenu(p.x, p.y);
      }
      this._ctxPedido = false;
      this._panArrastrado = false;
      this.draw();
    });

    c.addEventListener('dblclick', (ev) => {
      if (ev.button === 1) { this.zoomExtents(); return; }
      this._finishPoly();
    });

    /* Botón derecho: el navegador no debe abrir su menú; el nuestro se abre al soltar (§8) */
    c.addEventListener('contextmenu', (ev) => {
      ev.preventDefault();
      this._ctxPedido = true;
      this._ultimoCliente = { x: ev.clientX, y: ev.clientY };
    });

    window.addEventListener('keydown', (ev) => {
      const k = ev.key.toLowerCase();
      const ctrl = ev.ctrlKey || ev.metaKey;
      // Las cinco teclas de función de los forzados (F3, F7, F8, F9, F10) funcionan siempre, incluso
      // con el foco en un control del panel: en AutoCAD se conmutan sin dejar de escribir.
      if (k === 'f3' || k === 'f7' || k === 'f8' || k === 'f9' || k === 'f10') {
        ev.preventDefault();
        const clave = { f3: 'referenciaObjetos', f7: 'rejillaVisible', f8: 'orto', f9: 'forzadoRejilla', f10: 'polar' }[k];
        if (this.on.pref) this.on.pref(clave);
        return;
      }
      if (ev.target && /INPUT|TEXTAREA|SELECT/.test(ev.target.tagName)) return;
      // Si el usuario empieza a teclear números o medidas directamente en el lienzo (como en AutoCAD):
      const enDibujo = (this._poly && this._poly.pts && this._poly.pts.length > 0) || this.draft || this._comando || this._apunte;
      if (!ctrl && enDibujo && /^[0-9.,@<#-]$/.test(ev.key)) {
        const inp = document.getElementById('cmdValue');
        const box = document.getElementById('cmdbox');
        const lbl = document.getElementById('cmdLabel');
        if (inp && box) {
          box.hidden = false;
          if (lbl) {
            if (this._apunte) lbl.textContent = 'Azimut (°)';
            else if (this.tool === 'obstacle') lbl.textContent = 'Distancia / Medida de obstáculo (m)';
            else if (this.tool === 'line') lbl.textContent = 'Longitud de línea (m)';
            else if (this.tool === 'rect') lbl.textContent = 'Ancho,Alto (m)';
            else if (this.tool === 'circle') lbl.textContent = 'Radio (m)';
            else lbl.textContent = 'Distancia / Coordenadas';
          }
          inp.focus();
          inp.value = ev.key;
          ev.preventDefault();
          return;
        }
      }
            // Modo paseo en 3D (Walkthrough con W, A, S, D / Flechas):
      if (this.modo3d && !this.vistaCamara && !ctrl && /^[wasd]|arrowup|arrowdown|arrowleft|arrowright$/.test(k)) {
        const vel = ev.shiftKey ? 2.5 : 1.0;
        const azRad = (this.cam3d.azimut * Math.PI) / 180;
        const forward = { x: Math.sin(azRad), y: Math.cos(azRad) };
        const right = { x: Math.cos(azRad), y: -Math.sin(azRad) };
        let dx = 0, dy = 0;
        if (k === 'w' || k === 'arrowup') { dx += forward.x * vel; dy += forward.y * vel; }
        if (k === 's' || k === 'arrowdown') { dx -= forward.x * vel; dy -= forward.y * vel; }
        if (k === 'd' || k === 'arrowright') { dx += right.x * vel; dy += right.y * vel; }
        if (k === 'a' || k === 'arrowleft') { dx -= right.x * vel; dy -= right.y * vel; }
        this.cam3d.centro.x += dx;
        this.cam3d.centro.y += dy;
        this.draw();
        ev.preventDefault();
        return;
      }
if (k === 'escape') {
        // Si otra cosa está usando la tecla (el monitor en pantalla completa, por ejemplo), Esc
        // es suya: el plano no debe reaccionar a la misma pulsación que cierra esa ventana.
        if (this.on.escOcupado && this.on.escOcupado()) return;
        if (this.vistaCamara) { this.verDesdeCamara(null); return; }
        if (this._menu) { this._cerrarMenu(); return; }
        if (this._comando) {
          this._comando = null; this._fantasma = false;
          if (this.on.comando) this.on.comando(null);
          if (this.on.hint) this.on.hint('Comando cancelado.');
          this.draw(); return;
        }
        if (this._apunte) {
          this._cancelarApunte();
          // Cancelar la orientación termina la colocación: con la cámara ya puesta, Esc deja
          // también la herramienta en su sitio (Selección) en la misma pulsación.
          if (this.tool !== 'select') {
            if (this.on.setTool) this.on.setTool('select');
            else this.tool = 'select';
          }
          this.draw();
          return;
        }
        if (this._agarre) {
          const i = this.prj.entities.findIndex((x) => x.id === this._agarre.id);
          if (i >= 0) this.prj.entities[i] = this._agarre.copia;
          this._agarre = null; this._etiquetaTirador = '';
          if (this.on.hint) this.on.hint('Edición cancelada: el objeto vuelve a su sitio.');
          if (this.on.change) this.on.change('editar');
          this.draw(); return;
        }
        if (this._ventana) { this._ventana = null; if (this.on.hint) this.on.hint('Zoom ventana cancelado.'); this.draw(); return; }
        // Esc corta también la marquesina a medio arrastrar: se suelta el botón y no se coge nada
        if (this._box || this._lazo) { this._box = null; this._lazo = null; this.draw(); return; }
        // Aquí ya no queda nada en curso: Esc **devuelve la herramienta por defecto**, que es lo que
        // se espera al terminar de colocar una cámara, de cerrar un recinto o de medir. La selección
        // se conserva a propósito, para poder seguir ajustando en Propiedades lo que se acaba de
        // poner; una segunda pulsación, ya en Selección, es la que suelta lo seleccionado.
        this.draft = null; this._poly = null; this._measure = null;
        if (this.tool !== 'select') {
          if (this.toolKind) this.toolKind = null;
          if (this.on.setTool) this.on.setTool('select');
          else this.tool = 'select';
          this.draw();
          return;
        }
        this.selection.clear(); this.draw();
      }
      else if (k === 'enter') this._finishPoly();
      // Edición de objetos (§9): M mover, R girar, S escalar, E espejo. Van **antes** que los
      // atajos de vista porque con la herramienta Seleccionar y algo seleccionado, lo que se
      // espera es transformar el objeto. La «r» sigue siendo «vista anterior» cuando no hay
      // selección, que es el comportamiento que ya tenía el programa.
      else if (!ctrl && this.seleccionando && (k === 'm' || k === 's' || k === 'e' || (k === 'r' && this.selection.size))) {
        ev.preventDefault();
        const tipo = { m: 'mover', r: 'rotar', s: 'escalar', e: 'espejo' }[k];
        if (this.on.comandoEditar) this.on.comandoEditar(tipo);
      }
      else if (!ctrl && k === 'z') this.zoomExtents();
      else if (!ctrl && k === 'r') { if (!this.zoomAnterior() && this.on.hint) this.on.hint('No hay una vista anterior guardada.'); }
      else if (!ctrl && k === 'w') this.zoomVentana();
      else if (k === 'delete' || k === 'backspace') { if (this.on.delete && this.selection.size) { this.on.delete([...this.selection]); this.selection.clear(); } }
      else if (k === 'z' && ctrl) { ev.preventDefault(); if (this.on.undo) this.on.undo(ev.shiftKey); }
      else if (k === 'd' && ctrl) { ev.preventDefault(); if (this.on.duplicate) this.on.duplicate([...this.selection]); }
      else if (k === 'c' && ctrl) { ev.preventDefault(); if (this.on.portapapeles) this.on.portapapeles('copiar'); }
      else if (k === 'x' && ctrl) { ev.preventDefault(); if (this.on.portapapeles) this.on.portapapeles('cortar'); }
      else if (k === 'v' && ctrl) { ev.preventDefault(); if (this.on.portapapeles) this.on.portapapeles('pegar'); }
      else if (k === 'a' && ctrl) { ev.preventDefault(); this.selection = new Set(this.prj.entities.map((e) => e.id)); if (this.on.select) this.on.select(this.selected()); this.draw(); }
    });

    window.addEventListener('resize', () => { if (this._menu) this._cerrarMenu(); });
    window.addEventListener('blur', () => { if (this._menu) this._cerrarMenu(); });
  }

  /* ------------------------- menú del botón derecho ------------------------- */

  /** Estado que necesita el menú contextual (lo completa la aplicación desde `on.ctxEstado`). */
  _estadoMenu() {
    const extra = (this.on.ctxEstado && this.on.ctxEstado()) || {};
    return {
      seleccion: this.selection.size,
      hayVistas: this.nav.hayVistas,
      rejilla: this.prj && this.prj.settings ? this.prj.settings.gridVisible !== false : true,
      snap: this.prj && this.prj.settings ? this.prj.settings.snapEnabled !== false : true,
      capas: this.prj && this.prj.settings ? this.prj.settings.showCoverage !== false : true,
      ...extra };
  }

  /** Abre el menú contextual del botón derecho en las coordenadas del puntero. */
  _abrirMenu(cx, cy) {
    this._cerrarMenu();
    // Una sola cosa a la vez: el aviso flotante del lienzo se retira al abrir el menú
    if (this.on.menu) this.on.menu();
    const filas = menuContextual(this._estadoMenu());
    const div = document.createElement('div');
    div.className = 'ctxmenu';
    div.setAttribute('role', 'menu');
    for (const f of filas) {
      if (f.sep) { div.appendChild(document.createElement('hr')); continue; }
      const b = document.createElement('button');
      b.dataset.ctx = f.act;
      b.setAttribute('role', 'menuitem');
      if (f.disabled) b.disabled = true;
      if (f.danger) b.classList.add('danger');
      const marca = f.checked ? '✔' : '';
      b.innerHTML = `<span class="mk">${marca}</span><span class="lb">${f.label}</span>` + (f.key ? `<span class="ky">${f.key}</span>` : '');
      div.appendChild(b);
    }
    div.style.visibility = 'hidden';
    document.body.appendChild(div);
    // Posición medida de verdad: el menú nunca debe salirse de la pantalla ni tapar el borde
    const ancho = div.offsetWidth, alto = div.offsetHeight;
    div.style.left = Math.max(6, Math.min(cx, window.innerWidth - ancho - 6)) + 'px';
    div.style.top = Math.max(6, Math.min(cy, window.innerHeight - alto - 6)) + 'px';
    div.style.visibility = '';
    div.addEventListener('click', (ev) => {
      const b = ev.target.closest('button[data-ctx]');
      if (!b || b.disabled) return;
      const act = b.dataset.ctx;
      this._cerrarMenu();
      this._accionMenu(act);
    });
    this._menu = div;
    const cerrar = (ev) => {
      if (this._menu && ev.target.closest && ev.target.closest('.ctxmenu')) return;
      this._cerrarMenu();
    };
    setTimeout(() => { document.addEventListener('mousedown', cerrar, { once: true }); }, 0);
  }

  _cerrarMenu() {
    if (this._menu) { this._menu.remove(); this._menu = null; }
  }

  /** ¿Está el menú abierto? (lo usan las pruebas y la barra de estado) */
  get menuAbierto() { return !!this._menu; }

  _accionMenu(act) {
    // Lo que es puro movimiento de vista lo resuelve el propio motor CAD
    if (ACCIONES_VISTA.includes(act)) {
      if (act === 'zoom:ext') this.zoomExtents();
      else if (act === 'zoom:prev') { if (!this.zoomAnterior() && this.on.hint) this.on.hint('No hay una vista anterior guardada.'); }
      else if (act === 'zoom:ventana') this.zoomVentana();
      else if (act === 'zoom:real') this.zoomReal();
      return;
    }
    if (this.on.ctx) this.on.ctx(act);
  }

  /** Marco del zoom ventana en curso. */
  _ventanaDraw() {
    if (!this._ventana) return;
    const a = this._ventana.a, b = this._ventana.b;
    const ctx = this.ctx;
    if (!a) {
      ctx.fillStyle = '#facc15'; ctx.font = '11px system-ui';
      ctx.fillText('Zoom ventana: señale la primera esquina (Esc cancela)', 12, 18);
      return;
    }
    if (!b) return;
    ctx.strokeStyle = this.prefs.colorVentana; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.2;
    ctx.strokeRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
    ctx.setLineDash([]);
  }

  _finishPoly() {
    if (this._poly && this._poly.pts.length > 1 && this.on.draw) {
      if (this.tool === 'obstacle') {
        // Una cadena que vuelve al punto de partida se cierra sola (como una polilínea de AutoCAD)
        const pts = this._poly.pts;
        const cierra = dist(pts[0], pts[pts.length - 1]) < Math.max(0.05, this.prefs.pasoRejilla * 0.6);
        this.on.draw({ type: 'obstacle', kind: this.toolKind, points: cierra ? pts.slice(0, -1) : pts, closed: cierra });
      } else {
        // Zona, zona de privacidad y máscara son recintos cerrados; la polilínea no se cierra
        const tipo = this.tool === 'polyline' ? 'polyline' : this.tool;
        this.on.draw({ type: tipo, points: this._poly.pts, closed: tipo !== 'polyline' });
      }
    }
    this._poly = null; this.draft = null;
    this.draw();
  }

  /* --------------------- obstáculos y elementos en altura (§9) --------------------- */

  /**
   * Un clic de la herramienta de obstáculos. La geometría que se pide depende de lo que sea el
   * elemento (§9): un árbol es un punto, una puerta un tramo, un muro una cadena de vértices y el
   * mobiliario un rectángulo.
   */
  _puntoObstaculo(w) {
    const def = obstaculoDe(this.toolKind);
    if (!def) return;
    const ultimo = this._poly && this._poly.pts.length ? this._poly.pts[this._poly.pts.length - 1] : null;
    const s = this.snap(w, ultimo);
    if (def.dibujo === 'punto') {
      if (this.on.draw) this.on.draw({ type: 'obstacle', kind: def.id, points: [s] });
      return;
    }
    if (def.dibujo === 'segmento') {
      if (!this.draft) this.draft = { type: 'obstacle', kind: def.id, points: [s, s] };
      else { this.draft.points[1] = s; if (this.on.draw) this.on.draw(this.draft); this.draft = null; }
      return;
    }
    if (def.dibujo === 'rectangulo') {
      if (!this.draft) this.draft = { type: 'obstacle', kind: def.id, points: [s, s], rect: true };
      else {
        const a = this.draft.points[0], b = s;
        const pts = [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }];
        if (this.on.draw) this.on.draw({ type: 'obstacle', kind: def.id, points: pts, closed: true });
        this.draft = null;
      }
      return;
    }
    // Muros y cercas: vértices sucesivos, como una polilínea
    this._poly = this._poly || { pts: [] };
    this._poly.pts.push(s);
  }

  /** Activa la herramienta de obstáculos para un tipo concreto (muro, puerta, árbol…). */
  setObstacleTool(kind) {
    const def = obstaculoDe(kind);
    if (!def) return null;
    if (this.modo3d) this.setModo3d(false);
    this.tool = 'obstacle';
    this.toolKind = def.id;
    this.draft = null; this._poly = null;
    this._cursorNativo();
    if (this.on.hint) this.on.hint(`«${def.etiqueta}»: ${AYUDA_DIBUJO[def.dibujo]} ${def.descripcion}`);
    this.draw();
    return def;
  }

  /** Altura con la que se extruye una entidad en la vista 3D (muros del plano incluidos). */
  alturaDe(e) {
    return datosDe(e).altura;
  }

  /* --------------------------------- vista 3D (§8) --------------------------------- */

  /** Entra o sale de la vista 3D. Al entrar, la vista se encuadra sola la primera vez. */
  setModo3d(on) {
    this.modo3d = !!on;
    if (this.modo3d) {
      if (!this._visto3d) {
        encuadrarEscena(this.cam3d, this.prj, (this.prj.settings && this.prj.settings.alturaMuro) || 2.8);
        this._visto3d = true;
      }
    } else {
      this._orbitando = null;
      this.vistaCamara = null;
    }
    this._cursorNativo();
    this.draw();
    return this.modo3d;
  }

  /** Opciones de la vista 3D (haces, translucidez de los muros, retícula…). */
  setOpciones3d(o) {
    this.opciones3d = Object.assign({}, this.opciones3d, o || {});
    this._escena3dKey = '';
    this.draw();
    return this.opciones3d;
  }

  /** Aplica una vista predefinida (isométrica, cenital, desde el norte…). */
  setVista3d(id) {
    aplicarVista(this.cam3d, id);
    this.draw();
    return this.cam3d;
  }

  /**
   * Ver la escena **desde una cámara del proyecto** (§8): el ojo se pone en su posición de montaje y
   * mira con su azimut, su inclinación y el campo visual de su lente. Es la manera de comprobar de
   * verdad qué va a verse antes de instalar nada. Con `null` se vuelve a la vista orbital.
   */
  verDesdeCamara(id) {
    if (!id) {
      this.vistaCamara = null; this._mirada = { az: 0, tilt: 0 }; this._zoomOptico = 1;
      if (this.on.hint) this.on.hint('Vista orbital: se vuelve a mirar el proyecto desde fuera.');
      this.draw();
      return null;
    }
    const cam = this.prj.entities.find((e) => e.id === id && e.type === 'camera');
    if (!cam) {
      if (this.on.hint) this.on.hint('Esa cámara ya no está en el proyecto.');
      return null;
    }
    if (!this.modo3d) this.setModo3d(true);
    this.vistaCamara = id; this._mirada = { az: 0, tilt: 0 }; this._zoomOptico = 1;
    const nombre = (cam.data && (cam.data.name || cam.data.nombre)) || 'la cámara';
    if (this.on.hint) {
      this.on.hint(`Vista desde ${nombre}: arrastre para mirar alrededor, rueda para el zoom óptico, Esc para volver.`);
    }
    this.draw();
    return id;
  }

  /** Cámara con la que se está pintando: la orbital, o la vista desde una cámara del proyecto. */
  _camara3dActiva() {
    if (!this.vistaCamara) return this.cam3d;
    const cam = this.prj.entities.find((e) => e.id === this.vistaCamara && e.type === 'camera');
    if (!cam) { this.vistaCamara = null; return this.cam3d; }
    const data = cam.data || {};
    // Mirar alrededor acumula el giro **de la vista**, sin tocar los datos de la cámara
    const girada = {
      ...cam,
      data: {
        ...data,
        azimuth: (Number(data.azimuth) || 0) + (this._mirada ? this._mirada.az : 0),
        tilt: Math.max(-20, Math.min(89, (Number(data.tilt) || 0) + (this._mirada ? this._mirada.tilt : 0))) } };
    const c = camaraDesdeVigilancia(girada, this.prj.catalog, this.prj.rules, 12);
    const z = this._zoomOptico || 1;                     // la rueda estrecha el campo, como un zoom
    c.fov = Math.max(4, Math.min(120, c.fov / z));
    return c;
  }

  /** Datos para el rótulo de la vista desde cámara. */
  _datosVistaCamara() {
    const cam = this.prj.entities.find((e) => e.id === this.vistaCamara && e.type === 'camera');
    if (!cam) return null;
    const data = cam.data || {};
    const item = getItem(this.prj.catalog, data.catalogId);
    const fov = fieldOfView(item, Number(data.focal) || undefined);
    let alcance = 0;
    try {
      const fp = footprint(cam, this.prj.catalog, this.prj.rules || {}, {});
      alcance = fp.far || 0;
    } catch { alcance = 0; }
    return {
      nombre: data.name || data.nombre || 'Cámara',
      modelo: (item && (item.model || item.nombre)) || '',
      lente: Number(data.focal) || (item && item.specs && item.specs.lens) || 0,
      altura: Number(data.height) || 2.8,
      azimut: (Number(data.azimuth) || 0) + (this._mirada ? this._mirada.az : 0),
      inclinacion: (Number(data.tilt) || 0) + (this._mirada ? this._mirada.tilt : 0),
      fov: this._camara3dActiva().fov,
      alcance,
      vfovBase: fov.vfov };
  }

  /** Vuelve a encuadrar el proyecto en 3D. */
  encuadrar3d() {
    encuadrarEscena(this.cam3d, this.prj, (this.prj.settings && this.prj.settings.alturaMuro) || 2.8);
    this._visto3d = true;
    this.draw();
  }

  /** La escena se reconstruye solo cuando cambia algo: es lo que permite ir fino sin GPU (§36). */
  _escena() {
    const clave = [
      this.prj.entities.length, this.prj.entities.length ? this.prj.entities[this.prj.entities.length - 1].id : '',
      this.prj.settings.alturaMuro || '', this.opciones3d.mostrarHaz ? 1 : 0, this.opciones3d.mostrarPersona ? 1 : 0,
      this.opciones3d.sombras ? 1 : 0, this.opciones3d.ocultarTechos ? 1 : 0,
      this.opciones3d.contactos ? 1 : 0, this.vistaCamara || '',
      this.opciones3d.penumbra ? 1 : 0, this.opciones3d.rotulosCamaras ? 1 : 0,
      this.opciones3d.nombresEstancias ? 1 : 0,
      this.opciones3d.atenuarHaz ? 1 : 0, this.opciones3d.soporteCamara ? 1 : 0,
      this.opciones3d.degradadoHaz ? 1 : 0, this.opciones3d.sombraHaz ? 1 : 0,
      this.opciones3d.formasCamara ? 1 : 0,
      this.prj.rules ? JSON.stringify(this.prj.rules).length : 0,
    ].join('|');
    if (!this._escena3d || clave !== this._escena3dKey) {
      this._escena3d = construirEscena(this.prj, this.prj.catalog, this.prj.rules || {}, this.opciones3d);
      this._escena3dKey = clave;
    }
    return this._escena3d;
  }

  _paint3d() {
    const ctx = this.ctx;
    const q = this.prefs;
    const escena = this._escena();
    pintar3d(ctx, escena, this._camara3dActiva(), {
      w: this.w, h: this.h,
      fondo: q.fondo, rejilla: this.opciones3d.rejilla,
      colorRejilla: q.colorRejilla, colorEjes: q.colorEjes,
      colorTexto: q.colorCruz,
      seleccion: this.selection,
      opacidadMuros: this.opciones3d.opacidadMuros,
      referenciaAltura: this.opciones3d.referenciaAltura,
      sombras: this.opciones3d.sombras, niebla: this.opciones3d.niebla,
      ocultarTechos: this.opciones3d.ocultarTechos, rotulosSuelo: this.opciones3d.rotulosSuelo,
      contactos: this.opciones3d.contactos, aristas: this.opciones3d.aristas,
      suelo: this.opciones3d.suelo, degradado: this.opciones3d.degradado,
      materiales: this.opciones3d.materiales, penumbra: this.opciones3d.penumbra,
      rotulosCamaras: this.opciones3d.rotulosCamaras, norte: this.opciones3d.norte,
      cielo: this.opciones3d.cielo, juntas: this.opciones3d.juntas,
      escalaGrafica: this.opciones3d.escalaGrafica, nombresEstancias: this.opciones3d.nombresEstancias,
      atenuarHaz: this.opciones3d.atenuarHaz, soporteCamara: this.opciones3d.soporteCamara,
      zocalo: this.opciones3d.zocalo,
      degradadoHaz: this.opciones3d.degradadoHaz, sombraHaz: this.opciones3d.sombraHaz,
      formasCamara: this.opciones3d.formasCamara,
      desdeCamara: this.vistaCamara ? this._datosVistaCamara() : null });
    if (q.tipoPuntero !== 'flecha' && this._ratonDentro) this._cursor();
    this._etiqueta3d(escena);
  }

  /** Rótulo con la altura de la cámara de vista y el modo, para no perder el norte. */
  _etiqueta3d(escena) {
    const ctx = this.ctx;
    ctx.save();
    ctx.font = '11px system-ui, sans-serif';
    ctx.fillStyle = this.prefs.colorCruz;
    ctx.globalAlpha = 0.75;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    const vista = this._camara3dActiva();
    const texto = this.vistaCamara
      ? `3D · vista desde cámara · ${Math.round(vista.fov)}° de campo · muros ${(escena.alturaMuro || 0).toFixed(2)} m`
      : `3D · ${Math.round(vista.azimut)}° / ${Math.round(vista.elevacion)}° · ${vista.distancia.toFixed(0)} m · muros ${(escena.alturaMuro || 0).toFixed(2)} m`;
    ctx.fillText(texto, 10, 8);
    ctx.restore();
  }

  /**
   * Selección en 3D: se elige el volumen cuyo centro cae más cerca del clic (a menos de 24 px).
   * Es una aproximación suficiente para seleccionar un muro o un obstáculo y cambiarle la altura.
   */
  _pick3d(px, py) {
    const escena = this._escena();
    let mejor = null, mejorD = 24;
    for (const e of this.prj.entities) {
      const pts = (e.points || []).filter(Boolean);
      if (!pts.length) continue;
      let cx = 0, cy = 0;
      for (const p of pts) { cx += p.x; cy += p.y; }
      cx /= pts.length; cy /= pts.length;
      const d = datosDe(e);
      const s = proyectarPunto3d({ x: cx, y: cy, z: d.base + d.altura / 2 }, this.cam3d, this.w, this.h);
      if (s.detras) continue;
      const dd = Math.hypot(s.x - px, s.y - py);
      if (dd < mejorD) { mejorD = dd; mejor = e.id; }
    }
    return mejor;
  }

  measure() {
    if (!this._measure || !this._measure.a || !this._measure.b) return 0;
    return dist(this._measure.a, this._measure.b);
  }

  /* ---------------------------- dibujo ---------------------------- */
  draw() {
    if (!this.prj) return;
    if (this._raf) cancelAnimationFrame(this._raf);
    this._raf = requestAnimationFrame(() => this._paint());
  }

  _paint() {
    if (this.modo3d) return this._paint3d();
    const ctx = this.ctx;
    const q = this.prefs;
    // Colores del espacio de trabajo, configurables como en AutoCAD (Opciones → Visual → Colores)
    ctx.fillStyle = q.fondo;
    ctx.fillRect(0, 0, this.w, this.h);
    const rejilla = q.rejillaVisible !== undefined ? q.rejillaVisible : this.prj.settings.gridVisible !== false;
    if (rejilla) this._grid();
    if (this.prj.settings.showCoverage !== false && this.on.coverageData) this._coverage(this.on.coverageData());
    if (this.prj.settings.showRoutes !== false) this._cables();
    for (const layer of this.prj.layers) {
      if (layer.visible === false) continue;
      for (const e of this.prj.entities) {
        if (e.layer !== layer.id) continue;
        // El plano importado se puede atenuar para distinguirlo de lo dibujado aquí (§9)
        const atenuada = this._atenuarPlano && this._planoIds && this._planoIds.has(e.id);
        this._entity(e, atenuada ? LAYER_ATENUADA : layer);
      }
    }
    this._draft();
    this._selection();
    this._marquesina();
    this._lazoDibujo();
    this._pintarComando();
    this._pintarApunte();
    this._measureDraw();
    this._ventanaDraw();
    if (q.iconoEjes) this._iconoEjes();
    this._cursor();          // el puntero va siempre encima de todo, como en AutoCAD
  }

  /* --------------------- puntero configurable (§8) --------------------- */

  /**
   * Puntero del espacio de trabajo: cruz de tamaño y color elegidos, mira de selección (pickbox)
   * en el centro, coordenadas y modo de forzado al lado, y marca de referencia cuando el cursor se
   * engancha a un vértice. Es el puntero de AutoCAD, adaptado a un lienzo.
   */
  _cursor() {
    const q = this.prefs;
    if (q.tipoPuntero === 'flecha' || this.tool === 'pan' || !this._ratonDentro) return;
    const ctx = this.ctx;
    // La cruz se dibuja en coordenadas enteras y con medio píxel de desplazamiento: así las líneas
    // de 1 px salen nítidas (sin suavizado) y el puntero se ve como el de AutoCAD, no borroso.
    const x = Math.round(this._raton.x) + 0.5, y = Math.round(this._raton.y) + 0.5;
    const conMira = q.tipoPuntero === 'cruz_mira';
    const mira = cajaMira(x, y, conMira ? Math.max(2, Math.round(q.tamanoMira)) : 0);
    const arm = tamanoCruzPx(q.tamanoCruz, this.w, this.h);
    const hueco = conMira ? Math.max(3, mira.lado / 2 + 1) : 0;

    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = q.colorCruz;
    ctx.beginPath();
    // Las líneas se cortan en la mira: es lo que hace que se vea el cuadrado central
    ctx.moveTo(x - arm, y); ctx.lineTo(x - hueco, y);
    ctx.moveTo(x + hueco, y); ctx.lineTo(x + arm, y);
    ctx.moveTo(x, y - arm); ctx.lineTo(x, y - hueco);
    ctx.moveTo(x, y + hueco); ctx.lineTo(x, y + arm);
    ctx.stroke();

    if (conMira && mira.lado > 0) {
      ctx.strokeStyle = q.colorMira;
      ctx.strokeRect(mira.x, mira.y, mira.lado, mira.lado);
    }

    // Marca de referencia: cuadrado amarillo en el vértice enganchado (AutoCAD: marcador de osnap)
    const sp = this._snapPoint;
    if (sp && this._modoForzado === 'referencia' && sp.kind === 'vertex') {
      const sx = this.sx(sp.x), sy = this.sy(sp.y);
      ctx.strokeStyle = q.colorReferencia;
      ctx.lineWidth = 1.6;
      ctx.strokeRect(sx - 5.5, sy - 5.5, 11, 11);
      ctx.beginPath();
      ctx.moveTo(sx - 11, sy); ctx.lineTo(sx - 6, sy); ctx.moveTo(sx + 6, sy); ctx.lineTo(sx + 11, sy);
      ctx.moveTo(sx, sy - 11); ctx.lineTo(sx, sy - 6); ctx.moveTo(sx, sy + 6); ctx.lineTo(sx, sy + 11);
      ctx.stroke();
    }

    // Coordenadas y modo de forzado junto al cursor (entrada dinámica de AutoCAD)
    if (q.marcasJuntoCursor) {
      const mundo = this.toWorld({ x: this._raton.x, y: this._raton.y });
      const etiqueta = [coordenadasTexto(this._modoForzado === 'referencia' && sp ? sp : mundo),
        ETIQUETA_FORZADO[this._modoForzado] || ''].filter(Boolean).join('  ·  ');
      ctx.font = '11px system-ui, sans-serif';
      const ancho = ctx.measureText(etiqueta).width + 10;
      const px = Math.min(Math.max(6, x + 14), this.w - ancho - 6);
      const py = Math.min(Math.max(6, y + 16), this.h - 22);
      ctx.fillStyle = 'rgba(8, 11, 16, 0.72)';
      ctx.fillRect(px, py, ancho, 17);
      ctx.strokeStyle = 'rgba(219, 228, 238, 0.18)';
      ctx.strokeRect(px + 0.5, py + 0.5, ancho - 1, 16);
      ctx.fillStyle = q.colorCruz;
      ctx.fillText(etiqueta, px + 5, py + 12);
    }
    ctx.restore();
  }

  /** Icono de ejes del origen, como el icono del SCP (UCS) de AutoCAD. */
  _iconoEjes() {
    const q = this.prefs;
    const ctx = this.ctx;
    const dentro = 0 >= 0 && 0 <= this.w && this.sy(0) >= 0 && this.sy(0) <= this.h && this.sx(0) >= 0 && this.sx(0) <= this.w;
    const ox = dentro ? this.sx(0) : 26;
    const oy = dentro ? this.sy(0) : this.h - 26;
    if (!dentro && !q.iconoEsquina) return;
    const l = 22;
    ctx.save();
    ctx.strokeStyle = q.colorEjes;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ox, oy); ctx.lineTo(ox + l, oy);
    ctx.moveTo(ox, oy); ctx.lineTo(ox, oy - l);
    ctx.stroke();
    ctx.fillStyle = q.colorEjes;
    ctx.font = '10px system-ui, sans-serif';
    ctx.fillText('X', ox + l + 2, oy + 3);
    ctx.fillText('Y', ox - 3, oy - l - 3);
    ctx.fillStyle = 'rgba(143, 163, 184, 0.35)';
    ctx.fillRect(ox - 3, oy - 3, 6, 6);
    ctx.restore();
  }

  _grid() {
    const ctx = this.ctx;
    let step = this.gridStep || 1;
    while (step * this.scale < 12) step *= 5;
    while (step * this.scale > 220) step /= 5;
    const x0 = Math.floor(this.wx(0) / step) * step, x1 = this.wx(this.w);
    const y0 = Math.floor(this.wy(this.h) / step) * step, y1 = this.wy(0);
    ctx.strokeStyle = this.prefs.colorRejilla; ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = x0; x <= x1; x += step) { const s = this.sx(x); ctx.moveTo(s, 0); ctx.lineTo(s, this.h); }
    for (let y = y0; y <= y1; y += step) { const s = this.sy(y); ctx.moveTo(0, s); ctx.lineTo(this.w, s); }
    ctx.stroke();
    ctx.strokeStyle = this.prefs.colorEjes;
    ctx.beginPath();
    const o = this.sx(0); const oy = this.sy(0);
    ctx.moveTo(o, 0); ctx.lineTo(o, this.h); ctx.moveTo(0, oy); ctx.lineTo(this.w, oy);
    ctx.stroke();
  }

  _coverage(res) {
    if (!res || res.empty || !res.count) return;
    const key = res._key || (res.cols + 'x' + res.rows + ':' + (res.cameras || []).length);
    if (this._heatKey !== key) {
      const img = new ImageData(res.cols, res.rows);
      for (let i = 0; i < res.count.length; i++) {
        const c = res.count[i], o = i * 4;
        if (!res.inside[i]) continue;
        if (c === 0) { img.data[o] = 220; img.data[o + 1] = 60; img.data[o + 2] = 60; img.data[o + 3] = 70; }
        else if (c === 1) { img.data[o] = 46; img.data[o + 1] = 200; img.data[o + 2] = 120; img.data[o + 3] = 70; }
        else { img.data[o] = 255; img.data[o + 1] = 190; img.data[o + 2] = 60; img.data[o + 3] = 80; }
      }
      const c = document.createElement('canvas');
      c.width = res.cols; c.height = res.rows;
      c.getContext('2d').putImageData(img, 0, 0);
      this._heat = c; this._heatKey = key;
    }
    const ctx = this.ctx;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.globalAlpha = 0.55;
    const x = this.sx(res.bb.minX), y = this.sy(res.bb.minY + res.rows * res.cell);
    ctx.drawImage(this._heat, x, y, res.cols * res.cell * this.scale, res.rows * res.cell * this.scale);
    ctx.restore();
  }

  _cables() {
    const ctx = this.ctx;
    for (const e of this.prj.entities) {
      if (e.type !== 'cable') continue;
      const col = e.data.distanceStatus === 'EXCESIVA' ? '#ff5470' : e.data.distanceStatus === 'PROXIMA' ? '#ffb020' : '#3b82f6';
      ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.setLineDash([6, 4]);
      ctx.beginPath();
      e.points.forEach((p, i) => (i ? ctx.lineTo(this.sx(p.x), this.sy(p.y)) : ctx.moveTo(this.sx(p.x), this.sy(p.y))));
      ctx.stroke(); ctx.setLineDash([]);
    }
  }

  _entity(e, layer) {
    const ctx = this.ctx;
    // El color del propio elemento (un plano importado lo trae por entidad) manda sobre el de la capa
    let color = (e.data && e.data.color) || layer.color || '#888';
    // Vista previa de un comando (MOVER, GIRAR, ESCALAR…): se dibuja en cian y en discontinuo
    if (this._fantasma) { color = '#7dd3fc'; ctx.setLineDash([5, 4]); }
    // Resaltado del objeto bajo el cursor, si el usuario lo tiene activo (§8)
    const resaltado = this.prefs.resaltarAlPasar && this.hover && this.hover.id === e.id && !this.selection.has(e.id);
    if (resaltado) color = this.prefs.colorResaltado;
    ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 1.3;
    switch (e.type) {
      case 'line':
        if (e.points.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(this.sx(e.points[0].x), this.sy(e.points[0].y));
        ctx.lineTo(this.sx(e.points[1].x), this.sy(e.points[1].y));
        ctx.stroke();
        break;
      case 'polyline': case 'cable': case 'room':
        if (e.points.length < 2) return;
        // El cableado analógico (coaxial o UTP con balún) se distingue del IP en el plano (§38)
        if (e.type === 'cable' && e.data && e.data.analog) { ctx.strokeStyle = '#e0a75e'; ctx.setLineDash([6, 3]); }
        if (e.type === 'room') { ctx.fillStyle = (e.data.critical ? '#f2a33c' : '#2f6f4f') + '18'; ctx.globalAlpha = 0.9; }
        ctx.beginPath();
        e.points.forEach((p, i) => (i ? ctx.lineTo(this.sx(p.x), this.sy(p.y)) : ctx.moveTo(this.sx(p.x), this.sy(p.y))));
        if (e.closed) ctx.closePath();
        if (e.type === 'room') ctx.fill();
        // Sombreados importados de un plano (§9): se rellenan con suavidad para reconocerlos
        if (e.data && e.data.kind === 'hatch' && this.prj.settings.showHatch !== false) {
          ctx.save(); ctx.fillStyle = (color || '#8fa3b8') + '1c'; ctx.fill(); ctx.restore();
        }
        ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
        if (e.type === 'room' && this.prj.settings.showLabels !== false) {
          const c = { x: e.points.reduce((a, p) => a + p.x, 0) / e.points.length, y: e.points.reduce((a, p) => a + p.y, 0) / e.points.length };
          ctx.fillStyle = '#9fb0c0'; ctx.font = '10px system-ui';
          ctx.fillText((e.data.name || '') + (e.data.critical ? ' ★' : ''), this.sx(c.x) - 20, this.sy(c.y));
        }
        break;
      case 'pzona': case 'mascara': {
        if (e.points.length < 2) return;
        const esZona = e.type === 'pzona';
        const clase = (e.data && e.data.clase) || 'PUBLICA';
        const col = esZona
          ? ({ PUBLICA: '#e11d48', TERCEROS: '#f59e0b', SENSIBLE: '#9333ea', PROPIA: '#0ea5e9' })[clase] || '#e11d48'
          : '#0f172a';
        ctx.save();
        ctx.beginPath();
        e.points.forEach((p, i) => (i ? ctx.lineTo(this.sx(p.x), this.sy(p.y)) : ctx.moveTo(this.sx(p.x), this.sy(p.y))));
        ctx.closePath();
        if (esZona) { ctx.fillStyle = col + '1f'; ctx.fill(); }
        else {
          // La máscara se reconoce por su trama de rayado: es lo que la cámara NO graba
          const c = e.points.reduce((a, p) => ({ x: a.x + p.x / e.points.length, y: a.y + p.y / e.points.length }), { x: 0, y: 0 });
          const r = Math.max(...e.points.map((p) => Math.hypot(p.x - c.x, p.y - c.y))) * this.scale;
          ctx.fillStyle = '#0f172a12'; ctx.fill();
          ctx.strokeStyle = col; ctx.lineWidth = 1.1; ctx.setLineDash([]);
          for (let d = -r * 2; d < r * 2; d += 6) {
            ctx.beginPath();
            ctx.moveTo(this.sx(c.x) + d, this.sy(c.y) - r);
            ctx.lineTo(this.sx(c.x) + d + r * 2, this.sy(c.y) + r);
            ctx.stroke();
          }
        }
        ctx.restore();
        ctx.strokeStyle = col; ctx.lineWidth = 1.4; ctx.setLineDash(esZona ? [] : [5, 3]);
        ctx.beginPath();
        e.points.forEach((p, i) => (i ? ctx.lineTo(this.sx(p.x), this.sy(p.y)) : ctx.moveTo(this.sx(p.x), this.sy(p.y))));
        ctx.closePath();
        ctx.stroke(); ctx.setLineDash([]);
        if (this.prj.settings.showLabels !== false && this.prj.settings.showPrivacy !== false) {
          const c = { x: e.points.reduce((a, p) => a + p.x, 0) / e.points.length, y: e.points.reduce((a, p) => a + p.y, 0) / e.points.length };
          ctx.fillStyle = col; ctx.font = '10px system-ui';
          const txt = esZona ? (e.data.nombre || 'Zona') + ` · ${({ PUBLICA: 'vía pública', TERCEROS: 'terceros', SENSIBLE: 'intimidad', PROPIA: 'propia' })[clase] || clase}`
            : `▨ ${(e.data.camara ? (this.prj.entities.find((x) => x.id === e.data.camara) || { data: {} }).data.label : null) || 'todas'}`;
          ctx.fillText(txt, this.sx(c.x) - 22, this.sy(c.y));
        }
        break;
      }
      case 'rect': {
        const [a, b] = e.points;
        ctx.strokeRect(this.sx(Math.min(a.x, b.x)), this.sy(Math.max(a.y, b.y)), Math.abs(b.x - a.x) * this.scale, Math.abs(b.y - a.y) * this.scale);
        break;
      }
      case 'circle':
        ctx.beginPath(); ctx.arc(this.sx(e.points[0].x), this.sy(e.points[0].y), (e.radius || 0) * this.scale, 0, Math.PI * 2); ctx.stroke();
        break;
      case 'arc':
        ctx.beginPath();
        ctx.arc(this.sx(e.points[0].x), this.sy(e.points[0].y), (e.radius || 0) * this.scale, -rad(e.endAngle || 0), -rad(e.startAngle || 0));
        ctx.stroke();
        break;
      case 'text':
        ctx.fillStyle = color;
        ctx.font = `${Math.max(9, Math.min(40, (e.data.height || 0.3) * this.scale))}px system-ui`;
        if (e.data.rotacion) {
          ctx.save();
          ctx.translate(this.sx(e.points[0].x), this.sy(e.points[0].y));
          ctx.rotate(-rad(e.data.rotacion));
          ctx.fillText(e.data.text || '', 0, 0);
          ctx.restore();
        } else {
          ctx.fillText(e.data.text || '', this.sx(e.points[0].x), this.sy(e.points[0].y));
        }
        break;
      case 'obstacle': this._obstacleGlyph(e, color); break;
      case 'camera': this._cameraGlyph(e); break;
      case 'device': this._deviceGlyph(e); break;
      case 'image': {
        const img = this._images && this._images[e.id];
        if (img) {
          const w = (e.data.width || 10), h = (e.data.heightM || w * (img.height / img.width));
          ctx.globalAlpha = e.data.opacity === undefined ? 0.5 : e.data.opacity;
          ctx.drawImage(img, this.sx(e.points[0].x), this.sy(e.points[0].y + h), w * this.scale, h * this.scale);
          ctx.globalAlpha = 1;
        }
        break;
      }
    }
  }

  /**
   * Dibujo en planta de un obstáculo (§9). Los muros van con su espesor real, los huecos (puerta,
   * ventana) con su símbolo, los elementos de punto con su radio y los muebles en translucent
   * para que no se confundan con la arquitectura.
   */
  _obstacleGlyph(e, color) {
    const ctx = this.ctx;
    const d = datosDe(e);
    const pts = e.points.filter(Boolean);
    if (!pts.length) return;
    const P = (p) => [this.sx(p.x), this.sy(p.y)];
    if (d.radio > 0 && pts.length === 1) {
      const [x, y] = P(pts[0]);
      const r = Math.max(3, d.radio * this.scale);
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
      if (d.kind === 'columna' && (d.forma === 'cuadrada' || d.forma === 'rectangular')) {
        const forma = d.forma;
        const w = (d.ancho || (d.radio ? d.radio * 2 : 0.5)) * this.scale;
        const l = (d.largo || (forma === 'cuadrada' ? (d.ancho || 0.5) : 0.5)) * this.scale;
        const ang = ((d.rotacion || 0) * Math.PI) / 180;
        ctx.save();
        ctx.translate(x, y);
        if (ang) ctx.rotate(ang);
        ctx.fillStyle = (d.color || '#98a3b5') + '77';
        ctx.fillRect(-w / 2, -l / 2, w, l);
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.2;
        ctx.strokeRect(-w / 2, -l / 2, w, l);
        ctx.restore();
      } else if (d.kind === 'arbol' || d.kind === 'arbusto') {
        ctx.fillStyle = (d.color || '#4f7a52') + '55'; ctx.fill();
        ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, Math.max(1.5, r * 0.18), 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill();
      } else if (d.kind === 'persona') {
        ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, Math.max(1, r * 0.35), 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill();
      } else {
        ctx.fillStyle = (d.color || '#98a3b5') + '66'; ctx.fill();
        ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
      }
      // La altura, si hay sitio: es lo que distingue un muro de 2,8 m de uno de 1,1 m
      if (this.scale > 12 && this.prj.settings.showLabels !== false) {
        ctx.fillStyle = '#93a3b8'; ctx.font = '9px system-ui';
        ctx.fillText(`${d.altura.toFixed(1)} m`, x + r + 2, y + 3);
      }
      return;
    }
    const grueso = Math.max(1.2, Math.min(14, (d.ancho || 0.08) * this.scale));
    if (d.kind === 'puerta') {
      // Hueco: se dibuja como tal, sin línea, con el arco de la hoja
      const [x0, y0] = P(pts[0]), [x1, y1] = P(pts[1]);
      ctx.strokeStyle = color; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      const L = Math.hypot(x1 - x0, y1 - y0);
      if (L > 6) ctx.beginPath(); ctx.arc(x0, y0, L, Math.atan2(y1 - y0, x1 - x0), Math.atan2(y1 - y0, x1 - x0) + Math.PI / 2); ctx.stroke();
      return;
    }
    if (d.kind === 'ventana') {
      // Doble línea: el hueco acristalado
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      for (const desp of [-1.5, 1.5]) {
        ctx.beginPath();
        pts.forEach((p, i) => {
          const [x, y] = P(p);
          const nx = i < pts.length - 1 ? 0 : 0;
          i ? ctx.lineTo(x + nx + desp * 0.6, y + desp * 0.6) : ctx.moveTo(x + desp * 0.6, y + desp * 0.6);
        });
        ctx.stroke();
      }
      return;
    }
    if (e.closed && pts.length > 2) {
      if (d.kind === 'escalera') {
        // En planta: huellas de peldaños y flecha de subida
        ctx.beginPath();
        pts.forEach((p, i) => { const [x, y] = P(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
        ctx.closePath();
        ctx.fillStyle = (d.color || '#8892a0') + '33';
        ctx.fill();
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.4;
        ctx.stroke();

        // Rayado de peldaños
        const nSteps = Math.max(5, Math.min(18, d.numPeldanos || 10));
        const [p0, p1, p2, p3] = pts.map(P);
        ctx.save();
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        for (let s = 1; s < nSteps; s++) {
          const t = s / nSteps;
          const ax = p0[0] + (p1[0] - p0[0]) * t, ay = p0[1] + (p1[1] - p0[1]) * t;
          const bx = p3[0] + (p2[0] - p3[0]) * t, by = p3[1] + (p2[1] - p3[1]) * t;
          ctx.moveTo(ax, ay); ctx.lineTo(bx, by);
        }
        ctx.stroke();

        // Flecha de subida en el centro
        const mx0 = (p0[0] + p3[0]) / 2, my0 = (p0[1] + p3[1]) / 2;
        const mx1 = (p1[0] + p2[0]) / 2, my1 = (p1[1] + p2[1]) / 2;
        ctx.beginPath();
        ctx.arc(mx0 + (mx1 - mx0) * 0.15, my0 + (my1 - my0) * 0.15, 3, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(mx0 + (mx1 - mx0) * 0.15, my0 + (my1 - my0) * 0.15);
        ctx.lineTo(mx0 + (mx1 - mx0) * 0.85, my0 + (my1 - my0) * 0.85);
        ctx.stroke();
        ctx.restore();
        return;
      }

      // Losa o mueble: relleno suave y contorno
      ctx.beginPath();
      pts.forEach((p, i) => { const [x, y] = P(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
      ctx.closePath();
      ctx.fillStyle = (d.color || '#7d8798') + (d.techo ? '22' : '3a');
      ctx.globalAlpha = d.techo ? 0.55 : 0.85;
      ctx.fill(); ctx.globalAlpha = 1;
      ctx.strokeStyle = color; ctx.lineWidth = d.techo ? 1 : 1.3;
      if (d.techo) ctx.setLineDash([5, 3]);
      ctx.stroke(); ctx.setLineDash([]);
      return;
    }
    // Muros, tabiques, cercas: con su espesor, como en un plano
    ctx.strokeStyle = color;
    ctx.lineWidth = grueso;
    ctx.lineCap = 'round';
    ctx.globalAlpha = d.opaco ? 1 : 0.7;
    ctx.beginPath();
    pts.forEach((p, i) => { const [x, y] = P(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
    if (e.closed) ctx.closePath();
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 1.3; ctx.lineCap = 'butt';
  }

  /** Marca en el dibujo una cámara a la que los obstáculos dejan sin huella visible (§13). */
  _avisarCiega(e, p) {
    const ctx = this.ctx;
    ctx.save();
    ctx.strokeStyle = 'rgba(248,113,113,0.95)'; ctx.lineWidth = 1.6; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.arc(this.sx(p.x), this.sy(p.y), 13, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(248,113,113,0.95)'; ctx.font = 'bold 11px system-ui';
    ctx.fillText('sin visión', this.sx(p.x) + 16, this.sy(p.y) - 10);
    ctx.restore();
  }

  _cameraGlyph(e) {
    const ctx = this.ctx, p = e.points[0];
    const cams = (this.prj.entities || []).filter((x) => x.type === 'camera');
    const idx = cams.findIndex((x) => x.id === e.id);
    const lic = this.on.licencia ? this.on.licencia() : null;
    const bloqueadaTrial = lic && lic.esTrial && idx >= 1;

    if (bloqueadaTrial) {
      // En modo Trial la cámara 2 en adelante no proyecta haz ni cobertura
      ctx.save();
      ctx.fillStyle = '#ef4444';
      ctx.font = '10px system-ui';
      ctx.fillText('🔒 Trial (sin procesar)', this.sx(p.x) + 12, this.sy(p.y) + 14);
      ctx.restore();
    } else if (this.prj.settings.showCoverage !== false && this.on.coverageData) {
      const res = this.on.coverageData();
      if (res && (res._sombras || res._footprints)) {
        // Cada huella se dibuja **recortada por las sombras** de los obstáculos (§13): el cono ya no
        // atraviesa los muros. Una huella puede quedar partida en varios sectores; si no hay análisis
        // de sombras (por ejemplo, sin obstáculos) se cae a la huella teórica, que sigue siendo válida.
        const grupos = (res._sombras && res._sombras[e.id]) || (res._footprints[e.id] || []).map((q) => [q]);
        // Un PTZ proyecta la huella de cada posición de su patrulla (§38)
        const presets = isPtz(e, this.prj.catalog) ? cameraPresets(e) : [];
        const showPositions = this.prj.settings.showPresets !== false || this.selection.has(e.id);
        const path = (poly) => {
          ctx.beginPath();
          poly.forEach((q, i) => (i ? ctx.lineTo(this.sx(q.x), this.sy(q.y)) : ctx.moveTo(this.sx(q.x), this.sy(q.y))));
          ctx.closePath();
        };
        grupos.forEach((sectores, i) => {
          if (i > 0 && !showPositions) return;
          const poligonos = sectores.filter((q) => q && q.length >= 3);
          if (!poligonos.length) { this._avisarCiega(e, p); return; }
          poligonos.forEach((poly) => {
            path(poly);
            if (i === 0) {
              // Vista principal: es la que la cámara usa cuando no está en patrulla.
              // Si la cámara está **seleccionada**, su cono se repinta en el color de selección y
              // con el borde más grueso: se ve de golpe qué cubre lo que se ha cogido (§8).
              const sel = this.selection.has(e.id);
              ctx.fillStyle = sel ? conAlfa(this.prefs.colorSeleccion, 0.16) : 'rgba(242,163,60,0.10)';
              ctx.fill();
              ctx.strokeStyle = sel ? this.prefs.colorSeleccion : 'rgba(242,163,60,0.55)';
              ctx.lineWidth = sel ? 2 : 1; ctx.stroke();
            } else {
              ctx.fillStyle = 'rgba(96,165,250,0.07)'; ctx.fill();
              ctx.strokeStyle = 'rgba(96,165,250,0.55)'; ctx.lineWidth = 1; ctx.setLineDash([5, 4]);
              ctx.stroke(); ctx.setLineDash([]);
            }
          });
          if (i > 0 && this.scale > 9 && presets[i]) {
            const lejos = poligonos.flat().reduce((a, q) => (Math.hypot(q.x - p.x, q.y - p.y) > Math.hypot(a.x - p.x, a.y - p.y) ? q : a), poligonos[0][0]);
            ctx.fillStyle = 'rgba(147,197,253,0.95)'; ctx.font = '10px system-ui';
            ctx.fillText(presets[i].name || '', this.sx(lejos.x) - 14, this.sy(lejos.y) - 4);
          }
        });
      }
    }
    const x = this.sx(p.x), y = this.sy(p.y);
    const az = rad(e.data.azimuth || 0);
    const catItem = getItem(this.prj.catalog, e.data.catalogId);
    const esFisheye = !!(catItem && catItem.specs && (catItem.specs.fisheye || (catItem.specs.tipo && catItem.specs.tipo.toLowerCase().includes('pez'))));
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = '#e8443a'; ctx.fillStyle = '#e8443a'; ctx.lineWidth = 1.6;
    if (esFisheye) {
      // Símbolo específico 360° para cámara Fisheye (anillo exterior con lente hemisférica y punto central)
      ctx.beginPath(); ctx.arc(0, 0, 7.5, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 4.5, 0, Math.PI * 2); ctx.strokeStyle = '#f97316'; ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 2, 0, Math.PI * 2); ctx.fillStyle = '#e8443a'; ctx.fill();
    } else {
      ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.stroke();
      ctx.rotate(-az);
      ctx.beginPath(); ctx.moveTo(2, -3.5); ctx.lineTo(10, 0); ctx.lineTo(2, 3.5); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    // Zona de captura del módulo LPR: dónde la placa es legible (§38)
    if (isLpr(e, this.prj.catalog) && this.prj.settings.showLprZones !== false) {
      const z = captureZone(e, this.prj.catalog, this.prj.rules);
      ctx.beginPath();
      z.polygon.forEach((q, i) => (i ? ctx.lineTo(this.sx(q.x), this.sy(q.y)) : ctx.moveTo(this.sx(q.x), this.sy(q.y))));
      ctx.closePath();
      ctx.fillStyle = 'rgba(20,184,166,0.10)'; ctx.fill();
      ctx.strokeStyle = 'rgba(20,184,166,0.65)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
      if (this.scale > 8) {
        const mid = z.polygon[Math.floor(z.polygon.length * 0.75)];
        ctx.fillStyle = 'rgba(94,234,212,0.95)'; ctx.font = '10px system-ui';
        ctx.fillText(`LPR ${z.near.toFixed(0)}–${z.far.toFixed(0)} m`, this.sx(mid.x) - 20, this.sy(mid.y) + 10);
      }
    }
    if (this.prj.settings.showLabels !== false && this.scale > 8) {
      ctx.fillStyle = '#f0d0cc'; ctx.font = '10px system-ui';
      ctx.fillText(e.data.label || '', x + 9, y - 7);
    }
  }

  _deviceGlyph(e) {
    const ctx = this.ctx, p = e.points[0];
    const x = this.sx(p.x), y = this.sy(p.y);
    const kind = e.data.kind;
    ctx.save(); ctx.translate(x, y);
    ctx.strokeStyle = '#0ea5e9'; ctx.fillStyle = 'rgba(14,165,233,0.15)'; ctx.lineWidth = 1.5;
    if (kind === 'switch') { ctx.beginPath(); ctx.rect(-9, -6, 18, 12); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#0ea5e9'; for (let i = 0; i < 4; i++) ctx.fillRect(-7 + i * 4, 2, 2, 2); }
    else if (kind === 'nvr') { ctx.beginPath(); ctx.rect(-10, -7, 20, 14); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#14b8a6'; ctx.fillRect(-6, -3, 8, 3); }
    else if (kind === 'router') { ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.moveTo(-4, 3); ctx.lineTo(4, -3); ctx.stroke(); }
    else if (kind === 'ups') { ctx.beginPath(); ctx.rect(-8, -8, 16, 16); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#eab308'; ctx.font = '9px system-ui'; ctx.fillText('UPS', -8, 3); }
    else { ctx.beginPath(); ctx.rect(-9, -5, 18, 10); ctx.fill(); ctx.stroke(); }
    ctx.restore();
    if (this.prj.settings.showLabels !== false && this.scale > 8) {
      ctx.fillStyle = '#bfe3f5'; ctx.font = '10px system-ui';
      ctx.fillText(e.data.label || '', x + 12, y + 4);
    }
  }

  /** Rotula la cota dinámica al lado del cursor, estilo Entrada Dinámica de AutoCAD (§8). */
  _etiquetaMedida(ptMundo, texto) {
    if (!ptMundo || !texto) return;
    const ctx = this.ctx;
    ctx.save();
    const x = this.sx(ptMundo.x) + 14, y = this.sy(ptMundo.y) - 12;
    ctx.font = 'bold 11px monospace, system-ui';
    const w = ctx.measureText(texto).width + 10;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.fillRect(x, y - 14, w, 18);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y - 14, w, 18);
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(texto, x + 5, y);
    ctx.restore();
  }

  _draft() {
    const ctx = this.ctx;
    ctx.strokeStyle = this.prefs.colorSeleccion; ctx.lineWidth = 1.2; ctx.setLineDash([4, 3]);
    const d = this.draft;
    if (d) {
      ctx.beginPath();
      if (d.type === 'rect' || (d.type === 'obstacle' && d.rect)) {
        const [a, b] = d.points;
        ctx.rect(this.sx(Math.min(a.x, b.x)), this.sy(Math.max(a.y, b.y)), Math.abs(b.x - a.x) * this.scale, Math.abs(b.y - a.y) * this.scale);
      } else if (d.type === 'circle') {
        ctx.arc(this.sx(d.points[0].x), this.sy(d.points[0].y), (d.radius || 0) * this.scale, 0, Math.PI * 2);
      } else if (d.type === 'arc') {
        // El arco se dibuja en sentido antihorario desde el ángulo inicial hasta el final
        const ini = d.startAngle || 0;
        const barrido = d.fase === 'radio' ? 0 : (d.endAngle === undefined ? 0 : ((d.endAngle - ini + 360) % 360));
        ctx.arc(this.sx(d.points[0].x), this.sy(d.points[0].y), (d.radius || 0) * this.scale, -rad(ini), -rad(ini + barrido));
      } else {
        ctx.moveTo(this.sx(d.points[0].x), this.sy(d.points[0].y));
        ctx.lineTo(this.sx(d.points[1].x), this.sy(d.points[1].y));
      }
      ctx.stroke();
      if (d.type === 'line' || (d.type === 'obstacle' && !d.rect)) {
        const p0 = d.points[0], p1 = d.points[1];
        const L = Math.hypot(p1.x - p0.x, p1.y - p0.y);
        const ang = ((Math.atan2(p1.y - p0.y, p1.x - p0.x) * 180 / Math.PI) + 360) % 360;
        this._etiquetaMedida(p1, `${L.toFixed(2)} m < ${ang.toFixed(1)}°`);
      } else if (d.type === 'rect' || (d.type === 'obstacle' && d.rect)) {
        const [a, b] = d.points;
        const dx = Math.abs(b.x - a.x), dy = Math.abs(b.y - a.y);
        this._etiquetaMedida(b, `${dx.toFixed(2)} × ${dy.toFixed(2)} m`);
      }
    }
    if (this._poly && this._poly.pts.length) {
      ctx.beginPath();
      this._poly.pts.forEach((p, i) => (i ? ctx.lineTo(this.sx(p.x), this.sy(p.y)) : ctx.moveTo(this.sx(p.x), this.sy(p.y))));
      if (this._poly.cursor) ctx.lineTo(this.sx(this._poly.cursor.x), this.sy(this._poly.cursor.y));
      ctx.stroke();
      ctx.fillStyle = '#7dd3fc';
      for (const p of this._poly.pts) ctx.fillRect(this.sx(p.x) - 2, this.sy(p.y) - 2, 4, 4);
      if (this._poly.cursor && this._poly.pts.length) {
        const p0 = this._poly.pts[this._poly.pts.length - 1];
        const p1 = this._poly.cursor;
        const L = Math.hypot(p1.x - p0.x, p1.y - p0.y);
        const ang = ((Math.atan2(p1.y - p0.y, p1.x - p0.x) * 180 / Math.PI) + 360) % 360;
        this._etiquetaMedida(p1, `${L.toFixed(2)} m < ${ang.toFixed(1)}°`);
      }
    }
    ctx.setLineDash([]);
    if (this._snapPoint && !this.seleccionando) {
      ctx.strokeStyle = this.prefs.colorSeleccion; ctx.lineWidth = 1;
      const x = this.sx(this._snapPoint.x), y = this.sy(this._snapPoint.y);
      ctx.beginPath(); ctx.moveTo(x - 5, y); ctx.lineTo(x + 5, y); ctx.moveTo(x, y - 5); ctx.lineTo(x, y + 5); ctx.stroke();
    }
  }

  _selection() {
    // Mientras hay un comando en curso manda su vista previa: la selección real no se resalta
    if (!this.selection.size || this._comando) return;
    const ctx = this.ctx;
    const q = this.prefs;
    ctx.strokeStyle = q.colorSeleccion; ctx.lineWidth = 1.4; ctx.setLineDash([3, 3]);
    for (const e of this.selected()) {
      if (!e.points || !e.points.length) continue;
      const b = bbox(e.type === 'circle' ? [{ x: e.points[0].x - e.radius, y: e.points[0].y - e.radius }, { x: e.points[0].x + e.radius, y: e.points[0].y + e.radius }] : e.points);
      const pad = 5;
      ctx.strokeRect(this.sx(b.minX) - pad, this.sy(b.maxY) - pad, (b.maxX - b.minX) * this.scale + pad * 2, (b.maxY - b.minY) * this.scale + pad * 2);
    }
    ctx.setLineDash([]);
    this._pintarTiradores();
  }

  /**
   * Marquesina de selección (§8): el rectángulo que se arrastra para coger varios objetos.
   * Hacia la derecha, **ventana** (solo lo que cabe entero, azul y continuo); hacia la
   * izquierda, **cruce** (todo lo que toca, verde y discontinuo), como en AutoCAD.
   * Además se adelanta qué se va a coger: los objetos se marcan vivos y junto al cursor se
   * escribe cuántos son y cuánto mide el rectángulo.
   */
  _marquesina() {
    if (!this._box) return;
    // Las esquinas están en el mundo: se pasan a pantalla en cada dibujo, así el rectángulo
    // acompaña al dibujo aunque se acerque o se mueva la vista mientras se arrastra.
    const a = { x: this.sx(this._box.a.x), y: this.sy(this._box.a.y) };
    const b = { x: this.sx(this._box.b.x), y: this.sy(this._box.b.y) };
    const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
    const w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
    if (w < 3 && h < 3) return;                        // un clic limpio no pinta nada
    const ctx = this.ctx, q = this.prefs;
    const cruce = b.x < a.x;                           // de derecha a izquierda: cruce
    const color = cruce ? (q.colorCruce || '#4ade80') : (q.colorMarquesina || '#38bdf8');
    const relleno = Math.max(0, Math.min(45, Number(q.opacidadMarquesina ?? 18)));
    const alfa = Math.round((relleno / 100) * 255).toString(16).padStart(2, '0');
    const caja = cajaDe2(this._box.a, this._box.b);
    const modo = cruce ? 'cruce' : 'ventana';
    const ids = this._idsEnCaja(caja, modo);
    ctx.save();

    // 1) avance: los objetos que entrarían se marcan ya en color de selección
    if (q.resaltarPrevio !== false && ids.length) {
      const set = new Set(ids);
      ctx.strokeStyle = q.colorSeleccion; ctx.lineWidth = 2; ctx.setLineDash([]);
      for (const e of this.prj.entities) {
        if (!set.has(e.id)) continue;
        const c = cajaDeEntidad(e);
        if (!c) continue;
        ctx.strokeRect(this.sx(c.minX) - 3, this.sy(c.maxY) - 3,
          (c.maxX - c.minX) * this.scale + 6, (c.maxY - c.minY) * this.scale + 6);
      }
    }

    // 2) relleno translúcido
    const x0 = Math.round(x) + 0.5, y0 = Math.round(y) + 0.5;   // medio píxel: borde nítido
    const w0 = Math.max(1, Math.round(w) - 1), h0 = Math.max(1, Math.round(h) - 1);
    if (relleno > 0) { ctx.fillStyle = color + alfa; ctx.fillRect(x0, y0, w0, h0); }

    // 3) borde: primero un filete oscuro para que se vea sobre cualquier fondo, encima el color
    ctx.setLineDash([]);
    ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.strokeRect(x0, y0, w0, h0);
    ctx.lineWidth = 3; ctx.strokeStyle = color; ctx.setLineDash(cruce ? [9, 5] : []);
    ctx.strokeRect(x0, y0, w0, h0);
    ctx.setLineDash([]);

    // 4) esquinas remarcadas, como el marco de selección de AutoCAD
    const L = Math.min(16, Math.max(7, Math.min(w, h) / 4));
    ctx.lineWidth = 3; ctx.strokeStyle = color;
    const esquinas = [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]];
    for (const [cx, cy, sx, sy] of esquinas) {
      ctx.beginPath();
      ctx.moveTo(cx + sx * L, cy); ctx.lineTo(cx, cy); ctx.lineTo(cx, cy + sy * L);
      ctx.stroke();
    }

    // 5) rótulo junto al cursor: modo, cuántos objetos y tamaño en metros
    if (q.etiquetaMarquesina !== false) {
      const anchoM = Math.abs(caja.maxX - caja.minX), altoM = Math.abs(caja.maxY - caja.minY);
      const n = ids.length;
      const texto = `${cruce ? 'Cruce' : 'Ventana'} · ${n === 1 ? '1 objeto' : n + ' objetos'}` +
        ` · ${anchoM.toFixed(1)} × ${altoM.toFixed(1)} m`;
      ctx.font = '600 12px system-ui, sans-serif';
      const tw = ctx.measureText(texto).width;
      let tx = b.x + 14, ty = b.y + 20;
      if (tx + tw + 12 > this.w) tx = b.x - tw - 20;
      if (ty + 22 > this.h) ty = b.y - 10;
      ctx.fillStyle = 'rgba(0,0,0,0.72)';
      ctx.fillRect(tx - 6, ty - 14, tw + 12, 20);
      ctx.fillStyle = color;
      ctx.fillRect(tx - 6, ty - 14, 2.5, 20);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(texto, tx, ty);
    }
    ctx.restore();
  }

  /**
   * Identificadores que entran en una caja del mundo, en el modo pedido.
   * Solo se cogen los objetos de **capas visibles**: lo que esté en una capa apagada no se
   * selecciona aunque el rectángulo pase por encima (como en AutoCAD).
   */
  _idsEnCaja(caja, modo) {
    try {
      const ocultas = new Set((this.prj.layers || []).filter((l) => l.visible === false).map((l) => l.id));
      const ents = ocultas.size ? this.prj.entities.filter((e) => !ocultas.has(e.layer)) : this.prj.entities;
      const ids = seleccionarEnCaja(ents, caja, modo);
      return this._sumarConos(ids, ents, caja ? { caja } : null, modo);
    } catch { return []; }
  }

  /** Idéntico, pero para un **lazo** (polígono libre que puede autocortarse). */
  _idsEnPoligono(poli, modo) {
    try {
      const ocultas = new Set((this.prj.layers || []).filter((l) => l.visible === false).map((l) => l.id));
      const ents = ocultas.size ? this.prj.entities.filter((e) => !ocultas.has(e.layer)) : this.prj.entities;
      const ids = seleccionarEnPoligono(ents, poli, modo);
      return this._sumarConos(ids, ents, { poli }, modo);
    } catch { return []; }
  }

  /**
   * Con el ajuste «seleccionar por el cono» activo, una cámara entra también cuando el rectángulo
   * o el lazo **toca su huella de cobertura** (§13), aunque no llegue al símbolo. En modo ventana
   * no se aplica: si el cono contara ahí, sería casi imposible coger una cámara por ventana.
   */
  _sumarConos(ids, ents, forma, modo) {
    if (!this.prefs.seleccionarPorCono || modo === 'ventana' || !forma) return ids;
    const ya = new Set(ids);
    for (const e of ents) {
      if (e.type !== 'camera' || ya.has(e.id)) continue;
      for (const h of this._huellasDe(e)) {
        const fantasma = { id: e.id, type: 'polyline', points: h, data: { closed: true } };
        const toca = forma.caja ? entidadEnCaja(fantasma, forma.caja, 'cruce')
          : entidadEnPoligono(fantasma, forma.poli, 'cruce');
        if (toca) { ids.push(e.id); ya.add(e.id); break; }
      }
    }
    return ids;
  }

  /** Polígonos de la huella de cobertura de una cámara, ya recortados por las sombras. */
  _huellasDe(e) {
    if (e.type !== 'camera' || !this.on.coverageData) return [];
    try {
      const res = this.on.coverageData();
      if (!res) return [];
      const grupos = (res._sombras && res._sombras[e.id]) || (res._footprints && res._footprints[e.id]) || [];
      return grupos.flat().filter((q) => q && q.length >= 3);
    } catch { return []; }
  }

  /**
   * Dibujo del **lazo**: el trazado libre del ratón, en coordenadas del mundo, con el color y el
   * estilo del modo que corresponda según el sentido del giro (regla de AutoCAD: antihorario →
   * ventana en azul continuo; horario → cruce en verde discontinuo).
   */
  _lazoDibujo() {
    if (!this._lazo || this._lazo.pts.length < 2) return;
    const ctx = this.ctx, q = this.prefs;
    const traza = this._lazo.pts.map((t) => ({ x: this.sx(t.x), y: this.sy(t.y) }));
    const c = bbox(traza);
    if (Math.max(c.maxX - c.minX, c.maxY - c.minY) < 3) return;      // un clic limpio no pinta nada
    const horario = areaConSigno(traza) > 0;                          // Y de pantalla hacia abajo
    const modo = horario ? 'cruce' : 'ventana';
    const color = horario ? (q.colorCruce || '#4ade80') : (q.colorMarquesina || '#38bdf8');
    const relleno = Math.max(0, Math.min(45, Number(q.opacidadMarquesina ?? 18)));
    const alfa = Math.round((relleno / 100) * 255).toString(16).padStart(2, '0');
    const poli = simplify(this._lazo.pts, Math.max(1e-6, 1.5 / this.scale));
    const ids = this._idsEnPoligono(poli, modo);
    ctx.save();

    // 1) avance: los objetos que entrarían se marcan ya en color de selección
    if (q.resaltarPrevio !== false && ids.length) {
      const set = new Set(ids);
      ctx.strokeStyle = q.colorSeleccion; ctx.lineWidth = 2; ctx.setLineDash([]);
      for (const e of this.prj.entities) {
        if (!set.has(e.id)) continue;
        const cc = cajaDeEntidad(e);
        if (!cc) continue;
        ctx.strokeRect(this.sx(cc.minX) - 3, this.sy(cc.maxY) - 3,
          (cc.maxX - cc.minX) * this.scale + 6, (cc.maxY - cc.minY) * this.scale + 6);
      }
    }

    // 2) relleno y borde del trazado: el lazo se cierra solo, como el de AutoCAD
    ctx.beginPath();
    traza.forEach((t, i) => (i ? ctx.lineTo(t.x, t.y) : ctx.moveTo(t.x, t.y)));
    ctx.closePath();
    if (relleno > 0) { ctx.fillStyle = color + alfa; ctx.fill(); }
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.setLineDash([]); ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.stroke();
    ctx.lineWidth = 3; ctx.strokeStyle = color; ctx.setLineDash(horario ? [9, 5] : []);
    ctx.stroke();
    ctx.setLineDash([]);

    // 3) punto de origen, para saber por dónde se empezó
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.arc(traza[0].x, traza[0].y, 3.5, 0, Math.PI * 2); ctx.fill();

    // 4) rótulo junto al cursor
    if (q.etiquetaMarquesina !== false) {
      const cm = bbox(this._lazo.pts);
      const n = ids.length;
      const texto = `Lazo · ${horario ? 'cruce' : 'ventana'} · ${n === 1 ? '1 objeto' : n + ' objetos'}` +
        ` · ${(cm.maxX - cm.minX).toFixed(1)} × ${(cm.maxY - cm.minY).toFixed(1)} m`;
      ctx.font = '600 12px system-ui, sans-serif';
      const tw = ctx.measureText(texto).width;
      const ult = traza[traza.length - 1];
      let tx = ult.x + 14, ty = ult.y + 20;
      if (tx + tw + 12 > this.w) tx = ult.x - tw - 20;
      if (ty + 22 > this.h) ty = ult.y - 10;
      ctx.fillStyle = 'rgba(0,0,0,0.72)';
      ctx.fillRect(tx - 6, ty - 14, tw + 12, 20);
      ctx.fillStyle = color;
      ctx.fillRect(tx - 6, ty - 14, 2.5, 20);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(texto, tx, ty);
    }
    ctx.restore();
  }

  _measureDraw() {
    if (!this._measure || !this._measure.a) return;
    const ctx = this.ctx;
    const a = this._measure.a, b = this._measure.b || this.cursor;
    ctx.strokeStyle = '#facc15'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(this.sx(a.x), this.sy(a.y)); ctx.lineTo(this.sx(b.x), this.sy(b.y)); ctx.stroke();
    const d = dist(a, b);
    ctx.fillStyle = '#facc15'; ctx.font = '11px system-ui';
    ctx.fillText(`${d.toFixed(2)} m`, this.sx((a.x + b.x) / 2) + 6, this.sy((a.y + b.y) / 2) - 6);
  }

  /* ---------------------- comandos de edición (§8, §9) ---------------------- */

  /**
   * Comandos al estilo de AutoCAD: se señala un **punto base** y luego el destino, con la vista
   * previa puesta mientras se mueve el ratón. En cualquier momento se puede escribir el valor
   * exacto en la barra de estado (`valorComando`) o cancelar con Escape.
   *
   *   MOVER · COPIAR   base → destino
   *   PEGAR            base del portapapeles → destino
   *   GIRAR            base (centro de giro) → destino (el ángulo lo da la dirección)
   *   ESCALAR          base → punto de referencia (distancia de partida) → nueva distancia
   *   ESPEJO           base → otro punto: la recta que los une es el eje del espejo
   */
  iniciarComando(tipo, extra = {}) {
    const sel = this.selected();
    const necesitaSeleccion = ['mover', 'rotar', 'escalar', 'espejo', 'copiar'].includes(tipo);
    if (necesitaSeleccion && !sel.length) return false;
    if (tipo === 'pegar' && !(extra.entidades || []).length) return false;
    const origen = tipo === 'pegar'
      ? extra.entidades.map((e) => clonar(e))
      : sel.map((e) => clonar(e));
    this._comando = {
      tipo, fase: 'base', base: null, referencia: null, destino: null,
      origen, fantasma: origen.map((e) => clonar(e)), extra,
      // Al pegar se insertan copias nuevas; en el resto de comandos los objetos son los mismos y
      // hay que devolverlos a su id, porque el clon del «fantasma» lleva uno propio (§9).
      ids: tipo === 'pegar' ? [] : sel.map((e) => e.id) };
    if (this.on.comando) this.on.comando(this._comando);
    if (this.on.hint) this.on.hint(this._textoComando());
    this.draw();
    return true;
  }

  /* --------------------- orientación de la cámara (§9) --------------------- */

  /** Entra en modo «apuntar»: el cono de la cámara sigue al ratón hasta el siguiente clic. */
  _empezarApunte(e) {
    this._apunte = { id: e.id, original: e.data.azimuth, destino: null };
    if (this.on.hint) this.on.hint('Hacia dónde mira la cámara: mueva el ratón y haga clic (o escriba el ángulo y pulse Enter; Esc la deja como está).');
    this.draw();
  }

  /** Vista previa: el azimut se recalcula con el ratón y el cono se repinta al instante. */
  _moverApunte(w) {
    const a = this._apunte; if (!a) return;
    const e = this.prj.entities.find((x) => x.id === a.id);
    if (!e) { this._apunte = null; return; }
    a.destino = this.snap(w, e.points[0]);
    e.data.azimuth = Math.round(anguloDeg(e.points[0], a.destino) * 10) / 10;
    if (this.on.comandoInfo) this.on.comandoInfo(`Orientación ${Number(e.data.azimuth).toFixed(1).replace('.', ',')}°`);
    if (this.on.editLive) this.on.editLive(e);
    this.draw();
  }

  /** Segundo clic: se queda la orientación que se estaba viendo. */
  _fijarApunte(w) {
    const a = this._apunte; if (!a) return;
    const e = this.prj.entities.find((x) => x.id === a.id);
    if (e) {
      const p = this.snap(w, e.points[0]);
      e.data.azimuth = Math.round(anguloDeg(e.points[0], p) * 10) / 10;
    }
    this._apunte = null;
    if (this.on.comandoInfo) this.on.comandoInfo('');
    if (e && this.on.hint) this.on.hint(`Cámara orientada a ${Number(e.data.azimuth).toFixed(1).replace('.', ',')}°. Puede girarla con el mango, con R o desde Propiedades.`);
    if (this.on.change) this.on.change('orientar');
    this.draw();
  }

  /** Esc: la cámara se queda con el azimut que tenía al colocarla. */
  _cancelarApunte() {
    const a = this._apunte; if (!a) return;
    const e = this.prj.entities.find((x) => x.id === a.id);
    if (e) e.data.azimuth = a.original;
    this._apunte = null;
    if (this.on.comandoInfo) this.on.comandoInfo('');
    if (this.on.hint) this.on.hint('Orientación cancelada: la cámara se queda como estaba.');
    if (this.on.change) this.on.change('orientar');
    this.draw();
  }

  /** Pide un punto del plano para orientar una cámara ya colocada (`Apuntar…` del panel). */
  apuntarCamara(id) {
    const e = id ? this.prj.entities.find((x) => x.id === id) : this.selected().find((x) => x.type === 'camera');
    if (!e || e.type !== 'camera') return false;
    this.selection = new Set([e.id]);
    if (this.on.setTool) this.on.setTool('camera');   // la paleta queda señalada, como al pulsarla
    this._empezarApunte(e);
    return true;
  }

  /** Guía del apunte: línea discontinua desde la cámara hasta el punto que se está mirando. */
  _pintarApunte() {
    const a = this._apunte; if (!a || !a.destino) return;
    const e = this.prj.entities.find((x) => x.id === a.id);
    if (!e) return;
    const ctx = this.ctx, o = e.points[0];
    ctx.save();
    ctx.setLineDash([6, 4]); ctx.lineWidth = 1.5;
    ctx.strokeStyle = this.prefs.colorSeleccion;
    ctx.beginPath(); ctx.moveTo(this.sx(o.x), this.sy(o.y)); ctx.lineTo(this.sx(a.destino.x), this.sy(a.destino.y)); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(this.sx(a.destino.x), this.sy(a.destino.y), 5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffd166'; ctx.fill();
    ctx.restore();
  }

  /** Cancela el comando en curso sin tocar nada. */
  cancelarComando() {
    // Esc también corta la marquesina a medio arrastrar, como en AutoCAD: se suelta y listo
    if (this._box || this._lazo) { this._box = null; this._lazo = null; this.draw(); return true; }
    if (!this._comando) return false;
    this._comando = null; this._fantasma = false;
    if (this.on.comando) this.on.comando(null);
    this.draw();
    return true;
  }

  comandoActivo() { return this._comando ? this._comando.tipo : null; }

  /** Un clic del comando: base, referencia (solo al escalar) o destino. */
  _puntoComando(w) {
    const c = this._comando;
    if (!c) return;
    const p = this.snap(w, c.base);
    if (c.fase === 'base') {
      c.base = p;
      c.fase = c.tipo === 'escalar' ? 'referencia' : 'destino';
    } else if (c.fase === 'referencia') {
      c.referencia = p;
      c.fase = 'destino';
    } else {
      this._moverComando(w);
      this._aplicarComando();
      return;
    }
    if (this.on.hint) this.on.hint(this._textoComando());
    if (this.on.comando) this.on.comando(this._comando);
    this.draw();
  }

  /** Vista previa: se recalcula la copia transformada con la posición actual del ratón. */
  _moverComando(w) {
    const c = this._comando;
    if (!c || c.fase === 'base') return;
    const p = c.fase === 'referencia' ? this.snap(w, c.base) : this.snap(w, c.base);
    c.destino = p;
    c.fantasma = c.origen.map((e) => {
      const f = clonar(e);
      if (c.tipo === 'rotar') rotarEntidad(f, anguloDeg(c.base, p), c.base);
      else if (c.tipo === 'escalar') {
        const d0 = c.referencia ? dist(c.base, c.referencia) : 0;
        if (d0 > 1e-9) escalarEntidad(f, dist(c.base, p) / d0, c.base);
      } else if (c.tipo === 'espejo') espejarPorEje(f, c.base, p);
      else trasladar(f, p.x - c.base.x, p.y - c.base.y);
      return f;
    });
    if (this.on.comandoInfo) this.on.comandoInfo(this._valorComando());
    this.draw();
  }

  /** Cifra en vivo del comando: cuánto se está moviendo, girando o escalando. */
  _valorComando() {
    const c = this._comando;
    if (!c || !c.base || !c.destino) return '';
    const f = (v, u = 2) => Number(v).toFixed(u).replace('.', ',');
    switch (c.tipo) {
      case 'rotar': {
        let a = anguloDeg(c.base, c.destino);
        if (a > 180) a -= 360;
        return `Ángulo ${f(a, 1)}°`;
      }
      case 'escalar': {
        const d0 = c.referencia ? dist(c.base, c.referencia) : 0;
        if (!d0) return `Longitud de referencia ${f(dist(c.base, c.destino))} m`;
        return `Factor ×${f(dist(c.base, c.destino) / d0, 3)}`;
      }
      case 'espejo': return `Eje ${f(anguloDeg(c.base, c.destino), 1)}°`;
      default:
        return `Desplazamiento ${f(c.destino.x - c.base.x)} , ${f(c.destino.y - c.base.y)} m · ${f(dist(c.base, c.destino))} m`;
    }
  }

  /** Acepta el valor escrito en la barra de estado y termina el comando. */
  /**
   * Entrada directa de distancia o coordenadas durante la creación de geometría (§8).
   * Admite:
   *   - Una sola distancia (ej. "5.5" o "5,5"): avanza esa distancia exacta en la dirección del cursor.
   *   - Distancia y ángulo polar (ej. "10<45" o "8<180"): punto relativo con ese ángulo.
   *   - Incremento cartesiano (ej. "4,2" o "@4,2"): desplazamiento dx, dy relativo al punto base.
   *   - Coordenadas absolutas (ej. "#10,20"): fija el punto en esas coordenadas del plano.
   */
  aplicarDimensionDirecta(texto) {
    if (!texto || !String(texto).trim()) return false;
    const str = String(texto).trim();

    // 1. Caso de orientación de cámara
    if (this._apunte) {
      const e = this.prj.entities.find((x) => x.id === this._apunte.id);
      const v = parseFloat(str.replace(',', '.'));
      if (e && isFinite(v)) {
        e.data.azimuth = ((v % 360) + 360) % 360;
        this._apunte = null;
        if (this.on.comandoInfo) this.on.comandoInfo('');
        if (this.on.hint) this.on.hint(`Cámara orientada a ${Number(e.data.azimuth).toFixed(1).replace('.', ',')}°.`);
        if (this.on.change) this.on.change('orientar');
        this.draw(); return true;
      }
      return false;
    }

    // 2. Comandos interactivos de modificación (MOVER, GIRAR, ESCALAR...)
    if (this._comando) return this.valorComando(str);

    // 3. Creación interactiva de entidades (Muros, líneas, obstáculos, rectángulos, círculos, polilíneas)
    const enCadena = this._poly && this._poly.pts && this._poly.pts.length > 0;
    const enDraft = !!this.draft;

    if (!enCadena && !enDraft) return false;

    const base = enCadena
      ? this._poly.pts[this._poly.pts.length - 1]
      : (this.draft && this.draft.points ? this.draft.points[0] : { x: 0, y: 0 });

    const cursor = this._snapPoint || this.cursor || { x: base.x + 1, y: base.y };
    let ptFinal = null;

    // A. Formato polar: dist < angulo
    if (str.includes('<')) {
      const [sDist, sAng] = str.split('<');
      const d = parseFloat(sDist.replace(',', '.'));
      const a = parseFloat(sAng.replace(',', '.'));
      if (isFinite(d) && isFinite(a)) {
        const rad = (a * Math.PI) / 180;
        ptFinal = { x: base.x + d * Math.cos(rad), y: base.y + d * Math.sin(rad) };
      }
    }
    // B. Formato absoluto: #x,y
    else if (str.startsWith('#')) {
      const partes = str.slice(1).split(/[,;\s]+/).map((v) => parseFloat(v.replace(',', '.')));
      if (partes.length >= 2 && isFinite(partes[0]) && isFinite(partes[1])) {
        ptFinal = { x: partes[0], y: partes[1] };
      }
    }
    // C. Formato cartesiano relativo dx, dy: "@dx,dy" o "dx,dy"
    else if (str.includes(',') || str.includes(';') || (str.includes(' ') && !str.startsWith('@'))) {
      const limpio = str.startsWith('@') ? str.slice(1) : str;
      const partes = limpio.split(/[,;\s]+/).map((v) => parseFloat(v.replace(',', '.')));
      if (partes.length >= 2 && isFinite(partes[0]) && isFinite(partes[1])) {
        if (enDraft && (this.draft.type === 'rect' || (this.draft.type === 'obstacle' && this.draft.rect))) {
          // Para rectángulos, dx y dy son las dimensiones ancho y alto
          ptFinal = { x: base.x + partes[0], y: base.y + partes[1] };
        } else {
          ptFinal = { x: base.x + partes[0], y: base.y + partes[1] };
        }
      }
    }
    // D. Número único: distancia en la dirección actual del cursor (o radio de círculo)
    else {
      const d = parseFloat(str.replace(',', '.'));
      if (isFinite(d)) {
        if (enDraft && this.draft.type === 'circle') {
          this.draft.radius = Math.max(0.01, d);
          if (this.on.draw) this.on.draw(this.draft);
          this.draft = null;
          if (this.on.hint) this.on.hint(`Círculo creado con radio ${d.toFixed(2)} m.`);
          this.draw(); return true;
        }
        const dx = cursor.x - base.x, dy = cursor.y - base.y;
        const L = Math.hypot(dx, dy);
        const ux = L > 1e-6 ? dx / L : 1;
        const uy = L > 1e-6 ? dy / L : 0;
        ptFinal = { x: base.x + ux * d, y: base.y + uy * d };
      }
    }

    if (!ptFinal) return false;

    // Aplicar el punto al dibujo en curso
    if (this.tool === 'obstacle') {
      this._puntoObstaculo(ptFinal);
      if (this.on.hint) this.on.hint(`Vértice fijado a distancia tecleada (${str}). Pulse Enter para terminar la cadena.`);
      this.draw(); return true;
    }

    if (this.tool === 'polyline' || this.tool === 'room' || this.tool === 'pzona' || this.tool === 'mascara') {
      this._poly = this._poly || { pts: [] };
      this._poly.pts.push(ptFinal);
      if (this.on.hint) this.on.hint(`Vértice fijado a distancia tecleada (${str}). Pulse Enter para cerrar.`);
      this.draw(); return true;
    }

    if (this.tool === 'line') {
      if (!this.draft) this.draft = { type: 'line', points: [base, ptFinal] };
      else this.draft.points[1] = ptFinal;
      if (this.on.draw) this.on.draw(this.draft);
      this.draft = null;
      if (this.on.hint) this.on.hint(`Línea creada con longitud tecleada (${str}).`);
      this.draw(); return true;
    }

    if (this.tool === 'rect') {
      if (!this.draft) this.draft = { type: 'rect', points: [base, ptFinal] };
      else this.draft.points[1] = ptFinal;
      if (this.on.draw) this.on.draw(this.draft);
      this.draft = null;
      if (this.on.hint) this.on.hint(`Rectángulo creado con medidas tecleadas (${str}).`);
      this.draw(); return true;
    }

    return false;
  }

  valorComando(texto) {
    // Si se está orientando una cámara, el número escrito es el azimut (se teclea igual que el
    // ángulo de un comando GIRAR, §9).
    if (this._apunte) {
      const e = this.prj.entities.find((x) => x.id === this._apunte.id);
      const v = parseFloat(String(texto).trim().replace(',', '.'));
      if (e && isFinite(v)) {
        e.data.azimuth = ((v % 360) + 360) % 360;
        this._apunte = null;
        if (this.on.comandoInfo) this.on.comandoInfo('');
        if (this.on.hint) this.on.hint(`Cámara orientada a ${Number(e.data.azimuth).toFixed(1).replace('.', ',')}°.`);
        if (this.on.change) this.on.change('orientar');
        this.draw(); return true;
      }
      return false;
    }
    const c = this._comando;
    if (!c) return false;
    const limpio = String(texto).trim().replace(',', '.');
    const numeros = limpio.split(/[;\s]+/).map((v) => parseFloat(v)).filter((v) => isFinite(v));
    if (!numeros.length) return false;
    const f = clonar;
    if (c.tipo === 'rotar') {
      c.base = c.base || this.centroSeleccion();
      c.destino = { x: c.base.x + Math.cos((numeros[0] * Math.PI) / 180) * 10, y: c.base.y + Math.sin((numeros[0] * Math.PI) / 180) * 10 };
      c.fantasma = c.origen.map((e) => rotarEntidad(f(e), numeros[0], c.base));
    } else if (c.tipo === 'escalar') {
      if (!numeros[0]) return false;
      c.base = c.base || this.centroSeleccion();
      c.fantasma = c.origen.map((e) => escalarEntidad(f(e), numeros[0], c.base));
    } else if (c.tipo === 'mover' || c.tipo === 'copiar' || c.tipo === 'pegar') {
      const dx = numeros[0], dy = numeros.length > 1 ? numeros[1] : 0;
      c.base = c.base || { x: 0, y: 0 };
      c.destino = { x: c.base.x + dx, y: c.base.y + dy };
      c.fantasma = c.origen.map((e) => trasladar(f(e), dx, dy));
    } else if (c.tipo === 'espejo') {
      const a = (numeros[0] * Math.PI) / 180;
      c.base = c.base || this.centroSeleccion();
      c.destino = { x: c.base.x + Math.cos(a) * 10, y: c.base.y + Math.sin(a) * 10 };
      c.fantasma = c.origen.map((e) => espejarPorEje(f(e), c.base, c.destino));
    }
    this._aplicarComando();
    return true;
  }

  /** Escribe el comando en la geometría real y lo termina. */
  _aplicarComando() {
    const c = this._comando;
    if (!c) return;
    const inserta = c.tipo === 'copiar' || c.tipo === 'pegar';
    if (this.on.editStart) this.on.editStart();       // el deshacer guarda el estado previo
    if (inserta) {
      this.prj.entities.push(...c.fantasma);
      this.selection = new Set(c.fantasma.map((e) => e.id));
    } else {
      const ids = c.ids || [];
      c.fantasma.forEach((f, j) => {
        if (ids[j]) f.id = ids[j];                       // el fantasma recupera su identidad
        const i = this.prj.entities.findIndex((e) => e.id === f.id);
        if (i >= 0) this.prj.entities[i] = f;
      });
      if (ids.length) this.selection = new Set(ids);
    }
    const cuanto = this._valorComando();
    this._comando = null; this._fantasma = false;
    if (this.on.comando) this.on.comando(null);
    if (this.on.hint) {
      const nombre = { mover: 'Movido', copiar: 'Copiado', pegar: 'Pegado', rotar: 'Girado', escalar: 'Escalado', espejo: 'Espejo' }[c.tipo] || 'Aplicado';
      this.on.hint(`${nombre}${cuanto ? ': ' + cuanto : ''}.`);
    }
    if (this.on.change) this.on.change('editar');
    this.draw();
  }

  /** Qué se le pide al usuario en cada fase, para la barra de estado y la ayuda flotante. */
  _textoComando() {
    const c = this._comando;
    if (!c) return '';
    const nombres = { mover: 'MOVER', copiar: 'COPIAR', pegar: 'PEGAR', rotar: 'GIRAR', escalar: 'ESCALAR', espejo: 'ESPEJO' };
    const que = nombres[c.tipo] || c.tipo.toUpperCase();
    const mas = '(o escriba el valor y pulse Enter)';
    if (c.fase === 'base') return `${que}: haga clic en el punto base ${c.tipo === 'rotar' || c.tipo === 'escalar' ? '(centro de la operación) ' : ''}${mas}. Esc cancela.`;
    if (c.fase === 'referencia') return `${que}: haga clic en el extremo de la longitud de referencia ${mas}. Esc cancela.`;
    return `${que}: haga clic en el destino ${mas}. Esc cancela.`;
  }

  /** Dibuja la vista previa del comando: la copia transformada y la guía desde el punto base. */
  _pintarComando() {
    const c = this._comando;
    if (!c || !c.fantasma || !c.fantasma.length) return;
    const ctx = this.ctx;
    const capa = { color: '#7dd3fc' };
    ctx.save();
    ctx.setLineDash([5, 4]);
    this._fantasma = true;
    for (const e of c.fantasma) this._entity(e, capa);
    this._fantasma = false;
    ctx.setLineDash([]);
    if (c.base) {
      const x = this.sx(c.base.x), y = this.sy(c.base.y);
      ctx.strokeStyle = '#ffd166'; ctx.fillStyle = '#ffd166'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(x - 6, y); ctx.lineTo(x + 6, y); ctx.moveTo(x, y - 6); ctx.lineTo(x, y + 6); ctx.stroke();
      if (c.destino) {
        const dx = this.sx(c.destino.x), dy = this.sy(c.destino.y);
        ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(dx, dy); ctx.stroke();
        ctx.setLineDash([]);
        if (c.tipo === 'rotar') {
          const r = Math.hypot(dx - x, dy - y);
          ctx.beginPath(); ctx.arc(x, y, Math.max(4, r), 0, Math.PI * 2); ctx.stroke();
        }
        const texto = this._valorComando();
        if (texto) {
          ctx.font = '11px system-ui';
          const w = ctx.measureText(texto).width + 10;
          ctx.fillStyle = 'rgba(12,15,20,0.92)';
          ctx.fillRect(dx + 10, dy - 22, w, 16);
          ctx.fillStyle = '#e6edf3';
          ctx.fillText(texto, dx + 15, dy - 10);
        }
      }
    }
    ctx.restore();
  }

  /* ---------------------- tiradores (grips) ---------------------- */

  /**
   * Tiradores visibles de la selección, en coordenadas de pantalla. Es público porque las pruebas
   * y el panel de propiedades lo usan para saber dónde están los mangos de edición.
   */
  tiradoresVisibles() {
    const out = [];
    if (this.modo3d || !this.selection.size) return out;
    for (const e of this.selected()) {
      const ts = tiradoresDe(e, { alcanceMango: this._mangoCamara() });
      for (const t of ts) {
        out.push({ id: e.id, papel: t.papel, indice: t.indice, etiqueta: t.etiqueta,
          x: t.p.x, y: t.p.y, px: this.sx(t.p.x), py: this.sy(t.p.y) });
      }
    }
    return out;
  }

  /** Tirador más cercano al punto de pantalla `p`, si está a la distancia de agarre. */
  _tiradorCerca(p) {
    let mejor = null, dmejor = Infinity;
    const alcance = Math.max(9, (this.prefs.tamanoTirador || 6) + 4);
    for (const t of this.tiradoresVisibles()) {
      const d = Math.hypot(t.px - p.x, t.py - p.y);
      if (d < dmejor) { dmejor = d; mejor = t; }
    }
    return dmejor <= alcance ? mejor : null;
  }

  /** El tirador real de la entidad (con sus coordenadas recién calculadas). */
  _tiradorDe(e, agarre) {
    const t = tiradoresDe(e, { alcanceMango: this._mangoCamara() })
      .find((x) => x.papel === agarre.papel && x.indice === agarre.indice);
    return t || { p: { ...(e.points[0] || { x: 0, y: 0 }) }, papel: agarre.papel, indice: agarre.indice, etiqueta: agarre.etiqueta };
  }

  /** Punto de referencia para orto y polar mientras se arrastra un tirador. */
  _baseTirador(e, t) {
    const pts = e.points || [];
    if (t.papel === 'vertice' && t.indice > 0) return pts[t.indice - 1] || pts[0];
    if (t.papel === 'medio') return pts[t.indice] || pts[0];
    return pts[0] || null;
  }

  /** Largo del mango de orientación de una cámara: 2 m, o lo que sea visible en pantalla. */
  _mangoCamara() {
    return Math.max(0.4, Math.min(6, 40 / (this.scale || 20)));
  }

  /** Lo que se va escribiendo junto al cursor mientras se arrastra (longitud, radio, ángulo…). */
  _textoTirador(e, t, destino) {
    const f = (v, u = 2) => Number(v).toFixed(u).replace('.', ',');
    switch (t.papel) {
      case 'radio': return `Radio ${f(e.radius || (e.data && e.data.radio) || 0)} m`;
      case 'anguloInicio': return `Inicio ${f(t.p ? Math.atan2(destino.y - e.points[0].y, destino.x - e.points[0].x) * 180 / Math.PI : 0, 1)}°`;
      case 'anguloFin': return `Fin ${f(e.endAngle || 0, 1)}°`;
      case 'altura': return `Alto del texto ${f(e.data && e.data.height, 2)} m`;
      case 'direccion': return `Orientación ${f(e.data && e.data.azimuth, 1)}°`;
      case 'esquina': case 'lado': return e.type === 'image'
        ? `${f(e.data.width, 2)} × ${f(e.data.heightM || e.data.width, 2)} m`
        : `${f(areaDe(e))} m²`;
      case 'medio': return `Insertar vértice · ${f(longitudDe(e))} m`;
      default: return `${f(longitudDe(e))} m`;
    }
  }

  /** Pinta los tiradores: cuadrado para vértices, rombo para insertar, círculo para radios y giros. */
  _pintarTiradores() {
    const q = this.prefs, ctx = this.ctx;
    const lado = Math.max(0, q.tamanoTirador);
    if (!lado) return;
    const ts = this.tiradoresVisibles();
    const hov = this._tiradorHover;
    for (const t of ts) {
      const esHover = hov && hov.id === t.id && hov.papel === t.papel && hov.indice === t.indice;
      const l = lado * (esHover ? 1.6 : 1);
      ctx.fillStyle = esHover ? '#ffd166' : q.colorSeleccion;
      ctx.strokeStyle = '#0b0e12'; ctx.lineWidth = 1;
      // El mango de giro se pinta redondo y con un arco, para que se distinga de los vértices
      const redondo = ['radio', 'anguloInicio', 'anguloFin', 'altura', 'direccion', 'rotacion'].includes(t.papel);
      const rombo = ['medio', 'lado'].includes(t.papel);
      ctx.beginPath();
      if (redondo) ctx.arc(t.px, t.py, l / 2, 0, Math.PI * 2);
      else if (rombo) {
        ctx.moveTo(t.px, t.py - l / 2); ctx.lineTo(t.px + l / 2, t.py);
        ctx.lineTo(t.px, t.py + l / 2); ctx.lineTo(t.px - l / 2, t.py); ctx.closePath();
      } else ctx.rect(t.px - l / 2, t.py - l / 2, l, l);
      ctx.fill(); ctx.stroke();
    }
    // Etiqueta del tirador señalado: qué se mueve al arrastrarlo
    const activo = hov || (this._agarre ? { ...this._agarre.tirador, px: this.sx(this._agarre.tirador.p.x), py: this.sy(this._agarre.tirador.p.y) } : null);
    const texto = this._agarre ? this._etiquetaTirador : (activo ? activo.etiqueta : '');
    if (activo && texto) {
      ctx.font = '11px system-ui';
      const w = ctx.measureText(texto).width + 10;
      const x = Math.min(activo.px + 12, this.canvas.width / (window.devicePixelRatio || 1) - w - 4);
      ctx.fillStyle = 'rgba(12,15,20,0.9)';
      ctx.fillRect(x, activo.py - 20, w, 16);
      ctx.fillStyle = '#e6edf3';
      ctx.fillText(texto, x + 5, activo.py - 8);
    }
  }

  /* ---------------------- utilidades de edición ---------------------- */
  rotate(ids, angleDeg, base) {
    const a = rad(angleDeg);
    for (const e of this.prj.entities) {
      if (!ids.includes(e.id) || !e.points) continue;
      const c = base || { x: e.points.reduce((s, p) => s + p.x, 0) / e.points.length, y: e.points.reduce((s, p) => s + p.y, 0) / e.points.length };
      e.points = e.points.map((p) => {
        const dx = p.x - c.x, dy = p.y - c.y;
        return { x: c.x + dx * Math.cos(a) - dy * Math.sin(a), y: c.y + dx * Math.sin(a) + dy * Math.cos(a) };
      });
      if (e.data.azimuth !== undefined) e.data.azimuth = (e.data.azimuth + angleDeg + 360) % 360;
    }
    this.draw();
  }

  /**
   * Transformaciones sobre la selección (§9). Todas devuelven cuántas entidades han cambiado.
   * El punto base es el centro de la selección si no se da otro, que es lo que hace AutoCAD
   * cuando se transforma un grupo de objetos a la vez.
   */
  _aplicarATodos(ids, fn, base) {
    const sel = this.prj.entities.filter((e) => ids.includes(e.id));
    if (!sel.length) return 0;
    const c = base || this._centroDe(sel);
    sel.forEach((e) => fn(e, c));
    this.draw();
    return sel.length;
  }

  _centroDe(sel) {
    let n = 0, x = 0, y = 0;
    for (const e of sel) {
      const c = centroideDe(e);
      x += c.x; y += c.y; n++;
    }
    return n ? { x: x / n, y: y / n } : { x: 0, y: 0 };
  }

  /** Centro de la selección actual (lo usa la aplicación para rotar y escalar por un punto). */
  centroSeleccion() { return this._centroDe(this.selected()); }

  mover(ids, dx, dy) { return this._aplicarATodos(ids, (e) => trasladar(e, Number(dx) || 0, Number(dy) || 0)); }
  escalar(ids, factor, base) { return this._aplicarATodos(ids, (e, c) => escalarEntidad(e, Number(factor) || 1, c), base); }
  espejar(ids, eje, base) { return this._aplicarATodos(ids, (e, c) => espejarEntidad(e, eje === 'h' ? 'h' : 'v', c), base); }

  /**
   * Operaciones sobre los vértices de la selección: `insertar` añade uno en el punto medio del
   * tramo indicado, `borrar` quita el último (o el de índice dado) y `cerrar` abre o cierra.
   */
  vertices(ids, accion, indice) {
    const sel = this.prj.entities.filter((e) => ids.includes(e.id));
    let n = 0;
    for (const e of sel) {
      const pts = e.points || [];
      if (accion === 'insertar') {
        const i = Math.max(0, Math.min(indice === undefined ? pts.length - 1 : indice, pts.length - 1));
        const a = pts[i], b = pts[i + 1] || (e.closed ? pts[0] : null);
        if (a && b && insertarVertice(e, i + 1, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 })) n++;
      } else if (accion === 'borrar') {
        const i = indice === undefined ? pts.length - 1 : indice;
        if (borrarVertice(e, i)) n++;
      } else if (accion === 'cerrar') {
        if (cerrarEntidad(e)) n++;
      }
    }
    this.draw();
    return n;
  }

  duplicate(ids, dx = 1, dy = -1) {
    const out = [];
    for (const e of this.prj.entities) {
      if (!ids.includes(e.id)) continue;
      const c = JSON.parse(JSON.stringify(e));
      c.id = e.id + '_c' + Math.random().toString(36).slice(2, 6);
      c.points = (c.points || []).map((p) => ({ x: p.x + dx, y: p.y + dy }));
      out.push(c);
    }
    this.prj.entities.push(...out);
    this.selection = new Set(out.map((e) => e.id));
    this.draw();
    return out;
  }

  /** Exporta la vista actual a PNG. */
  toPng(scaleFactor = 2) {
    const src = this.canvas;
    const c = document.createElement('canvas');
    c.width = src.width * scaleFactor / (window.devicePixelRatio || 1);
    c.height = src.height * scaleFactor / (window.devicePixelRatio || 1);
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#12151a'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return new Promise((res) => c.toBlob((b) => res(b), 'image/png'));
  }
}
