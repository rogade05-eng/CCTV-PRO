/**
 * CCTV DESIGN PRO — Puente con el shell de escritorio (SQLite y conversor DWG)
 *
 * El programa funciona **igual** en el navegador y dentro del ejecutable de Windows. Este archivo
 * es el único que sabe que existe un shell: si no lo hay (`window.__TAURI__` ausente), todas las
 * funciones contestan «no disponible» y el resto del programa sigue con el catálogo y las reglas
 * que trae de serie. Ninguna función de cálculo depende de esto (§3, §42).
 *
 * Lo que aporta cuando SÍ hay shell:
 *   · Base de datos SQLite propia (§32): catálogo, reglas, proyectos, copias y auditoría.
 *   · Conversor DWG local (§9): ejecuta `tools/converter/` y devuelve el DXF.
 *   · Ficheros del proyecto dentro de la carpeta portable (§35).
 *
 * Este módulo no toca el DOM: se puede probar bajo Node.
 */

/** Tablas que la aplicación espera encontrar en la base (contraste con el esquema del shell). */
export const TABLAS_ESPERADAS = ['meta', 'catalog_items', 'rules', 'projects', 'backups', 'audit', 'converters'];

/** Columnas que la aplicación escribe en `catalog_items`, en el mismo orden que el INSERT. */
export const COLUMNAS_CATALOGO = ['id', 'categoria', 'fabricante', 'modelo', 'nombre', 'unidad', 'precio', 'especif', 'actualizado'];

export const SQL_INSERT_CATALOGO =
  `INSERT INTO catalog_items (${COLUMNAS_CATALOGO.join(', ')}) VALUES (${COLUMNAS_CATALOGO.map((_, i) => '?' + (i + 1)).join(', ')})
   ON CONFLICT(id) DO UPDATE SET categoria=excluded.categoria, fabricante=excluded.fabricante,
     modelo=excluded.modelo, nombre=excluded.nombre, unidad=excluded.unidad, precio=excluded.precio,
     especif=excluded.especif, actualizado=excluded.actualizado`;

export const SQL_INSERT_REGLA =
  `INSERT INTO rules (clave, valor, unidad, etiqueta, grupo, ayuda) VALUES (?, ?, ?, ?, ?, ?)
   ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor, unidad=excluded.unidad,
     etiqueta=excluded.etiqueta, grupo=excluded.grupo, ayuda=excluded.ayuda`;

/* ------------------------------------------------------------------ disponibilidad */

/** ¿Estamos dentro del ejecutable de escritorio? (en el navegador, siempre false) */
export function hayShell() {
  const w = typeof window !== 'undefined' ? window : null;
  return !!(w && w.__TAURI__ && w.__TAURI__.core && typeof w.__TAURI__.core.invoke === 'function');
}

/** Invoca un comando del shell. Sin shell devuelve `null` en lugar de fallar. */
export async function invocar(cmd, args = {}) {
  if (!hayShell()) return null;
  return window.__TAURI__.core.invoke(cmd, args);
}

/* ------------------------------------------------------------------ conversiones puras */

/** Artículo del catálogo → fila de la base de datos. */
export function articuloAFila(item, fecha = new Date().toISOString()) {
  return [
    String(item.id),
    String(item.category || 'otros'),
    String(item.manufacturer || ''),
    String(item.model || ''),
    String(item.name || item.model || item.id),
    String(item.unit || 'ud'),
    Number(item.price) || 0,
    JSON.stringify(item.specs || {}),
    fecha,
  ];
}

/** Fila de la base de datos → artículo del catálogo (con las características ya deserializadas). */
export function filaAArticulo(fila) {
  let specs = {};
  try { specs = fila.especif ? JSON.parse(fila.especif) : (fila.specs || {}); } catch { specs = {}; }
  return {
    id: fila.id,
    category: fila.categoria || fila.category || 'otros',
    manufacturer: fila.fabricante || fila.manufacturer || '',
    model: fila.modelo || fila.model || '',
    name: fila.nombre || fila.name || fila.id,
    unit: fila.unidad || fila.unit || 'ud',
    price: Number(fila.precio !== undefined ? fila.precio : fila.price) || 0,
    specs,
  };
}

/** Catálogo del programa → objeto listo para guardar en SQLite. */
export function catalogoARegistros(catalogo, fecha) {
  return {
    version: catalogo.version || 1,
    moneda: catalogo.currency || 'EUR',
    filas: (catalogo.items || []).map((i) => articuloAFila(i, fecha)),
    sql: SQL_INSERT_CATALOGO,
  };
}

/** Reglas del proyecto → filas para la base (definiciones + valor vigente). */
export function reglasARegistros(definiciones, valores, fecha) {
  return (definiciones || []).map((d) => [
    d.key, Number(valores[d.key] !== undefined ? valores[d.key] : d.def) || 0,
    d.unit || '', d.label || d.key, d.group || '', d.help || '',
  ]).map((f, i) => ({ fila: f, definicion: (definiciones || [])[i], fecha }));
}

/** Filas de `rules` → mapa clave→valor que usan los motores de cálculo. */
export function reglasAMapa(filas) {
  const mapa = {};
  for (const f of filas || []) {
    if (f && f.clave !== undefined) mapa[f.clave] = Number(f.valor);
    else if (f && f.key !== undefined) mapa[f.key] = Number(f.value);
  }
  return mapa;
}

/* ------------------------------------------------------------------ operaciones con el shell */

/** Estado del shell: base de datos, versión de SQLite y conversores disponibles. */
export async function estado() {
  const info = await invocar('info_shell');
  if (!info) return { disponible: false, motivo: 'sin shell (ejecutándose en el navegador)' };
  return {
    disponible: true,
    shell: info.shell,
    version: info.version,
    plataforma: info.plataforma,
    arquitectura: info.arquitectura,
    raiz: info.raiz,
    baseDeDatos: info.baseDeDatos,
    conversores: info.conversores || [],
  };
}

/** Prepara la base y carga las semillas del programa (idempotente). */
export async function inicializar() {
  return invocar('db_inicializa');
}

export async function consultar(sql, params) {
  const r = await invocar('db_consulta', { sql, params: params || [] });
  return r || [];
}

export async function ejecutar(sql, params) {
  const r = await invocar('db_ejecuta', { sql, params: params || [] });
  return r ? r.filas : 0;
}

/** Catálogo guardado en la base; `null` si no hay shell o la base está vacía. */
export async function cargarCatalogo() {
  if (!hayShell()) return null;
  const filas = await consultar('SELECT id, categoria, fabricante, modelo, nombre, unidad, precio, especif FROM catalog_items ORDER BY categoria, id');
  if (!filas.length) return null;
  const meta = await consultar('SELECT clave, valor FROM meta');
  const porClave = Object.fromEntries((meta || []).map((m) => [m.clave, m.valor]));
  return {
    version: Number(porClave.catalogo_version) || 1,
    currency: porClave.moneda || 'EUR',
    items: filas.map(filaAArticulo),
    origen: 'sqlite',
  };
}

/** Reglas guardadas en la base; `null` si no hay shell o la tabla está vacía. */
export async function cargarReglas() {
  if (!hayShell()) return null;
  const filas = await consultar('SELECT clave, valor FROM rules');
  if (!filas.length) return null;
  return reglasAMapa(filas);
}

/** Guarda el catálogo completo y devuelve cuántos artículos quedaron en la base. */
export async function guardarCatalogo(catalogo) {
  if (!hayShell()) return 0;
  const registros = catalogoARegistros(catalogo);
  let n = 0;
  for (const fila of registros.filas) {
    n += await ejecutar(registros.sql, fila);
  }
  await ejecutar('INSERT INTO meta (clave, valor) VALUES (?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor', ['catalogo_version', String(registros.version)]);
  await ejecutar('INSERT INTO meta (clave, valor) VALUES (?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor', ['moneda', registros.moneda]);
  await ejecutar('INSERT INTO audit (fecha, accion, detalle) VALUES (?, ?, ?)', [new Date().toISOString(), 'catalogo:guardar', `${n} artículos`]);
  return n;
}

/** Guarda las reglas vigentes del proyecto. */
export async function guardarReglas(definiciones, valores) {
  if (!hayShell()) return 0;
  let n = 0;
  for (const r of reglasARegistros(definiciones, valores)) {
    n += await ejecutar(SQL_INSERT_REGLA, r.fila);
  }
  await ejecutar('INSERT INTO audit (fecha, accion, detalle) VALUES (?, ?, ?)', [new Date().toISOString(), 'reglas:guardar', `${n} reglas`]);
  return n;
}

/** Guarda el proyecto (.cctv) en la base, con la copia de seguridad anterior. */
export async function guardarProyecto(nombre, cctv) {
  if (!hayShell()) return null;
  return invocar('db_ejecuta', {
    sql: 'INSERT INTO projects (nombre, codigo, cliente, modificado, version, datos) VALUES (?, ?, ?, ?, 1, ?) ON CONFLICT(nombre) DO UPDATE SET modificado=excluded.modificado, codigo=excluded.codigo, cliente=excluded.cliente, datos=excluded.datos, version = projects.version + 1',
    params: [nombre, (cctv.meta || {}).code || '', (cctv.meta || {}).client || '', new Date().toISOString(), JSON.stringify(cctv)],
  });
}

export async function listarProyectos() {
  return consultar('SELECT id, nombre, codigo, cliente, modificado, version FROM projects ORDER BY modificado DESC');
}

export async function copiasDe(nombre) {
  return consultar('SELECT fecha, motivo, length(datos) AS bytes FROM backups WHERE proyecto = ? ORDER BY fecha DESC LIMIT 20', [nombre]);
}

export async function auditoria(limite = 20) {
  return consultar('SELECT fecha, accion, detalle FROM audit ORDER BY id DESC LIMIT ?', [limite]);
}

/* ------------------------------------------------------------------ conversor DWG (§9) */

export async function estadoConversor() {
  const r = await invocar('conversor_estado');
  return r || { carpeta: '', conversores: [] };
}

export async function convertirDwg(entrada, salida) {
  return invocar('conversor_convertir', { entrada, salida });
}

/**
 * Convierte un DWG que está en memoria y devuelve el DXF (en Base64) sin pasar por el disco
 * de la interfaz: el shell escribe el DWG temporal, ejecuta el conversor local y devuelve el
 * DXF producido. Es la ruta que usa «Convertir DWG e importar» (§9).
 */
export async function convertirDwgBytes(nombre, bytes) {
  if (!hayShell()) return null;
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  return invocar('conversor_convertir_base64', { nombre, base64: bytesABase64(u8) });
}

/* ------------------------------------------------------------------ ficheros portables (§35) */

export async function leerTexto(ruta) {
  return invocar('leer_texto', { ruta });
}

export async function escribirTexto(ruta, contenido) {
  return invocar('escribir_texto', { ruta, contenido });
}

/* ------------------------------- binario (DWG, DXF binario, ZIP, PDF) -------------------------------
 * Los ficheros binarios NO pueden viajar como texto: si un DWG se escribiera carácter a carácter,
 * cada byte mayor de 127 se convertiría en dos bytes UTF-8 y el fichero quedaría corrupto
 * (justo el fallo que hacía que la conversión DWG → DXF no encontrara su entrada).
 * Por eso el shell recibe y devuelve los bytes en Base64, que es texto seguro de 7 bits.
 */

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/** Bytes → Base64 (implementación propia: no depende de `btoa` ni del entorno). */
export function bytesABase64(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  let out = '';
  let i = 0;
  for (; i + 3 <= u8.length; i += 3) {
    const n = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + B64[n & 63];
  }
  const resto = u8.length - i;
  if (resto === 1) {
    const n = u8[i] << 16;
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + '==';
  } else if (resto === 2) {
    const n = (u8[i] << 16) | (u8[i + 1] << 8);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + '=';
  }
  return out;
}

const B64_REV = (() => {
  const t = new Uint8Array(256);
  for (let i = 0; i < B64.length; i++) t[B64.charCodeAt(i)] = i;
  return t;
})();

/** Base64 → bytes. Acepta saltos de línea y devuelve el mismo contenido byte a byte. */
export function base64ABytes(b64) {
  const limpio = String(b64 == null ? '' : b64).replace(/[^A-Za-z0-9+/=]/g, '');
  const relleno = limpio.endsWith('==') ? 2 : limpio.endsWith('=') ? 1 : 0;
  const out = new Uint8Array(Math.max(0, (limpio.length / 4) * 3 - relleno));
  let o = 0;
  for (let i = 0; i + 4 <= limpio.length; i += 4) {
    const n = (B64_REV[limpio.charCodeAt(i)] << 18) | (B64_REV[limpio.charCodeAt(i + 1)] << 12) |
      (B64_REV[limpio.charCodeAt(i + 2)] << 6) | B64_REV[limpio.charCodeAt(i + 3)];
    if (o < out.length) out[o++] = (n >> 16) & 255;
    if (o < out.length) out[o++] = (n >> 8) & 255;
    if (o < out.length) out[o++] = n & 255;
  }
  return out;
}

/** Guarda bytes (DWG, ZIP, PDF…) en la carpeta portable. Devuelve los bytes escritos o `null`. */
export async function escribirBinario(ruta, bytes) {
  if (!hayShell()) return null;
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  const r = await invocar('escribir_binario', { ruta, base64: bytesABase64(u8), bytes: u8.length });
  return r ? r.bytes : null;
}

/** Lee un fichero binario de la carpeta portable. Devuelve `{bytes, ruta, tamano}` o `null`. */
export async function leerBinario(ruta) {
  if (!hayShell()) return null;
  const r = await invocar('leer_binario', { ruta });
  if (!r || !r.base64) return null;
  const bytes = base64ABytes(r.base64);
  return { bytes, ruta: r.ruta || ruta, tamano: r.bytes, correcto: r.bytes === bytes.length };
}

export async function listarCarpeta(ruta) {
  const r = await invocar('listar_carpeta', { ruta });
  return r ? r.entradas : [];
}

/* ------------------------------------------------------------------ resumen para la interfaz */

/** Texto corto del estado del shell, para la barra de estado y los paneles. */
export function resumenEstado(est) {
  if (!est || !est.disponible) return 'Navegador · catálogo de serie (sin base de datos SQLite)';
  const bd = est.baseDeDatos || {};
  const conv = (est.conversores || []).length;
  return `Escritorio ${est.plataforma}/${est.arquitectura} · SQLite ${bd.sqlite} · ` +
    `${bd.articulos || 0} artículos · ${bd.reglas || 0} reglas · ` +
    (conv ? `${conv} conversor(es) DWG disponible(s)` : 'sin conversor DWG (el programa sigue con DXF)');
}
