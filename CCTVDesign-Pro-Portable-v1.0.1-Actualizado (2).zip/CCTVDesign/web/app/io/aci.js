/**
 * CCTV DESIGN PRO — Colores del plano (índice ACI de AutoCAD, §9)
 *
 * Un plano real no se ve si se ignora su color, y mucho menos si se ignora su capa. Este módulo
 * resuelve las dos cosas sin depender del navegador, así que se prueba en Node:
 *
 *   · Tabla ACI completa (256 colores): la paleta de AutoCAD para **fondo oscuro** (la del espacio
 *     modelo por defecto), que es la que corresponde a un lienzo negro como el nuestro. En ella el
 *     color 7 es blanco, y por eso se ve; los grises 250–255 son la rampa oscura de esa paleta, así
 *     que se aclaran cuando hacen falta (en la paleta de fondo claro, el mismo índice es gris medio).
 *   · Color verdadero (código 420 del DXF) cuando el plano lo trae.
 *   · Medida de contraste real (luminancia percibida) y aclarado automático de los colores que no
 *     se verían sobre el fondo oscuro del lienzo, conservando el tono.
 *   · Tres modos de color del plano importado: original, claro y monocromo.
 */

/** Color de la capa (BYLAYER): el elemento hereda el color de su capa. */
export const BYLAYER = 256;
/** Color del bloque (BYBLOCK): el elemento hereda el color de la inserción. */
export const BYBLOCK = 0;

/** Fondo del lienzo (el mismo que pinta el motor CAD). */
export const FONDO_LIENZO = '#12151a';
/** Fondo del papel, para PDF y planos impresos. */
export const FONDO_PAPEL = '#ffffff';
/** Contraste mínimo exigido para dar un color por visible sobre el fondo. */
export const MINIMO_CONTRASTE = 2.6;
/** Color del plano en modo «claro»: se ve sobre el lienzo oscuro sin competir con las capas de CCTV. */
export const CLARO_DEL_PLANO = '#c9d4e0';
/** Color único del modo monocromo (sobre fondo oscuro) y sobre papel. */
export const MONOCROMO_OSCURO = '#a9b6c6';
export const MONOCROMO_PAPEL = '#1f2937';

/** Tabla ACI: índice → 0xRRGGBB (posición 0 = BYBLOCK; 256 = BYLAYER, fuera de la tabla). */
export const ACI_TABLE = [
  0x000000, 0xff0000, 0xffff00, 0x00ff00, 0x00ffff, 0x0000ff, 0xff00ff, 0xffffff,
  0x808080, 0xc0c0c0, 0xff0000, 0xff7f7f, 0xa50000, 0xa55252, 0x7f0000, 0x7f3f3f,
  0x4c0000, 0x4c2626, 0x260000, 0x261313, 0xff3f00, 0xff9f7f, 0xa52900, 0xa56752,
  0x7f1f00, 0x7f4f3f, 0x4c1300, 0x4c2f26, 0x260900, 0x261713, 0xff7f00, 0xffbf7f,
  0xa55200, 0xa57c52, 0x7f3f00, 0x7f5f3f, 0x4c2600, 0x4c3926, 0x261300, 0x261c13,
  0xffbf00, 0xffdf7f, 0xa57c00, 0xa59152, 0x7f5f00, 0x7f6f3f, 0x4c3900, 0x4c4226,
  0x261c00, 0x262113, 0xffff00, 0xffff7f, 0xa5a500, 0xa5a552, 0x7f7f00, 0x7f7f3f,
  0x4c4c00, 0x4c4c26, 0x262600, 0x262613, 0xbfff00, 0xdfff7f, 0x7ca500, 0x91a552,
  0x5f7f00, 0x6f7f3f, 0x394c00, 0x424c26, 0x1c2600, 0x212613, 0x7fff00, 0xbfff7f,
  0x52a500, 0x7ca552, 0x3f7f00, 0x5f7f3f, 0x264c00, 0x394c26, 0x132600, 0x1c2613,
  0x3fff00, 0x9fff7f, 0x29a500, 0x67a552, 0x1f7f00, 0x4f7f3f, 0x134c00, 0x2f4c26,
  0x092600, 0x172613, 0x00ff00, 0x7fff7f, 0x00a500, 0x52a552, 0x007f00, 0x3f7f3f,
  0x004c00, 0x264c26, 0x002600, 0x132613, 0x00ff3f, 0x7fff9f, 0x00a529, 0x52a567,
  0x007f1f, 0x3f7f4f, 0x004c13, 0x264c2f, 0x002609, 0x135817, 0x00ff7f, 0x7fffbf,
  0x00a552, 0x52a57c, 0x007f3f, 0x3f7f5f, 0x004c26, 0x264c39, 0x002613, 0x13581c,
  0x00ffbf, 0x7fffdf, 0x00a57c, 0x52a591, 0x007f5f, 0x3f7f6f, 0x004c39, 0x264c42,
  0x00261c, 0x135858, 0x00ffff, 0x7fffff, 0x00a5a5, 0x52a5a5, 0x007f7f, 0x3f7f7f,
  0x004c4c, 0x264c4c, 0x002626, 0x135858, 0x00bfff, 0x7fdfff, 0x007ca5, 0x5291a5,
  0x005f7f, 0x3f6f7f, 0x00394c, 0x26427e, 0x001c26, 0x135858, 0x007fff, 0x7fbfff,
  0x0052a5, 0x527ca5, 0x003f7f, 0x3f5f7f, 0x00264c, 0x26397e, 0x001326, 0x131c58,
  0x003fff, 0x7f9fff, 0x0029a5, 0x5267a5, 0x001f7f, 0x3f4f7f, 0x00134c, 0x262f7e,
  0x000926, 0x131758, 0x0000ff, 0x7f7fff, 0x0000a5, 0x5252a5, 0x00007f, 0x3f3f7f,
  0x00004c, 0x26267e, 0x000026, 0x131358, 0x3f00ff, 0x9f7fff, 0x2900a5, 0x6752a5,
  0x1f007f, 0x4f3f7f, 0x13004c, 0x2f267e, 0x090026, 0x171358, 0x7f00ff, 0xbf7fff,
  0x5200a5, 0x7c52a5, 0x3f007f, 0x5f3f7f, 0x26004c, 0x39267e, 0x130026, 0x1c1358,
  0xbf00ff, 0xdf7fff, 0x7c00a5, 0x9152a5, 0x5f007f, 0x6f3f7f, 0x39004c, 0x42264c,
  0x1c0026, 0x581358, 0xff00ff, 0xff7fff, 0xa500a5, 0xa552a5, 0x7f007f, 0x7f3f7f,
  0x4c004c, 0x4c264c, 0x260026, 0x581358, 0xff00bf, 0xff7fdf, 0xa5007c, 0xa55291,
  0x7f005f, 0x7f3f6f, 0x4c0039, 0x4c2642, 0x26001c, 0x581358, 0xff007f, 0xff7fbf,
  0xa50052, 0xa5527c, 0x7f003f, 0x7f3f5f, 0x4c0026, 0x4c2639, 0x260013, 0x58131c,
  0xff003f, 0xff7f9f, 0xa50029, 0xa55267, 0x7f001f, 0x7f3f4f, 0x4c0013, 0x4c262f,
  0x260009, 0x581317, 0x000000, 0x656565, 0x666666, 0x999999, 0xcccccc, 0xffffff,
];

const hex2 = (n) => '#' + n.toString(16).padStart(6, '0');

/** Índice ACI → '#rrggbb'. Devuelve `null` para BYLAYER y BYBLOCK (no traen color propio). */
export function aciAHex(aci) {
  const i = Number(aci);
  if (!isFinite(i) || i <= 0 || i > 255) return null;
  return hex2(ACI_TABLE[i]);
}

const NOMBRES = { 1: 'Rojo', 2: 'Amarillo', 3: 'Verde', 4: 'Cian', 5: 'Azul', 6: 'Magenta', 7: 'Blanco/negro', 8: 'Gris oscuro', 9: 'Gris claro' };
for (let i = 10; i <= 249; i++) NOMBRES[i] = `Tono ${Math.floor((i - 10) / 10) + 1} · nivel ${(i - 10) % 10 + 1}`;
for (let i = 250; i <= 255; i++) NOMBRES[i] = 'Gris ' + i;
NOMBRES[0] = 'Según el bloque'; NOMBRES[256] = 'Según la capa';

export function nombreAci(aci) { return NOMBRES[Number(aci)] || ('ACI ' + aci); }
/** ¿El color se hereda de la capa (BYLAYER)? */
export const esByLayer = (aci) => Number(aci) === BYLAYER;
/** ¿El color se hereda del bloque (BYBLOCK)? */
export const esByBlock = (aci) => Number(aci) === BYBLOCK;

/* ------------------------------ medida y ajuste de contraste ------------------------------ */

/** Componentes de un '#rrggbb' (acepta también '#rgb'). */
export function componentes(hex) {
  let h = String(hex || '').trim().replace('#', '');
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
  return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
}

/**
 * Normaliza un color a `#rrggbb` en minúsculas. Acepta `#abc`, `abc`, `#AABBCC`, `0xAABBCC` y
 * números de 24 bits. Devuelve `null` si no es un color.
 */
export function normalizarHex(v) {
  if (typeof v === 'number') return isFinite(v) ? '#' + (Math.max(0, Math.min(0xffffff, Math.round(v)))).toString(16).padStart(6, '0') : null;
  const t = String(v === undefined || v === null ? '' : v).trim();
  const c = componentes(t.startsWith('0x') || t.startsWith('0X') ? t.slice(2) : t);
  return c ? aHex(c.r, c.g, c.b) : null;
}

export const aHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');

/**
 * Luminancia relativa (0 negro, 1 blanco) con la linealización de la luz (sRGB → lineal) que
 * usan las normas de contraste. Es la medida que distingue de verdad «no se ve» de «se ve»:
 * con una fórmula cuadrada simple, el negro sobre el fondo del lienzo daba 2,6 y se daba por
 * visible, cuando en realidad es indistinguible.
 */
export function luminancia(hex) {
  const c = componentes(hex);
  if (!c) return 0;
  const lin = (v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); };
  const l = 0.2126 * lin(c.r) + 0.7152 * lin(c.g) + 0.0722 * lin(c.b);
  return Math.round(l * 10000) / 10000;
}

/** Relación de contraste entre dos colores (1 = idénticos, 21 = blanco sobre negro). */
export function contraste(a, b) {
  const la = luminancia(a), lb = luminancia(b);
  return Math.round(((Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)) * 100) / 100;
}

const aHsl = ({ r, g, b }) => {
  const rf = r / 255, gf = g / 255, bf = b / 255;
  const max = Math.max(rf, gf, bf), min = Math.min(rf, gf, bf), l = (max + min) / 2;
  if (max === min) return { h: 0, s: 0, l };
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  const h = max === rf ? ((gf - bf) / d + (gf < bf ? 6 : 0)) : max === gf ? ((bf - rf) / d + 2) : ((rf - gf) / d + 4);
  return { h: h * 60, s, l };
};

const deHsl = ({ h, s, l }) => {
  if (s <= 0) { const v = l * 255; return aHex(v, v, v); }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const f = (t) => {
    let x = t; if (x < 0) x += 1; if (x > 1) x -= 1;
    if (x < 1 / 6) return p + (q - p) * 6 * x;
    if (x < 1 / 2) return q;
    if (x < 2 / 3) return p + (q - p) * (2 / 3 - x) * 6;
    return p;
  };
  const hh = (((h % 360) + 360) % 360) / 360;
  return aHex(f(hh + 1 / 3) * 255, f(hh) * 255, f(hh - 1 / 3) * 255);
};

/**
 * Ajusta un color para que se vea sobre un fondo, conservando el tono (que el rojo siga siendo
 * rojo). Funciona en los dos sentidos:
 *
 *   · fondo oscuro (el lienzo): aclara lo que no se ve. Un plano trae colores pensados para papel
 *     blanco: el negro de la capa 0, el azul puro (ACI 5) o los grises bajos desaparecerían.
 *   · fondo claro (el papel del PDF): oscurece lo que no se ve, en particular la tinta blanca
 *     del índice 7, que en pantalla es blanca y en papel debe ser negro.
 *
 * @returns {{color:string, cambiado:boolean, inicial:string, contraste:number, tinta?:boolean}}
 */
export function ajustarParaFondo(hex, fondo = FONDO_LIENZO, minimo = MINIMO_CONTRASTE) {
  const c = componentes(hex);
  if (!c) return { color: hex, cambiado: false, inicial: hex, contraste: 0 };
  const inicial = contraste(hex, fondo);
  if (inicial >= minimo) return { color: hex, cambiado: false, inicial: hex, contraste: inicial };
  const oscuro = luminancia(fondo) < 0.2;
  const luz0 = luminancia(hex);
  // Tinta del color del papel: en CAD se invierte (blanco sobre negro, negro sobre blanco)
  if (oscuro && luz0 < 0.03) return { color: CLARO_DEL_PLANO, cambiado: true, inicial: hex, contraste: contraste(CLARO_DEL_PLANO, fondo), tinta: true };
  if (!oscuro && luz0 > 0.9) return { color: MONOCROMO_PAPEL, cambiado: true, inicial: hex, contraste: contraste(MONOCROMO_PAPEL, fondo), tinta: true };
  const { h, s, l } = aHsl(c);
  let nivel = l, mejor = hex;
  for (let i = 0; i < 40; i++) {
    nivel = oscuro ? Math.min(0.98, nivel + 0.03) : Math.max(0.02, nivel - 0.03);
    mejor = deHsl({ h, s: oscuro ? s : Math.min(1, s + 0.15), l: nivel });
    if (contraste(mejor, fondo) >= minimo) break;
  }
  if (contraste(mejor, fondo) < minimo) mejor = oscuro ? deHsl({ h, s: Math.max(0.15, s * 0.6), l: 0.84 }) : deHsl({ h, s: Math.min(1, s + 0.3), l: 0.24 });
  return { color: mejor, cambiado: true, inicial: hex, contraste: contraste(mejor, fondo) };
}

/** Atajo con el nombre que usa el lienzo: aclarar lo que no se ve sobre el fondo oscuro. */
export const aclararParaFondo = (hex, fondo = FONDO_LIENZO, minimo = MINIMO_CONTRASTE) => ajustarParaFondo(hex, fondo, minimo);

/* ---------------------------------- modos de color del plano ---------------------------------- */

/**
 * Modos de color de un plano importado:
 *   · `original`  — los colores del plano; solo se aclaran los que no se verían (§9).
 *   · `claro`     — toda la geometría importada en un color claro: el CCTV destaca sobre el plano.
 *   · `monocromo` — gris claro suave, como fondo de trabajo.
 */
export const MODOS_COLOR = ['original', 'claro', 'monocromo'];
export const ETIQUETA_MODO = {
  original: 'Colores del plano',
  claro: 'Claro (recomendado)',
  monocromo: 'Monocromo tenue',
};

/** Color con el que se dibuja una capa del plano en pantalla. */
export function colorDePlano(hex, modo = 'original', fondo = FONDO_LIENZO) {
  if (modo === 'claro') return CLARO_DEL_PLANO;
  if (modo === 'monocromo') return MONOCROMO_OSCURO;
  return ajustarParaFondo(hex, fondo).color;
}

/** Color con el que se dibuja una capa del plano en un plano impreso (fondo blanco). */
export function colorDePlanoPapel(hex, modo = 'original') {
  if (modo === 'claro') return '#4a5568';
  if (modo === 'monocromo') return MONOCROMO_PAPEL;
  return ajustarParaFondo(hex || '#333333', FONDO_PAPEL).color;
}

/** Color verdadero (código 420 del DXF, entero de 24 bits) → '#rrggbb'. */
export function hexDeVerdadero(n) {
  const v = Math.max(0, Math.min(0xffffff, Number(n) || 0));
  return '#' + v.toString(16).padStart(6, '0');
}

/**
 * Resuelve el color de un elemento del plano aplicando la herencia del formato DXF:
 * color propio del elemento → color del bloque (BYBLOCK) → color de la capa (BYLAYER).
 * @param {{aci?:number, colorVerdadero?:number, byBlock?:boolean, colorUtil?:string}} entidad
 * @param {{aci?:number, color?:string, colorVerdadero?:number}} capa
 */
export function resolverColor(entidad = {}, capa = {}) {
  if (entidad.colorVerdadero !== undefined && entidad.colorVerdadero !== null) return hexDeVerdadero(entidad.colorVerdadero);
  if (entidad.aci !== undefined && entidad.aci !== null && !esByLayer(entidad.aci) && !esByBlock(entidad.aci)) return aciAHex(entidad.aci);
  if (entidad.colorUtil) return entidad.colorUtil;
  if (capa.colorVerdadero !== undefined && capa.colorVerdadero !== null) return hexDeVerdadero(capa.colorVerdadero);
  if (capa.aci !== undefined && capa.aci !== null && !esByLayer(capa.aci) && !esByBlock(capa.aci)) return aciAHex(capa.aci);
  return capa.color || null;
}

/** Color '#rrggbb' → ACI más parecido (para exportar el DXF conservando el color). */
export function aciParecido(hex) {
  const c = componentes(hex);
  if (!c) return 7;
  let mejor = 7, mejorD = Infinity;
  for (let i = 1; i <= 255; i++) {
    const x = ACI_TABLE[i];
    const dr = ((x >> 16) & 255) - c.r, dg = ((x >> 8) & 255) - c.g, db = (x & 255) - c.b;
    const d = 0.299 * dr * dr + 0.587 * dg * dg + 0.114 * db * db;
    if (d < mejorD) { mejorD = d; mejor = i; }
  }
  return mejor;
}

