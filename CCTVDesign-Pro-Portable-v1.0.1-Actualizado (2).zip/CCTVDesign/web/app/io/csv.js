/**
 * CCTV DESIGN PRO — CSV y XML (CP CCTV §29)
 */

export function toCsv(rows, sep = ';', dec = ',') {
  const esc = (v) => {
    if (v === null || v === undefined) return '';
    let s = String(v);
    if (typeof v === 'number' && dec === ',') s = s.replace('.', ',');
    return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return rows.map((r) => r.map(esc).join(sep)).join('\r\n');
}

/** Descarga texto. `bom` añade BOM UTF-8: solo procede en CSV para que Excel detecte la codificación. */
export function downloadText(filename, text, mime = 'text/plain;charset=utf-8', bom = false) {
  const blob = new Blob([bom ? '\ufeff' + text : text], { type: mime });
  triggerDownload(blob, filename);
}

export function downloadBytes(filename, bytes, mime) {
  triggerDownload(new Blob([bytes], { type: mime }), filename);
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

const xmlEsc = (s) => String(s === null || s === undefined ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&apos;');

/** Serializa el proyecto a XML legible para integración futura (§39). */
export function projectToXml(prj, extra = {}) {
  const L = [];
  L.push('<?xml version="1.0" encoding="UTF-8"?>');
  L.push('<cctvProject version="1" generated="' + new Date().toISOString() + '">');
  L.push('  <meta>');
  for (const [k, v] of Object.entries(prj.meta)) L.push(`    <${k}>${xmlEsc(v)}</${k}>`);
  L.push('  </meta>');
  L.push('  <cameras>');
  for (const c of prj.entities.filter((e) => e.type === 'camera')) {
    L.push(`    <camera id="${xmlEsc(c.id)}" label="${xmlEsc(c.data.label)}" catalogId="${xmlEsc(c.data.catalogId)}" x="${c.points[0].x}" y="${c.points[0].y}" height="${c.data.height}" azimuth="${c.data.azimuth}" tilt="${c.data.tilt}" objective="${xmlEsc(c.data.objective)}" ip="${xmlEsc(c.data.ip)}" switch="${xmlEsc(c.data.switchId)}"/>`);
  }
  L.push('  </cameras>');
  L.push('  <devices>');
  for (const d of prj.entities.filter((e) => e.type === 'device')) {
    L.push(`    <device id="${xmlEsc(d.id)}" kind="${xmlEsc(d.data.kind)}" label="${xmlEsc(d.data.label)}" catalogId="${xmlEsc(d.data.catalogId)}" x="${d.points[0].x}" y="${d.points[0].y}" ip="${xmlEsc(d.data.ip)}"/>`);
  }
  L.push('  </devices>');
  L.push('  <links>');
  for (const cb of prj.entities.filter((e) => e.type === 'cable')) {
    L.push(`    <link from="${xmlEsc(cb.data.from)}" to="${xmlEsc(cb.data.to)}" geometric="${Number(cb.data.geometric).toFixed(2)}" supply="${Number(cb.data.supply).toFixed(2)}" status="${xmlEsc(cb.data.distanceStatus)}"/>`);
  }
  L.push('  </links>');
  for (const [key, value] of Object.entries(extra)) {
    L.push(`  <${key}>`);
    if (Array.isArray(value)) {
      for (const row of value) {
        const attrs = Object.entries(row).map(([k, v]) => `${k}="${xmlEsc(typeof v === 'number' ? +v.toFixed(4) : v)}"`).join(' ');
        L.push(`    <item ${attrs}/>`);
      }
    } else if (value && typeof value === 'object') {
      for (const [k, v] of Object.entries(value)) L.push(`    <${k}>${xmlEsc(typeof v === 'number' ? +v.toFixed(4) : v)}</${k}>`);
    }
    L.push(`  </${key}>`);
  }
  L.push('</cctvProject>');
  return L.join('\n');
}
