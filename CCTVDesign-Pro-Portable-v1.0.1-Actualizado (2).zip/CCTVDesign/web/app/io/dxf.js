/**
 * CCTV DESIGN PRO — DXF: importación y exportación (CP CCTV §8, §9, §29)
 *
 * ASCII R2000 (AC1015). Sin AutoCAD, sin ODA y sin librerías externas.
 * Importa entidades sueltas y BLOQUES con INSERT: definiciones con punto base,
 * escalado, rotación, matrices de inserción (MINSERT), bloques anidados y
 * atributos (ATTDEF/ATTRIB) convertidos en texto de plano.
 */
import { rad } from '../core/geometry.js?v=b441e3fc';
import { aciAHex, aciParecido, esByLayer, esByBlock } from './aci.js?v=b441e3fc';

const L = (out, code, value) => { out.push(String(code), String(value)); };

/**
 * Color que se escribe en el DXF. Si la capa conserva el índice del plano original se respeta
 * (así el DXF exportado mantiene los colores de siempre y no los aclarados para el lienzo).
 */
function aciFor(hex, aci) {
  if (aci !== undefined && aci !== null && Number(aci) > 0 && Number(aci) <= 255) return Number(aci);
  const map = { '#e8443a': 1, '#eab308': 2, '#2f6f4f': 3, '#0ea5e9': 4, '#3b82f6': 5, '#c084fc': 6, '#d4d4d8': 7, '#5b6b7c': 8, '#f2a33c': 30, '#8b5cf6': 200, '#14b8a6': 40, '#a3a3a3': 9, '#94a3b8': 251 };
  return map[(hex || '').toLowerCase()] || aciParecido(hex);
}

const num = (v, d = 0) => (v === undefined || v === null || v === '' || isNaN(Number(v)) ? d : Number(v));

/**
 * Nombre de capa válido para DXF: sin acentos (ANSI_1252 los destroza en otros CAD),
 * en mayúsculas y sin espacios ni caracteres prohibidos por el formato.
 */
export function dxfLayerName(name) {
  return String(name === undefined || name === null ? '' : name)
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toUpperCase().replace(/[^A-Z0-9_$\-.]/g, '_').replace(/_{2 }/g, '_').replace(/^$/, '0');
}

/**
 * Identificador de capa: el nombre del plano en mayúsculas. Un plano puede escribir «Muros» y
 * «MUROS» y son la misma capa; si el motor CAD comparase literalmente, la geometría no se
 * pintaría (era exactamente el fallo de «el plano importado no se ve»). El nombre original se
 * conserva aparte, en `layerInfo[id].name`, para mostrarlo tal cual en la interfaz.
 */
export function capaId(name) {
  const n = String(name === undefined || name === null ? '' : name).trim();
  return n ? n.toUpperCase() : '0';
}

/* ------------------------------- geometría ------------------------------- */
/* Matriz afín 2D: x' = a·x + c·y + e ; y' = b·x + d·y + f (igual que Canvas/PDF). */
const MID = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 });
const applyM = (m, p) => ({ x: m.a * p.x + m.c * p.y + m.e, y: m.b * p.x + m.d * p.y + m.f });
/** Composición: apply(compose(m, n), p) === apply(n, apply(m, p)) — primero m, después n. */
const compose = (m, n) => ({
  a: n.a * m.a + n.c * m.b, b: n.b * m.a + n.d * m.b,
  c: n.a * m.c + n.c * m.d, d: n.b * m.c + n.d * m.d,
  e: n.a * m.e + n.c * m.f + n.e, f: n.b * m.e + n.d * m.f + n.f });
const detM = (m) => m.a * m.d - m.b * m.c;
const scaleM = (m) => Math.sqrt(Math.abs(detM(m))) || 1;
const rotM = (m) => Math.atan2(m.b, m.a);
/** Matriz de un INSERT: traslación + rotación + escala, con punto base del bloque. */
function insertMatrix(ins, base = { x: 0, y: 0 }) {
  const r = rad(ins.rotation || 0);
  const cos = Math.cos(r), sin = Math.sin(r);
  const sx = ins.scale.x, sy = ins.scale.y;
  const m = { a: cos * sx, b: sin * sx, c: -sin * sy, d: cos * sy, e: 0, f: 0 };
  // p' = R·S·(p − base) + P  ⇒  traslación = P − R·S·base
  const t = applyM(m, base);
  m.e = num(ins.x) - t.x; m.f = num(ins.y) - t.y;
  return m;
}

/* --------------------------------- escritor -------------------------------- */

/** Bloques de símbolo que exporta el programa cuando opts.blocks = true (§8). */
const EXPORT_BLOCKS = [
  { name: 'CCTV_CAMARA', layer: 'CAMARAS', radius: 0.25, arm: 0.8, attr: 'ETIQUETA', desc: 'Simbolo de camara CCTV' },
  { name: 'CCTV_PTZ', layer: 'CAMARAS', radius: 0.3, arm: 0.9, attr: 'ETIQUETA', ptz: true, desc: 'Simbolo de camara PTZ CCTV' },
  { name: 'CCTV_EQUIPO', layer: 'EQUIPOS', radius: 0.35, arm: 0, attr: 'ETIQUETA', desc: 'Simbolo de equipo de red' },
];

/** Generador de handles hexadecimales (el DXF AC1015 identifica cada registro así). */
function handleGen(inicio = 0x30) {
  let n = inicio;
  return () => (n++).toString(16).toUpperCase();
}

/**
 * Escribe el DXF AC1015 con el grafo completo de handles y marcadores de subclase.
 * Sin esto, el archivo solo lo lee nuestro propio parser: AutoCAD, LibreDWG y ODA exigen
 * que cada registro declare su handle (código 5) y su propietario (330), y que las tablas
 * VPORT/LTYPE/LAYER/STYLE/BLOCK_RECORD existan. Es la diferencia entre «exportar un archivo»
 * y «exportar un DXF que otro CAD abre» (§29).
 */
function writeBlocks(out, h, recHandles) {
  L(out, 0, 'SECTION'); L(out, 2, 'BLOCKS');
  // Bloques de espacio (modelo/papel): todo DXF AC1015 los lleva vacíos
  for (const espacio of ['*Model_Space', '*Paper_Space']) {
    const hr = recHandles[espacio] || h();
    L(out, 0, 'BLOCK'); L(out, 5, h()); L(out, 330, hr);
    L(out, 100, 'AcDbEntity'); L(out, 8, '0'); L(out, 100, 'AcDbBlockBegin');
    L(out, 2, espacio); L(out, 70, 0);
    L(out, 10, 0); L(out, 20, 0); L(out, 30, 0); L(out, 3, espacio); L(out, 1, '');
    L(out, 0, 'ENDBLK'); L(out, 5, h()); L(out, 330, hr);
    L(out, 100, 'AcDbEntity'); L(out, 8, '0'); L(out, 100, 'AcDbBlockEnd');
  }
  for (const b of EXPORT_BLOCKS) {
    const hr = recHandles[b.name] || h();
    L(out, 0, 'BLOCK'); L(out, 5, h()); L(out, 330, hr);
    L(out, 100, 'AcDbEntity'); L(out, 8, b.layer); L(out, 100, 'AcDbBlockBegin');
    L(out, 2, b.name); L(out, 70, 0);
    L(out, 10, 0); L(out, 20, 0); L(out, 30, 0); L(out, 3, b.name); L(out, 1, '');
    // Geometría del símbolo: dentro del bloque vive en la capa 0 (se hereda la del INSERT)
    L(out, 0, 'CIRCLE'); L(out, 5, h()); L(out, 330, hr); L(out, 100, 'AcDbEntity'); L(out, 8, '0');
    L(out, 100, 'AcDbCircle'); L(out, 10, 0); L(out, 20, 0); L(out, 30, 0); L(out, 40, b.radius);
    if (b.arm) {
      L(out, 0, 'LINE'); L(out, 5, h()); L(out, 330, hr); L(out, 100, 'AcDbEntity'); L(out, 8, '0');
      L(out, 100, 'AcDbLine'); L(out, 10, 0); L(out, 20, 0); L(out, 30, 0); L(out, 11, b.arm); L(out, 21, 0); L(out, 31, 0);
    }
    if (b.ptz) {
      L(out, 0, 'LINE'); L(out, 5, h()); L(out, 330, hr); L(out, 100, 'AcDbEntity'); L(out, 8, '0');
      L(out, 100, 'AcDbLine'); L(out, 10, 0); L(out, 20, 0); L(out, 30, 0); L(out, 11, 0); L(out, 21, b.arm * 0.6); L(out, 31, 0);
    }
    // Atributo de etiqueta editable en el plano
    L(out, 0, 'ATTDEF'); L(out, 5, h()); L(out, 330, hr); L(out, 100, 'AcDbEntity'); L(out, 8, '0');
    L(out, 100, 'AcDbText'); L(out, 10, b.radius + 0.1); L(out, 20, b.radius + 0.1); L(out, 30, 0);
    L(out, 40, 0.35); L(out, 1, b.attr); L(out, 100, 'AcDbAttributeDefinition');
    L(out, 3, b.attr); L(out, 2, b.attr); L(out, 70, 0);
    L(out, 0, 'ENDBLK'); L(out, 5, h()); L(out, 330, hr);
    L(out, 100, 'AcDbEntity'); L(out, 8, '0'); L(out, 100, 'AcDbBlockEnd');
  }
  L(out, 0, 'ENDSEC');
}

/** Exporta el proyecto a DXF ASCII. opts.blocks escribe símbolos como bloques + INSERT. */
export function toDxf(prj, opts = {}) {
  const h = handleGen();
  const outHead = [], out = [];
  const hr = {};                                  // handle de la BLOCK_RECORD de cada bloque
  hr['*Model_Space'] = h(); hr['*Paper_Space'] = h();
  if (opts.blocks) for (const b of EXPORT_BLOCKS) hr[b.name] = h();
  const modelH = hr['*Model_Space'];

  /* --- TABLAS: VPORT, LTYPE, LAYER, STYLE y BLOCK_RECORD (§29) --- */
  L(out, 0, 'SECTION'); L(out, 2, 'TABLES');
  const tabla = (nombre, count, subclase) => {
    const ht = h();
    L(out, 0, 'TABLE'); L(out, 5, ht); L(out, 100, 'AcDbSymbolTable'); L(out, 2, nombre); L(out, 70, count);
    return { ht, rec: (tipo) => { const r = h(); L(out, 0, tipo); L(out, 5, r); L(out, 330, ht); L(out, 100, 'AcDbSymbolTableRecord'); if (subclase[tipo]) L(out, 100, subclase[tipo]); return r; } };
  };
  const vt = tabla('VPORT', 1, { VPORT: 'AcDbViewportTableRecord' });
  vt.rec('VPORT');
  L(out, 2, '*Active'); L(out, 70, 0);
  L(out, 10, 0); L(out, 20, 0); L(out, 11, 1); L(out, 21, 1);
  L(out, 12, 0); L(out, 22, 0); L(out, 13, 0); L(out, 23, 0); L(out, 14, 1); L(out, 24, 1);
  L(out, 15, 0); L(out, 25, 0); L(out, 16, 0); L(out, 26, 0); L(out, 36, 1);
  L(out, 17, 0); L(out, 27, 0); L(out, 37, 0); L(out, 40, 1000); L(out, 41, 1.5);
  L(out, 42, 50); L(out, 43, 0); L(out, 44, 0); L(out, 50, 0); L(out, 51, 0);
  L(out, 71, 0); L(out, 72, 100); L(out, 73, 1); L(out, 74, 3);
  L(out, 75, 0); L(out, 76, 0); L(out, 77, 0); L(out, 78, 0);
  L(out, 0, 'ENDTAB');

  const lt = tabla('LTYPE', 1, { LTYPE: 'AcDbLinetypeTableRecord' });
  lt.rec('LTYPE');
  L(out, 2, 'Continuous'); L(out, 70, 0); L(out, 3, 'Solid line'); L(out, 72, 65); L(out, 73, 0); L(out, 40, 0);
  L(out, 0, 'ENDTAB');

  // La capa «0» es obligatoria en todo DXF (es la capa de los símbolos y de los bloques)
  const capasDxf = [{ name: '0', color: '#d4d4d8', visible: true },
    ...prj.layers.filter((l) => dxfLayerName(l.name) !== '0')];
  const ly = tabla('LAYER', capasDxf.length, { LAYER: 'AcDbLayerTableRecord' });
  for (const layer of capasDxf) {
    ly.rec('LAYER');
    L(out, 2, dxfLayerName(layer.name));
    L(out, 70, 0); L(out, 62, layer.visible === false ? -aciFor(layer.colorOriginal || layer.color, layer.aci) : aciFor(layer.colorOriginal || layer.color, layer.aci));
    L(out, 6, 'Continuous');
  }
  L(out, 0, 'ENDTAB');

  const st = tabla('STYLE', 1, { STYLE: 'AcDbTextStyleTableRecord' });
  st.rec('STYLE');
  L(out, 2, 'Standard'); L(out, 70, 0); L(out, 40, 0);
  L(out, 41, 1); L(out, 50, 0); L(out, 71, 0); L(out, 42, 2.5); L(out, 3, 'txt'); L(out, 4, '');
  L(out, 0, 'ENDTAB');

  const nombresBloque = ['*Model_Space', '*Paper_Space', ...(opts.blocks ? EXPORT_BLOCKS.map((b) => b.name) : [])];
  const br = tabla('BLOCK_RECORD', nombresBloque.length, { BLOCK_RECORD: 'AcDbBlockTableRecord' });
  for (const n of nombresBloque) {
    L(out, 0, 'BLOCK_RECORD'); L(out, 5, hr[n]); L(out, 330, br.ht);
    L(out, 100, 'AcDbSymbolTableRecord'); L(out, 100, 'AcDbBlockTableRecord');
    L(out, 2, n); L(out, 70, 0); L(out, 280, 1); L(out, 281, 0);
  }
  L(out, 0, 'ENDTAB'); L(out, 0, 'ENDSEC');

  if (opts.blocks) writeBlocks(out, h, hr);

  /* --- ENTIDADES: cada una con handle y propietario (el espacio modelo) --- */
  L(out, 0, 'SECTION'); L(out, 2, 'ENTITIES');
  const layerName = (id) => {
    const l = prj.layers.find((x) => x.id === id);
    return dxfLayerName(l ? l.name : id);
  };
  const onlyLayers = opts.layers;
  /** Cabecera común de entidad: handle propio + propietario + capa. */
  const ent = (tipo, ln, sub) => {
    L(out, 0, tipo); L(out, 5, h()); L(out, 330, modelH);
    L(out, 100, 'AcDbEntity'); L(out, 8, ln);
    if (sub) L(out, 100, sub);
  };

  /** Emite un INSERT con su ATTRIB de etiqueta (§8: símbolos por bloque). */
  const insert = (block, layer, x, y, rotation, label) => {
    const hi = h();
    L(out, 0, 'INSERT'); L(out, 5, hi); L(out, 330, modelH);
    L(out, 100, 'AcDbEntity'); L(out, 8, layer); L(out, 100, 'AcDbBlockReference');
    L(out, 66, 1); L(out, 2, block);
    L(out, 10, x); L(out, 20, y); L(out, 30, 0);
    L(out, 41, 1); L(out, 42, 1); L(out, 43, 1); L(out, 50, rotation || 0);
    if (label) {
      L(out, 0, 'ATTRIB'); L(out, 5, h()); L(out, 330, hi);
      L(out, 100, 'AcDbEntity'); L(out, 8, layer); L(out, 100, 'AcDbText');
      L(out, 10, x + 0.35); L(out, 20, y + 0.35); L(out, 30, 0);
      L(out, 40, 0.35); L(out, 1, label); L(out, 100, 'AcDbAttribute');
      L(out, 2, 'ETIQUETA'); L(out, 70, 0);
    }
    L(out, 0, 'SEQEND'); L(out, 5, h()); L(out, 330, hi);
    L(out, 100, 'AcDbEntity'); L(out, 8, layer);
  };

  for (const e of prj.entities) {
    if (onlyLayers && !onlyLayers.includes(e.layer)) continue;
    if (e.type === 'image') continue;
    const ln = layerName(e.layer);
    const z = (e.data && e.data.height) || 0;

    if (opts.blocks && (e.type === 'camera' || e.type === 'device')) {
      const p = e.points[0];
      const isPtz = e.type === 'camera' && !!((e.data && e.data.presets || []).length) && (e.data.catalogId || '').indexOf('PTZ') >= 0;
      insert(isPtz ? 'CCTV_PTZ' : e.type === 'camera' ? 'CCTV_CAMARA' : 'CCTV_EQUIPO', ln,
        p.x, p.y, e.type === 'camera' ? (e.data.azimuth || 0) : 0,
        (e.data.label || '') + (e.type === 'camera' && e.data.height ? ` h=${e.data.height}m` : ''));
      continue;
    }

    // Los obstáculos salen como geometría normal, pero con la altura en la cota (código 38): así un
    // CAD externo los levanta a su altura real en vez de dejarlos planos en el suelo (§9, §23).
    if (e.type === 'obstacle') {
      const pts = e.points.filter(Boolean);
      const z = (e.data && (e.data.base || 0)) || 0;
      if (pts.length === 1 && e.radius) {
        ent('CIRCLE', ln, 'AcDbCircle');
        L(out, 10, pts[0].x); L(out, 20, pts[0].y); L(out, 30, z); L(out, 40, e.radius);
        if (e.data && e.data.altura) L(out, 39, e.data.altura);
      } else if (pts.length >= 2) {
        ent('LWPOLYLINE', ln, 'AcDbPolyline');
        L(out, 90, pts.length); L(out, 70, e.closed ? 1 : 0); L(out, 38, z); L(out, 43, 0);
        // Grosor de extrusión: el muro se levanta lo que mide su altura
        if (e.data && e.data.ancho) L(out, 43, e.data.ancho);
        for (const p of pts) { L(out, 10, p.x); L(out, 20, p.y); }
        if (e.data && e.data.altura) L(out, 39, e.data.altura);
      }
      continue;
    }
    if (e.type === 'line' && e.points.length >= 2) {
      ent('LINE', ln, 'AcDbLine');
      L(out, 10, e.points[0].x); L(out, 20, e.points[0].y); L(out, 30, 0);
      L(out, 11, e.points[1].x); L(out, 21, e.points[1].y); L(out, 31, 0);
    } else if (e.type === 'polyline' || e.type === 'cable' || e.type === 'room') {
      const pts = e.points;
      if (pts.length < 2) continue;
      ent('LWPOLYLINE', ln, 'AcDbPolyline');
      L(out, 90, pts.length); L(out, 70, e.closed ? 1 : 0);
      // Los muros marcados salen a su cota y con su altura como grosor de extrusión (§9)
      const alturaMuro = e.data && e.data.muro ? (e.data.altura || e.data.h || 0) : 0;
      L(out, 38, (e.data && e.data.base) || 0);
      L(out, 43, e.data && e.data.ancho ? e.data.ancho : 0);
      for (const p of pts) { L(out, 10, p.x); L(out, 20, p.y); }
      if (alturaMuro) L(out, 39, alturaMuro);
    } else if (e.type === 'rect') {
      const [a, b] = e.points;
      const pts = [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }];
      ent('LWPOLYLINE', ln, 'AcDbPolyline');
      L(out, 90, 4); L(out, 70, 1); L(out, 38, 0); L(out, 43, 0);
      for (const p of pts) { L(out, 10, p.x); L(out, 20, p.y); }
    } else if (e.type === 'circle') {
      ent('CIRCLE', ln, 'AcDbCircle');
      L(out, 10, e.points[0].x); L(out, 20, e.points[0].y); L(out, 30, 0); L(out, 40, e.radius || 0);
    } else if (e.type === 'arc') {
      ent('ARC', ln, 'AcDbCircle');
      L(out, 10, e.points[0].x); L(out, 20, e.points[0].y); L(out, 30, 0); L(out, 40, e.radius || 0);
      L(out, 100, 'AcDbArc'); L(out, 50, e.startAngle || 0); L(out, 51, e.endAngle || 0);
    } else if (e.type === 'text') {
      ent('TEXT', ln, 'AcDbText');
      L(out, 10, e.points[0].x); L(out, 20, e.points[0].y); L(out, 30, 0);
      L(out, 40, (e.data && e.data.height) || 0.3); L(out, 1, (e.data && e.data.text) || '');
      L(out, 7, 'Standard'); L(out, 100, 'AcDbText');
    } else if (e.type === 'camera') {
      const p = e.points[0], az = rad(e.data.azimuth || 0);
      ent('CIRCLE', ln, 'AcDbCircle');
      L(out, 10, p.x); L(out, 20, p.y); L(out, 30, 0); L(out, 40, 0.25);
      ent('LINE', ln, 'AcDbLine');
      L(out, 10, p.x); L(out, 20, p.y); L(out, 30, z);
      L(out, 11, p.x + Math.cos(az) * 0.8); L(out, 21, p.y + Math.sin(az) * 0.8); L(out, 31, z);
      ent('TEXT', ln, 'AcDbText');
      L(out, 10, p.x + 0.35); L(out, 20, p.y + 0.35); L(out, 30, 0); L(out, 40, 0.35);
      L(out, 1, (e.data.label || '') + (e.data.label && z ? ` h=${z}m` : ''));
      L(out, 7, 'Standard'); L(out, 100, 'AcDbText');
    } else if (e.type === 'device') {
      const p = e.points[0];
      ent('CIRCLE', ln, 'AcDbCircle');
      L(out, 10, p.x); L(out, 20, p.y); L(out, 30, 0); L(out, 40, 0.35);
      ent('TEXT', ln, 'AcDbText');
      L(out, 10, p.x + 0.5); L(out, 20, p.y + 0.4); L(out, 30, 0); L(out, 40, 0.35); L(out, 1, e.data.label || '');
      L(out, 7, 'Standard'); L(out, 100, 'AcDbText');
    }
  }
  L(out, 0, 'ENDSEC');
  L(out, 0, 'EOF');

  /* --- CABECERA: se escribe al final porque $HANDSEED necesita el último handle usado --- */
  L(outHead, 0, 'SECTION'); L(outHead, 2, 'HEADER');
  L(outHead, 9, '$ACADVER'); L(outHead, 1, 'AC1015');
  L(outHead, 9, '$INSUNITS'); L(outHead, 70, 6);            // 6 = metros
  L(outHead, 9, '$MEASUREMENT'); L(outHead, 70, 1);         // métrico
  L(outHead, 9, '$EXTMIN'); L(outHead, 10, 0); L(outHead, 20, 0); L(outHead, 30, 0);
  L(outHead, 9, '$EXTMAX'); L(outHead, 10, 1000); L(outHead, 20, 1000); L(outHead, 30, 0);
  L(outHead, 9, '$DWGCODEPAGE'); L(outHead, 3, 'ANSI_1252');
  L(outHead, 9, '$HANDSEED'); L(outHead, 5, h());
  L(outHead, 0, 'ENDSEC');
  return outHead.concat(out).join('\n');
}

/* --------------------------------- lector --------------------------------- */

/** Devuelve los pares (código, valor) del DXF, tolerando líneas sueltas o vacías. */
export function readPairs(text) {
  const raw = String(text).replace(/\r\n?/g, '\n').split('\n');
  const pairs = [];
  for (let i = 0; i < raw.length - 1; i++) {
    const code = parseInt(raw[i].trim(), 10);
    if (isNaN(code)) continue;                     // recuperación ante ruido
    pairs.push([code, raw[i + 1].trim()]);
    i++;
  }
  return pairs;
}

/** Agrupa los pares en registros: cada uno empieza por código 0 (tipo) y acumula códigos. */
function readRecords(pairs) {
  const recs = [];
  let i = 0;
  while (i < pairs.length) {
    if (pairs[i][0] !== 0) { i++; continue; }
    const type = pairs[i][1];
    const codes = [];
    i++;
    while (i < pairs.length && pairs[i][0] !== 0) { codes.push([pairs[i][0], pairs[i][1]]); i++; }
    recs.push({ type, codes });
  }
  return recs;
}

const first = (rec, code) => { const c = rec.codes.find((x) => x[0] === code); return c ? c[1] : undefined; };
const all = (rec, code) => rec.codes.filter((x) => x[0] === code).map((x) => x[1]);

/** Vértices de una LWPOLYLINE/POLYLINE: se recorren los códigos en orden. */
function vertices(rec) {
  const pts = [];
  let cur = null;
  for (const [code, val] of rec.codes) {
    if (code === 10) { if (cur) pts.push(cur); cur = { x: num(val) }; }
    else if (code === 20 && cur) { cur.y = num(val); }
  }
  if (cur) pts.push(cur);
  return pts;
}

/** Vértices de POLYLINE clásica: vienen en registros VERTEX aparte. */
function polylineVertices(rec) {
  return (rec.vertices || []).map((v) => ({ x: num(first(v, 10)), y: num(first(v, 20)) }));
}

/** Convierte un registro DXF en entidad del motor CAD. Devuelve null si no se soporta. */
export function buildEntity(rec, unsupported) {
  const layer = capaId(first(rec, 8) || 'ARQUITECTURA');
  const flag = parseInt(first(rec, 70) || '0', 10) || 0;
  const e = { type: null, layer, points: [], closed: false, data: {} };
  // Color del elemento (§9): 420 es color verdadero de 24 bits y manda sobre el índice 62;
  // 62 = 0 es «según el bloque» (BYBLOCK) y 256 «según la capa» (BYLAYER), que es lo habitual.
  const tc = first(rec, 420);
  const aci63 = first(rec, 62);
  if (tc !== undefined && tc !== '') e.colorVerdadero = parseInt(tc, 10) & 0xffffff;
  else if (aci63 !== undefined && aci63 !== '') e.aci = parseInt(aci63, 10);

  switch (rec.type) {
    case 'LINE':
      e.type = 'line';
      e.points = [{ x: num(first(rec, 10)), y: num(first(rec, 20)) }, { x: num(first(rec, 11)), y: num(first(rec, 21)) }];
      break;
    case 'LWPOLYLINE':
      e.type = 'polyline'; e.closed = (flag & 1) === 1; e.points = vertices(rec);
      break;
    case 'POLYLINE':
      e.type = 'polyline'; e.closed = (flag & 1) === 1; e.points = polylineVertices(rec);
      break;
    case 'CIRCLE':
      e.type = 'circle'; e.radius = num(first(rec, 40)); e.points = [{ x: num(first(rec, 10)), y: num(first(rec, 20)) }];
      break;
    case 'ARC':
      e.type = 'arc'; e.radius = num(first(rec, 40));
      e.startAngle = num(first(rec, 50)); e.endAngle = num(first(rec, 51));
      e.points = [{ x: num(first(rec, 10)), y: num(first(rec, 20)) }];
      break;
    case 'TEXT': case 'MTEXT':
      e.type = 'text';
      e.points = [{ x: num(first(rec, 10)), y: num(first(rec, 20)) }];
      e.data = { text: (first(rec, 1) || '').replace(/[{}\\]/g, ''), height: num(first(rec, 40), 0.3) || 0.3, rotation: num(first(rec, 50)) };
      break;
    case 'POINT':
      e.type = 'circle'; e.radius = 0.05; e.points = [{ x: num(first(rec, 10)), y: num(first(rec, 20)) }];
      break;
    case 'SOLID': case 'TRACE': {
      // 4 esquinas (la 3ª y la 4ª pueden venir invertidas); se emite como polígono cerrado.
      const xs = [10, 11, 12, 13].map((c) => first(rec, c));
      const ys = [20, 21, 22, 23].map((c) => first(rec, c));
      const pts = [];
      for (let i = 0; i < 4; i++) if (xs[i] !== undefined && ys[i] !== undefined) pts.push({ x: num(xs[i]), y: num(ys[i]) });
      if (pts.length < 4 && pts.length >= 3) pts.push({ ...pts[0] });
      if (pts.length >= 4) { e.type = 'polyline'; e.closed = true; e.points = [pts[0], pts[1], pts[3], pts[2]]; }
      else return null;
      break;
    }
    case 'SPLINE': {
      const pts = splineGeometry(rec);
      if (pts.length < 2) return null;
      e.type = 'polyline'; e.closed = (flag & 1) === 1 && pts.length > 2;
      e.points = pts;
      e.data = { kind: 'spline', degree: parseInt(first(rec, 71) || '3', 10) || 3, ctrl: all(rec, 10).length };
      break;
    }
    case 'HATCH': {
      // Un sombreado (solera, zona pintada, achurado) se incorpora como uno o varios contornos
      // cerrados: es la lectura útil para la planta (superficies y recintos), no el patrón.
      const rings = hatchContours(rec.codes);
      if (!rings.length) { if (unsupported) unsupported[rec.type] = (unsupported[rec.type] || 0) + 1; return null; }
      const pattern = first(rec, 2) || 'SOLID';
      return rings.map((ring, i) => ({
        type: 'polyline', layer, closed: true, points: ring, data: { kind: 'hatch', pattern, ring: i + 1, rings: rings.length } }));
    }
    case 'ELLIPSE': {
      const cx = num(first(rec, 10)), cy = num(first(rec, 20));
      const mx = num(first(rec, 11)), my = num(first(rec, 21));
      const ratio = num(first(rec, 40), 1) || 1;
      const a0 = num(first(rec, 41)), a1 = num(first(rec, 42), 2 * Math.PI);
      const major = Math.hypot(mx, my);
      const rot = Math.atan2(my, mx);
      const steps = 48;
      const pts = [];
      for (let i = 0; i <= steps; i++) {
        const t = a0 + ((a1 - a0) * i) / steps;
        const ux = major * Math.cos(t), uy = major * ratio * Math.sin(t);
        pts.push({ x: cx + ux * Math.cos(rot) - uy * Math.sin(rot), y: cy + ux * Math.sin(rot) + uy * Math.cos(rot) });
      }
      e.type = 'polyline'; e.closed = Math.abs(a1 - a0 - 2 * Math.PI) < 1e-6; e.points = pts;
      break;
    }
    default:
      if (unsupported) unsupported[rec.type] = (unsupported[rec.type] || 0) + 1;
      return null;
  }
  if (e.type === 'polyline' && e.points.length < 2) return null;
  return e;
}

/** Puntos de control (10/20) y de ajuste (11/21) de una SPLINE, en orden. */
function splinePointsOf(rec, xc, yc) {
  const pts = [];
  let cur = null;
  for (const [code, val] of rec.codes) {
    if (code === xc) { if (cur) pts.push(cur); cur = { x: num(val) }; }
    else if (code === yc && cur) cur.y = num(val);
  }
  if (cur) pts.push(cur);
  return pts;
}

/**
 * Aproxima una SPLINE con una polilínea: B-spline (De Boor) sobre los puntos de control, o
 * interpolación de Catmull-Rom sobre los puntos de ajuste cuando el plano los trae (§9).
 */
function splineGeometry(rec) {
  const flag = parseInt(first(rec, 70) || '0', 10) || 0;
  const degree = Math.max(1, Math.min(3, parseInt(first(rec, 71) || '3', 10) || 3));
  const fit = splinePointsOf(rec, 11, 21);
  const ctrl = splinePointsOf(rec, 10, 20);
  const pts = (flag & 8) && fit.length >= 2 ? catmullRom(fit, (flag & 1) === 1) : bspline(ctrl, degree, (flag & 1) === 1, all(rec, 40).map(num));
  return dedupe(pts);
}

/** Muestreo de una B-spline por el algoritmo de De Boor (nudos uniformes si el plano no los trae). */
function bspline(ctrl, degree, closed, knots) {
  if (ctrl.length < 2) return ctrl;
  const n = ctrl.length;
  const p = Math.min(degree, n - 1);
  const list = closed && n > 2 ? [...ctrl, ctrl[0]] : ctrl;
  const m = list.length;
  const K = knots && knots.length === m + p + 1 ? knots.slice() : uniformKnots(m, p, closed);
  const steps = Math.max(24, m * 8);
  const a = K[p], b = K[K.length - 1 - p];
  const out = [];
  for (let i = 0; i <= steps; i++) {
    const u = a + ((b - a) * i) / steps;
    out.push(deBoor(list, p, K, Math.min(u, b - 1e-12)));
  }
  return closed ? out : out;
}

function uniformKnots(n, p, closed) {
  const count = n + p + 1;
  const K = [];
  for (let i = 0; i < count; i++) {
    if (closed) K.push(i);
    else K.push(i < p ? 0 : i > n - 1 ? n - p : i - p);
  }
  return K;
}

/** Evaluación puntual de una B-spline: De Boor recursivo. */
function deBoor(pts, p, K, u) {
  let k = p;
  while (k < pts.length && u >= K[k + 1]) k++;
  if (k >= pts.length) k = pts.length - 1;
  const d = [];
  for (let j = 0; j <= p; j++) d.push({ x: pts[Math.min(k - p + j, pts.length - 1)].x, y: pts[Math.min(k - p + j, pts.length - 1)].y });
  for (let r = 1; r <= p; r++) {
    for (let j = p; j >= r; j--) {
      const i = k - p + j;
      const den = K[i + p - r + 1] - K[i];
      const a = den === 0 ? 0 : (u - K[i]) / den;
      d[j] = { x: (1 - a) * d[j - 1].x + a * d[j].x, y: (1 - a) * d[j - 1].y + a * d[j].y };
    }
  }
  return d[p];
}

/** Interpolación de Catmull-Rom sobre los puntos de ajuste de una SPLINE. */
function catmullRom(pts, closed) {
  const P = closed ? [pts[pts.length - 1], ...pts, pts[0], pts[1]] : [pts[0], ...pts, pts[pts.length - 1]];
  const out = [];
  for (let i = 1; i < P.length - 2; i++) {
    const p0 = P[i - 1], p1 = P[i], p2 = P[i + 1], p3 = P[i + 2];
    for (let j = 0; j < 8; j++) {
      const t = j / 8, t2 = t * t, t3 = t2 * t;
      out.push({
        x: 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
        y: 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3) });
    }
  }
  out.push(closed ? out[0] : pts[pts.length - 1]);
  return out;
}

/** Elimina puntos repetidos consecutivos (los convertidores suelen duplicar los extremos). */
function dedupe(pts) {
  const out = [];
  for (const p of pts) {
    const last = out[out.length - 1];
    if (!last || Math.abs(last.x - p.x) > 1e-9 || Math.abs(last.y - p.y) > 1e-9) out.push(p);
  }
  return out;
}

/**
 * Contornos de un HATCH: recorre los códigos 91/92/93 y las aristas (línea, arco o polilínea con
 * bulge). Devuelve un anillo cerrado de puntos por contorno.
 */
function hatchContours(codes) {
  const at = (i) => Number(codes[i][1]) || 0;
  let i = codes.findIndex((c) => c[0] === 91);
  if (i < 0) return [];
  i++;
  const rings = [];
  while (i < codes.length) {
    if (codes[i][0] !== 92) { i++; continue; }
    i++;
    let edgeType = 1, closed = true, count = 0;
    while (i < codes.length && codes[i][0] !== 10 && codes[i][0] !== 11 && codes[i][0] !== 92 && codes[i][0] !== 91) {
      if (codes[i][0] === 72) edgeType = at(i);
      else if (codes[i][0] === 73) closed = at(i) !== 0;
      else if (codes[i][0] === 93) count = at(i);
      i++;
    }
    const pts = [];
    const push = (p) => { const last = pts[pts.length - 1]; if (!last || Math.hypot(last.x - p.x, last.y - p.y) > 1e-9) pts.push(p); };
    if (edgeType === 0) {
      // Contorno definido por una polilínea: los códigos 93 son vértices (10/20) con posible bulge (42)
      for (let e = 0; e < count && i < codes.length; e++) {
        if (codes[i][0] === 10) {
          const y = i + 1 < codes.length && codes[i + 1][0] === 20 ? Number(codes[i + 1][1]) || 0 : 0;
          push({ x: at(i), y });
          i += 2;
        } else i++;
        while (i < codes.length && (codes[i][0] === 42 || codes[i][0] === 40)) i++;
      }
    } else {
      for (let e = 0; e < count && i < codes.length; e++) {
        const toks = [];
        if (codes[i][0] === 72) { edgeType = at(i); i++; }
        while (i < codes.length && codes[i][0] !== 72 && codes[i][0] !== 92 && codes[i][0] !== 91) { toks.push(codes[i]); i++; }
        if (!toks.length) break;
        const g = (code, def = 0) => { const t = toks.find((x) => x[0] === code); return t ? (Number(t[1]) || 0) : def; };
        if (edgeType === 2) {                                 // arco de contorno: se muestrea
          const cx = g(10), cy = g(20), r = g(40), a0 = g(50), a1 = g(51);
          const sweep = a1 >= a0 ? a1 - a0 : a1 - a0 + 2 * Math.PI;
          for (let k = 0; k <= 12; k++) {
            const a = a0 + (sweep * k) / 12;
            push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
          }
        } else {                                              // arista recta
          push({ x: g(10), y: g(20) });
          if (toks.some((x) => x[0] === 11)) push({ x: g(11), y: g(21) });
        }
      }
    }
    if (pts.length >= 3) {
      // Un contorno cerrado no repite el primer punto en el modelo del motor CAD
      const a = pts[0], b = pts[pts.length - 1];
      if (closed && Math.hypot(a.x - b.x, a.y - b.y) < 1e-6 && pts.length > 3) pts.pop();
      rings.push(pts);
    }
  }
  return rings;
}

/** Aplica una matriz afín a una entidad ya construida (usado al expandir bloques). */
export function transformEntity(e, m) {
  const s = scaleM(m);
  const sy = Math.hypot(m.b, m.d) || s;
  switch (e.type) {
    case 'line': case 'polyline': case 'room': case 'cable':
      return { ...e, points: e.points.map((p) => applyM(m, p)) };
    case 'rect':
      return { ...e, points: e.points.map((p) => applyM(m, p)) };
    case 'circle':
      return { ...e, points: [applyM(m, e.points[0])], radius: (e.radius || 0) * s };
    case 'arc': {
      const c = applyM(m, e.points[0]);
      const r = (e.radius || 0) * s;
      const p0 = applyM(m, { x: e.points[0].x + (e.radius || 0) * Math.cos(rad(e.startAngle || 0)), y: e.points[0].y + (e.radius || 0) * Math.sin(rad(e.startAngle || 0)) });
      const p1 = applyM(m, { x: e.points[0].x + (e.radius || 0) * Math.cos(rad(e.endAngle || 0)), y: e.points[0].y + (e.radius || 0) * Math.sin(rad(e.endAngle || 0)) });
      let a0 = (Math.atan2(p0.y - c.y, p0.x - c.x) * 180) / Math.PI;
      let a1 = (Math.atan2(p1.y - c.y, p1.x - c.x) * 180) / Math.PI;
      if (detM(m) < 0) { const t = a0; a0 = a1; a1 = t; }   // espejo: se invierte el sentido
      return { ...e, points: [c], radius: r, startAngle: a0, endAngle: a1 };
    }
    case 'text': {
      const shear = Math.abs(m.a * m.b + m.c * m.d) > 1e-9 * (s * s + 1e-12);
      const rot = shear ? (e.data.rotation || 0) : (e.data.rotation || 0) + (rotM(m) * 180) / Math.PI;
      return { ...e, points: [applyM(m, e.points[0])], data: { ...e.data, height: (e.data.height || 0.3) * sy, rotation: ((rot % 360) + 360) % 360 } };
    }
    default:
      return e;
  }
}

/** Lector de DXF **binario** (sentinel «AutoCAD Binary DXF»): devuelve pares (código, valor). */
export function readBinaryPairs(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const SENTINEL = 'AutoCAD Binary DXF';
  const head = new TextDecoder('latin1').decode(u8.slice(0, SENTINEL.length));
  if (head !== SENTINEL) throw new Error('El archivo no es un DXF binario (falta la firma «AutoCAD Binary DXF»)');
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let p = 22;                                  // firma + CR LF + 0x1A + 0x00
  const pairs = [];
  const str = () => { let s = ''; while (p < u8.length && u8[p] !== 0) s += String.fromCharCode(u8[p++]); p++; return s; };
  const doubleAt = (range) => { const v = dv.getFloat64(p, true); p += 8; return String(v); };
  const intAt = (bytes) => { const v = bytes === 2 ? dv.getInt16(p, true) : dv.getInt32(p, true); p += bytes; return String(v); };
  while (p < u8.length) {
    let code = u8[p++];
    if (code === 255) { code = dv.getUint16(p, true); p += 2; }
    if (p > u8.length) break;
    let value;
    if (code >= 0 && code <= 9) value = str();
    else if (code >= 10 && code <= 59) value = doubleAt();
    else if (code >= 60 && code <= 79) value = intAt(2);
    else if (code >= 90 && code <= 99) value = intAt(4);
    else if (code === 100 || code === 102 || code === 105) value = str();
    else if (code >= 110 && code <= 149) value = doubleAt();
    else if (code >= 160 && code <= 169) { value = String(Number(dv.getBigInt64(p, true))); p += 8; }
    else if (code >= 170 && code <= 179) value = intAt(2);
    else if (code >= 210 && code <= 239) value = doubleAt();
    else if (code >= 270 && code <= 289) value = intAt(2);
    else if (code >= 290 && code <= 299) value = String(u8[p++]);
    else if (code >= 300 && code <= 309) value = str();
    else if (code >= 310 && code <= 319) { const n = u8[p++]; p += n; value = ''; }
    else if (code >= 320 && code <= 369) value = str();
    else if (code >= 370 && code <= 389) value = intAt(2);
    else if (code >= 390 && code <= 399) value = str();
    else if (code >= 400 && code <= 409) value = intAt(2);
    else if (code >= 410 && code <= 419) value = str();
    else if (code >= 420 && code <= 429) value = intAt(4);
    else if (code >= 430 && code <= 439) value = str();
    else if (code >= 440 && code <= 449) value = intAt(4);
    else if (code >= 450 && code <= 459) value = intAt(4);
    else if (code >= 460 && code <= 469) value = doubleAt();
    else if (code >= 470 && code <= 479) value = str();
    else if (code >= 480 && code <= 481) value = str();
    else if (code === 999) value = str();
    else if (code >= 1000 && code <= 1009) value = str();
    else if (code >= 1010 && code <= 1059) value = doubleAt();
    else if (code >= 1060 && code <= 1070) value = intAt(2);
    else if (code === 1071) value = intAt(4);
    else { value = ''; }                        // código desconocido: se ignora y se sigue
    pairs.push([code, value]);
  }
  return pairs;
}

/** Importa un DXF **binario** (lo que generan los conversores de DWG). */
export function fromBinaryDxf(bytes, opts = {}) {
  return fromPairs(readBinaryPairs(bytes), opts);
}

/**
 * Decodifica los bytes de un DXF ASCII teniendo en cuenta su página de códigos (§9).
 * Los planos antiguos y los exportados desde AutoCAD en español vienen en ANSI 1252 (CP1252):
 * si el texto no es UTF-8 válido (aparecen caracteres de reemplazo) se reinterpreta en CP1252.
 */
export function decodeDxfBytes(u8) {
  const utf8 = new TextDecoder('utf-8', { fatal: false }).decode(u8);
  const rotos = (utf8.match(/\uFFFD/g) || []).length;
  if (!rotos) return { text: utf8, encoding: utf8.charCodeAt(0) === 0xFEFF ? 'utf-8 (BOM)' : 'utf-8', replaced: 0 };
  try {
    const cp1252 = new TextDecoder('windows-1252').decode(u8);
    return { text: cp1252, encoding: 'windows-1252 (ANSI)', replaced: rotos };
  } catch (e) {
    return { text: utf8, encoding: 'utf-8 (con caracteres ilegibles)', replaced: rotos };
  }
}

/** Importa cualquier DXF: detecta si es texto o binario por su firma y respeta la codificación. */
export function importDxfAuto(data, opts = {}) {
  if (data instanceof Uint8Array || data instanceof ArrayBuffer) {
    const u8 = data instanceof Uint8Array ? data : new Uint8Array(data);
    const head = new TextDecoder('latin1').decode(u8.slice(0, 18));
    if (head.startsWith('AutoCAD Binary DXF')) return { ...fromBinaryDxf(u8, opts), binary: true };
    const dec = decodeDxfBytes(u8);
    if (dec.text.indexOf('\u0000') >= 0) throw new Error('Archivo binario no reconocido: no es DXF ASCII ni DXF binario');
    const out = fromDxf(dec.text, opts);
    out.report.encoding = dec.encoding;
    out.report.encodingFixed = dec.replaced;
    return { ...out, binary: false, encoding: dec.encoding };
  }
  return { ...fromDxf(String(data), opts), binary: false };
}

/** Importa un DXF ASCII (texto) expandiendo bloques. */
export function fromDxf(text, opts = {}) {
  return fromPairs(readPairs(text), opts);
}

/**
 * Importa un DXF a partir de sus pares (código, valor), expandiendo bloques.
 * @returns {{layers:string[], entities:object[], blocks:string[], report:object}}
 */
export function fromPairs(pairs, opts = {}) {
  const maxDepth = opts.maxDepth || 8;
  const recs = readRecords(pairs);
  const blocks = new Map();
  const records = [];
  const layerInfo = new Map();
  const report = { blocks: 0, blockNames: [], inserts: 0, expanded: 0, entities: 0, depth: 0, missing: [], cycles: [],
    unsupported: {}, attributes: 0, xrefs: [], xrefMissing: 0, xrefResolved: 0, units: null, extents: null, acadVer: '',
    colores: { capasTabla: 0, capasConColor: 0, entidadesConColor: 0, entidadesByBlock: 0, apagadas: [], congeladas: [] } };
  headerInfo(pairs, report);

  let mode = '';
  for (let i = 0; i < recs.length; i++) {
    const r = recs[i];
    if (r.type === 'SECTION') { mode = first(r, 2) || ''; continue; }
    if (r.type === 'ENDSEC') { mode = ''; continue; }

    if (mode === 'BLOCKS') {
      if (r.type !== 'BLOCK') continue;
      const name = first(r, 2) || '';
      const xrefPath = first(r, 1) || '';                  // un bloque con ruta es una referencia externa
      const def = {
        name, layer: first(r, 8) || '0', base: { x: num(first(r, 10)), y: num(first(r, 20)) },
        flags: parseInt(first(r, 70) || '0', 10) || 0, records: [], xref: xrefPath || null };
      i++;
      while (i < recs.length && recs[i].type !== 'ENDBLK') { consume(recs, i, def.records, (k) => { i = k; }); i++; }
      if (isXrefBlock(r, xrefPath)) { def.xref = xrefPath || '(sin ruta)'; def.records = []; }
      // Los bloques de espacio (*Model_Space, *Paper_Space…) son estructurales, no símbolos:
      // se leen para no perder el flujo, pero no cuentan como bloques del plano.
      if (!name.startsWith('*')) blocks.set(name.toUpperCase(), def);
      continue;
    }
    /* Tabla de capas: nombre, color (62/420), apagado (62 negativo) y congelado (bit 1 de 70).
     * Sin esto, un plano real entraba con todas las capas del mismo gris (§9). */
    if (mode === 'TABLES') {
      if (r.type !== 'LAYER') continue;
      const nombre = first(r, 2) || '0';
      const id = capaId(nombre);
      const aciBruto = parseInt(first(r, 62) || '7', 10);
      const aci = Math.abs(isNaN(aciBruto) ? 7 : aciBruto);
      const tc = first(r, 420);
      const banderas = parseInt(first(r, 70) || '0', 10) || 0;
      const apagada = aciBruto < 0;
      const congelada = (banderas & 1) === 1;
      layerInfo.set(id, {
        id, name: nombre, aci, linetype: first(r, 6) || 'Continuous',
        colorVerdadero: tc !== undefined ? parseInt(tc, 10) & 0xffffff : undefined,
        color: aciAHex(aci) || '#ffffff',
        visible: !apagada && !congelada, apagada, congelada });
      report.colores.capasTabla++;
      if (apagada) report.colores.apagadas.push(nombre);
      if (congelada) report.colores.congeladas.push(nombre);
      continue;
    }
    if (mode !== 'ENTITIES') continue;
    if (r.type === 'VERTEX' || r.type === 'SEQEND' || r.type === 'ENDBLK' || r.type === 'ATTDEF') continue;
    if (r.type === 'INSERT') {
      // Los ATTRIB que siguen al INSERT alimentan los ATTDEF del bloque (al estilo de AutoCAD).
      const attribs = [];
      let k = i + 1;
      while (k < recs.length && recs[k].type === 'ATTRIB') {
        attribs.push({ tag: first(recs[k], 2) || '', value: first(recs[k], 1) || '',
          x: num(first(recs[k], 10)), y: num(first(recs[k], 20)), h: num(first(recs[k], 40), 0.3), rot: num(first(recs[k], 50)) });
        k++;
      }
      if (k < recs.length && recs[k].type === 'SEQEND') k++;
      r.attribs = attribs;
      i = k - 1;
      records.push(r);
      continue;
    }
    consume(recs, i, records, (k) => { i = k; });
  }
  report.blocks = blocks.size;
  report.blockNames = [...blocks.values()].map((b) => b.name);

  const layers = new Set();
  const entities = [];
  /** Color propio de un registro (el que heredan los elementos BYBLOCK del bloque). */
  const colorDeRec = (rec) => {
    const tc = first(rec, 420);
    if (tc !== undefined && tc !== '') return { colorVerdadero: parseInt(tc, 10) & 0xffffff };
    const aci = first(rec, 62);
    if (aci !== undefined && aci !== '') {
      const n = parseInt(aci, 10);
      if (!isNaN(n) && !esByLayer(n) && !esByBlock(n)) return { aci: n };
    }
    return null;
  };
  const emit = (rec, m, inheritedLayer, depth, stack, colorCtx = null) => {
    if (depth > maxDepth) return;
    if (rec.type === 'INSERT') {
      const key = (first(rec, 2) || '').toUpperCase();
      const def = blocks.get(key);
      report.inserts++;
      if (!def) { report.missing.push(key || '(sin nombre)'); return; }
      if (def.xref) {
        // Referencia externa: el dibujo vive en otro archivo. Si el proyectista lo aporta
        // (opts.xrefs), se inserta transformado; si no, se informa y el resto del plano sigue igual.
        const ext = opts.xrefs && (opts.xrefs.get ? opts.xrefs.get(def.name) || opts.xrefs.get(key) : opts.xrefs[def.name] || opts.xrefs[key]);
        if (!ext || !ext.length) { report.xrefMissing++; report.xrefs.push({ name: def.name, path: def.xref, resolved: false }); return; }
        const insLayer = capaId(first(rec, 8) || inheritedLayer);
        const scale = { x: num(first(rec, 41), 1) || 1, y: num(first(rec, 42), 1) || 1, z: num(first(rec, 43), 1) || 1 };
        const base = insertMatrix({ x: num(first(rec, 10)), y: num(first(rec, 20)), rotation: num(first(rec, 50)), scale }, def.base);
        const mm = compose(base, m);
        report.xrefResolved++;
        report.expanded++;
        for (const sub of ext) { const moved = transformEntity(sub, mm); layers.add(moved.layer); entities.push(moved); report.entities++; }
        report.xrefs.push({ name: def.name, path: def.xref, resolved: true, entities: ext.length });
        return;
      }
      if (stack.includes(key)) { report.cycles.push(key); return; }        // referencia circular
      const insLayer = capaId(first(rec, 8) || inheritedLayer);
      // El color del INSERT lo heredan los elementos BYBLOCK del bloque (§9)
      const insColor = colorDeRec(rec) || colorCtx;
      const scale = { x: num(first(rec, 41), 1) || 1, y: num(first(rec, 42), 1) || 1, z: num(first(rec, 43), 1) || 1 };
      const cols = Math.max(1, parseInt(first(rec, 70) || '1', 10) || 1);   // MINSERT
      const rows = Math.max(1, parseInt(first(rec, 71) || '1', 10) || 1);
      const colSp = num(first(rec, 44)), rowSp = num(first(rec, 45));
      report.depth = Math.max(report.depth, depth + 1);
      for (let c = 0; c < cols; c++) {
        for (let rr = 0; rr < rows; rr++) {
          const base = insertMatrix({ x: num(first(rec, 10)) + c * colSp, y: num(first(rec, 20)) + rr * rowSp,
            rotation: num(first(rec, 50)), scale }, def.base);
          const mm = compose(base, m);        // primero el bloque (hijo), después el INSERT contenedor
          report.expanded++;
          const defs = attdefMap(def);
          for (const sub of def.records) emit(sub, mm, insLayer, depth + 1, [...stack, key], insColor);
          for (const at of rec.attribs || []) {
            if (!at.value) continue;
            // El ATTDEF vive en coordenadas del bloque (hay que transformarlo); el ATTRIB
            // del INSERT viene ya en coordenadas de dibujo, por lo que se respeta tal cual.
            const target = defs.get(at.tag.toUpperCase());
            const pos = target ? applyM(mm, { x: target.x, y: target.y }) : { x: at.x, y: at.y };
            const h = target ? target.h * scaleM(mm) : at.h;
            entities.push({ type: 'text', layer: insLayer, points: [pos], closed: false,
              data: { text: at.value, height: h || 0.3, tag: at.tag } });
            layers.add(insLayer);
            report.attributes++;
          }
        }
      }
      return;
    }
    if (rec.type === 'ATTDEF') return;
    const built = buildEntity(rec, report.unsupported);
    if (!built) return;
    for (const ent of Array.isArray(built) ? built : [built]) {          // un HATCH puede dar varios contornos
      if (ent.layer === '0' || !ent.layer) ent.layer = inheritedLayer;   // capa heredada del INSERT
      ent.layer = capaId(ent.layer);
      // BYBLOCK: el elemento toma el color del bloque que lo inserta; si el bloque no trae color
      // propio, se queda con el de su capa (BYLAYER), que es lo que dice el formato DXF.
      if (esByBlock(ent.aci)) {
        report.colores.entidadesByBlock++;
        if (colorCtx && colorCtx.colorVerdadero !== undefined) { ent.colorVerdadero = colorCtx.colorVerdadero; delete ent.aci; }
        else if (colorCtx && colorCtx.aci !== undefined) { ent.aci = colorCtx.aci; }
        else delete ent.aci;
      }
      if (ent.aci !== undefined || ent.colorVerdadero !== undefined) report.colores.entidadesConColor++;
      const moved = transformEntity(ent, m);
      layers.add(moved.layer);
      entities.push(moved);
      report.entities++;
    }
  };

  for (const r of records) emit(r, MID(), 'ARQUITECTURA', 0, []);
  // Capas usadas que no venían declaradas en la tabla: en CAD se dibujan con color blanco (7)
  for (const id of layers) {
    if (!layerInfo.has(id)) layerInfo.set(id, { id, name: id, aci: 7, color: aciAHex(7), visible: true, sinDeclarar: true });
  }
  report.colores.capasConColor = [...layerInfo.values()].filter((l) => l.aci !== 7 || l.colorVerdadero !== undefined).length;
  return { layers: Array.from(layers), entities, blocks: report.blockNames, report, layerInfo: Object.fromEntries(layerInfo) };
}

/** Mapa de ATTDEF de un bloque: etiqueta → posición y altura por defecto. */
function attdefMap(def) {
  const map = new Map();
  for (const rec of def.records) {
    if (rec.type !== 'ATTDEF') continue;
    const tag = (first(rec, 2) || '').toUpperCase();
    if (!tag) continue;
    map.set(tag, { x: num(first(rec, 10)), y: num(first(rec, 20)), h: num(first(rec, 40), 0.3) });
  }
  return map;
}

/** Un bloque es una referencia externa si trae ruta de archivo (código 1) o bandera de XREF (bit 4). */
function isXrefBlock(rec, path) {
  const flags = parseInt(first(rec, 70) || '0', 10) || 0;
  return !!(path && /[\\/]|\.[a-z]{3}$/i.test(String(path))) || (flags & 4) === 4 || (flags & 8) === 8;
}

/** Unidades de dibujo del DXF ($INSUNITS) y su equivalencia en metros. */
export const INSUNITS = {
  0: { id: 'sin unidad', toMeters: 0 },
  1: { id: 'pulgadas', toMeters: 0.0254 }, 2: { id: 'pies', toMeters: 0.3048 }, 3: { id: 'millas', toMeters: 1609.344 },
  4: { id: 'milímetros', toMeters: 0.001 }, 5: { id: 'centímetros', toMeters: 0.01 }, 6: { id: 'metros', toMeters: 1 },
  7: { id: 'kilómetros', toMeters: 1000 }, 9: { id: 'milésimas de pulgada', toMeters: 0.0000254 },
  10: { id: 'yardas', toMeters: 0.9144 }, 14: { id: 'decímetros', toMeters: 0.1 } };

/** Lee las variables de cabecera útiles para el flujo §41 (unidades, extensión y versión del plano). */
function headerInfo(pairs, report) {
  const val = (name, code) => {
    for (let i = 0; i < pairs.length - 1; i++) {
      if (pairs[i][0] === 9 && pairs[i][1] === name) {
        for (let k = i + 1; k < Math.min(i + 6, pairs.length); k++) if (pairs[k][0] === code) return pairs[k][1];
      }
    }
    return undefined;
  };
  const ui = parseInt(val('$INSUNITS', 70) || '0', 10) || 0;
  const info = INSUNITS[ui] || null;
  if (info && ui !== 0) {
    report.units = { code: ui, id: info.id, toMeters: info.toMeters };
    if (Math.abs(info.toMeters - 1) > 1e-9) report.unitAdvice = `El plano está dibujado en ${info.id}: cada unidad equivale a ${info.toMeters} m.`;
  }
  const x0 = parseFloat(val('$EXTMIN', 10)), y0 = parseFloat(val('$EXTMIN', 20));
  const x1 = parseFloat(val('$EXTMAX', 10)), y1 = parseFloat(val('$EXTMAX', 20));
  if ([x0, y0, x1, y1].every((v) => !isNaN(v))) report.extents = { minX: x0, minY: y0, maxX: x1, maxY: y1 };
  report.acadVer = val('$ACADVER', 1) || '';
}

/** Toma el registro i como entidad y deja el índice tras sus sub-registros (VERTEX/SEQEND). */
function consume(recs, i, sink, setIndex) {
  const r = recs[i];
  if (r.type === 'POLYLINE') {
    const verts = [];
    let k = i + 1;
    while (k < recs.length && recs[k].type === 'VERTEX') { verts.push(recs[k]); k++; }
    if (k < recs.length && recs[k].type === 'SEQEND') k++;
    sink.push({ ...r, vertices: verts });
    setIndex(k - 1);
    return;
  }
  sink.push(r);
}
