/**
 * CCTV DESIGN PRO — Descompresor DEFLATE propio (RFC 1951)
 *
 * El contrato prohíbe depender de librerías externas y el programa tiene que leer archivos que
 * **no ha escrito él**: un XLSX exportado por Excel, un ZIP del distribuidor con el catálogo, un
 * paquete de planos. Todos ellos usan DEFLATE (método 8 del ZIP), así que el propio lector debe
 * descomprimirlo. Este módulo implementa el algoritmo completo (bloques sin comprimir, Huffman
 * fijo y Huffman dinámico) en JavaScript puro: funciona igual en el navegador, en Node y dentro
 * del shell de escritorio, sin dependencias y sin asincronía.
 *
 * Es la pieza que hace que `readZip` entienda ZIP comprimidos de verdad.
 */

/* ---------------------------------------------- lector de bits */

class Bits {
  constructor(u8, pos = 0) { this.u8 = u8; this.pos = pos; this.bit = 0; }
  /** Lee n bits en orden LSB-first (como los lee cualquier descompresor de DEFLATE). */
  leer(n) {
    let v = 0;
    for (let i = 0; i < n; i++) {
      if (this.pos >= this.u8.length) throw new Error('DEFLATE truncado');
      const b = (this.u8[this.pos] >> this.bit) & 1;
      v |= b << i;
      this.bit++;
      if (this.bit === 8) { this.bit = 0; this.pos++; }
    }
    return v;
  }
  alinear() { if (this.bit) { this.bit = 0; this.pos++; } }
  get bytePos() { return this.pos + (this.bit ? 1 : 0); }
}

/* ---------------------------------------------- tablas del RFC 1951 */

const LONGITUDES_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
const LONGITUDES_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DISTANCIAS_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
const DISTANCIAS_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const ORDEN_LONGITUDES = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

/* ---------------------------------------------- árbol de Huffman */

/** Construye el árbol canónico (definido en el RFC) a partir de la lista de longitudes de código. */
function arbol(longitudes, nombre) {
  const maxBits = Math.max(...longitudes, 0);
  const cuenta = new Array(maxBits + 1).fill(0);
  for (const l of longitudes) if (l) cuenta[l]++;
  const siguiente = new Array(maxBits + 1).fill(0);
  let codigo = 0;
  for (let b = 1; b <= maxBits; b++) {
    codigo = (codigo + (cuenta[b - 1] || 0)) << 1;
    siguiente[b] = codigo;
  }
  const tabla = new Map();
  for (let s = 0; s < longitudes.length; s++) {
    const l = longitudes[s];
    if (!l) continue;
    tabla.set(`${l}:${siguiente[l]}`, s);
    siguiente[l]++;
  }
  if (tabla.size === 0) throw new Error(`árbol Huffman vacío (${nombre})`);
  return { maxBits, tabla };
}

function simbolo(bits, ar) {
  let codigo = 0;
  for (let l = 1; l <= ar.maxBits; l++) {
    codigo = (codigo << 1) | bits.leer(1);
    const s = ar.tabla.get(`${l}:${codigo}`);
    if (s !== undefined) return s;
  }
  throw new Error('código Huffman no encontrado');
}

/* ---------------------------------------------- inflate */

/**
 * Descomprime un bloque DEFLATE crudo (sin cabecera zlib/gzip).
 * @param {Uint8Array} u8 bytes comprimidos
 * @param {number} [tamanoEsperado] tamaño descomprimido, si se conoce (permite reservar memoria)
 * @returns {Uint8Array}
 */
export function inflateRaw(u8, tamanoEsperado = 0) {
  const bits = new Bits(u8);
  const salida = new Uint8Array(tamanoEsperado || Math.max(1024, u8.length * 4));
  let n = 0;
  const crecer = (necesita) => {
    if (necesita <= salida.length) return;
    let nuevo = salida.length * 2;
    while (nuevo < necesita) nuevo *= 2;
    const ampliada = new Uint8Array(nuevo);
    ampliada.set(salida.subarray(0, n));
    salida = ampliada;
  };

  let ultimo = false;
  while (!ultimo) {
    ultimo = bits.leer(1) === 1;
    const tipo = bits.leer(2);
    if (tipo === 0) {
      // Bloque almacenado sin comprimir
      bits.alinear();
      const p = bits.bytePos;
      const len = u8[p] | (u8[p + 1] << 8);
      const nlen = u8[p + 2] | (u8[p + 3] << 8);
      if ((len ^ 0xffff) !== nlen) throw new Error('bloque sin comprimir incoherente');
      crecer(n + len);
      for (let i = 0; i < len; i++) salida[n++] = u8[p + 4 + i];
      bits.pos = p + 4 + len; bits.bit = 0;
    } else if (tipo === 1 || tipo === 2) {
      let arbolLit, arbolDist;
      if (tipo === 1) {
        // Huffman fijo
        const lit = new Array(288);
        for (let i = 0; i < 144; i++) lit[i] = 8;
        for (let i = 144; i < 256; i++) lit[i] = 9;
        for (let i = 256; i < 280; i++) lit[i] = 7;
        for (let i = 280; i < 288; i++) lit[i] = 8;
        arbolLit = arbol(lit, 'fijo/lit');
        arbolDist = arbol(new Array(30).fill(5), 'fijo/dist');
      } else {
        // Huffman dinámico: el bloque declara sus propias longitudes
        const hlit = bits.leer(5) + 257;
        const hdist = bits.leer(5) + 1;
        const hclen = bits.leer(4) + 4;
        const longC = new Array(19).fill(0);
        for (let i = 0; i < hclen; i++) longC[ORDEN_LONGITUDES[i]] = bits.leer(3);
        const arbolC = arbol(longC, 'cl');
        const longitudes = [];
        while (longitudes.length < hlit + hdist) {
          const s = simbolo(bits, arbolC);
          if (s < 16) longitudes.push(s);
          else if (s === 16) { const rep = 3 + bits.leer(2); const v = longitudes[longitudes.length - 1]; for (let i = 0; i < rep; i++) longitudes.push(v); }
          else if (s === 17) { const rep = 3 + bits.leer(3); for (let i = 0; i < rep; i++) longitudes.push(0); }
          else { const rep = 11 + bits.leer(7); for (let i = 0; i < rep; i++) longitudes.push(0); }
        }
        arbolLit = arbol(longitudes.slice(0, hlit), 'din/lit');
        arbolDist = arbol(longitudes.slice(hlit), 'din/dist');
      }
      for (;;) {
        const s = simbolo(bits, arbolLit);
        if (s < 256) { crecer(n + 1); salida[n++] = s; continue; }
        if (s === 256) break;                       // fin del bloque
        const li = s - 257;
        if (li >= LONGITUDES_BASE.length) throw new Error('símbolo de longitud fuera de rango');
        const longitud = LONGITUDES_BASE[li] + bits.leer(LONGITUDES_EXTRA[li]);
        const ds = simbolo(bits, arbolDist);
        if (ds >= DISTANCIAS_BASE.length) throw new Error('símbolo de distancia fuera de rango');
        const distancia = DISTANCIAS_BASE[ds] + bits.leer(DISTANCIAS_EXTRA[ds]);
        if (distancia > n) throw new Error('distancia mayor que lo descomprimido');
        crecer(n + longitud);
        for (let i = 0; i < longitud; i++) { salida[n] = salida[n - distancia]; n++; }
      }
    } else {
      throw new Error('tipo de bloque DEFLATE reservado (3)');
    }
  }
  return salida.subarray(0, n);
}

/** Descomprime con cabecera zlib (método 8), por si el contenedor la incluye. */
export function inflateZlib(u8) {
  if (u8.length < 2) throw new Error('datos zlib demasiado cortos');
  const cmf = u8[0], flg = u8[1];
  if ((cmf & 0x0f) !== 8) throw new Error('método de compresión no soportado');
  if (((cmf << 8) | flg) % 31 !== 0) throw new Error('cabecera zlib incoherente');
  const tieneDiccionario = (flg & 0x20) !== 0;
  return inflateRaw(u8.subarray(2 + (tieneDiccionario ? 4 : 0)));
}
