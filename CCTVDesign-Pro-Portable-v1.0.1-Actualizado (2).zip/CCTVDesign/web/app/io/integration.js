/**
 * CCTV DESIGN PRO — Intercambio con ARQ GEN y con otras herramientas (§4, §39)
 *
 * El contrato pide una **API de integración con ARQ GEN que sea una extensión, nunca una
 * dependencia**: CCTV DESIGN PRO debe funcionar exactamente igual si este archivo se borra.
 * Por eso aquí no hay nada que el resto del programa necesite: este módulo solo LEE del modelo
 * y escribe ficheros de intercambio (paquete JSON y contrato XML), y sabe leer un paquete de
 * ARQ GEN para aprovechar sus estancias como zonas del proyecto.
 *
 * Regla de oro (§42): lo que ARQ GEN aporta son geometrías y nombres; todos los cálculos de CCTV
 * se rehacen aquí con el motor propio.
 */
import { polyArea } from '../core/geometry.js?v=b441e3fc';
import { getItem } from '../core/catalog.js?v=b441e3fc';

export const INTEGRATION = {
  id: 'CCTV-INTEGRATION',
  version: '1.0.0',
  contract: 'CP CCTV §4, §39',
  format: 'JSON (paquete) + XML (contrato)',
  capabilities: ['zonas', 'muros', 'camaras', 'equipos', 'enlaces', 'materiales', 'presupuesto', 'almacenamiento', 'validacion', 'modulos'],
  direction: 'bidireccional: exporta el diseño y acepta estancias y escala de ARQ GEN',
  removable: true,
};

const attrs = (o) => Object.entries(o)
  .filter(([, v]) => v !== undefined && v !== null && v !== '')
  .map(([k, v]) => `${k}="${String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;')}"`).join(' ');
const ms = (n) => (n === undefined || n === null ? null : Math.round(n * 1000) / 1000);

/**
 * Paquete de integración del proyecto: lo mínimo y suficiente para que otra herramienta
 * (ARQ GEN, un ERP, un GIS) entienda el diseño sin necesidad de CCTV DESIGN PRO.
 */
export function integrationPackage(prj, results = {}) {
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const devs = prj.entities.filter((e) => e.type === 'device');
  const cables = prj.entities.filter((e) => e.type === 'cable');
  const rooms = prj.entities.filter((e) => e.type === 'room');
  return {
    magic: INTEGRATION.id,
    version: INTEGRATION.version,
    contract: INTEGRATION.contract,
    generatedAt: new Date().toISOString(),
    capabilities: INTEGRATION.capabilities,
    project: {
      name: prj.meta.name, client: prj.meta.client || '', site: prj.meta.site || '',
      scale: prj.meta.scale, units: 'm', currency: prj.meta.currency || 'EUR',
      entities: prj.entities.length, layers: prj.layers.map((l) => l.name),
    },
    zones: rooms.map((r) => ({
      id: r.id, name: r.data.name || r.id, critical: !!r.data.critical,
      area: ms(Math.abs(polyArea(r.points))), points: r.points.length,
    })),
    walls: prj.entities.filter((e) => e.layer === 'ARQUITECTURA' && e.points.length >= 2)
      .map((e) => ({ id: e.id, type: e.type, thickness: e.data.h || null, points: e.points.length })),
    cameras: cams.map((c) => {
      const it = getItem(prj.catalog, c.data.catalogId) || { specs: {} };
      return {
        id: c.id, label: c.data.label, model: it.model || '', x: ms(c.points[0].x), y: ms(c.points[0].y),
        height: c.data.height, azimuth: c.data.azimuth, tilt: c.data.tilt, focal: c.data.focal,
        objective: c.data.objective, ip: c.data.ip || '', switch: c.data.switchId || '',
        kind: it.specs.analog ? 'analog' : it.specs.ptz ? 'ptz' : it.specs.lpr ? 'lpr' : 'ip',
      };
    }),
    devices: devs.map((d) => ({
      id: d.id, kind: d.data.kind, label: d.data.label, catalogId: d.data.catalogId,
      x: ms(d.points[0].x), y: ms(d.points[0].y), ip: d.data.ip || '',
    })),
    links: cables.map((c) => ({
      id: c.id, from: c.data.from, to: c.data.to, medium: c.data.media || 'auto',
      geometric: ms(c.data.geometric), supply: ms(c.data.supply), drop: ms(c.data.drop),
      status: c.data.distanceStatus || '',
    })),
    results: {
      coveragePct: results.coverage ? ms(results.coverage.coveragePct) : null,
      poe: results.poe ? results.poe.overall : null,
      storageTb: results.storage ? ms(results.storage.requiredTb) : null,
      bomLines: results.bom ? results.bom.length : null,
      budgetTotal: results.budget ? ms(results.budget.total) : null,
      validation: results.validation ? { ok: results.validation.ok, summary: results.validation.summary } : null,
    },
  };
}

/** Contrato XML del paquete: mismo contenido, formato que cualquier ERP puede leer. */
export function integrationToXml(pkg) {
  const L = [];
  L.push('<?xml version="1.0" encoding="UTF-8"?>');
  L.push(`<cctvIntegration ${attrs({ version: pkg.version, contract: pkg.contract, generated: pkg.generatedAt })}>`);
  L.push(`  <contract id="${pkg.magic}" versions="${pkg.capabilities.join(' ')}" removable="true"/>`);
  L.push(`  <project ${attrs(pkg.project)}/>`);
  L.push('  <zones>');
  for (const z of pkg.zones) L.push(`    <zone ${attrs(z)}/>`);
  L.push('  </zones>');
  L.push('  <cameras>');
  for (const c of pkg.cameras) L.push(`    <camera ${attrs(c)}/>`);
  L.push('  </cameras>');
  L.push('  <devices>');
  for (const d of pkg.devices) L.push(`    <device ${attrs(d)}/>`);
  L.push('  </devices>');
  L.push('  <links>');
  for (const k of pkg.links) L.push(`    <link ${attrs(k)}/>`);
  L.push('  </links>');
  L.push('  <results>');
  for (const [k, v] of Object.entries(pkg.results)) {
    if (v && typeof v === 'object') L.push(`    <${k} ${attrs(v)}/>`);
    else L.push(`    <${k}>${v === null ? '' : v}</${k}>`);
  }
  L.push('  </results>');
  L.push('</cctvIntegration>');
  return L.join('\n');
}

/**
 * Lee un paquete de ARQ GEN. Se admiten las claves en español (formato nativo de ARQ GEN) y en
 * inglés (formato neutro de la API). Lo único que se interpreta son geometrías y nombres.
 */
export function importArqGen(data) {
  const src = typeof data === 'string' ? JSON.parse(data) : data;
  const plantas = src.plantas || src.floors || src.levels || [];
  const rooms = [];
  const walls = [];
  let escala = Number(src.escala || src.scale || 0) || null;
  for (const planta of plantas) {
    const est = planta.estancias || planta.rooms || [];
    const muros = planta.muros || planta.walls || [];
    if (!escala && planta.escala) escala = Number(planta.escala) || null;
    for (const e of est) {
      const pts = (e.poligono || e.polygon || e.points || []).map((p) => (Array.isArray(p) ? { x: Number(p[0]), y: Number(p[1]) } : { x: Number(p.x), y: Number(p.y) }))
        .filter((p) => isFinite(p.x) && isFinite(p.y));
      if (pts.length < 3) continue;
      rooms.push({
        name: e.nombre || e.name || 'Estancia sin nombre',
        critical: !!(e.critica || e.critical),
        points: pts,
        area: Math.abs(polyArea(pts)),
        floor: planta.nombre || planta.name || '',
      });
    }
    for (const m of muros) {
      const pts = (m.poligono || m.polygon || m.points || (m.a && m.b ? [m.a, m.b] : []))
        .map((p) => (Array.isArray(p) ? { x: Number(p[0]), y: Number(p[1]) } : { x: Number(p.x), y: Number(p.y) }));
      if (pts.length >= 2) walls.push({ points: pts, thickness: Number(m.espesor || m.thickness) || 0.15 });
    }
  }
  return {
    ok: rooms.length > 0,
    project: src.proyecto || src.project || '',
    scale: escala,
    rooms, walls,
    summary: `${rooms.length} estancia(s) y ${walls.length} muro(s) de ${plantas.length} planta(s)`,
  };
}

/** Añade al proyecto las zonas y muros leídos de ARQ GEN (nunca toca lo ya dibujado). */
export function applyArqGen(prj, pack, opts = {}) {
  const layerZones = 'ZONAS';
  const layerWalls = 'ARQUITECTURA';
  // El identificador de capa es el nombre en mayúsculas; se busca por identificador, no por nombre,
  // porque un proyecto puede tener la capa «Zonas de interés» (id ZONAS) y crear otra con el mismo
  // identificador dejaría dos capas iguales y la geometría se pintaría con la que aparezca primero.
  const ensureLayer = (name) => {
    const id = String(name).toUpperCase();
    const existente = prj.layers.find((l) => String(l.id).toUpperCase() === id);
    if (existente) return existente;
    const capa = { id, name, color: id === 'ZONAS' ? '#3f9b6d' : '#8fa3b8', visible: true, locked: false };
    prj.layers.push(capa);
    return capa;
  };
  ensureLayer(layerZones);
  const added = { rooms: 0, walls: 0 };
  if (!prj.meta.scale || Math.abs(prj.meta.scale - 1) < 1e-9) {
    if (pack.scale && Math.abs(pack.scale - 1) > 1e-9) prj.meta.scale = pack.scale;   // calibración heredada
  }
  if (opts.rooms !== false) {
    for (const r of pack.rooms) {
      prj.entities.push({
        id: 'ARQ' + Math.random().toString(36).slice(2, 8), type: 'room', layer: layerZones, closed: true,
        points: r.points, data: { name: r.name, critical: r.critical, source: 'ARQ GEN' },
      });
      added.rooms++;
    }
  }
  if (opts.walls) {
    for (const w of pack.walls) {
      prj.entities.push({
        id: 'ARQW' + Math.random().toString(36).slice(2, 8), type: 'polyline', layer: layerWalls, closed: false,
        points: w.points, data: { kind: 'wall', h: w.thickness, source: 'ARQ GEN' },
      });
      added.walls++;
    }
  }
  return added;
}

/**
 * Comprobación de desacoplamiento (§39): el core y los demás módulos de E/S no pueden depender
 * de este archivo. Se le pasa la lista de fuentes del proyecto y devuelve las violaciones.
 */
export function checkDecoupled(sources = [], opts = {}) {
  const allow = opts.allow || ['main.js', 'panels.js'];     // la interfaz es quien ofrece la función
  const violations = [];
  let checked = 0;
  for (const { path, source } of sources) {
    if (/integration\.js$/.test(path)) continue;
    if (allow.some((a) => path.endsWith(a))) continue;
    checked++;
    const imports = [...String(source).matchAll(/import\s+[^;]*from\s+['"]([^'"]+)['"]/g)].map((m) => m[1]);
    for (const imp of imports) if (/integration/.test(imp)) violations.push({ path, imp });
  }
  return { ok: violations.length === 0, checked, violations, coreClean: violations.every((v) => !/\/core\//.test(v.path)) };
}
