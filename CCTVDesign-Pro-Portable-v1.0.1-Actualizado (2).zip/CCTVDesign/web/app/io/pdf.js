/**
 * CCTV DESIGN PRO — Escritor PDF vectorial propio (CP CCTV §29)
 * Genera PDF 1.4 con texto (Helvetica/WinAnsi) y vectorial. Sin dependencias.
 */

const PAGES = {
  A4: [595.28, 841.89], A3: [841.89, 1190.55], A2: [1190.55, 1683.78],
  A1: [1683.78, 2383.94], A0: [2383.94, 3370.39],
};

/** Codifica texto a WinAnsi (byte por byte) y escapa caracteres especiales de PDF. */
function pdfString(s) {
  const map = { 0x20ac: 0x80, 0x201a: 0x82, 0x0192: 0x83, 0x201e: 0x84, 0x2026: 0x85, 0x2020: 0x86, 0x2021: 0x87,
    0x02c6: 0x88, 0x2030: 0x89, 0x0160: 0x8a, 0x2039: 0x8b, 0x0152: 0x8c, 0x017d: 0x8e, 0x2018: 0x91,
    0x2019: 0x92, 0x201c: 0x93, 0x201d: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97, 0x02dc: 0x98,
    0x2122: 0x99, 0x0161: 0x9a, 0x203a: 0x9b, 0x0153: 0x9c, 0x017e: 0x9e, 0x0178: 0x9f };
  let out = '';
  for (const ch of String(s)) {
    let c = ch.codePointAt(0);
    if (map[c] !== undefined) c = map[c];
    if (c > 255) c = 63; // '?'
    if (c === 40 || c === 41 || c === 92) out += '\\' + String.fromCharCode(c);
    else if (c < 32) out += ' ';
    else out += String.fromCharCode(c);
  }
  return out;
}

class ByteBuf {
  constructor() { this.chunks = []; this.length = 0; }
  write(s) { this.chunks.push(s); this.length += s.length; }
  bytes() {
    const out = new Uint8Array(this.length);
    let o = 0;
    for (const c of this.chunks) for (let i = 0; i < c.length; i++) out[o++] = c.charCodeAt(i) & 0xff;
    return out;
  }
}

const rgb = (hex) => {
  const h = (hex || '#000000').replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
};
const f = (n) => (Math.round(n * 1000) / 1000).toString();

export class PdfDoc {
  constructor(opts = {}) {
    const size = PAGES[opts.size] || PAGES.A4;
    this.w = opts.landscape ? size[1] : size[0];
    this.h = opts.landscape ? size[0] : size[1];
    this.margin = opts.margin === undefined ? 36 : opts.margin;
    this.meta = { title: opts.title || '', author: opts.author || 'CCTV DESIGN PRO', subject: opts.subject || '' };
    this.pages = [];
    this.addPage();
  }

  addPage() { this.pages.push([]); this.page = this.pages[this.pages.length - 1]; return this; }
  get width() { return this.w; }
  get height() { return this.h; }
  get contentWidth() { return this.w - this.margin * 2; }

  text(x, y, str, size = 9, o = {}) {
    this.page.push({ t: 'text', x, y, s: String(str), size, bold: !!o.bold, color: o.color || '#000000', align: o.align || 'left' });
    return this;
  }
  line(x1, y1, x2, y2, o = {}) {
    this.page.push({ t: 'line', x1, y1, x2, y2, width: o.width || 0.5, color: o.color || '#000000', dash: o.dash });
    return this;
  }
  rect(x, y, w, h, o = {}) {
    this.page.push({ t: 'rect', x, y, w, h, fill: o.fill, stroke: o.stroke, width: o.width || 0.5, dash: o.dash });
    return this;
  }
  polyline(pts, o = {}) {
    this.page.push({ t: 'poly', pts, width: o.width || 0.5, color: o.color || '#000000', close: !!o.close, fill: o.fill, dash: o.dash });
    return this;
  }

  _render(page) {
    const L = [];
    for (const op of page) {
      if (op.t === 'text') {
        const [r, g, b] = rgb(op.color);
        let x = op.x;
        if (op.align === 'center' || op.align === 'right') {
          const w = op.s.length * op.size * (op.bold ? 0.55 : 0.5);
          x -= op.align === 'center' ? w / 2 : w;
        }
        L.push(`${f(r)} ${f(g)} ${f(b)} rg BT /F${op.bold ? 2 : 1} ${f(op.size)} Tf ${f(x)} ${f(op.y)} Td (${pdfString(op.s)}) Tj ET`);
      } else if (op.t === 'line') {
        const [r, g, b] = rgb(op.color);
        L.push(`${f(op.width)} w ${f(r)} ${f(g)} ${f(b)} RG ${op.dash ? `[${op.dash.join(' ')}] 0 d` : '[] 0 d'} ${f(op.x1)} ${f(op.y1)} m ${f(op.x2)} ${f(op.y2)} l S`);
      } else if (op.t === 'rect') {
        if (op.fill) { const [r, g, b] = rgb(op.fill); L.push(`${f(r)} ${f(g)} ${f(b)} rg ${f(op.x)} ${f(op.y)} ${f(op.w)} ${f(op.h)} re f`); }
        if (op.stroke !== undefined) {
          const [r, g, b] = rgb(op.stroke);
          L.push(`${f(op.width)} w ${f(r)} ${f(g)} ${f(b)} RG ${op.dash ? `[${op.dash.join(' ')}] 0 d` : '[] 0 d'} ${f(op.x)} ${f(op.y)} ${f(op.w)} ${f(op.h)} re S`);
        }
      } else if (op.t === 'poly' && op.pts.length > 1) {
        const [r, g, b] = rgb(op.color || '#000000');
        if (op.fill) { const [fr, fg, fb] = rgb(op.fill); L.push(`${f(fr)} ${f(fg)} ${f(fb)} rg`); }
        L.push(`${f(op.width)} w ${f(r)} ${f(g)} ${f(b)} RG ${op.dash ? `[${op.dash.join(' ')}] 0 d` : '[] 0 d'} ` +
          op.pts.map((p, i) => `${f(p.x)} ${f(p.y)} ${i ? 'l' : 'm'}`).join(' ') + (op.close ? ' h' : '') + (op.fill ? ' B' : ' S'));
      }
    }
    return L.join('\n');
  }

  save() {
    const buf = new ByteBuf();
    const offsets = [];
    const objects = [];
    objects.push('<< /Type /Catalog /Pages 2 0 R >>');
    objects.push(null); // páginas, se rellena luego
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const kids = [];
    let n = 5;
    this.pages.forEach((pg) => {
      const content = this._render(pg);
      const contentObj = n + 1;
      kids.push(`${n} 0 R`);
      objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(this.w)} ${f(this.h)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentObj} 0 R >>`);
      objects.push({ stream: content });
      n += 2;
    });
    objects[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${this.pages.length} >>`;

    buf.write('%PDF-1.4\n%\xe2\xe3\xcf\xd3\n');
    objects.forEach((o, i) => {
      offsets[i] = buf.length;
      buf.write(`${i + 1} 0 obj\n`);
      if (o && o.stream !== undefined) {
        const body = o.stream;
        buf.write(`<< /Length ${body.length} >>\nstream\n${body}\nendstream\n`);
      } else buf.write(`${o}\n`);
      buf.write('endobj\n');
    });
    const xref = buf.length;
    buf.write(`xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`);
    for (const off of offsets) buf.write(`${String(off).padStart(10, '0')} 00000 n \n`);
    buf.write(`trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info << /Title (${pdfString(this.meta.title)}) /Author (${pdfString(this.meta.author)}) /Producer (CCTV DESIGN PRO) /CreationDate (D:${new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)}Z) >> >>\nstartxref\n${xref}\n%%EOF`);
    return buf.bytes();
  }
}
