/**
 * CCTV DESIGN PRO — Escritor XLSX (OOXML mínimo, CP CCTV §29)
 * Genera un libro real de Excel sin librerías externas, usando inlineStr.
 */
import { zipStore, readZip } from './zip.js?v=b441e3fc';

const esc = (s) => String(s === null || s === undefined ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const colName = (i) => {
  let s = '';
  i++;
  while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); }
  return s;
};

function sheetXml(rows, opts = {}) {
  const L = [];
  L.push('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
  L.push('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">');
  if (opts.widths && opts.widths.length) {
    L.push('<cols>');
    opts.widths.forEach((w, i) => L.push(`<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`));
    L.push('</cols>');
  }
  L.push('<sheetData>');
  rows.forEach((row, r) => {
    const cells = [];
    row.forEach((v, c) => {
      if (v === null || v === undefined || v === '') return;
      const ref = `${colName(c)}${r + 1}`;
      const style = r === 0 && opts.header !== false ? ' s="1"' : '';
      if (typeof v === 'number' && isFinite(v)) cells.push(`<c r="${ref}"${style}><v>${v}</v></c>`);
      else cells.push(`<c r="${ref}"${style} t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`);
    });
    L.push(`<row r="${r + 1}">${cells.join('')}</row>`);
  });
  L.push('</sheetData></worksheet>');
  return L.join('');
}

/**
 * @param {{name:string, rows:any[][], widths?:number[]}[]} sheets
 * @returns {Uint8Array}
 */
export function toXlsx(sheets) {
  const files = [];
  const sheetNames = sheets.map((s, i) => s.name || `Hoja${i + 1}`);
  files.push({ name: '[Content_Types].xml', data:
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
    sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') +
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
    '</Types>' });
  files.push({ name: '_rels/.rels', data:
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
    '</Relationships>' });
  files.push({ name: 'xl/workbook.xml', data:
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
    '<sheets>' + sheetNames.map((n, i) => `<sheet name="${esc(n).slice(0, 31)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets></workbook>' });
  files.push({ name: 'xl/_rels/workbook.xml.rels', data:
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') +
    `<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
    '</Relationships>' });
  files.push({ name: 'xl/styles.xml', data:
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<fonts count="2"><font><sz val="10"/><name val="Calibri"/></font>' +
    '<font><b/><sz val="10"/><name val="Calibri"/></font></fonts>' +
    '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>' +
    '<borders count="1"><border/></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
    '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>' +
    '</styleSheet>' });
  sheets.forEach((s, i) => files.push({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s.rows, s) }));
  return zipStore(files);
}


/* ------------------------------ lectura ------------------------------ */
const decodeXml = (t) => String(t)
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
  .replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
  .replace(/&#x([0-9a-fA-F]+);/g, (_, n) => String.fromCodePoint(parseInt(n, 16)))
  .replace(/&amp;/g, '&');

const colIndex = (ref) => {
  let i = 0;
  for (const ch of ref) { if (ch >= 'A' && ch <= 'Z') i = i * 26 + (ch.charCodeAt(0) - 64); else break; }
  return i - 1;
};

/**
 * Lee un libro XLSX y devuelve { sheets: [{ name, rows: any[][] }] }.
 * Soporta celdas compartidas, inlineStr, fórmulas con resultado y números.
 */
export function fromXlsx(u8) {
  const entries = readZip(u8);
  const get = (n) => entries.find((e) => e.name === n);
  const td = new TextDecoder();
  const wbPart = get('xl/workbook.xml');
  if (!wbPart) throw new Error('El archivo no contiene xl/workbook.xml');
  const wb = td.decode(wbPart.data);
  const relsPart = get('xl/_rels/workbook.xml.rels');
  const rid = {};
  if (relsPart) for (const m of td.decode(relsPart.data).matchAll(/Id="([^"]+)"[^>]*Target="([^"]+)"/g)) rid[m[1]] = m[2];

  const shared = [];
  const ssPart = get('xl/sharedStrings.xml');
  if (ssPart) {
    for (const m of td.decode(ssPart.data).matchAll(/<si>([\s\S]*?)<\/si>/g)) {
      let text = '';
      for (const t of m[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)) text += decodeXml(t[1]);
      shared.push(text);
    }
  }

  const sheets = [];
  for (const sm of wb.matchAll(/<sheet[^>]*name="([^"]*)"[^>]*r:id="([^"]+)"/g)) {
    const target = rid[sm[2]] || '';
    const path = 'xl/' + target.replace(/^\//, '').replace(/^xl\//, '');
    const part = get(path);
    if (!part) continue;
    const xml = td.decode(part.data);
    const rows = [];
    for (const rm of xml.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
      const cells = [];
      for (const cm of rm[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const attrs = cm[1] || '', body = cm[2] || '';
        const ref = (attrs.match(/r="([^"]+)"/) || [])[1];
        const t = (attrs.match(/t="([^"]+)"/) || [])[1];
        const col = ref !== undefined ? colIndex(ref) : cells.length;
        const vm = body.match(/<v>([\s\S]*?)<\/v>/);
        const tm = body.match(/<t[^>]*>([\s\S]*?)<\/t>/);
        let val = '';
        if (t === 's' && vm) val = shared[parseInt(vm[1], 10)] ?? '';
        else if (t === 'inlineStr' && tm) val = decodeXml(tm[1]);
        else if (vm) { const n = parseFloat(vm[1]); val = isNaN(n) ? decodeXml(vm[1]) : n; }
        else if (tm) val = decodeXml(tm[1]);
        while (cells.length <= col) cells.push('');
        cells[col] = val;
      }
      if (cells.length) rows.push(cells);
    }
    sheets.push({ name: sm[1], rows });
  }
  return { sheets };
}
