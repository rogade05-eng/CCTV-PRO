/**
 * CCTV DESIGN PRO — DWG: identificación, estrategia y puente de conversión (CP CCTV §9)
 *
 * DWG es un formato binario **propietario y cerrado**: no se puede leer de forma fiable sin
 * ingeniería inversa ni depender de AutoCAD/ODA. El contrato exige una «estrategia técnicamente
 * viable, sin hacer que el programa dependa de AutoCAD», así que este módulo:
 *
 *   1. **Identifica** el archivo y su versión por la firma de 6 bytes (AC1015, AC1032, …).
 *   2. **Resuelve** la conversión a DXF con un conversor externo **opcional** (LibreDWG
 *      `dwg2dxf`, ODA File Converter, etc.) o con el DXF que exporte el usuario; el programa
 *      importa después ese DXF con su propio lector (texto o binario).
 *   3. **Informa** de la ruta recomendada según la versión, sin bloquear nunca el resto del
 *      programa: si no hay conversor, se explica cómo obtener el DXF.
 *
 * CCTV DESIGN PRO nunca invoca a AutoCAD ni envía el plano a ningún servicio de Internet (§3).
 */

/** Firmas de versión DWG (6 primeros bytes del archivo). */
export const DWG_VERSIONS = {
  AC1006: { name: 'DWG R10', year: 1988, dxf: 'R10', readable: false },
  AC1009: { name: 'DWG R11/R12', year: 1992, dxf: 'R12', readable: false },
  AC1012: { name: 'DWG R13', year: 1994, dxf: 'R13', readable: false },
  AC1014: { name: 'DWG R14', year: 1997, dxf: 'R14', readable: false },
  AC1015: { name: 'DWG 2000/2000i/2002', year: 2000, dxf: 'R2000', readable: false },
  AC1018: { name: 'DWG 2004/2005/2006', year: 2004, dxf: 'R2004', readable: false },
  AC1021: { name: 'DWG 2007/2008/2009', year: 2007, dxf: 'R2007', readable: false },
  AC1024: { name: 'DWG 2010/2011/2012', year: 2010, dxf: 'R2010', readable: false },
  AC1027: { name: 'DWG 2013/2014/2015/2016/2017', year: 2013, dxf: 'R2013', readable: false },
  AC1032: { name: 'DWG 2018/2019/2020/2021/2022/2023/2024', year: 2018, dxf: 'R2018', readable: false },
};

/** Conversores externos que el programa puede usar si están instalados (todos opcionales). */
export const CONVERTERS = [
  { id: 'libredwg', name: 'LibreDWG (dwg2dxf)', binary: 'dwg2dxf', license: 'GPL-3.0', note: 'Conversión local, sin AutoCAD; se empaqueta con el programa o se instala aparte.',
    command: (input, output) => `dwg2dxf -o "${output}" "${input}"`, reads: Object.keys(DWG_VERSIONS) },
  { id: 'oda', name: 'ODA File Converter', binary: 'ODAFileConverter', license: 'Propietaria (gratuita)', note: 'Conversor oficial gratuito de Open Design Alliance; conversión local por lotes.',
    command: (input, output) => `ODAFileConverter "${input}" "${output}" ACAD2018 DXF 0 1`, reads: Object.keys(DWG_VERSIONS) },
  { id: 'dxfout', name: 'DXF exportado del CAD original', binary: '', license: '—', note: 'El proyectista abre el DWG en su programa y guarda como DXF ASCII o binario; es la ruta más simple y no instala nada.',
    command: () => '', reads: Object.keys(DWG_VERSIONS) },
];

/** Detecta si un buffer es DWG y de qué versión. */
export function dwgInfo(bytes) {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const head = String.fromCharCode(...arr.slice(0, 6));
  const version = DWG_VERSIONS[head] || null;
  const isDwg = /^AC10\d\d$/.test(head);
  const isBinaryDxf = head === 'AutoCA';
  return {
    file: isDwg ? 'dwg' : isBinaryDxf ? 'binary-dxf' : 'desconocido',
    signature: head, version: version || null, isDwg, isBinaryDxf, size: arr.length,
    versionName: version ? version.name : (isDwg ? `DWG desconocido (${head})` : '—'),
    // El DWG nunca se interpreta directamente: se convierte a DXF y lo lee el lector propio
    needsConversion: isDwg,
    dxfEquivalent: version ? version.dxf : null,
  };
}

/** Estrategia recomendada para un archivo concreto (texto listo para el asistente). */
export function dwgStrategy(info, converters = CONVERTERS) {
  const steps = [];
  if (!info.isDwg) {
    return { title: 'El archivo no es un DWG', steps: ['Compruebe la extensión y el contenido del archivo.'],
      recommended: converters[2], alternatives: [] };
  }
  const known = !!info.version;
  steps.push(`Archivo identificado como ${info.versionName}${known ? ` (DXF equivalente ${info.dxfEquivalent})` : ''}.`);
  steps.push('CCTV DESIGN PRO no interpreta DWG directamente: es un formato propietario. La ruta admitida es convertir a DXF y leerlo con el lector propio del programa (DXF ASCII o binario).');
  steps.push('La conversión se ejecuta en su equipo, sin AutoCAD y sin enviar el plano a Internet (§3).');
  steps.push('Si el DXF resultante es muy grande, exporte solo la planta del nivel que va a usar: el programa calcula más rápido con menos entidades.');
  const recommended = known && info.version.year >= 2007 ? converters[0] : converters[0];
  return {
    title: `Cómo importar ${info.versionName}`,
    steps,
    recommended,
    alternatives: converters.filter((c) => c !== recommended),
    signature: info.signature,
    warning: known ? null : 'La firma no corresponde a una versión conocida: puede ser un DWG de una versión más reciente o un archivo renombrado.',
  };
}

/**
 * Estado del puente de conversión en este entorno.
 * En el prototipo de navegador no se pueden ejecutar procesos: la conversión se realiza fuera y
 * se importa el DXF. En el shell de escritorio (Tauri, §35) el puente ejecuta el conversor local.
 */
export function bridgeStatus(env = {}) {
  const canSpawn = !!env.canSpawn;
  return {
    canSpawn,
    mode: canSpawn ? 'Conversión automática disponible' : 'Conversión externa (manual)',
    hint: canSpawn
      ? 'El programa puede ejecutar el conversor local que encuentre en su carpeta tools/.'
      : 'Convierta el DWG a DXF con su conversor habitual (LibreDWG, ODA File Converter o el propio CAD) y arrastre el DXF al programa. Los archivos DXF binarios también se leen.',
  };
}

/** Verifica que un texto DXF proceda de una conversión razonable (control de calidad). */
export function inspectConvertedDxf(text) {
  const t = String(text);
  const sections = (t.match(/\nSECTION/g) || []).length;
  const entities = (t.match(/\n(LINE|LWPOLYLINE|POLYLINE|CIRCLE|ARC|TEXT|MTEXT|INSERT|SOLID|ELLIPSE|POINT)\n/g) || []).length;
  const blocks = (t.match(/\nBLOCK\n/g) || []).length;
  return {
    ok: sections > 0 && entities > 0, sections, entities, blocks,
    binary: t.startsWith('AutoCAD Binary DXF'),
    note: entities > 20000 ? 'Plano muy denso: considere exportar solo la planta necesaria.' : null,
  };
}


/* ---------------------------------------------- Interoperabilidad BIM / IFC (ISO 16739) */
/**
 * CCTV DESIGN PRO — Exportador nativo IFC / BIM (Industry Foundation Classes ISO 16739)
 *
 * Exporta el proyecto de seguridad y videovigilancia a un modelo BIM interoperable (IFC 2x3 Coordination View).
 * Permite importar el diseño completo de CCTV en herramientas como Autodesk Revit, ArchiCAD, Allplan,
 * Solibri Model Checker y visores IFC libres (BIM-vision, Open IFC Viewer).
 *
 * Mapeo de elementos:
 *   · Cámaras de seguridad -> IfcSensor (USERDEFINED, SECURITYCAMERA) con colocación 3D, altura, azimut e inclinación.
 *   · Equipos de red/grabación -> IfcCommunicationsAppliance / IfcElectricDistributionBoard (Switches, NVRs, Rack).
 *   · Cableado y canalizaciones -> IfcCableSegment con trayectoria 3D poli-línea.
 *   · Muros y tabiques -> IfcWallStandardCase con extrusión prismática según altura de muro.
 *   · Obstáculos (estanterías, racks, maquinaria) -> IfcBuildingElementProxy con dimensiones físicas y altura.
 *   · Estancias / Zonas -> IfcSpace con superficie y delimitación perimetral.
 */

function generateGuid() {
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$';
  let guid = '';
  for (let i = 0; i < 22; i++) {
    guid += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return guid;
}

function cleanStr(s) {
  return String(s || '').replace(/['\\]/g, ' ').trim();
}

/**
 * Convierte un proyecto a texto estándar IFC (formato STEP físico ISO 10303-21).
 * @param {Object} prj - Proyecto CCTV
 * @param {Object} opts - Opciones de exportación
 * @returns {string} Texto IFC completo
 */
export function toIfc(prj, opts = {}) {
  let id = 1;
  const nextId = () => id++;
  const lines = [];

  const add = (line) => {
    lines.push(line);
    return id - 1;
  };

  const meta = prj.meta || {};
  const prjName = cleanStr(meta.name || 'Proyecto CCTV');
  const author = cleanStr(meta.author || 'CCTV DESIGN PRO');
  const client = cleanStr(meta.client || 'Cliente');
  const dateStr = new Date().toISOString().replace(/\.\d+Z$/, '');

  // 1. Unidades y contexto geométrico base
  const idPerson = add(`#${nextId()}=IFCPERSON($,'${author}',$,$,$,$,$,$);`);
  const idOrg = add(`#${nextId()}=IFCORGANIZATION($,'${author}',$,$,$);`);
  const idPersonOrg = add(`#${nextId()}=IFCPERSONANDORGANIZATION(#${idPerson},#${idOrg},$);`);
  const idApp = add(`#${nextId()}=IFCAPPLICATION(#${idOrg},'1.0.1','CCTV DESIGN PRO','CCTV_PRO');`);
  const idOwnerHist = add(`#${nextId()}=IFCOWNERHISTORY(#${idPersonOrg},#${idApp},$,.ADDED.,$,$,$,${Math.floor(Date.now() / 1000)});`);

  // Unidades SI (metro, radián, segundo)
  const idUnitM = add(`#${nextId()}=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);`);
  const idUnitRad = add(`#${nextId()}=IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.);`);
  const idUnitSec = add(`#${nextId()}=IFCSIUNIT(*,.TIMEUNIT.,$,.SECOND.);`);
  const idUnitAssign = add(`#${nextId()}=IFCUNITASSIGNMENT((#${idUnitM},#${idUnitRad},#${idUnitSec}));`);

  // Contexto 3D
  const idOrigin3D = add(`#${nextId()}=IFCCARTESIANPOINT((0.,0.,0.));`);
  const idAxisZ = add(`#${nextId()}=IFCDIRECTION((0.,0.,1.));`);
  const idAxisX = add(`#${nextId()}=IFCDIRECTION((1.,0.,0.));`);
  const idAxisPlacement = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idOrigin3D},#${idAxisZ},#${idAxisX});`);
  const idGeoContext = add(`#${nextId()}=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#${idAxisPlacement},$);`);

  // Estructura espacial: Project -> Site -> Building -> Storey
  const idProj = add(`#${nextId()}=IFCPROJECT('${generateGuid()}',#${idOwnerHist},'${prjName}',$,$,$,$,(#${idGeoContext}),#${idUnitAssign});`);
  const idSitePlacement = add(`#${nextId()}=IFCLOCALPLACEMENT($,#${idAxisPlacement});`);
  const idSite = add(`#${nextId()}=IFCSITE('${generateGuid()}',#${idOwnerHist},'Emplazamiento',$,$,#${idSitePlacement},$,$,.ELEMENT.,$,$,$,$,$);`);

  const idBldPlacement = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idSitePlacement},#${idAxisPlacement});`);
  const idBuilding = add(`#${nextId()}=IFCBUILDING('${generateGuid()}',#${idOwnerHist},'${client}',$,$,#${idBldPlacement},$,$,.ELEMENT.,$,$,$);`);

  const idStoreyPlacement = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idBldPlacement},#${idAxisPlacement});`);
  const idStorey = add(`#${nextId()}=IFCBUILDINGSTOREY('${generateGuid()}',#${idOwnerHist},'Planta 1',$,$,#${idStoreyPlacement},$,$,.ELEMENT.,0.);`);

  // Relaciones de agregación espacial
  add(`#${nextId()}=IFCRELAGGREGATES('${generateGuid()}',#${idOwnerHist},'SiteContainer',$,#${idProj},(#${idSite}));`);
  add(`#${nextId()}=IFCRELAGGREGATES('${generateGuid()}',#${idOwnerHist},'BuildingContainer',$,#${idSite},(#${idBuilding}));`);
  add(`#${nextId()}=IFCRELAGGREGATES('${generateGuid()}',#${idOwnerHist},'StoreyContainer',$,#${idBuilding},(#${idStorey}));`);

  const productIds = [];

  // Función para crear puntos 3D
  const pt3d = (x, y, z) => add(`#${nextId()}=IFCCARTESIANPOINT((${Number(x || 0).toFixed(4)},${Number(y || 0).toFixed(4)},${Number(z || 0).toFixed(4)}));`);
  const dir3d = (x, y, z) => add(`#${nextId()}=IFCDIRECTION((${Number(x).toFixed(4)},${Number(y).toFixed(4)},${Number(z).toFixed(4)}));`);

  // Recorrer entidades del proyecto
  for (const e of prj.entities || []) {
    const data = e.data || {};
    const name = cleanStr(data.name || data.nombre || data.label || e.id);

    if (e.type === 'camera') {
      const p = (e.points && e.points[0]) || { x: 0, y: 0 };
      const h = Number(data.height) || 2.8;
      const az = Number(data.azimuth) || 0;
      const tilt = Number(data.tilt) || 0;
      const focal = Number(data.focal) || 4.0;
      const radAz = (az * Math.PI) / 180;
      const radTilt = (tilt * Math.PI) / 180;

      // Dirección de visión de la cámara en 3D
      const dx = Math.sin(radAz) * Math.cos(radTilt);
      const dy = Math.cos(radAz) * Math.cos(radTilt);
      const dz = -Math.sin(radTilt);

      const idPos = pt3d(p.x, p.y, h);
      const idDirZ = dir3d(0, 0, 1);
      const idDirX = dir3d(dx, dy, dz);
      const idCamPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idPos},#${idDirZ},#${idDirX});`);
      const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idCamPlace});`);

      // Geometría simplificada de la cámara (cubo 0.2 x 0.1 x 0.1 m)
      const idBoxOrigin = pt3d(0, 0, 0);
      const idBoxPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idBoxOrigin},#${idAxisZ},#${idAxisX});`);
      const idBox = add(`#${nextId()}=IFCBLOCK(#${idBoxPlace},0.2,0.1,0.1);`);
      const idCamShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'Body','CSG',(#${idBox}));`);
      const idCamProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idCamShape}));`);

      // IfcSensor (SECURITYCAMERA)
      const idCam = add(`#${nextId()}=IFCSENSOR('${generateGuid()}',#${idOwnerHist},'${name}','CCTV Camera focal=${focal}mm',$,#${idLocalPlace},#${idCamProdDef},'${e.id}',.USERDEFINED.);`);
      productIds.push(idCam);

    } else if (e.type === 'device') {
      const p = (e.points && e.points[0]) || { x: 0, y: 0 };
      const kind = cleanStr(data.kind || 'switch');
      const idPos = pt3d(p.x, p.y, 0.5);
      const idDevPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idPos},#${idAxisZ},#${idAxisX});`);
      const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idDevPlace});`);

      // Geometría de caja para rack o equipo (0.48 x 0.35 x 0.2 m)
      const idBoxOrigin = pt3d(0, 0, 0);
      const idBoxPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idBoxOrigin},#${idAxisZ},#${idAxisX});`);
      const idBox = add(`#${nextId()}=IFCBLOCK(#${idBoxPlace},0.48,0.35,0.2);`);
      const idDevShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'Body','CSG',(#${idBox}));`);
      const idDevProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idDevShape}));`);

      const idDev = add(`#${nextId()}=IFCCOMMUNICATIONSAPPLIANCE('${generateGuid()}',#${idOwnerHist},'${name}','Tipo ${kind}',$,#${idLocalPlace},#${idDevProdDef},'${e.id}',.USERDEFINED.);`);
      productIds.push(idDev);

    } else if (e.type === 'cable' && e.points && e.points.length >= 2) {
      // Trayectoria de cable como IfcCableSegment
      const ptIds = e.points.map((pt) => pt3d(pt.x, pt.y, 2.7));
      const idCurve = add(`#${nextId()}=IFCPOLYLINE((${ptIds.map((p) => '#' + p).join(',')}));`);
      const idWireShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'FootPrint','Curve2D',(#${idCurve}));`);
      const idWireProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idWireShape}));`);
      const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idAxisPlacement});`);

      const idCable = add(`#${nextId()}=IFCCABLESEGMENT('${generateGuid()}',#${idOwnerHist},'${name}','UTP/Fibra',$,#${idLocalPlace},#${idWireProdDef},'${e.id}',.CABLESEGMENT.);`);
      productIds.push(idCable);

    } else if (e.type === 'room' && e.points && e.points.length >= 3) {
      // Estancia/Espacio
      const ptIds = e.points.map((pt) => pt3d(pt.x, pt.y, 0));
      ptIds.push(ptIds[0]); // cerrar bucle
      const idPoly = add(`#${nextId()}=IFCPOLYLINE((${ptIds.map((p) => '#' + p).join(',')}));`);
      const idSpaceShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'FootPrint','Curve2D',(#${idPoly}));`);
      const idSpaceProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idSpaceShape}));`);
      const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idAxisPlacement});`);

      const idSpace = add(`#${nextId()}=IFCSPACE('${generateGuid()}',#${idOwnerHist},'${name}',$,$,#${idLocalPlace},#${idSpaceProdDef},$,.ELEMENT.,.INTERNAL.,$);`);
      productIds.push(idSpace);

    } else if ((e.type === 'line' || e.type === 'polyline') && (data.muro || e.layer === 'ARQUITECTURA' || e.layer === 'MUROS')) {
      // Muro arquitectónico
      const pts = e.points || [];
      if (pts.length >= 2) {
        const ptIds = pts.map((pt) => pt3d(pt.x, pt.y, 0));
        const idPoly = add(`#${nextId()}=IFCPOLYLINE((${ptIds.map((p) => '#' + p).join(',')}));`);
        const idWallShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'Axis','Curve2D',(#${idPoly}));`);
        const idWallProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idWallShape}));`);
        const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idAxisPlacement});`);

        const idWall = add(`#${nextId()}=IFCWALLSTANDARDCASE('${generateGuid()}',#${idOwnerHist},'Muro',$,$,#${idLocalPlace},#${idWallProdDef},'${e.id}');`);
        productIds.push(idWall);
      }
    } else if (e.type === 'obstacle') {
      const p = (e.points && e.points[0]) || { x: 0, y: 0 };
      const obsTipo = cleanStr(data.tipo || 'obstaculo');
      const h = Number(data.altura) || 2.0;
      const w = Number(data.ancho) || 1.0;
      const l = Number(data.largo) || 1.0;

      const idPos = pt3d(p.x, p.y, 0);
      const idObsPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idPos},#${idAxisZ},#${idAxisX});`);
      const idLocalPlace = add(`#${nextId()}=IFCLOCALPLACEMENT(#${idStoreyPlacement},#${idObsPlace});`);

      const idBoxOrigin = pt3d(-l / 2, -w / 2, 0);
      const idBoxPlace = add(`#${nextId()}=IFCAXIS2PLACEMENT3D(#${idBoxOrigin},#${idAxisZ},#${idAxisX});`);
      const idBox = add(`#${nextId()}=IFCBLOCK(#${idBoxPlace},${l.toFixed(2)},${w.toFixed(2)},${h.toFixed(2)});`);
      const idObsShape = add(`#${nextId()}=IFCSHAPEREPRESENTATION(#${idGeoContext},'Body','CSG',(#${idBox}));`);
      const idObsProdDef = add(`#${nextId()}=IFCPRODUCTDEFINITIONSHAPE($,$,(#${idObsShape}));`);

      const idProxy = add(`#${nextId()}=IFCBUILDINGELEMENTPROXY('${generateGuid()}',#${idOwnerHist},'${name || obsTipo}','Obstaculo CCTV ${obsTipo}',$,#${idLocalPlace},#${idObsProdDef},'${e.id}',.ELEMENT.,$);`);
      productIds.push(idProxy);
    }
  }

  // Vincular todos los productos a la planta del edificio (IfcRelContainedInSpatialStructure)
  if (productIds.length > 0) {
    add(`#${nextId()}=IFCRELCONTAINEDINSPATIALSTRUCTURE('${generateGuid()}',#${idOwnerHist},'StoreyElements',$,(${productIds.map((p) => '#' + p).join(',')}),#${idStorey});`);
  }

  // Montar archivo STEP completo
  const header = [
    'ISO-10303-21;',
    'HEADER;',
    "FILE_DESCRIPTION(('ViewDefinition [CoordinationView_V2.0]'),'2;1');",
    `FILE_NAME('${prjName.replace(/\s+/g, '_')}.ifc','${dateStr}',('${author}'),('Arena AI'),'IFC generator 1.0','CCTV DESIGN PRO','');`,
    "FILE_SCHEMA(('IFC2X3'));",
    'ENDSEC;',
    'DATA;',
  ];

  const footer = [
    'ENDSEC;',
    'END-ISO-10303-21;',
    '',
  ];

  return [...header, ...lines, ...footer].join('\r\n');
}
