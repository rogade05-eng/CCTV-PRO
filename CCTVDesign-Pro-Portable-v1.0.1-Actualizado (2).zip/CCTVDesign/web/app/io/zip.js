/**
 * CCTV DESIGN PRO — Contenedor ZIP: escritor propio y lector completo
 *
 *   · Escritura (`zipStore`): método «store», sin compresión. Es lo que necesita un .xlsx
 *     (Excel exige un contenedor ZIP válido, no compresión) y evita depender de nada externo.
 *   · Lectura (`readZip`): entiende ZIP **guardados y comprimidos** (método 8, DEFLATE), con
 *     verificación de CRC de cada entrada. Lo usan la importación de XLSX (§25) y las
 *     herramientas de empaquetado, que reciben archivos escritos por otros programas.
 */
import { inflateRaw } from './inflate.js?v=b441e3fc';
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

export function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const enc = (s) => new TextEncoder().encode(s);

function u16(n) { return [n & 255, (n >>> 8) & 255]; }
function u32(n) { return [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]; }

/** Dosify time/date para las cabeceras ZIP. */
function dosDateTime(d = new Date()) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

/**
 * @param {{name:string, data:Uint8Array|string}[]} files
 * @returns {Uint8Array}
 */
export function zipStore(files) {
  const out = [];
  const central = [];
  const { time, date } = dosDateTime();
  let offset = 0;
  const push = (arr) => { for (const b of arr) out.push(b); offset += arr.length; };

  for (const f of files) {
    const name = enc(f.name);
    const data = typeof f.data === 'string' ? enc(f.data) : f.data;
    const crc = crc32(data);
    const entryOffset = offset;   // debe capturarse ANTES de escribir la cabecera local
    const local = [0x50, 0x4b, 3, 4, ...u16(20), ...u16(0), ...u16(0), ...u16(time), ...u16(date),
      ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)];
    push(local); push(name); push(data);
    central.push({ name, crc, size: data.length, offset: entryOffset });
  }

  const cdStart = offset;
  for (const c of central) {
    push([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(time), ...u16(date),
      ...u32(c.crc), ...u32(c.size), ...u32(c.size), ...u16(c.name.length), ...u16(0), ...u16(0),
      ...u16(0), ...u16(0), ...u32(0), ...u32(c.offset)]);
    push(c.name);
  }
  const cdSize = offset - cdStart;
  push([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(central.length), ...u16(central.length),
    ...u32(cdSize), ...u32(cdStart), ...u16(0)]);
  return new Uint8Array(out);
}


/**
 * Lector ZIP mínimo (store) simétrico con `zipStore`.
 * Devuelve [{ name, size, crc, data:Uint8Array }] verificando firmas.
 */
/**
 * Lee un ZIP y **descomprime** lo que esté comprimido.
 *
 * Un XLSX exportado por Excel, un paquete de catálogo del distribuidor o un ZIP de planos usan
 * DEFLATE (método 8); antes este lector solo devolvía bien las entradas guardadas sin comprimir
 * (las que escribe el propio programa). Ahora:
 *   · método 0 (guardado)  → se copia tal cual;
 *   · método 8 (deflate)   → se descomprime con el inflate propio (`io/inflate.js`);
 *   · otro método          → se avisa en lugar de devolver datos falsos.
 * Cada entrada informa de su CRC (`crcOk`) y de cómo venía (`metodo`).
 */
export function readZip(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let eocd = -1;
  for (let i = u8.length - 22; i >= 0; i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('No es un archivo ZIP válido (falta EOCD)');
  const count = dv.getUint16(eocd + 10, true);
  const cdSize = dv.getUint32(eocd + 12, true);
  const cdStart = dv.getUint32(eocd + 16, true);
  if (cdStart + cdSize > u8.length) throw new Error('Directorio central truncado');
  const out = [];
  let p = cdStart;
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('Firma de directorio central inválida');
    const metodo = dv.getUint16(p + 10, true);
    const crc = dv.getUint32(p + 16, true);
    const comprimido = dv.getUint32(p + 20, true);
    const sinComprimir = dv.getUint32(p + 24, true);
    const nLen = dv.getUint16(p + 28, true), eLen = dv.getUint16(p + 30, true), cLen = dv.getUint16(p + 32, true);
    const lho = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(u8.subarray(p + 46, p + 46 + nLen));
    const lnLen = dv.getUint16(lho + 26, true), leLen = dv.getUint16(lho + 28, true);
    const start = lho + 30 + lnLen + leLen;
    const bruto = u8.subarray(start, start + comprimido);
    let data = bruto;
    let error = null;
    if (metodo === 0) {
      data = bruto.subarray(0, sinComprimir || comprimido);
    } else if (metodo === 8) {
      try { data = inflateRaw(bruto, sinComprimir); } catch (e) { error = e.message; data = new Uint8Array(0); }
    } else {
      error = `método de compresión ${metodo} no soportado`;
      data = new Uint8Array(0);
    }
    const crcOk = error ? false : (sinComprimir ? crc32(data) === crc : true);
    out.push({ name, size: sinComprimir, comprimido, crc, metodo, crcOk, error, data });
    p += 46 + nLen + eLen + cLen;
  }
  return out;
}
