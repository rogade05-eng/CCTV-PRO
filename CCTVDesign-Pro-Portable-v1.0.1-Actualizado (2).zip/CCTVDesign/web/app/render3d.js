/**
 * CCTV DESIGN PRO — Pintado de la vista 3D (CP CCTV §8, §36)
 *
 * Dibuja en un lienzo la escena que prepara `core/view3d.js`. No usa WebGL: la tarjeta gráfica
 * exigida por el contrato (§36: Windows 10/11 con 4 GB de RAM, Celeron y sin GPU dedicada) no lo
 * garantiza, y Canvas 2D basta para leer volúmenes. El orden es el del pintor, de lejos a cerca.
 *
 * Lo que se ve, y para qué sirve al colocar una cámara:
 *   · los muros, tabiques y obstáculos extruidos con su altura real;
 *   · el haz de cada cámara, desde su altura de montaje hasta la huella en el suelo (si el haz
 *     tropieza con algo, se ve el tropiezo);
 *   · el cono de visión a la altura de una persona, que es lo que de verdad importa;
 *   · la retícula del suelo y las cotas de altura (2,8 m de referencia).
 */
import {
  baseDe, proyectar, ordenar, profundidadDe, sombreado, caraVisible, ojoDe, lineasSuelo, lamina,
  hazDeCamara, cuerpoDeCamara, cuerpoDeEquipo, montajeDeCamara, cajaDelProyecto,
  encuadrarCaja as encuadrar3d, sombrasDelSuelo, contactosDelSuelo, sombraDeHaz, LUZ } from './core/view3d.js?v=b441e3fc';
import { volumenesDelProyecto, datosDe, ALTURA_MURO, ALTURA_PERSONA, ALTURA_OBJETIVO,
  IndiceOpacos, segmentosOpacos } from './core/obstacles.js?v=b441e3fc';
import { footprintsOf } from './core/ptz.js?v=b441e3fc';
import { recortarHuellas } from './core/shadows.js?v=b441e3fc';
import { getItem } from './core/catalog.js?v=b441e3fc';
import { cierreConvexo, recortarPoligono } from './core/geometry.js?v=b441e3fc';

/** Escena 3D lista para pintar: se recalcula solo cuando cambia algo (§36: sin GPU, hay que escatimar). */
export function construirEscena(prj, catalog, rules, opts = {}) {
  const alturaMuro = (prj.settings && prj.settings.alturaMuro) || ALTURA_MURO;
  const caja = cajaDelProyecto(prj, alturaMuro);
  const volumenes = volumenesDelProyecto(prj, alturaMuro);
  const caras = [];
  for (const v of volumenes) for (const c of v.caras) caras.push({ ...c, tipo: v.tipo, id: v.id, kind: v.kind });

  // Zonas (estancias) como láminas en el suelo: dan la referencia de dónde se mide la cobertura
  const suelo = [];
  const nombres = [];
  for (const e of prj.entities) {
    if (e.type === 'room' && e.points.length >= 3) {
      suelo.push(lamina(e.points, 0.005, e.data && e.data.critical ? '#2b6cb0' : '#1f4e79', 0.35));
      if (opts.nombresEstancias !== false && e.data && e.data.name) {
        const c = centroide(e.points);
        nombres.push({ pos: { x: c.x, y: c.y, z: 0.15 }, texto: e.data.name, clase: 'estancia' });
      }
    }
  }

  // Sombras en el suelo: dan la pista de la altura de cada cosa sin necesidad de girar la vista
  const sombras = opts.sombras === false ? [] : sombrasDelSuelo(volumenes, opts);
  // Mancha de contacto: la sombra suave donde cada cosa apoya, que es lo que la «pega» al suelo
  const contactos = opts.contactos === false ? [] : contactosDelSuelo(volumenes, opts);

  // Cámaras: cuerpo, haz hasta la huella y plano de comprobación a la altura de una persona
  const haces = [];
  const sombrasHaz = [];
  const cuerpos = [];
  const montajes = [];
  const plomadas = [];
  const lineas = [];
  const mostrarHaz = opts.mostrarHaz !== false;
  const mostrarPersona = !!opts.mostrarPersona;
  // Índice de obstáculos: el haz 3D tampoco atraviesa los muros (§13)
  let idxOpacos = null;
  try {
    const alturaMuro = (prj.settings && prj.settings.alturaMuro) || ALTURA_MURO;
    idxOpacos = new IndiceOpacos(segmentosOpacos(prj, alturaMuro), 2);
  } catch { idxOpacos = null; }
  const hObjetivo = ALTURA_OBJETIVO;

  for (const cam of prj.entities) {
    if (cam.type !== 'camera') continue;
    const h = Number((cam.data || {}).height) || 2.8;
    const pos = { x: cam.points[0].x, y: cam.points[0].y, z: h };
    // El cuerpo se gira con el azimut y saca el objetivo por delante: se ve hacia dónde mira
    const giro = ((Number((cam.data || {}).azimuth) || 0) * Math.PI) / 180;
    // Si se está viendo **desde** esta cámara, su cuerpo no se pinta: se está dentro de ella.
    // Con la forma real activada se dibuja el tipo que dice el catálogo (domo, bala, PTZ, caja…)
    // y a su tamaño; si no, la cajita orientada de siempre, que es lo que había antes.
    const item = getItem(catalog, (cam.data || {}).catalogId);
    const sp = (item && item.specs) || {};
    const forma = opts.formasCamara === false ? '' : (sp.form || 'dome');
    if (opts.desdeCamara !== cam.id) {
      if (forma) {
        cuerpos.push(...cuerpoDeEquipo(pos, giro, forma, sp.dim || null, opts.colorCamara || '#e2e8f0',
          { sensores: sp.sensores }));
      } else {
        cuerpos.push(cuerpoDeCamara(pos, opts.colorCamara || '#e2e8f0', 0.24, giro));
      }
    }
    if (!mostrarHaz) continue;
    let fps = [];
    try { fps = footprintsOf(cam, catalog, rules) || []; } catch { fps = []; }
    // Huella real: la que queda tras descontar la sombra de los obstáculos (§13)
    let huellas = fps.map((fp) => [fp.polygon]);
    if (idxOpacos) {
      try {
        const rec = recortarHuellas(fps, h, hObjetivo, idxOpacos);
        huellas = rec.map((r, i) => (r.sectores.length ? r.sectores : [fps[i].polygon]));
      } catch { huellas = fps.map((fp) => [fp.polygon]); }
    }
    // Ídem con el haz: visto desde dentro taparía media pantalla
    if (opts.desdeCamara !== cam.id) {
      const degradado = opts.degradadoHaz !== false;
      const atenuar = opts.atenuarHaz === false ? 1 : (opts.bandasHaz || 2);
      for (const grupo of huellas) {
        for (const poly of grupo) {
          if (!poly || poly.length < 3) continue;
          const col = colorDeCamara(cam, opts);
          haces.push(...hazDeCamara(pos, poly, col, degradado ? 0.17 : 0.14, degradado ? 1 : atenuar, degradado));
          // Sombra propia del haz: la mancha que el cono deja en el suelo, para que no flote
          if (opts.sombraHaz !== false) {
            const s = sombraDeHaz(pos, poly, LUZ, (opts.opacidadSombraHaz === undefined ? 0.17 : opts.opacidadSombraHaz));
            if (s) sombrasHaz.push(s);
          }
        }
      }
    }
    // Soporte de la cámara: una cámara no flota en el aire, cuelga de algo. Y la plomada hasta el
    // suelo dice exactamente dónde cae, que es lo que se mide en planta.
    if (opts.soporteCamara !== false) {
      // El accesorio con el que se sujeta: escuadra de pared, tubo de techo o mástil (§24). Es lo
      // que dice de qué va colgada y lo que hay que pedir al distribuidor junto con la cámara.
      const sujecion = opts.formasCamara === false ? 'techo' : ((cam.data || {}).mount || 'pared');
      montajes.push(...montajeDeCamara(pos, giro, sujecion, forma || 'dome'));
      if (sujecion !== 'poste') {
        plomadas.push({ a: { x: cam.points[0].x, y: cam.points[0].y, z: h }, b: { x: cam.points[0].x, y: cam.points[0].y, z: 0 } });
      }
    }
    // Plano de comprobación: la altura a la que se mira si se ve a una persona (§13)
    if (mostrarPersona) {
      for (const grupo of huellas) {
        for (const poly of grupo) {
          if (!poly || poly.length < 3) continue;
          haces.push(lamina(escalarPoligono(poly, pos, ALTURA_OBJETIVO / Math.max(0.2, h)), ALTURA_OBJETIVO, '#f6ad55', 0.2));
        }
      }
    }
    // Línea de visión al centro de la huella: muestra en seguida si algo se interpone
    if (huellas.length && huellas[0].length && huellas[0][0].length) {
      const c = centroide(huellas[0][0]);
      lineas.push({ a: pos, b: { x: c.x, y: c.y, z: ALTURA_OBJETIVO } });
    }
  }
  // Rótulos de las cámaras: el nombre y la altura de montaje, que es lo que se comprueba en obra
  const etiquetas = [];
  if (opts.rotulosCamaras !== false) {
    for (const cam of prj.entities) {
      if (cam.type !== 'camera') continue;
      const h = Number((cam.data || {}).height) || 2.8;
      const nombre = (cam.data && (cam.data.name || cam.data.nombre)) || 'Cámara';
      etiquetas.push({ pos: { x: cam.points[0].x, y: cam.points[0].y, z: h + 0.45 }, texto: `${nombre} · ${h.toFixed(2).replace('.', ',')} m` });
    }
  }

  return { caja, caras, suelo, sombras, sombrasHaz, contactos, haces, cuerpos, lineas, alturaMuro, volumenes,
    etiquetas: nombres.concat(etiquetas), montajes, plomadas };
}

function colorDeCamara(cam, opts) {
  if (opts.colorHaz) return opts.colorHaz;
  const obj = (cam.data || {}).objective || 'OBSERVACION';
  return { OBSERVACION: '#63b3ed', DETECCION: '#68d391', RECONOCIMIENTO: '#f6e05e', IDENTIFICACION: '#fc8181', MATRICULA: '#b794f4' }[obj] || '#63b3ed';
}

/** Recorta la huella del suelo a la altura `z` (la sección del haz a esa cota). */
function escalarPoligono(pol, apex, fraccion) {
  const f = Math.max(0.02, Math.min(1, fraccion));
  return pol.map((p) => ({ x: apex.x + (p.x - apex.x) * f, y: apex.y + (p.y - apex.y) * f }));
}

function centroide(pol) {
  let x = 0, y = 0;
  for (const p of pol) { x += p.x; y += p.y; }
  return { x: x / pol.length, y: y / pol.length };
}

/**
 * Pinta la escena en el lienzo.
 * @param {CanvasRenderingContext2D} ctx
 * @param {object} escena la que devuelve `construirEscena`
 * @param {object} cam cámara orbital de `core/view3d.js`
 * @param {object} opts `{w, h, fondo, rejilla, colorRejilla, seleccion, opacidadMuros, cotas}`
 */
export function pintar3d(ctx, escena, cam, opts = {}) {
  const w = opts.w || ctx.canvas.width, h = opts.h || ctx.canvas.height;
  const fondo = opts.fondo || '#12151a';
  ctx.save();
  // Cielo: un degradado vertical, más oscuro arriba y algo más claro hacia el horizonte. Cuesta un
  // degradado por fotograma y quita la sensación de «pantalla en negro».
  if (opts.cielo !== false) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, mezclar(fondo, '#000000', 0.3));
    g.addColorStop(0.58, fondo);
    g.addColorStop(1, mezclar(fondo, '#41536b', 0.22));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else {
    ctx.fillStyle = fondo;
    ctx.fillRect(0, 0, w, h);
  }
  const b = baseDe(cam);
  const ojo = b.ojo;
  // Niebla de profundidad: lo lejano se funde con el fondo, que es la pista más barata de
  // profundidad que hay sin GPU (§36). Se calcula una vez por fotograma con el tamaño de la escena.
  const niebla = nieblaDe(escena, cam, opts, fondo);

  // 0. Suelo: un plano con degradado radial, más claro en el centro. Sin él la planta flota en el
  //    vacío; con él se lee como una maqueta sobre una mesa.
  if (opts.suelo !== false && escena.caja) pintarSuelo(ctx, escena, cam, w, h, opts);

  // 1. Retícula del suelo (se pinta primero: queda debajo de todo)
  if (opts.rejilla !== false && escena.caja) {
    const paso = pasoRejilla(cam.distancia);
    // La retícula se desvanece con la distancia: se reparte en tres bandas (cerca, medio y fondo) y
    // cada una se traza con su opacidad. Es lo que evita el «borde» donde acaba el suelo.
    const lineas = lineasSuelo(escena.caja, paso);
    const dmedia = lineas.map((l) => Math.hypot((l.a.x + l.b.x) / 2 - ojo.x, (l.a.y + l.b.y) / 2 - ojo.y, ojo.z));
    let dmin = Infinity, dmax = 1;
    for (const d of dmedia) { if (d < dmin) dmin = d; if (d > dmax) dmax = d; }
    const bandas = [[], [], []];
    lineas.forEach((l, i) => {
      const t = (dmedia[i] - dmin) / Math.max(1, dmax - dmin);
      bandas[t < 0.34 ? 0 : t < 0.67 ? 1 : 2].push(l);
    });
    const alfas = [0.95, 0.6, 0.25];
    bandas.forEach((grupo, k) => {
      if (!grupo.length) return;
      ctx.globalAlpha = alfas[k];
      ctx.strokeStyle = opts.colorRejilla || '#1e2530';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (const l of grupo) {
        const a = proyectar(l.a, cam, w, h), c = proyectar(l.b, cam, w, h);
        if (a.detras || c.detras) continue;
        ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y);
      }
      ctx.stroke();
    });
    ctx.globalAlpha = 1;
    // El contorno del suelo, para que se vea dónde acaba la planta
    const C = escena.caja;
    const esquinas = [
      { x: C.minX, y: C.minY, z: 0 }, { x: C.maxX, y: C.minY, z: 0 },
      { x: C.maxX, y: C.maxY, z: 0 }, { x: C.minX, y: C.maxY, z: 0 },
    ].map((p) => proyectar(p, cam, w, h));
    ctx.strokeStyle = opts.colorEjes || '#2b3648';
    ctx.beginPath();
    esquinas.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath(); ctx.stroke();
  }


  // 1 bis. Rótulos de distancia en la retícula: sin ellos no hay forma de saber a cuántos metros
  // se está mirando, que en CCTV es el dato que decide la lente (§13)
  if (opts.rotulosSuelo !== false && opts.rejilla !== false && escena.caja) {
    rotularSuelo(ctx, escena, cam, w, h, pasoRejilla(cam.distancia), opts);
  }

  // 2. Manchas de contacto y sombras: van antes que nada, los volúmenes se pintan encima
  if (opts.contactos !== false && escena.contactos && escena.contactos.length) {
    for (const s of ordenarPreparadas(carasAlOjo(escena.contactos, b), ojo)) pintarCara(ctx, s, cam, w, h, ojo, { sinLuz: true, sinBorde: true });
  }
  if (opts.sombras !== false && escena.sombras && escena.sombras.length) {
    for (const s of ordenarPreparadas(carasAlOjo(escena.sombras, b), ojo)) pintarCara(ctx, s, cam, w, h, ojo, { sinLuz: true, sinBorde: true });
  }
  // Sombra propia de cada haz: se pinta con las sombras, antes que los volúmenes, para que quede
  // debajo de todo (incluido el propio haz, que es translúcido y se pinta después)
  if (opts.sombraHaz !== false && escena.sombrasHaz && escena.sombrasHaz.length) {
    for (const s of ordenarPreparadas(carasAlOjo(escena.sombrasHaz, b), ojo)) pintarCara(ctx, s, cam, w, h, ojo, { sinLuz: true, sinBorde: true });
  }

  // 3. Zonas en el suelo
  for (const l of carasAlOjo(escena.suelo, b)) pintarCara(ctx, l.cara, cam, w, h, ojo, { sinLuz: true, borde: '#4a90d9', niebla });

  // 4. Volúmenes (muros, obstáculos, mobiliario, techos): ordenados de lejos a cerca
  const opacidadMuros = opts.opacidadMuros === undefined ? 1 : opts.opacidadMuros;
  const techos = new Set(['techo', 'cubierta']);
  // Cada cara larga se parte en trozos antes de ordenarse: es lo que permite que una persona tape
  // el trozo de muro que tiene detrás y la tape el que tiene delante (ver `trocearCara`).
  const preparadas = [];
  for (const prep of carasAlOjo(escena.caras.filter((c) => !c.plana && !(opts.ocultarTechos && techos.has(c.kind))), b)) {
    // Lo que en pantalla no llega a setenta píxeles no se parte: por muy largo que sea el muro, a
    // esa distancia no hay nada que se le pueda cruzar por delante. Es lo que mantiene a raya el
    // número de trozos sin GPU (§36).
    const grande = grandeEnPantalla(prep.cara, cam, w, h);
    for (const trozo of (grande ? trocearCara(prep.cara, ojo) : [prep.cara])) {
      preparadas.push({ cara: trozo, prof: trozo.lados ? 0 : prep.prof });
    }
  }
  const caras = ordenarPreparadas(preparadas, ojo);
  for (const cara of caras) {
    // Las aristas se dibujan **con cada cara**, no en una pasada final: así el algoritmo del pintor
    // las tapa con las caras más cercanas y no se ven las aristas de lo que queda detrás.
    pintarCara(ctx, seleccionar(cara, opts.seleccion, opacidadMuros), cam, w, h, ojo,
      { borde: 'auto', niebla, aristas: opts.aristas !== false, degradado: opts.degradado !== false,
        materiales: opts.materiales !== false, juntas: opts.juntas !== false, zocalo: opts.zocalo !== false });
  }

  // 5. Haces de las cámaras: se pintan después de los volúmenes, translúcidos
  const haces = ordenar(escena.haces, ojo);
  for (const cara of haces) pintarCara(ctx, cara, cam, w, h, ojo, { sinLuz: true, degradadoHaz: opts.degradadoHaz !== false });

  // 6. Cuerpos de las cámaras, soportes y líneas de visión
  for (const c of escena.cuerpos) {
    for (const cara of ordenarPreparadas(carasAlOjo(c.caras, b), ojo)) pintarCara(ctx, cara, cam, w, h, ojo, { niebla });
  }
  if (escena.montajes) {
    for (const m of escena.montajes) {
      for (const cara of ordenarPreparadas(carasAlOjo(m.caras, b), ojo)) pintarCara(ctx, cara, cam, w, h, ojo, { niebla });
    }
  }
  if (escena.plomadas && escena.plomadas.length) {
    ctx.strokeStyle = 'rgba(160,180,205,0.28)';
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 4]);
    ctx.beginPath();
    for (const l of escena.plomadas) {
      const a = proyectar(l.a, cam, w, h), c = proyectar(l.b, cam, w, h);
      if (a.detras || c.detras) continue;
      ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }
  ctx.strokeStyle = 'rgba(246,224,94,0.55)';
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 4]);
  ctx.beginPath();
  for (const l of escena.lineas) {
    const a = proyectar(l.a, cam, w, h), c = proyectar(l.b, cam, w, h);
    if (a.detras || c.detras) continue;
    ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);

  // 6 bis. Rótulos de las cámaras, nombres de estancia y flecha de norte
  if (escena.etiquetas && escena.etiquetas.length) {
    rotularCamaras(ctx, escena.etiquetas, cam, w, h, opts);
  }
  if (opts.norte !== false && escena.caja) pintarNorte(ctx, escena, cam, w, h, opts);
  if (opts.escalaGrafica !== false && escena.caja && !opts.desdeCamara) pintarEscala(ctx, escena, cam, w, h, opts);

  // 7. Referencia de altura: una persona de 1,75 m junto al origen, para juzgar las alturas
  if (opts.referenciaAltura !== false && escena.caja && !opts.desdeCamara) {
    pintarRegla(ctx, escena, cam, w, h, opts);
  }

  // 8. Si se mira **desde una cámara**, el rótulo con sus datos: es la gracia de la vista
  if (opts.desdeCamara) pintarHudCamara(ctx, opts.desdeCamara, w, h, opts);
  ctx.restore();
}

/**
 * Rótulo de la vista desde una cámara: una cruz en el centro para marcar dónde apunta y una placa
 * con el nombre, la óptica, la altura, el azimut y la inclinación. Es lo que convierte el 3D en una
 * herramienta de diseño: «esto es exactamente lo que va a ver esta cámara».
 */
function pintarHudCamara(ctx, info, w, h, opts) {
  const d = info || {};
  ctx.save();
  // Cruz de encuadre
  const cx = w / 2, cy = h / 2, t = Math.min(26, Math.min(w, h) * 0.04);
  ctx.strokeStyle = 'rgba(230,240,255,0.55)';
  ctx.lineWidth = 1;
  ctx.setLineDash([6, 5]);
  ctx.beginPath();
  ctx.moveTo(cx - t, cy); ctx.lineTo(cx + t, cy);
  ctx.moveTo(cx, cy - t); ctx.lineTo(cx, cy + t);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(230,240,255,0.75)'; ctx.stroke();

  const lineas = [
    `📷 ${d.nombre || 'Cámara'}`,
    `${d.modelo || ''}${d.lente ? ' · ' + d.lente + ' mm' : ''}`,
    `altura ${(d.altura !== undefined ? d.altura : 2.8).toFixed(2)} m · azimut ${Math.round(d.azimut || 0)}°` +
      ` · inclinación ${Math.round(d.inclinacion || 0)}°`,
    `campo ${Math.round(d.fov || 0)}° × alcance ${(d.alcance !== undefined ? d.alcance : 0).toFixed(1)} m`,
  ].filter(Boolean);
  ctx.font = '600 12px system-ui, sans-serif';
  const ancho = Math.max(...lineas.map((l) => ctx.measureText(l).width)) + 22;
  const alto = lineas.length * 17 + 12;
  ctx.fillStyle = 'rgba(8,11,16,0.78)';
  ctx.fillRect(14, 14, ancho, alto);
  ctx.fillStyle = '#63b3ed';
  ctx.fillRect(14, 14, 3, alto);
  ctx.fillStyle = '#e8f0fa';
  lineas.forEach((l, i) => ctx.fillText(l, 26, 32 + i * 17));
  ctx.font = '11px system-ui, sans-serif';
  ctx.fillStyle = 'rgba(200,215,235,0.75)';
  ctx.fillText('Vista desde la cámara · arrastre para mirar alrededor · Esc para volver', 16, h - 16);
  void opts;
  ctx.restore();
}

function seleccionar(cara, seleccion, opacidadMuros) {
  const sel = seleccion && seleccion.size && cara.id && seleccion.has(cara.id);
  const c = { ...cara, opacidad: (cara.opacidad === undefined ? 1 : cara.opacidad) * opacidadMuros };
  if (sel) {
    c.color = '#63b3ed';
    c.opacidad = Math.min(1, (cara.opacidad === undefined ? 1 : cara.opacidad) * Math.max(0.85, opacidadMuros));
  }
  return c;
}

/** Pinta una cara proyectada. Con `sinLuz` no se sombrea (láminas y haces translúcidos). */
function pintarCara(ctx, cara, cam, w, h, ojo, opts = {}) {
  const pts = [];
  for (const p of cara.puntos) {
    const s = proyectar(p, cam, w, h);
    if (s.detras) return;
    pts.push(s);
  }
  if (pts.length < 3) return;
  if (!cara.plana && !cara.haz && opts.omitirTraseras !== false && !caraVisible(cara, ojo)) return;
  // Caras degeneradas (de canto): ni se pintan
  let area = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    area += a.x * b.y - b.x * a.y;
  }
  if (Math.abs(area) < 1.5) return;

  // `opts.luz` sube o baja la luz de la escena entera sin tocar la geometría: es la manera de
  // «exponer» la imagen sin un filtro del lienzo, que en CPU cuesta casi 3 ms por fotograma (§36).
  const luz = opts.sinLuz ? 1 : sombreado(cara) * (opts.luz > 0 ? opts.luz : 1);
  let color = matizar(cara.color || '#8b95a6', luz);
  // Niebla: la cara se funde con el fondo según lo lejos que esté del ojo
  const n = opts.niebla;
  if (n && n.cantidad > 0) {
    const c = centroDe(cara.puntos);
    const d = Math.hypot(c.x - ojo.x, c.y - ojo.y, c.z - ojo.z);
    const t = Math.max(0, Math.min(1, (d - n.d0) / Math.max(1, n.d1 - n.d0))) * n.cantidad;
    if (t > 0.01) color = mezclar(color, n.color, t);
  }
  // La silueta del haz: el contorno del cono en pantalla, que es el cierre convexo de sus puntos
  // proyectados. Pintar el cono de una vez es lo que permite un degradado de verdad sin pagar un
  // degradado por cada lado de la huella.
  let contorno = pts;
  if (cara.silueta && opts.degradadoHaz !== false) {
    const hull = cierreConvexo(pts);
    if (hull.length >= 3) contorno = hull;
  }
  ctx.beginPath();
  contorno.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();

  // Materiales: el cristal y las rejas se ven a través, no son bloques de color
  let opacidad = cara.opacidad === undefined ? 1 : cara.opacidad;
  if (opts.materiales && !cara.plana && !cara.haz) {
    const k = cara.kind;
    if (k === 'ventana') opacidad *= 0.42;
    else if (k === 'cerca' || k === 'reja') opacidad *= 0.38;
    else if (k === 'puerta') opacidad *= 0.7;
  }
  ctx.globalAlpha = Math.max(0.05, Math.min(1, opacidad));

  // Degradado por altura: la base de cada cara más oscura y la coronación más clara. Es la oclusión
  // ambiental más barata que hay —un solo degradado lineal en pantalla— y es lo que hace que un
  // cubo deje de parecer un hexágono plano.
  let relleno = color;
  let alto = 0;
  if (opts.degradado && !cara.plana && !cara.haz) {
    let ymin = Infinity, ymax = -Infinity;
    for (const p of pts) { if (p.y < ymin) ymin = p.y; if (p.y > ymax) ymax = p.y; }
    alto = ymax - ymin;
    if (alto > 4) {
      const g = ctx.createLinearGradient(0, ymax, 0, ymin);
      g.addColorStop(0, matizar(color, 0.74));         // abajo: en sombra de contacto
      g.addColorStop(1, matizar(color, 1.1));          // arriba: mira al cielo
      relleno = g;
    }
  }
  // Haz con degradado: el cono se desvanece con la distancia de verdad. En la silueta se usa un
  // degradado **radial** con centro en la cámara (densidad máxima junto al objetivo, casi nula al
  // final del alcance) y en el charco del suelo uno lineal en la misma dirección.
  if (cara.degradado && opts.degradadoHaz !== false) {
    const pa = proyectar(cara.degradado.desde, cam, w, h);
    const pb = proyectar(cara.degradado.hasta, cam, w, h);
    if (!pa.detras && !pb.detras) {
      const [cr, cg, cb] = rgbDe(color);
      const rgba = (a) => `rgba(${cr},${cg},${cb},${a})`;
      if (cara.silueta) {
        const r = Math.max(3, Math.hypot(pb.x - pa.x, pb.y - pa.y));
        const gh = ctx.createRadialGradient(pa.x, pa.y, 0, pa.x, pa.y, r);
        gh.addColorStop(0, rgba(1));
        gh.addColorStop(0.25, rgba(0.72));
        gh.addColorStop(0.6, rgba(0.34));
        gh.addColorStop(1, rgba(0.05));
        relleno = gh;
      } else if (Math.abs(pa.x - pb.x) + Math.abs(pa.y - pb.y) > 2) {
        const gh = ctx.createLinearGradient(pa.x, pa.y, pb.x, pb.y);
        gh.addColorStop(0, rgba(1));
        gh.addColorStop(0.35, rgba(0.62));
        gh.addColorStop(0.7, rgba(0.3));
        gh.addColorStop(1, rgba(0.08));
        relleno = gh;
      }
    }
  }
  ctx.fillStyle = relleno;
  ctx.fill();
  if (opts.materiales && !cara.plana && !cara.haz) pintarMaterial(ctx, cara, pts, color, alto, opts);
  ctx.globalAlpha = 1;
  // Juntas de fábrica: hiladas en la cara, calculadas **en 3D** y proyectadas, así que la
  // perspectiva las separa como debe ser (no vale repartirlas a ojo en pantalla).
  if (opts.juntas && !cara.plana && !cara.haz) pintarJuntas(ctx, cara, cam, w, h, color, opts);
  // Costuras: un trozo de una cara partida comparte borde con su vecino, y al rellenar dos
  // polígonos pegados el suavizado deja una línea de medio píxel del fondo. Se repasa con el mismo
  // relleno, así que la junta desaparece sin dibujar un borde que no existe en la cara original.
  if (opts.lados && !opts.sinBorde) {
    ctx.lineWidth = 1;
    ctx.strokeStyle = relleno;
    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) {
      if (opts.lados[i]) continue;
      const a = pts[i], b = pts[(i + 1) % pts.length];
      ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
    }
    ctx.stroke();
    ctx.beginPath();                     // se deja el camino de la cara otra vez para los bordes
    contorno.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.closePath();
  }
  // Aristas: el contorno se repasa más oscuro en la **misma** pasada que el relleno, de modo que
  // las caras pintadas después (más cercanas) tapan las aristas de lo que queda detrás. Si hay
  // aristas, el borde no se traza aparte: va encima y es más oscuro, así que se comería el color
  // del borde y se pagaría un trazo por trozo para nada.
  const lados = opts.lados || null;
  const aristas = opts.aristas && !opts.sinBorde && !cara.haz && !cara.plana;
  if (opts.borde && !opts.sinBorde && !aristas) {
    ctx.lineWidth = 1;
    ctx.strokeStyle = opts.borde === 'auto' ? matizar(color, 0.72) : opts.borde;
    trazarLados(ctx, pts, lados);
    ctx.stroke();
  }
  if (aristas) {
    ctx.lineWidth = 1;
    ctx.strokeStyle = matizar(color, 0.5);
    trazarLados(ctx, pts, lados);
    ctx.stroke();
  }
}

/** Si una cara ocupa lo bastante en pantalla como para que valga la pena partirla (y ordenarla fina). */
function grandeEnPantalla(cara, cam, w, h, minimo = 70) {
  const p = cara.puntos;
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for (const q of p) {
    const s = proyectar(q, cam, w, h);
    if (s.detras || !isFinite(s.x)) return false;
    if (s.x < x0) x0 = s.x; if (s.x > x1) x1 = s.x;
    if (s.y < y0) y0 = s.y; if (s.y > y1) y1 = s.y;
  }
  return (x1 - x0) > minimo || (y1 - y0) > minimo;
}

/** Traza el contorno de una cara; con `lados`, sólo los lados marcados (ver `trocearCara`). */
function trazarLados(ctx, pts, lados) {
  if (!lados) return;                    // el camino de la cara ya está puesto
  ctx.beginPath();
  for (let i = 0; i < pts.length; i++) {
    if (!lados[i]) continue;
    const a = pts[i], b = pts[(i + 1) % pts.length];
    ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
  }
}

/**
 * Detalle de material, **recortado a la propia cara** (`ctx.clip`), así que sale gratis en
 * geometría: el cristal recibe dos brillos diagonales y las rejas y cercas se dibujan con barrotes
 * verticales en vez de como un muro macizo.
 */
function pintarMaterial(ctx, cara, pts, color, alto, opts) {
  const k = cara.kind;
  if (k !== 'ventana' && k !== 'puerta' && k !== 'cerca' && k !== 'reja' && k !== 'maquinaria' && k !== 'escalera' && k !== 'estanteria') return;
  if (pts.length < 3 || alto < 3) return;
  let x0 = Infinity, x1 = -Infinity, ymin = Infinity, ymax = -Infinity;
  for (const p of pts) {
    if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x;
    if (p.y < ymin) ymin = p.y; if (p.y > ymax) ymax = p.y;
  }
  ctx.save();
  ctx.clip();                                   // el camino de la cara sigue puesto
  if (k === 'estanteria') {
    // Ranuras y perforaciones industriales de cremallera en perfiles de estantería
    ctx.strokeStyle = matizar(color, 0.65);
    ctx.lineWidth = 1;
    const ancho = x1 - x0;
    if (ancho > 8 && alto > 15) {
      const nRanuras = Math.max(3, Math.min(8, Math.round(alto / 18)));
      ctx.beginPath();
      for (let i = 1; i <= nRanuras; i++) {
        const yRan = ymin + (alto * i) / (nRanuras + 1);
        ctx.moveTo(x0 + ancho * 0.15, yRan);
        ctx.lineTo(x1 - ancho * 0.15, yRan);
      }
      ctx.stroke();
    }
  } else if (k === 'escalera') {
    // Relieve antideslizante en huellas de peldaños (estrías sutiles en la superficie)
    ctx.strokeStyle = matizar(color, 0.78);
    ctx.lineWidth = 1;
    const ancho = x1 - x0;
    if (ancho > 10) {
      const nEstrias = Math.max(2, Math.min(5, Math.round(ancho / 14)));
      ctx.beginPath();
      for (let i = 1; i <= nEstrias; i++) {
        const xEst = x0 + (ancho * i) / (nEstrias + 1);
        ctx.moveTo(xEst, ymin);
        ctx.lineTo(xEst, ymax);
      }
      ctx.stroke();
    }
  } else if (k === 'ventana' || k === 'puerta') {
    // Dos brillos diagonales: la pista que dice «esto es un cristal»
    ctx.strokeStyle = k === 'puerta' ? 'rgba(255,240,210,0.35)' : 'rgba(214,242,255,0.55)';
    ctx.lineWidth = Math.max(1, Math.min(3, alto / 22));
    const ancho = x1 - x0;
    ctx.beginPath();
    ctx.moveTo(x0 + ancho * 0.15, ymax); ctx.lineTo(x0 + ancho * 0.55, ymin);
    ctx.moveTo(x0 + ancho * 0.35, ymax); ctx.lineTo(x0 + ancho * 0.75, ymin);
    ctx.stroke();
    if (k === 'puerta' || k === 'ventana') {
      // Marco y, en la ventana, un parteluz en cruz: la carpintería es lo que la delata
      const c = centroide(pts);
      const marco = escalarPoligono(pts, c, k === 'puerta' ? 0.82 : 0.86);
      ctx.strokeStyle = matizar(color, 1.3);
      ctx.lineWidth = Math.max(1, Math.min(2.5, alto / 26));
      ctx.beginPath();
      marco.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.closePath(); ctx.stroke();
      if (k === 'ventana') {
        ctx.lineWidth = Math.max(1, Math.min(2, alto / 34));
        ctx.beginPath();
        ctx.moveTo(c.x, ymin); ctx.lineTo(c.x, ymax);          // parteluz vertical
        ctx.moveTo(x0, c.y); ctx.lineTo(x1, c.y);              // y travesaño
        ctx.stroke();
      } else {
        const px = x1 - (x1 - x0) * 0.2, py = ymin + alto * 0.55;
        ctx.fillStyle = matizar(color, 1.5);
        ctx.beginPath(); ctx.arc(px, py, Math.max(1, alto / 30), 0, Math.PI * 2); ctx.fill();
      }
    }
  } else if (k === 'maquinaria') {
    // Un rack se reconoce por las unidades (esas las marca `pintarJuntas`) y por sus testigos:
    // tres puntos de luz en el frontal, que es lo que se ve de noche en la grabación.
    const cy = ymin + alto * 0.14;
    const tonos = ['#7ee081', '#7ee081', '#f2c14e'];
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = tonos[i];
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.arc(x0 + (x1 - x0) * (0.72 + i * 0.08), cy, Math.max(1, alto / 55), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  } else {
    // Barrotes: una cerca es transparente, no un muro
    const n = Math.max(3, Math.min(16, Math.round((x1 - x0) / 9)));
    ctx.strokeStyle = matizar(color, 1.35);
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 1; i < n; i++) {
      const x = x0 + ((x1 - x0) * i) / n;
      ctx.moveTo(x, ymin); ctx.lineTo(x, ymax);
    }
    // Dos travesaños horizontales, como cualquier verja
    ctx.moveTo(x0, ymin + alto * 0.22); ctx.lineTo(x1, ymin + alto * 0.22);
    ctx.moveTo(x0, ymin + alto * 0.78); ctx.lineTo(x1, ymin + alto * 0.78);
    ctx.stroke();
  }
  ctx.restore();
  void opts;
}

/**
 * Hiladas de fábrica: una junta cada 45 cm en las caras verticales de muros, tabiques, muretes y
 * columnas. Se calculan en 3D (interpolando entre la hilada de abajo y la de arriba) y se proyectan,
 * de modo que la perspectiva las junta hacia el fondo como es debido.
 */
/** Tipos que llevan zócalo y coronación, y paso de las divisiones de cada uno (0 = sin divisiones). */
const PASO_JUNTA = { muro: 0.45, tabique: 0.45, murete: 0.3, estanteria: 0.42, maquinaria: 0.2 };

function pintarJuntas(ctx, cara, cam, w, h, color, opts) {
  const k = cara.kind;
  if (!(k in PASO_JUNTA) && k !== 'columna') return;      // la columna lleva zócalo, no hiladas
  const ps = cara.puntos || [];
  if (ps.length < 4) return;
  let zmin = Infinity, zmax = -Infinity;
  for (const p of ps) { const z = p.z || 0; if (z < zmin) zmin = z; if (z > zmax) zmax = z; }
  const altoM = zmax - zmin;
  if (altoM < 0.6) return;                          // cara horizontal (coronación): sin juntas
  const inf = ps.filter((p) => (p.z || 0) <= zmin + 1e-6);
  const sup = ps.filter((p) => (p.z || 0) >= zmax - 1e-6);
  if (inf.length < 2 || sup.length < 2) return;
  // Cada punto de abajo se empareja con el de arriba más cercano en planta
  const pareja = inf.map((a) => sup.reduce((m, b) =>
    (Math.hypot(b.x - a.x, b.y - a.y) < Math.hypot(m.x - a.x, m.y - a.y) ? b : m), sup[0]));
  const medio = (i, t) => ({
    x: inf[i].x + (pareja[i].x - inf[i].x) * t,
    y: inf[i].y + (pareja[i].y - inf[i].y) * t,
    z: zmin + altoM * t });

  // Zócalo: la franja oscura de la base, que es lo que asienta el muro en el suelo
  if (opts.zocalo !== false) {
    const t = Math.min(0.14, altoM * 0.09) / altoM;
    const q = [inf[0], inf[1], medio(1, t), medio(0, t)].map((p) => proyectar(p, cam, w, h));
    if (!q.some((p) => p.detras)) {
      ctx.save();
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = matizar(color, 0.6);
      ctx.beginPath();
      q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
  }

  const paso = PASO_JUNTA[k] || 0;
  const n = paso ? Math.min(8, Math.max(1, Math.floor(altoM / paso))) : 0;
  ctx.save();
  ctx.strokeStyle = matizar(color, 0.76);
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.5;
  // Todas las juntas de la cara en **un solo trazo**: en canvas el coste está en el trazo, no en el
  // trozo de camino, así que esto divide el gasto por ocho.
  ctx.beginPath();
  for (let i = 1; i < n; i++) {                           // n = 0 (columna): ni una división
    const t = i / n;
    const A = { x: inf[0].x + (pareja[0].x - inf[0].x) * t, y: inf[0].y + (pareja[0].y - inf[0].y) * t, z: zmin + altoM * t };
    const B = { x: inf[1].x + (pareja[1].x - inf[1].x) * t, y: inf[1].y + (pareja[1].y - inf[1].y) * t, z: zmin + altoM * t };
    const a = proyectar(A, cam, w, h), b = proyectar(B, cam, w, h);
    if (a.detras || b.detras) continue;
    ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
  }
  ctx.stroke();

  // Coronación: la línea clara del remate, que perfila el muro contra el fondo
  if (opts.zocalo !== false) {
    const a = proyectar(medio(0, 0.985), cam, w, h), b = proyectar(medio(1, 0.985), cam, w, h);
    if (!a.detras && !b.detras) {
      ctx.globalAlpha = 0.7;
      ctx.strokeStyle = matizar(color, 1.4);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    }
  }
  ctx.restore();
}

/* --------------------------------------------------------------- profundidad y suelo */

/** Suelo de la maqueta: un plano con degradado radial que se apaga hacia los bordes. */
/**
 * Recorta un polígono del mundo con el plano que pasa por delante del ojo, perpendicular a la mira:
 * lo que queda **detrás** del ojo no se puede proyectar, y una sola esquina así bastaba para que el
 * suelo desapareciera entero. Eso es lo que pasa al mirar desde dentro de la escena, que es lo que
 * hace el monitor (y la vista 3D cuando se mete el punto de vista en el edificio): el suelo se iba
 * y dejaba un vacío negro en el que cualquier cosa se perdía.
 *
 * El margen (en metros por delante del ojo) no es un adorno: un vértice que cae **justo** en el
 * plano del ojo se proyecta dividiendo por cero y sale a diez mil millones de píxeles. Con holgura,
 * los vértices recortados caen de lleno delante. Eso sí: quedan muy cerca del ojo, así que se
 * proyectan muy lejos del lienzo —quien use el resultado para medir algo en pantalla tiene que
 * recortarlo antes al lienzo—.
 */
export function recortarDelante(pol, b, margen = 1.5) {
  const out = [];
  const n = pol.length;
  const lado = (p) => (p.x - b.ojo.x) * b.f.x + (p.y - b.ojo.y) * b.f.y + (p.z - b.ojo.z) * b.f.z;
  for (let i = 0; i < n; i++) {
    const p = pol[i], q = pol[(i + 1) % n];
    const dp = lado(p), dq = lado(q);
    if (dp >= margen) out.push(p);
    if ((dp >= margen) !== (dq >= margen)) {
      // El corte se hace **en el margen**, no en el plano del ojo: cortar en el plano devuelve un
      // punto con profundidad cero que al proyectarse explota.
      const t = (dp - margen) / (dp - dq);
      out.push({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, z: p.z + (q.z - p.z) * t });
    }
  }
  return out;
}

/** De qué lado del plano del ojo cae un punto: positivo si está por delante (metros). */
function ladoDe(p, b) {
  return (p.x - b.ojo.x) * b.f.x + (p.y - b.ojo.y) * b.f.y + (p.z - b.ojo.z) * b.f.z;
}

/**
 * Deja la cara **como se puede pintar**: si cruza el plano del ojo, se recorta por delante de él.
 * Una cara así no se puede proyectar tal cual —lo que queda detrás sale del revés y se come la
 * pantalla—, y descartarla entera, que es lo que se hacía, es un desastre en cuanto el ojo está
 * dentro de la escena: mirando desde una cámara se iban 73 de las 75 caras del proyecto de prueba,
 * porque los muros que envuelven al que mira son justo los que cruzan el plano del ojo. Lo que se ve
 * entonces es el suelo y nada más, que es la pinta de «se ha puesto un plano gris en medio».
 *
 * El margen es pequeño (15 cm) porque aquí no hay degradado que medir: basta con no proyectar un
 * punto pegado al ojo, que es lo que dispararía las coordenadas a diez mil millones de píxeles.
 */
function caraAlOjo(cara, b, margen = 0.15) {
  const puntos = cara.puntos;
  if (!puntos || puntos.length < 3) return null;
  let cruza = false;
  for (const p of puntos) if (ladoDe(p, b) < margen) { cruza = true; break; }
  if (!cruza) return { cara, prof: 0 };
  const rec = recortarDelante(puntos, b, margen);
  if (rec.length < 3) return null;
  // Una cara recortada se ordena por su punto **más lejano**, no por su centroide. Es la geometría
  // que rodea al observador —un muro que pasa a 20 cm, una losa que el ojo atraviesa—, así que su
  // centroide puede caer a metro y medio y mandarla al final de la cola: se pintaría **encima** de
  // todo lo que tiene delante. Eso es, ni más ni menos, «una capa gris que tapa lo que hay detrás».
  let lejos = 0;
  for (const p of rec) lejos = Math.max(lejos, Math.hypot(p.x - b.ojo.x, p.y - b.ojo.y, p.z - b.ojo.z));
  return { cara: { ...cara, puntos: rec }, prof: lejos };
}

/** Recorta una lista de caras con el plano del ojo y quita las que se quedan sin nada. */
function carasAlOjo(caras, b) {
  const out = [];
  for (const c of caras || []) { const r = caraAlOjo(c, b); if (r) out.push(r); }
  return out;
}

/**
 * Parte una cara larga en trozos. El algoritmo del pintor compara caras **de una en una**, así que
 * una sola profundidad por cara sólo sirve si la cara es corta: un muro de veinte metros que va de
 * 3 a 23 m de profundidad no se puede ordenar con un número. Con su centroide a 7 m se pinta
 * **encima** de una persona que está a 8 m delante de él, y la persona desaparece detrás de una
 * mancha gris —que es exactamente lo que se veía en el monitor—. Partido en trozos de dos metros,
 * cada trozo se ordena por su sitio y la persona tapa lo que tiene detrás y la tapan lo que tiene
 * delante, que es lo que tiene que pasar.
 *
 * Sólo se parte por el eje que más profundidad abarca, y las aristas se conservan **sólo en el
 * contorno de la cara original** (`lados`): los trozos sueltos no dibujan su propio borde, que es
 * lo que evitaría que el muro saliera rayado.
 */
function trocearCara(cara, ojo, tope = 2, maximo = 6) {
  const p = cara.puntos;
  if (!p || p.length !== 4) return [cara];
  const out = [];
  const medio = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 });
  const rec = (pts, lados, resto) => {
    let cerca = Infinity, lejos = 0;
    for (const q of pts) {
      const d = Math.hypot(q.x - ojo.x, q.y - ojo.y, q.z - ojo.z);
      if (d < cerca) cerca = d; if (d > lejos) lejos = d;
    }
    if (resto < 2 || lejos - cerca <= tope) { out.push({ puntos: pts, lados }); return; }
    const [a, b, c, e] = pts;
    const d = (q) => Math.hypot(q.x - ojo.x, q.y - ojo.y, q.z - ojo.z);
    const du = Math.abs(d(a) - d(b)) + Math.abs(d(e) - d(c));
    const dv = Math.abs(d(a) - d(e)) + Math.abs(d(b) - d(c));
    if (du >= dv) {
      // Corte a lo largo de `u`: el lado compartido va de la mitad de (a,b) a la de (e,c), que es
      // la recta por la que pasa el centro de la cara.
      const m01 = medio(a, b), m32 = medio(e, c);
      rec([a, m01, m32, e], [lados[0], false, lados[2], lados[3]], resto / 2);
      rec([m01, b, c, m32], [lados[0], lados[1], lados[2], false], resto / 2);
    } else {
      const m03 = medio(a, e), m12 = medio(b, c);
      rec([a, b, m12, m03], [lados[0], lados[1], false, lados[3]], resto / 2);
      rec([m03, m12, c, e], [false, lados[1], lados[2], lados[3]], resto / 2);
    }
  };
  rec(p, [true, true, true, true], maximo);
  if (out.length < 2) return [cara];
  return out.map((t) => ({ ...cara, puntos: t.puntos, lados: t.lados }));
}

/** Ordena de lejos a cerca una lista de `{cara, prof}`; `prof` = 0 significa «usa su centroide». */
function ordenarPreparadas(preparadas, ojo) {
  return preparadas
    .map((o) => ({ cara: o.cara, d: o.prof > 0 ? o.prof : profundidadDe(o.cara, ojo) }))
    .sort((a, b) => b.d - a.d)
    .map((o) => o.cara);
}

function pintarSuelo(ctx, escena, cam, w, h, opts) {
  const C = escena.caja;
  if (!C) return;
  // El suelo se extiende bastante más allá de la caja del proyecto: visto desde dentro, el suelo
  // tiene que llegar hasta donde alcanza la vista, no hasta donde acaba el edificio.
  const dx = (C.maxX - C.minX) * 0.35 + 8, dy = (C.maxY - C.minY) * 0.35 + 8;
  const b = baseDe(cam);
  const poligono = recortarDelante([
    { x: C.minX - dx, y: C.minY - dy, z: 0 }, { x: C.maxX + dx, y: C.minY - dy, z: 0 },
    { x: C.maxX + dx, y: C.maxY + dy, z: 0 }, { x: C.minX - dx, y: C.maxY + dy, z: 0 },
  ], b);
  if (poligono.length < 3) return;
  const esquinas = poligono.map((p) => proyectar(p, cam, w, h));
  if (esquinas.some((p) => p.detras)) return;
  // El degradado se centra en el suelo **que se ve**, no en el centro del edificio: si la cámara
  // mira hacia una esquina, el centro de la caja cae fuera del encuadre y el suelo se queda con el
  // color del fondo, que es justo lo que hacía que la mitad inferior de la imagen saliera negra.
  //
  // Y se centra en el suelo que cabe **en el lienzo**: los vértices que pone el recorte caen a veces
  // a miles de píxeles (un punto recortado a metro y medio del ojo se proyecta lejísimos), y si el
  // centro y el radio se calculan con ellos el degradado se sale entero de la imagen: lo que queda
  // dentro es un **color plano**, y un suelo plano es exactamente la pinta de «un plano gris se ha
  // puesto en medio». Recortando al lienzo, el degradado vuelve a recorrer el suelo que se ve.
  const visible = recortarPoligono(esquinas.map((p) => ({ x: p.x, y: p.y })),
    [{ x: 0, y: 0 }, { x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h }]);
  const pts = visible.length >= 3 ? visible : esquinas;
  let sx = 0, sy = 0;
  for (const p of pts) { sx += p.x; sy += p.y; }
  const centro = { x: sx / pts.length, y: sy / pts.length };
  let lejos = 0;
  for (const p of pts) lejos = Math.max(lejos, Math.hypot(p.x - centro.x, p.y - centro.y));
  const radio = Math.max(80, lejos * 1.05);
  const fondo = opts.fondo || '#12151a';
  ctx.save();
  ctx.beginPath();
  esquinas.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
  const g = ctx.createRadialGradient(centro.x, centro.y, radio * 0.05, centro.x, centro.y, radio);
  g.addColorStop(0, mezclar(fondo, '#2c3a4e', 0.85));
  g.addColorStop(0.55, mezclar(fondo, '#212b39', 0.5));
  g.addColorStop(1, fondo);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.restore();
}

/** Rótulos flotantes de las cámaras: nombre y altura de montaje. */
function rotularCamaras(ctx, etiquetas, cam, w, h, opts) {
  ctx.save();
  ctx.font = '10px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (const e of etiquetas) {
    if (e.clase === 'estancia' && opts.nombresEstancias === false) continue;
    if (e.clase !== 'estancia' && opts.rotulosCamaras === false) continue;
    const p = proyectar(e.pos, cam, w, h);
    if (p.detras || p.x < 4 || p.x > w - 4 || p.y < 4 || p.y > h - 4) continue;
    if (e.clase === 'estancia') {                   // el nombre de la estancia va pegado al suelo
      ctx.globalAlpha = 0.72;
      ctx.fillStyle = opts.colorTexto || '#93a6bd';
      ctx.fillText(e.texto, p.x, p.y);
      ctx.globalAlpha = 1;
      continue;
    }
    const ancho = ctx.measureText(e.texto).width + 10;
    ctx.fillStyle = 'rgba(8,11,16,0.72)';
    ctx.fillRect(p.x - ancho / 2, p.y - 8, ancho, 15);
    ctx.strokeStyle = 'rgba(140,170,205,0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(p.x - ancho / 2, p.y - 8, ancho, 15);
    ctx.fillStyle = opts.colorTexto || '#c3d3e6';
    ctx.fillText(e.texto, p.x, p.y);
  }
  ctx.restore();
}

/** Escala gráfica: una barra que dice cuántos metros son tantos píxeles, como en un plano. */
function pintarEscala(ctx, escena, cam, w, h, opts) {
  const C = escena.caja;
  if (!C) return;
  const cx = (C.minX + C.maxX) / 2, cy = (C.minY + C.maxY) / 2;
  const a = proyectar({ x: cx, y: cy, z: 0 }, cam, w, h);
  if (a.detras) return;
  let metros = 1, px = 0;
  for (const m of [1, 2, 5, 10, 20, 50, 100, 200]) {
    const b = proyectar({ x: cx + m, y: cy, z: 0 }, cam, w, h);
    if (b.detras) continue;
    px = Math.abs(b.x - a.x);
    metros = m;
    if (px >= 110) break;
  }
  if (px < 24) return;
  const x = 16, y = h - 20;
  ctx.save();
  ctx.strokeStyle = opts.colorTexto || '#8fa3b8';
  ctx.fillStyle = opts.colorTexto || '#8fa3b8';
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.85;
  ctx.beginPath();
  ctx.moveTo(x, y - 4); ctx.lineTo(x, y); ctx.lineTo(x + px, y); ctx.lineTo(x + px, y - 4);
  ctx.moveTo(x + px / 2, y); ctx.lineTo(x + px / 2, y - 3);
  ctx.stroke();
  ctx.font = '10px system-ui, sans-serif';
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.fillText('0', x, y - 7);
  ctx.textAlign = 'right';
  ctx.fillText(`${metros} m`, x + px, y - 7);
  ctx.restore();
}

/** Flecha de norte en el suelo: sin ella, un azimut de 90° no dice nada. */
function pintarNorte(ctx, escena, cam, w, h, opts) {
  const C = escena.caja;
  if (!C) return;
  const x = (C.minX + C.maxX) / 2, y = C.maxY + Math.max(2, (C.maxY - C.minY) * 0.06);
  const largo = Math.max(2, (C.maxY - C.minY) * 0.08);
  const a = proyectar({ x, y, z: 0 }, cam, w, h);
  const b = proyectar({ x, y: y + largo, z: 0 }, cam, w, h);
  if (a.detras || b.detras) return;
  ctx.save();
  ctx.strokeStyle = 'rgba(150,180,215,0.75)';
  ctx.fillStyle = 'rgba(150,180,215,0.75)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
  ctx.stroke();
  const ang = Math.atan2(b.y - a.y, b.x - a.x);
  const t = 7;
  ctx.beginPath();
  ctx.moveTo(b.x, b.y);
  ctx.lineTo(b.x - t * Math.cos(ang - 0.4), b.y - t * Math.sin(ang - 0.4));
  ctx.lineTo(b.x - t * Math.cos(ang + 0.4), b.y - t * Math.sin(ang + 0.4));
  ctx.closePath(); ctx.fill();
  ctx.font = '600 11px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('N', b.x - Math.cos(ang) * 12, b.y - Math.sin(ang) * 12);
  void opts;
  ctx.restore();
}

/** Centro (3D) de una cara: para medir a qué distancia está del ojo. */
function centroDe(pts) {
  let x = 0, y = 0, z = 0;
  for (const p of pts || []) { x += p.x; y += p.y; z += p.z || 0; }
  const n = Math.max(1, (pts || []).length);
  return { x: x / n, y: y / n, z: z / n };
}

/** Parámetros de la niebla de profundidad para este fotograma. */
function nieblaDe(escena, cam, opts, fondo) {
  const cantidad = opts.niebla === false ? 0 : (opts.cantidadNiebla === undefined ? 0.55 : opts.cantidadNiebla);
  const C = escena.caja;
  const radio = C ? 0.5 * Math.hypot(C.maxX - C.minX, C.maxY - C.minY) : 30;
  const mira = cam.objetivo || { x: 0, y: 0, z: 0 };
  // El rango se puede fijar desde fuera (`nieblaD0` y `nieblaD1`): el monitor lo necesita porque su
  // cámara es la equivalente a mirar desde una cámara de vigilancia, cuya «distancia» es un valor
  // ficticio de 12 m que no tiene nada que ver con lo que hay delante.
  const d0 = opts.nieblaD0 !== undefined ? opts.nieblaD0 : Math.max(1, cam.distancia - radio * 0.35);
  const d1 = opts.nieblaD1 !== undefined ? opts.nieblaD1 : Math.max(d0 + 1, cam.distancia + radio * 1.35);
  void mira;
  return { cantidad, d0, d1, color: fondo };
}

/** Trocea un color `#rrggbb`, `rgb(...)` o `#rgb` en sus tres componentes. Sin expresiones
 *  regulares: se llama una vez por cara y por fotograma, y ahí se nota. */
function rgbDe(c) {
  const s = typeof c === 'string' ? c.trim() : '';
  if (s.charCodeAt(0) === 35) {                       // '#'
    const h = s.slice(1);
    const n = parseInt(h.length === 3 ? h[0] + h[0] + h[1] + h[1] + h[2] + h[2] : h, 16);
    return Number.isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [139, 149, 166];
  }
  if (s.charCodeAt(0) === 114) {                      // 'rgb(' o 'rgba('
    const nums = s.slice(s.indexOf('(') + 1).split(',');
    return [Number(nums[0]) || 0, Number(nums[1]) || 0, Number(nums[2]) || 0];
  }
  return [139, 149, 166];
}

/** Mezcla dos colores: `t` = 0 deja el primero, `t` = 1 deja el segundo. */
export function mezclar(a, b, t) {
  const [r1, g1, b1] = rgbDe(a), [r2, g2, b2] = rgbDe(b);
  const k = t < 0 ? 0 : t > 1 ? 1 : t;
  return `rgb(${Math.round(r1 + (r2 - r1) * k)},${Math.round(g1 + (g2 - g1) * k)},${Math.round(b1 + (b2 - b1) * k)})`;
}

/** Rótulos de distancia sobre la retícula del suelo (por ejemplo «10 m»), como una cota de planta. */
function rotularSuelo(ctx, escena, cam, w, h, paso, opts) {
  const C = escena.caja;
  if (!C) return;
  ctx.save();
  ctx.font = '10px system-ui, sans-serif';
  ctx.fillStyle = opts.colorTexto || '#7f8ea3';
  ctx.globalAlpha = 0.75;
  const x0 = Math.ceil(C.minX / paso) * paso, y0 = Math.ceil(C.minY / paso) * paso;
  const marcas = [];
  for (let x = x0; x <= C.maxX; x += paso) marcas.push({ x, y: C.maxY, texto: `${Math.round(x)} m` });
  for (let y = y0; y <= C.maxY; y += paso) marcas.push({ x: C.minX, y, texto: `${Math.round(y)} m` });
  let puestos = 0;
  for (const m of marcas) {
    if (puestos > 24) break;                       // no se llena el dibujo de números
    const p = proyectar({ x: m.x, y: m.y, z: 0 }, cam, w, h);
    if (p.detras || p.x < 8 || p.y < 8 || p.x > w - 8 || p.y > h - 8) continue;
    ctx.fillText(m.texto, p.x + 3, p.y - 3);
    puestos++;
  }
  ctx.restore();
}

/**
 * Aclara u oscurece un color según el sombreado. Acepta `#rgb`, `#rrggbb` y `rgb(...)`: hace falta
 * lo último porque una cara que ya pasó por la niebla llega aquí como `rgb(...)`, y si no se
 * pudiera volver a matizar, el degradado por altura no se vería sobre ella.
 */
export function matizar(color, factor) {
  const [r, g, b] = rgbDe(color);
  const f = Math.max(0.25, Math.min(1.6, factor));
  const m = (c) => Math.max(0, Math.min(255, Math.round(c * f)));
  return `rgb(${m(r)},${m(g)},${m(b)})`;
}

/** Paso de la retícula según lo lejos que esté la vista (como en planta, §8). */
export function pasoRejilla(distancia) {
  let paso = 1;
  while (paso * 40 < distancia) paso *= 2;
  return paso;
}

/** Regla de alturas: una escala vertical de 3 m en una esquina de la planta. */
function pintarRegla(ctx, escena, cam, w, h, opts) {
  const C = escena.caja;
  if (!C) return;
  const x = C.minX, y = C.minY;
  const tramos = [0, 1, 2, 2.8, 3.5];
  ctx.strokeStyle = opts.colorEjes || '#2b3648';
  ctx.lineWidth = 1;
  ctx.beginPath();
  const a = proyectar({ x, y, z: 0 }, cam, w, h);
  const b = proyectar({ x, y, z: Math.max(3.5, escena.alturaMuro + 0.5) }, cam, w, h);
  if (a.detras || b.detras) return;
  ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
  ctx.stroke();
  ctx.fillStyle = opts.colorTexto || '#7d8ba1';
  ctx.font = '10px system-ui, sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  for (const z of tramos) {
    if (z > Math.max(3.5, escena.alturaMuro + 0.5)) continue;
    const p = proyectar({ x, y, z }, cam, w, h);
    if (p.detras) continue;
    ctx.beginPath(); ctx.moveTo(p.x - 4, p.y); ctx.lineTo(p.x + 4, p.y); ctx.stroke();
    ctx.fillText(`${z.toFixed(z === 2.8 ? 1 : 0)} m`, p.x + 7, p.y);
  }
  // Silueta humana de 1,75 m al lado de la regla: es la referencia que de verdad dice «¿se ve a una
  // persona?». Se dibuja en pantalla, escalada con la altura que ocupa 1,75 m en ese punto.
  const px = x - 0.9, py = y;
  const pie = proyectar({ x: px, y: py, z: 0 }, cam, w, h);
  const cabeza = proyectar({ x: px, y: py, z: 1.75 }, cam, w, h);
  if (!pie.detras && !cabeza.detras) {
    const alto = Math.abs(pie.y - cabeza.y);
    if (alto > 10) {
      const an = Math.max(2, alto * 0.11);
      ctx.fillStyle = 'rgba(200,178,115,0.9)';
      // cabeza
      ctx.beginPath();
      ctx.arc(cabeza.x, cabeza.y + an * 0.5, an * 0.5, 0, Math.PI * 2);
      ctx.fill();
      // tronco y piernas
      ctx.fillRect(cabeza.x - an * 0.45, cabeza.y + an, an * 0.9, alto * 0.46);
      ctx.fillRect(cabeza.x - an * 0.38, cabeza.y + an + alto * 0.46, an * 0.3, alto * 0.42);
      ctx.fillRect(cabeza.x + an * 0.08, cabeza.y + an + alto * 0.46, an * 0.3, alto * 0.42);
    }
  }
}

/** Encuadra la vista 3D en el proyecto (se usa al entrar en 3D por primera vez). */
export function encuadrar(cam, prj, alturaMuro = ALTURA_MURO) {
  const caja = cajaDelProyecto(prj, alturaMuro);
  if (!caja) return cam;
  return encuadrar3d(cam, caja, caja.maxZ);
}

export { ALTURA_MURO, ALTURA_PERSONA, ALTURA_OBJETIVO, datosDe, ojoDe, caraAlOjo, carasAlOjo, ordenarPreparadas, trocearCara };
