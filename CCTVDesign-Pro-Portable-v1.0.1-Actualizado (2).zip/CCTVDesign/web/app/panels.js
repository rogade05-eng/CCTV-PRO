/**
 * CCTV DESIGN PRO — Paneles laterales (§7)
 * Todo el HTML es declarativo; las acciones se delegan mediante data-act.
 */
import { OBJECTIVES } from './core/project.js?v=b441e3fc';
import { CATEGORIES, getItem } from './core/catalog.js?v=b441e3fc';
import { RULE_DEFS } from './core/rules.js?v=b441e3fc';
import { layoutTopology, topologySvg } from './diagrams.js?v=b441e3fc';
import { isPtz, cameraPresets, presetLimits, patrolCycle, ptzSummary, ptzSchedule } from './core/ptz.js?v=b441e3fc';
import { isLpr, lprOptics, lprSummary, maxSpeedFor } from './core/lpr.js?v=b441e3fc';
import { ANALYTICS_TYPES, cameraRules, analyticsSummary, analyticsSchedule, supportsType } from './core/analytics.js?v=b441e3fc';
import { fiberSummary, FIBER_TYPES } from './core/fiber.js?v=b441e3fc';
import { ANALOG_FORMATS, ANALOG_CABLES, isAnalog, analogLink, analogPlan, analogSummary, analogSchedule } from './core/analog.js?v=b441e3fc';
import { detectedModules } from './core/modules.js?v=b441e3fc';
import { ETIQUETA_MODO, MODOS_COLOR } from './io/aci.js?v=b441e3fc';
import { GRUPOS, PREF_DEFS, defsDeGrupo, TEMAS, TEMAS_LISTA, TECLAS, CONMUTABLES, LEYENDA_CONMUTABLE,
  avisoContraste, resumenPrefs, tamanoCruzPx, revisarPrefs, colorSugerido } from './core/workspace.js?v=b441e3fc';
import { UNIDADES, unidadPorId, unidadPorInsunits, tamanoEnMetros, formatearLongitud, formatearEscala,
  factorEscala } from './core/units.js?v=b441e3fc';
import { OBSTACULOS, obstaculoDe, gruposDeObstaculos, datosDe, resumenMuros, esElemento3d, ALTURA_MURO,
  ALTURA_PERSONA, ALTURA_OBJETIVO } from './core/obstacles.js?v=b441e3fc';
import { VISTAS } from './core/view3d.js?v=b441e3fc';
import { vistaDe } from './core/monitor.js?v=b441e3fc';
import { analisisPrivacidad, evaluarCumplimiento, zonasDe, mascarasDe, CLASES_LISTA, FUNCIONES_IA,
  NIVELES_IA, etiquetaClase } from './core/privacy.js?v=b441e3fc';
import { camposDe, leerCampo, resumenDe, ETIQUETA_TIPO, areaDe } from './core/edit.js?v=b441e3fc';

export const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
export const num = (v, d = 2) => Number(v || 0).toFixed(d).replace('.', ',');
export const money = (v, cur) => `${num(v)} ${(cur || 'EUR')}`;

const row = (label, control, hint) =>
  `<div class="frow">${hint ? `<span class="hint" title="${esc(hint)}">?</span>` : ''}<label>${label}</label>${control}</div>`;
/**
 * Campo del panel. Los numéricos se pintan como **texto con teclado decimal** a propósito: en
 * español las fracciones se escriben con coma («3,5») y un `type="number"` la descarta sin avisar,
 * con lo que escribir 3,5 dejaba 35. El valor se interpreta igual con coma que con punto.
 */
const input = (act, value, attrs = '') => {
  const a = String(attrs).replace('type="number"', 'type="text" inputmode="decimal" autocomplete="off" class="num"');
  return `<input data-act="${act}" value="${esc(value)}" ${a}>`;
};
const select = (act, opts, value) =>
  `<select data-act="${act}">${opts.map((o) => `<option value="${esc(o[0])}" ${String(o[0]) === String(value) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
const btn = (act, label, cls = '') => `<button class="btn ${cls}" data-act="${act}">${label}</button>`;
/** Deslizador: sirve para girar la cámara a mano con el ratón, como una ruleta de acimut. */
const slider = (act, value, min = 0, max = 359, paso = 1) =>
  `<input class="slider" type="range" data-act="${act}" min="${min}" max="${max}" step="${paso}" value="${Number(value) || 0}">`;
const card = (title, body, tools = '') => `<section class="card"><header>${title}${tools}</header>${body}</section>`;
const badge = (t, cls) => `<span class="badge ${cls}">${t}</span>`;
const table = (heads, rows, cls = '') =>
  `<div class="twrap"><table class="${cls}"><thead><tr>${heads.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${
    rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
const sev = (s) => (s === 'ok' || s === 'SUFICIENTE' || s === 'NORMAL' ? 'ok' : s === 'warn' || s === 'PROXIMA' || s === 'RESERVA BAJA' ? 'warn' : s === 'info' ? 'info' : 'err');

export const PANEL_TITLES = {
  props: 'Propiedades', coverage: 'Cobertura', cabling: 'Cableado', network: 'Red', poe: 'PoE',
  recording: 'Grabación', rack: 'Rack', catalog: 'Catálogo', materials: 'Materiales', budget: 'Presupuesto',
  docs: 'Documentación', validation: 'Validación', rules: 'Reglas', walkthrough: 'Recorrido del proyecto',
  layers: 'Capas', project: 'Proyecto', ptz: 'Módulo PTZ', modules: 'Módulos del sistema',
  lpr: 'Módulo LPR', analytics: 'Analítica de vídeo', fiber: 'Fibra óptica',
  options: 'Opciones de dibujo y espacio de trabajo',
  escala: 'Unidades y escala del plano', obstaculos: 'Obstáculos, muros y alturas',
  tresd: 'Vista 3D',
  monitor: 'Monitor de cámara',
  privacy: 'Privacidad y cumplimiento normativo',
  license: 'Licencia y Privilegios' };

export function renderPanel(name, app) {
  switch (name) {
    case 'props': return propsPanel(app);
    case 'coverage': return coveragePanel(app);
    case 'cabling': return cablingPanel(app);
    case 'network': return networkPanel(app);
    case 'poe': return poePanel(app);
    case 'recording': return recordingPanel(app);
    case 'rack': return rackPanel(app);
    case 'catalog': return catalogPanel(app);
    case 'materials': return materialsPanel(app);
    case 'budget': return budgetPanel(app);
    case 'docs': return docsPanel(app);
    case 'validation': return validationPanel(app);
    case 'rules': return rulesPanel(app);
    case 'walkthrough': return walkthroughPanel(app);
    case 'ptz': return ptzPanel(app);
    case 'lpr': return lprPanel(app);
    case 'analytics': return analyticsPanel(app);
    case 'fiber': return fiberPanel(app);
    case 'options': return optionsPanel(app);
    case 'escala': return escalaPanel(app);
    case 'obstaculos': return obstaculosPanel(app);
    case 'tresd': return tresdPanel(app);
    case 'monitor': return monitorPanel(app);
    case 'privacy': return privacyPanel(app);
    case 'license': return renderLicensePanel(app);
    case 'analog': return analogPanel(app);
    case 'modules': return modulesPanel(app);
    case 'layers': return layersPanel(app);
    case 'project': return projectPanel(app);
    default: return `<p class="muted">Panel no disponible.</p>`;
  }
}

/* ------------------------------ plano importado (§9) ------------------------------ */

/**
 * Tarjeta del plano importado: dice dónde está, permite volver a él y ofrece la salida cuando
 * el plano llega en coordenadas lejanas (el caso clásico: «no encuentro el DXF que he importado»).
 */
function planoImportadoCard(app) {
  const p = app._plano;
  const guardado = app.prj.settings ? app.prj.settings.ultimoPlano : null;
  if (!p && !guardado) {
    return card('Plano importado (§9)', `
      <p class="muted small">Aquí aparecerá el plano que importe (DXF o DWG convertido), con su extensión
      y su posición. Al importarlo, la vista se coloca sola sobre él y el menú del botón derecho
      (o el botón <b>Encuadrar plano</b>) lo devuelve a pantalla en cualquier momento.</p>
      <div class="btnrow">${btn('file:dxf', '📄 Importar DXF…')}${btn('db:convertir', '🔄 Convertir DWG e importar…')}</div>`);
  }
  if (!p) {
    const caja = guardado.caja;
    return card('Plano importado (última sesión)', `
      <div class="specs">Se guardó el plano <b>${esc(guardado.nombre)}</b> con ${guardado.entidades || 0} entidades
      (${caja ? `${num(caja.maxX - caja.minX, 1)} × ${num(caja.maxY - caja.minY, 1)} m` : 'extensión desconocida'}).
      Vuelva a importarlo para seguir trabajando con él: los ficheros del proyecto no llevan la geometría del plano.</div>
      <div class="btnrow">${btn('file:dxf', '📄 Importar DXF…')}${btn('db:convertir', '🔄 Convertir DWG e importar…')}</div>`);
  }
  const t = { ancho: p.caja ? p.caja.maxX - p.caja.minX : 0, alto: p.caja ? p.caja.maxY - p.caja.minY : 0 };
  const c = { x: p.caja ? (p.caja.minX + p.caja.maxX) / 2 : 0, y: p.caja ? (p.caja.minY + p.caja.maxY) / 2 : 0 };
  return card('Plano importado (§9)', `
    <div class="kpi">
      <div><b>${p.entidades}</b><span>entidades</span></div>
      <div><b>${num(t.ancho, 1)} × ${num(t.alto, 1)}</b><span>metros</span></div>
      <div><b>${p.creadas.length}</b><span>capas nuevas</span></div>
    </div>
    <div class="specs"><b>${esc(p.nombre)}</b><br>
      Centro: (${num(c.x, 1)}, ${num(c.y, 1)}) m · importado ${new Date(p.cuando).toLocaleTimeString('es-ES')}<br>
      ${p.lejos ? '<span class="warn-text">Este plano está lejos de lo dibujado en el proyecto: use «Traer a la zona del proyecto».</span>' : 'Situado junto a lo dibujado en el proyecto.'}
      ${p.atenuado ? '<br>Se está dibujando atenuado (en gris).' : ''}</div>
    <div class="frow"><label>Colores del plano</label>${select('plan:planoColores:modo', MODOS_COLOR.map((m) => [m, ETIQUETA_MODO[m]]), (app.prj.settings && app.prj.settings.colorPlano) || 'original')}</div>
    <div class="specs">${p.ajustadas && p.ajustadas.length
      ? `Se han aclarado <b>${p.ajustadas.length} capa(s)</b> que venían en negro o demasiado oscuras para verse sobre el fondo oscuro del lienzo (lo mismo que hace AutoCAD, que dibuja el color 7 en blanco sobre fondo negro y en negro sobre papel).`
      : 'El plano se dibuja con sus propios colores; se aclaran solo los que no se verían sobre el fondo oscuro.'}
      ${p.colores ? `<br>Colores: <b>${p.colores.propios}</b> definidos en el elemento · <b>${p.colores.deCapa}</b> heredados de su capa.` : ''}</div>
    <div class="btnrow">
      ${btn('plan:planoEncuadrar', '⤢ Encuadrar plano')}
      ${btn('plan:planoTraer', '↦ Traer a la zona del proyecto', p.lejos ? 'primary' : '')}
      ${btn('plan:planoAtenuar', p.atenuado ? '◐ Colores originales' : '◑ Atenuar')}
      ${btn('plan:planoSeleccionar', '⬚ Seleccionar todo')}
      ${btn('plano:capas', '👁 Ocultar / mostrar capas')}
      ${btn('plan:planoQuitar', '🗑 Quitar plano', 'danger')}
    </div>
    <p class="muted small">El plano importado viene con sus propias capas (§11) y se puede mover, atenuar o
    retirar sin tocar la instalación de CCTV, que se calcula siempre con el motor propio (§42).</p>`);
}

/* ------------------------------ propiedades ------------------------------ */
function propsPanel(app) {
  const sel = app.cad.selected();
  if (!sel.length) return `<p class="muted">Seleccione una cámara para modificar su orientación, altura, lente o campo de visión.</p>` +
    planoImportadoCard(app) +
    card('Colocar elementos', `<div class="btnrow">
      ${btn('tool:camera', '📷 Cámara')} ${btn('tool:device', '🖧 Equipo')} ${btn('tool:room', '▢ Zona')} ${btn('tool:polyline', '⟋ Línea')}
      ${btn('tool:rect', '▭ Rectángulo')} ${btn('tool:circle', '◯ Círculo')} ${btn('tool:text', 'T Texto')} ${btn('tool:measure', '📏 Medir')}
    </div><p class="muted small">Herramientas equivalentes a la barra lateral. Esc cancela la herramienta activa.</p>`);
  if (sel.length > 1) {
    const capas = (app.prj.layers || []).map((l) => [l.id, l.name || l.id]);
    const tipos = [...new Set(sel.map((e) => e.type))];
    return card(`${sel.length} elementos seleccionados`, `<div class="btnrow">
      ${btn('edit:delete', '🗑 Eliminar', 'danger')} ${btn('edit:duplicate', '⧉ Duplicar')} ${btn('edit:rotate', '⟳ Rotar…')}
      ${btn('cam:align', 'Alinear cámaras seleccionadas')}</div>
      <div class="btnrow">${btn('edit:mover', '✥ Mover…')} ${btn('edit:escalar', '⤢ Escalar…')}
      ${btn('edit:espejo:v', '⇋ Espejo')} ${btn('edit:cerrar', 'Cerrar o abrir')}</div>
      ${row('Capa para toda la selección', select('edit:set:layer', capas, sel[0].layer))}
      ${row('Altura (si son obstáculos o muros)', input('edit:set:altura', leerCampo(sel.find((e) => e.type === 'obstacle') || sel[0], 'altura'), 'type="number" step="0.05" min="0.05"'))}
      <div class="specs">Tipos: ${tipos.map((t) => ETIQUETA_TIPO[t] || t).join(', ')}</div>
      ${table(['Tipo', 'Capa', 'Etiqueta'], sel.map((e) => [e.type, e.layer, esc(e.data.label || e.data.name || e.id)]))}`);
  }
  const e = sel[0];
  if (e.type === 'camera') {
    const item = getItem(app.prj.catalog, e.data.catalogId);
    const s = (item && item.specs) || {};
    const fp = app.footprintOf(e);
    const cov = app.results.coverage && (app.results.coverage.cameras || []).find((c) => c.id === e.id);
    const switches = app.prj.entities.filter((x) => x.type === 'device' && x.data.kind === 'switch');
    return card(`Cámara — ${esc(e.data.label || e.id)}`, `
      ${row('Etiqueta', input('cam:label', e.data.label))}
      ${(() => {
        const allCams = (app.prj.catalog.items || []).filter((i) => i.category === 'camera');
        const f = app.camPickerFilter || { marca: '', tipo: '', q: '' };
        const q = (f.q || '').trim().toLowerCase();
        const marcas = Array.from(new Set(allCams.map((i) => i.manufacturer).filter(Boolean))).sort();
        const tipos = Array.from(new Set(allCams.map((i) => (i.specs && (i.specs.tipo || i.specs.form)) || '').filter(Boolean))).sort();
        const filtradas = allCams.filter((i) => {
          if (f.marca && i.manufacturer !== f.marca) return false;
          const t = (i.specs && (i.specs.tipo || i.specs.form)) || '';
          if (f.tipo && t !== f.tipo) return false;
          if (q) {
            const txt = `${i.manufacturer} ${i.model} ${i.name || ''} ${t}`.toLowerCase();
            if (!txt.includes(q)) return false;
          }
          return true;
        });
        const opciones = [];
        // Si el modelo actual quedó fuera del filtro, lo mostramos arriba para que el usuario no pierda contexto
        if (e.data.catalogId && !filtradas.some((i) => i.id === e.data.catalogId)) {
          const actual = allCams.find((i) => i.id === e.data.catalogId);
          if (actual) opciones.push([actual.id, `${actual.manufacturer} ${actual.model} (actual)`]);
        }
        for (const i of filtradas) {
          const tBadge = (i.specs && i.specs.tipo) ? ` [${i.specs.tipo}]` : '';
          opciones.push([i.id, `${i.manufacturer} ${i.model}${tBadge}`]);
        }
        return `
          <div class="campicker-box" style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:4px; padding:6px 8px; margin:4px 0 8px 0;">
            <div style="display:flex; gap:6px; margin-bottom:5px;">
              <select data-act="cam:filter:marca" style="flex:1; font-size:11px; padding:2px 4px; border-radius:3px; background:#1b2028; color:#eee; border:1px solid #444;" title="Filtrar por fabricante/marca">
                <option value="">Todas las marcas (${marcas.length})</option>
                ${marcas.map((m) => `<option value="${esc(m)}" ${f.marca === m ? 'selected' : ''}>${esc(m)}</option>`).join('')}
              </select>
              <select data-act="cam:filter:tipo" style="flex:1; font-size:11px; padding:2px 4px; border-radius:3px; background:#1b2028; color:#eee; border:1px solid #444;" title="Filtrar por tipo o factor de forma">
                <option value="">Todos los tipos (${tipos.length})</option>
                ${tipos.map((t) => `<option value="${esc(t)}" ${f.tipo === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}
              </select>
            </div>
            <div style="display:flex; gap:6px; align-items:center; margin-bottom:5px;">
              <input type="text" data-act="cam:filter:q" placeholder="Buscar modelo o especificación…" value="${esc(f.q)}" style="flex:1; font-size:11px; padding:2px 6px; border-radius:3px; background:#14171d; color:#eee; border:1px solid #444;">
              <span class="campicker-count muted small" style="white-space:nowrap; font-size:10px;">${filtradas.length} disp.</span>
            </div>
            ${row('Modelo', select('cam:catalog', opciones.length ? opciones : [['', '(Sin coincidencias)']], e.data.catalogId))}
          </div>`;
      })()}
      ${item ? `<div class="specs">${s.resW}×${s.resH} · ${s.lens} mm · ${s.ir} m IR · ${s.codec} · ${s.ip}</div>` : ''}
      ${row('Altura (m)', input('cam:height', e.data.height, 'type="number" step="0.1" min="1"'))}
      ${row('Orientación (°)', `<span class="campodoble">${input('cam:azimuth', e.data.azimuth, 'type="number" step="5"')}${slider('cam:giro', e.data.azimuth)}</span>`,
        'Escriba el ángulo o arrastre la ruleta: el cono y el haz se redibujan al instante.')}
      ${row('Inclinación (°)', input('cam:tilt', e.data.tilt, 'type="number" step="1" min="0" max="89"'))}
      ${row('Focal (mm)', input('cam:focal', e.data.focal || s.lens || 4, 'type="number" step="0.1"'))}
      ${row('Objetivo', select('cam:objective', Object.entries(OBJECTIVES).map(([k, v]) => [k, v.label]), e.data.objective))}
      ${row('FPS', input('cam:fps', e.data.fps || s.fps || 25, 'type="number" step="1"'))}
      ${row('Bitrate (kbps)', input('cam:bitrate', e.data.bitrate || s.bitrate || 0, 'type="number" step="256"'), '0 = automático según equipo')}
      ${row('Dirección IP', input('cam:ip', e.data.ip))}
      ${row('Switch', select('cam:switch', [['', '— sin asignar —'], ...switches.map((sw) => [sw.id, sw.data.label || sw.id])], e.data.switchId))}
      ${row('Alimentación', select('cam:poemode', [['poe', 'PoE'], ['psu', 'Fuente 12 V']], e.data.power || (s.poe ? 'poe' : 'psu')))}
      ${row('Montaje', select('cam:mount', [['pared', 'Escuadra de pared'], ['techo', 'Colgada del techo'], ['poste', 'Mástil o poste']], e.data.mount || 'pared'), 'El soporte se dibuja en la vista 3D y cuenta como material.')}
      ${item && s.form ? `<div class="specs">${esc(s.tipo || s.form)} · ${esc(s.dim ? `${s.dim.forma === 'cilindro' ? `Ø ${s.dim.d} × ${s.dim.h}` : `${s.dim.l} × ${s.dim.w} × ${s.dim.h}`} mm` : '—')}${s.peso ? ` · ${esc(s.peso)} kg` : ''}</div>` : ''}
      <div class="specs">FOV ${num(fp.hfov, 1)}° × ${num(fp.vfov, 1)}° · alcance ${num(fp.near, 1)}–${num(fp.far, 1)} m</div>
      ${cov ? `<div class="specs">Cubre ${num(cov.area)} m² · ${cov.objectiveLabel} hasta ${num(cov.effectiveMax, 1)} m (teórico ${num(cov.theoreticalMax, 1)} m) · ${num(cov.ppmAtFar, 0)} ppm al final del cono</div>` : ''}
      ${cov && (cov.sombraPct || 0) > 0.5 ? `<div class="specs">🌑 ${num(cov.sombraPct, 0)} % de la huella en sombra por obstáculos · ${num(cov.areaHuella, 1)} de ${num(cov.areaTeorica, 1)} m²${cov.sectores > 1 ? ` · ${cov.sectores} sectores` : ''}</div>` : ''}
      <div class="btnrow">${btn('cmd:rotar', '⟳ Girar…')} ${btn('cam:apuntar', '🎯 Apuntar…')} ${btn('cam:giro:-15', '⟲ −15°')} ${btn('cam:giro:+15', '⟳ +15°')}</div>
      <div class="specs">GIRAR (R) gira la cámara como un bloque de AutoCAD: punto base, y arrastre o escriba el ángulo. «Apuntar…» pide un punto del plano hacia el que mirar. Con el objeto seleccionado también se arrastra el mango redondo de orientación.</div>
      <div class="btnrow">${btn('cam:rotate90', '⟳ Girar 90°')} ${btn('cam:aim', '🎯 Orientar al centro de la zona')} ${btn('edit:delete', '🗑 Eliminar', 'danger')}</div>`) +
      (isPtz(e, app.prj.catalog) ? ptzEditor(app, e) : '') +
      (isLpr(e, app.prj.catalog) ? lprEditor(app, e) : '') +
      (isAnalog(e, app.prj.catalog) ? analogCameraEditor(app, e) : '') +
      analyticsEditor(app, e);
  }
  if (e.type === 'device') {
    const item = getItem(app.prj.catalog, e.data.catalogId);
    const s = (item && item.specs) || {};
    return card(`Equipo — ${esc(e.data.label || e.id)}`, `
      ${row('Etiqueta', input('dev:label', e.data.label))}
      ${row('Tipo', select('dev:kind', [['switch', 'Switch'], ['nvr', 'NVR'], ['router', 'Router'], ['patchpanel', 'Patch panel'], ['ups', 'UPS']], e.data.kind))}
      ${row('Equipo', select('dev:catalog', app.prj.catalog.items.map((i) => [i.id, `${i.manufacturer} ${i.model} — ${i.name}`]), e.data.catalogId))}
      ${item ? `<div class="specs">${esc(item.name)}${s.ports ? ` · ${s.ports} puertos` : ''}${s.poeBudget ? ` · PoE ${s.poeBudget} W` : ''}${s.channels ? ` · ${s.channels} canales` : ''}${s.u ? ` · ${s.u} U` : ''}</div>` : ''}
      ${row('Dirección IP', input('dev:ip', e.data.ip))}
      <div class="btnrow">${btn('edit:delete', '🗑 Eliminar', 'danger')}</div>`);
  }
  if (e.type === 'room') {
    return card(`Zona — ${esc(e.data.name || '')}`, `
      ${row('Nombre', input('room:name', e.data.name))}
      ${row('Zona crítica', `<input type="checkbox" data-act="room:critical" ${e.data.critical ? 'checked' : ''}>`)}
      <div class="specs">${e.points.length} vértices · polígono cerrado · ${num(areaDe(e))} m²</div>
      ${editorDeGeometria(e)}
      ${barraDeEdicion(e)}
      <div class="btnrow">${btn('edit:delete', '🗑 Eliminar', 'danger')}</div>`);
  }
  // Cualquier otro objeto del dibujo (líneas, polilíneas, rectángulos, círculos, arcos, textos,
  // imágenes y obstáculos) se edita con el editor genérico, que se construye solo con la
  // descripción de campos que da core/edit.js.
  return editorDeObjeto(app, e);
}

/* ------------------------------------------------------------------ editor de objetos */

/** Un control por cada campo editable del objeto, según lo que declara `camposDe`. */
function campoHtml(e, c) {
  const v = leerCampo(e, c.clave);
  if (c.tipo === 'numero') {
    const attrs = `type="number" step="${c.paso === undefined ? 0.05 : c.paso}"` +
      (c.min !== undefined ? ` min="${c.min}"` : '') + (c.max !== undefined ? ` max="${c.max}"` : '');
    return row(c.etiqueta + (c.unidad ? ` (${c.unidad})` : ''), input(`edit:set:${c.clave}`, v, attrs), c.nota);
  }
  if (c.tipo === 'texto') return row(c.etiqueta, input(`edit:set:${c.clave}`, v), c.nota);
  if (c.tipo === 'lista') return row(c.etiqueta, select(`edit:set:${c.clave}`, c.opciones, v), c.nota);
  if (c.tipo === 'logico') {
    return row(c.etiqueta, `<input type="checkbox" data-act="edit:set:${c.clave}" ${v ? 'checked' : ''}>`, c.nota);
  }
  if (c.tipo === 'color') {
    return row(c.etiqueta, `<span class="colorfield"><input type="color" data-act="edit:set:color" value="${esc(v || '#8b95a6')}">${btn('edit:setcolorcapa', 'Usar el de la capa')}</span>`, c.nota);
  }
  return '';
}

/** Tabla de vértices con sus coordenadas editables y un botón para quitar cada uno. */
function editorDeGeometria(e) {
  const pts = (e.points || []).filter(Boolean);
  if (pts.length < 2 || e.type === 'rect') return '';
  const cerrable = e.type === 'polyline' || e.type === 'room' || e.type === 'obstacle';
  const filas = pts.map((p, i) => [
    `${i + 1}`,
    input(`edit:vertice:${i}:x`, p.x.toFixed(3), 'type="number" step="0.05" class="mini"'),
    input(`edit:vertice:${i}:y`, p.y.toFixed(3), 'type="number" step="0.05" class="mini"'),
    `<button class="btn mini" data-act="edit:vertice:borrar:${i}" title="Quitar este vértice">✕</button>`,
  ]);
  return `<details open class="sub"><summary>Vértices (${pts.length})</summary>
    ${table(['#', 'X (m)', 'Y (m)', ''], filas, 'vertices')}
    <div class="btnrow">${btn('edit:vertice:mas', '＋ Insertar vértice')}${btn('edit:vertice:menos', '－ Quitar el último')}${
      cerrable ? btn('edit:cerrar', e.closed ? 'Abrir la figura' : 'Cerrar la figura') : ''}</div>
  </details>`;
}

/** Transformaciones y operaciones sobre el objeto: mover, girar, escalar, espejo, duplicar… */
function barraDeEdicion(e) {
  return `<details class="sub"><summary>Transformar</summary>
    <div class="btnrow">${btn('edit:mover', '✥ Mover…')} ${btn('edit:rotar', '⟳ Girar…')} ${btn('edit:escalar', '⤢ Escalar…')}</div>
    <div class="btnrow">${btn('edit:espejo:v', '⇋ Espejo vertical')} ${btn('edit:espejo:h', '⇅ Espejo horizontal')}</div>
    <div class="btnrow">${btn('edit:duplicate', '⧉ Duplicar')} ${btn('edit:seleccionar:tipo', 'Seleccionar los del mismo tipo')} ${btn('edit:delete', '🗑 Eliminar', 'danger')}</div>
    <p class="muted small">Arrastre los cuadraditos (vértices) para deformar el objeto; los rombos
    insertan un vértice nuevo y los círculos cambian el radio, el alto o la orientación.
    <b>M</b> mover · <b>R</b> girar · <b>S</b> escalar · <b>E</b> espejo · <b>Esc</b> cancelar.</p>
  </details>`;
}

/** Ficha completa de cualquier objeto del dibujo. */
function editorDeObjeto(app, e) {
  const campos = camposDe(e, app.prj);
  const etiqueta = ETIQUETA_TIPO[e.type] || e.type;
  const titulo = e.type === 'obstacle'
    ? `${esc((e.data && e.data.etiqueta) || 'Obstáculo')} — ${etiqueta.toLowerCase()}`
    : `${etiqueta}`;
  const medidas = `<div class="specs">${esc(resumenDe(e))} · capa ${esc(e.layer)}</div>`;
  return card(esc(titulo), `
    ${medidas}
    ${editorDeGeometria(e)}
    ${campos.map((c) => campoHtml(e, c)).join('')}
    ${barraDeEdicion(e)}`);
}

/* ------------------------------ cobertura ------------------------------ */
function coveragePanel(app) {
  const r = app.results.coverage;
  const head = `<div class="btnrow">${btn('cov:analyze', '▶ Analizar cobertura', 'primary')}${btn('cov:autocam', '✨ Propuesta automática de cámaras')}</div>`;
  if (!r || r.empty) return head + `<p class="muted">Ejecute el análisis para calcular área cubierta, solapes y zonas ciegas (§14).</p>`;
  const zoneRows = r.zones.map((z) => [esc(z.name) + (z.critical ? ' ★' : ''), num(z.area, 1), num(z.covered, 1), num(z.pct, 1) + ' %',
    badge(z.pct >= 99.5 ? 'OK' : z.pct >= 80 ? 'PARCIAL' : 'DEFICIENTE', z.pct >= 99.5 ? 'ok' : z.pct >= 80 ? 'warn' : 'err')]);
  const blind = (r.blindZones || []).slice(0, 12).map((b, i) => [i + 1, num(b.area, 1), `${num(b.centroid.x, 1)} ; ${num(b.centroid.y, 1)}`]);
  const camRows = (r.cameras || []).map((c) => [esc(c.label) + (c.ptz ? ' 🎥' : ''), num(c.area, 1), esc(c.objectiveLabel), num(c.effectiveMax, 1),
    c.ptz ? `${c.presets} · ${num(c.weightedArea, 0)} m²` : '—',
    num(c.sombraPct || 0, 0) + ' %',
    badge(c.meetsObjective ? 'SÍ' : 'NO', c.meetsObjective ? 'ok' : 'warn')]);
  return head +
    card('Resumen global', `<div class="kpi">
      <div><b>${num(r.coveragePct, 1)} %</b><span>cobertura</span></div>
      <div><b>${num(r.areaCovered)} m²</b><span>cubierta</span></div>
      <div><b>${num(r.areaUncovered)} m²</b><span>descubierta</span></div>
      <div><b>${num(r.overlapPct, 1)} %</b><span>solape</span></div>
      <div><b>${(r.blindZones || []).length}</b><span>zonas ciegas</span></div></div>
      <div class="legend"><i style="background:#2ec878"></i>1 cámara <i style="background:#ffbe3c"></i>solape <i style="background:#dc3c3c"></i>zona ciega</div>`) +
    card('Por zona de interés', table(['Zona', 'Área m²', 'Cubierta m²', '%', 'Estado'], zoneRows)) +
    card('Zonas ciegas', blind.length ? table(['#', 'Área m²', 'Centroide (x;y)'], blind) : `<p class="muted">Sin zonas ciegas por encima del umbral.</p>`) +
    card('Cámaras', table(['Cámara', 'Cubre m²', 'Objetivo', 'Alcanza hasta (m)', 'PTZ presets · media', 'En sombra', 'Cumple'], camRows)) +
    (r.ptzCameras ? card('Cámaras PTZ (módulo §38)', `<div class="specs">
      ${r.ptzCameras} cámara(s) PTZ · ${r.ptzPresets} preset(s) · unión instantánea <b>${num((r.cameras || []).filter((c) => c.ptz).reduce((a, c) => a + c.area, 0))} m²</b> ·
      media ponderada por tiempo <b>${num(r.ptzWeightedArea)} m²</b></div>
      <p class="muted small">Un PTZ solo puede estar en una posición a la vez: la cobertura de la unión (todas las posiciones) es optimista;
      la <b>media ponderada</b> reparte el área de cada preset según el tiempo que la cámara permanece en él (Σ permanencia · área / ciclo).
      El análisis de cobertura usa la unión; los documentos justifican ambas cifras.</p>`) : '');
}

/* ------------------------------ cableado ------------------------------ */
function cablingPanel(app) {
  const links = app.results.links || [];
  const rules = app.prj.rules;
  const head = card('Parámetros (§17, §33)', `
    ${row('Reserva de cable (%)', input('rule:set:RESERVA_CABLE', rules.RESERVA_CABLE, 'type="number" step="1"'))}
    ${row('Margen por cámara (m)', input('rule:set:MARGEN_CABLE', rules.MARGEN_CABLE, 'type="number" step="0.5"'))}
    ${row('Distancia máx. UTP (m)', input('rule:set:MAX_UTP', rules.MAX_UTP, 'type="number" step="1"'))}
    ${row('Aviso al (%)', input('rule:set:AVISO_UTP_PCT', rules.AVISOUTP || rules.AVISO_UTP_PCT, 'type="number" step="1"'))}
    <div class="btnrow">${btn('cable:generate', '▶ Generar rutas', 'primary')}${btn('cable:clear', 'Limpiar rutas')}</div>`);
  if (!links.length) return head + `<p class="muted">Genere las rutas para calcular longitudes. El algoritmo evita muros y aprovecha las bandejas dibujadas en la capa Canalizaciones (§16).</p>`;
  const total = links.reduce((a, l) => a + l.supply, 0);
  const maxLink = links.reduce((a, l) => Math.max(a, l.net), 0);
  return head + card('Cuadro de cableado (§18)', table(
    ['Cámara', 'Switch', 'Ruta (m)', 'Suministro (m)', '% UTP', 'Estado', 'Medio calculado', 'Decisión del proyectista'],
    links.map((l) => [esc(l.camera), esc(l.switch), num(l.geometric, 1), num(l.supply, 1), num(l.pct, 0) + ' %',
      badge(l.status, sev(l.status)), esc(l.medium),
      `<select data-act="cable:media" data-id="${esc(l.id)}">
         <option value="auto" ${l.mediaChoice === 'auto' ? 'selected' : ''}>Automático por distancia</option>
         <option value="fiber" ${l.mediaChoice === 'fiber' ? 'selected' : ''}>Fibra óptica</option>
         <option value="utp" ${l.mediaChoice === 'utp' ? 'selected' : ''}>Forzar UTP</option>
       </select>`])) +
    `<div class="specs">Longitud total de suministro: <b>${num(total, 1)} m</b> · Máximo enlace: <b>${num(maxLink, 1)} m</b> de ${num(rules.MAX_UTP, 0)} m admitidos</div>`);
}

/* ------------------------------ red ------------------------------ */
function networkPanel(app) {
  const t = app.results.topology;
  if (!t) return `<p class="muted">Añada switches, NVR y router con la herramienta Equipo.</p>`;
  const layout = layoutTopology(t);
  return card('Esquema lógico (§23)', topologySvg(layout)) +
    card('Acciones', `<div class="btnrow">${btn('net:assign', '⚡ Asignación automática', 'primary')}${btn('net:address', 'IP automáticas')}${btn('net:diagpdf', 'Exportar diagrama PDF')}</div>`) +
    card('Elementos', table(['Tipo', 'Etiqueta', 'Modelo', 'IP', 'Cámaras'], [
      ...t.routers.map((r) => ['Router', esc(r.label), esc(r.model), esc(r.ip), '—']),
      ...t.nvrs.map((n) => ['NVR', esc(n.label), esc(n.model), esc(n.ip), app.prj.entities.filter((e) => e.type === 'camera').length]),
      ...t.nodes.map((s) => ['Switch', esc(s.label), esc(s.model), '', s.children.length]),
    ])) + (t.orphans.length ? `<p class="warn-text">⚠ ${t.orphans.length} cámara(s) sin switch asignado.</p>` : '');
}

/* ------------------------------ PoE ------------------------------ */
function poePanel(app) {
  const p = app.results.poe;
  if (!p || !p.groups.length) return `<p class="muted">Añada un switch PoE y asigne cámaras (§20).</p>`;
  return card('Balance PoE', `<div class="kpi">
      <div><b>${num(p.totalPower, 1)} W</b><span>consumo</span></div>
      <div><b>${num(p.totalBudget, 0)} W</b><span>presupuesto</span></div>
      <div><b>${num(p.spare, 1)} W</b><span>libres</span></div>
      <div><b>${badge(p.overall, sev(p.overall))}</b><span>estado</span></div></div>
      <div class="specs">Reserva configurada: ${p.reservePct} % (§33)</div>`) +
    card('Por switch', table(['Switch', 'Cámaras', 'Puertos', 'Consumo', 'Presupuesto', 'Estado'],
      p.groups.map((g) => [esc(g.label), `${g.poeCameras}/${g.cameras}`, `${g.cameras}/${g.usablePorts}`, `${num(g.totalPower, 1)} W`,
        `${g.budget} W`, badge(g.status + (g.reason ? ' — ' + g.reason : ''), sev(g.status))]))) +
    card('Cámaras', table(['Cámara', 'PoE', 'Consumo', 'Clase', 'Alimentación'],
      p.perCamera.map((c) => [esc(c.label), c.poe ? 'Sí' : 'No', `${num(c.power, 1)} W`, c.poeClass, c.poe ? 'PoE' : 'Fuente 12 V']))) +
    card('Alimentación general', `<div class="specs">Carga total estimada (cámaras + red + cabecera): <b>${num(p.totalLoad, 1)} W</b><br>
      UPS recomendado con margen del 25 %: <b>${p.upsNeeded} W</b> · Cámaras no PoE: <b>${p.nonPoeCount}</b></div>`);
}

/* ------------------------------ grabación ------------------------------ */
function recordingPanel(app) {
  const s = app.results.storage;
  const rules = app.prj.rules;
  const head = card('Parámetros (§21)', `
    ${row('Días de retención', input('rule:set:DIAS_GRABACION', rules.DIAS_GRABACION, 'type="number" step="1"'))}
    ${row('Horas/día', input('rule:set:HORAS_GRABACION', rules.HORAS_GRABACION, 'type="number" step="1"'))}
    ${row('Modo', select('rec:mode', [['24x7', 'Continuo 24×7'], ['motion', 'Detección de movimiento']], app.prj.settings.recordMode || '24x7'))}
    ${row('Actividad (%)', input('rec:duty', Math.round((app.prj.settings.motionDuty || 0.35) * 100), 'type="number" step="5"'), 'Porcentaje del tiempo con grabación en modo movimiento')}
    ${row('Reserva de disco (%)', input('rule:set:RESERVA_DISCO', rules.RESERVA_DISCO, 'type="number" step="1"'))}
    <div class="btnrow">${btn('rec:calc', '▶ Calcular', 'primary')}${btn('rec:apply', 'Aplicar discos recomendados')}</div>`);
  if (!s) return head;
  const rec = s.recommendation;
  return head + card('Resultado', `<div class="kpi">
      <div><b>${num(s.totalMbps, 1)} Mbps</b><span>ancho de banda</span></div>
      <div><b>${num(s.totalGb)} GB</b><span>${s.days} días</span></div>
      <div><b>${num(s.requiredTb)} TB</b><span>necesario</span></div>
      <div><b>${num(s.installedTb)} TB</b><span>instalado</span></div>
      <div><b>${badge(s.enough ? 'SUFICIENTE' : 'INSUFICIENTE', s.enough ? 'ok' : 'err')}</b><span>almacenamiento</span></div></div>
      <div class="specs">Retención real con lo instalado: <b>${num(s.retentionDays, 1)} días</b> · Canales NVR: <b>${app.prj.entities.filter((e) => e.type === 'camera').length}/${s.channels || '—'}</b>${
        s.capacityMbps ? ` · Ancho de banda NVR: ${num(s.totalMbps, 1)}/${s.capacityMbps} Mbps` : ''}</div>
      ${rec ? `<div class="specs">Recomendación: <b>${rec.qty} × ${esc(rec.model)}</b> = ${rec.totalTb} TB${rec.cost ? ` · coste ${money(rec.cost, app.prj.catalog.currency)}` : ''}${rec.infeasible ? ' ⚠ no cabe en las bahías' : ''}</div>` : ''}`) +
    card('Por cámara', table(['Cámara', 'kbps', 'GB/día', 'GB total', 'Modo'],
      s.perCamera.map((c) => [esc(c.label), c.kbps, num(c.gbPerDay, 2), num(c.gb, 1), esc(c.recording)])));
}

/* ------------------------------ rack ------------------------------ */
function rackPanel(app) {
  const r = app.results.rack;
  if (!r) return `<p class="muted">Añada un rack al proyecto.</p>`;
  const rows = [];
  let u = r.capacity;
  for (const it of r.rows) {
    for (let k = 0; k < it.qty; k++) {
      rows.push([`${u}U → ${u - it.uEach + 1}U`, esc(it.name), it.uEach + ' U']);
      u -= it.uEach;
    }
  }
  return card('Rack ' + esc(r.label), `
    ${row('Modelo', select('rack:change', app.prj.catalog.items.filter((i) => i.category === 'rack').map((i) => [i.id, `${i.manufacturer} ${i.model} — ${i.name}`]), app.prj.rack.catalogId))}
    <div class="rackbar"><div class="rackfill" style="width:${Math.min(100, r.fill)}%"></div></div>
    <div class="specs">${r.used} U de ${r.capacity} U (${num(r.fill, 0)} %) · libres ${r.free} U · carga ${num(r.load, 0)} W</div>
    <div class="btnrow">${btn('rack:auto', '⚙ Distribución automática', 'primary')}${btn('rack:clear', 'Vaciar')}</div>`) +
    card('Distribución', `<div class="rack">${rows.map((x) => `<div class="ru"><span>${x[0]}</span><b>${x[1]}</b><i>${x[2]}</i></div>`).join('') || '<div class="ru empty">Rack vacío</div>'}</div>`) +
    (r.warnings.length ? card('Avisos', r.warnings.map((w) => `<p class="${w.severity === 'error' ? 'err-text' : 'warn-text'}">${esc(w.text)}</p>`).join('')) : '');
}

/* ------------------------------ catálogo ------------------------------ */
function catalogPanel(app) {
  const f = app.catalogFilter || { cat: '', q: '' };
  const items = app.prj.catalog.items.filter((i) =>
    (!f.cat || i.category === f.cat) &&
    (!f.q || `${i.manufacturer} ${i.model} ${i.name}`.toLowerCase().includes(f.q.toLowerCase())));
  return card('Catálogo (§24)', `
    <div class="btnrow">${btn('cat:import', '⬆ Importar CSV')} ${btn('cat:template', '⬇ Plantilla CSV')} ${btn('cat:export', '⬇ Exportar catálogo')}</div>
    <div class="btnrow">${btn('cat:distribuidor', '🏷 Cargar catálogo del distribuidor')}</div>
    <input data-act="cat:search" placeholder="Buscar modelo o fabricante…" value="${esc(f.q)}">
    <select data-act="cat:filter"><option value="">Todas las categorías</option>${
      Object.entries(CATEGORIES).map(([k, v]) => `<option value="${k}" ${f.cat === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
    ${table(['Artículo', 'Categoría', 'Precio'], items.slice(0, 200).map((i) => [
      `<b>${esc(i.manufacturer)} ${esc(i.model)}</b><br><span class="muted small">${esc(i.name)}</span>`,
      CATEGORIES[i.category] || i.category,
      `<input class="price" data-act="cat:price" data-id="${esc(i.id)}" value="${esc(i.price)}" type="number" step="0.01">`]))}
    <p class="muted small">${items.length} artículo(s) · precios editables en línea. «Cargar catálogo del distribuidor» añade las cámaras y el equipamiento publicados por el distribuidor (marca, modelo, sensor, focal, consumo y dimensiones reales).</p>`);
}

/* ------------------------------ materiales ------------------------------ */
function materialsPanel(app) {
  const bom = app.results.bom;
  if (!bom || !bom.length) return `<p class="muted">Complete el diseño y ejecute Calcular todo para generar el listado de materiales (§26).</p>`;
  const cur = app.prj.catalog.currency;
  return card('Listado de materiales', table(['Partida', 'Cant.', 'Unidad', 'Total'],
    bom.map((l) => [`<b>${esc(l.label)}</b><br><span class="muted small">${esc(l.note)}</span>`, l.qty, esc(l.unit), money(l.total, cur)])) +
    `<div class="specs">Coste total de materiales: <b>${money(bom.reduce((a, l) => a + l.total, 0), cur)}</b></div>
     <div class="btnrow">${btn('mat:csv', '⬇ CSV')} ${btn('mat:xlsx', '⬇ XLSX')}</div>`);
}

/* ------------------------------ presupuesto ------------------------------ */
function budgetPanel(app) {
  const b = app.results.budget;
  const rules = app.prj.rules;
  const head = card('Base de precios (§27)', `
    ${row('Margen (%)', input('rule:set:MARGEN_PRESUPUESTO', rules.MARGEN_PRESUPUESTO, 'type="number" step="1"'))}
    ${row('Descuento (%)', input('rule:set:DESCUENTO', rules.DESCUENTO, 'type="number" step="1"'))}
    ${row('Impuestos (%)', input('rule:set:IMPUESTOS', rules.IMPUESTOS, 'type="number" step="1"'))}
    ${row('Transporte', input('rule:set:COSTO_TRANSPORTE', rules.COSTO_TRANSPORTE, 'type="number" step="1"'))}
    ${row('Instalación', input('rule:set:COSTO_INSTALACION', rules.COSTO_INSTALACION, 'type="number" step="1"'))}
    ${row('Moneda', input('rule:set:MONEDA', rules.MONEDA))}`);
  if (!b) return head;
  return head + card('Presupuesto', `<div class="kpi">
      <div><b>${money(b.total, b.currency)}</b><span>total con impuestos</span></div>
      <div><b>${money(b.base, b.currency)}</b><span>base imponible</span></div>
      <div><b>${money(b.costSum, b.currency)}</b><span>coste</span></div>
      <div><b>${num(b.profitPct, 1)} %</b><span>margen real</span></div></div>
      ${table(['Partida', 'Cant.', 'Coste ud.', 'Venta ud.', 'Total venta'],
        b.lines.map((l) => [esc(l.label), l.qty, num(l.price), num(l.saleUnit), num(l.saleTotal)]))}
      <div class="specs">Descuento ${money(b.discountAmt, b.currency)} · Impuestos ${money(b.taxAmt, b.currency)} · Beneficio ${money(b.profit, b.currency)}</div>
      <div class="btnrow">${btn('bud:pdf', '⬇ PDF')}${btn('bud:xlsx', '⬇ XLSX')}${btn('bud:csv', '⬇ CSV')}</div>`);
}

/* ------------------------------ documentación ------------------------------ */
function docsPanel(app) {
  const v = app.results.validation;
  return card('Documentos (§28)', `
    <p class="muted small">Cada documento se genera a partir del diseño actual, sin intervención manual.</p>
    <div class="btnrow">
      ${btn('doc:memory', '📄 Memoria descriptiva')}
      ${btn('doc:technical', '📄 Memoria técnica')}
      ${btn('doc:cameras', '📄 Listado de cámaras')}
      ${btn('doc:equipment', '📄 Listado de equipos')}
      ${btn('doc:cabling', '📄 Cuadro de cableado')}
      ${btn('doc:poe', '📄 Cálculo PoE')}
      ${btn('doc:storage', '📄 Cálculo de almacenamiento')}
      ${btn('doc:ptz', '📄 Cámaras PTZ — posiciones')}
      ${btn('doc:lpr', '📄 Cámaras LPR — puesta en marcha')}
      ${btn('doc:analytics', '📄 Analítica — cuadro de reglas')}
      ${btn('doc:fiber', '📄 Fibra — presupuesto óptico')}
      ${btn('doc:analog', '📄 Vídeo analógico — cuadro de enlaces')}
      ${btn('doc:sheets', '📄 Hojas de cámara (una por equipo)', 'primary')}
      ${btn('doc:privacy', '🔒 Anexo de protección de datos y cumplimiento')}
      ${btn('arq:json', '🔗 Paquete de integración ARQ GEN (JSON)')} ${btn('arq:xml', '🔗 Contrato de integración (XML)')}
      ${btn('doc:complete', '📚 Dossier completo', 'primary')}
    </div>`) +
    card('Planos y láminas (§29)', `<div class="btnrow">
      ${btn('plan:pdf', 'Plano PDF (A3)')} ${btn('plan:pdf:3d', 'Lámina 3D PDF (A3)')} ${btn('plan:png', 'Plano PNG')} ${btn('plan:dxf', 'Plano DXF')} ${btn('plan:dxfblocks', 'Plano DXF con bloques')}</div>
      ${row('Escala del plano', select('plan:scale', [['fit', 'Ajuste automático'], ['1:50', '1:50'], ['1:100', '1:100'], ['1:200', '1:200']], app.planScale || 'fit'))}`) +
    card('Intercambio (§29, §39)', `<div class="btnrow">
      ${btn('exp:json', 'JSON')} ${btn('exp:xml', 'XML')} ${btn('exp:csv', 'CSV de cámaras')} ${btn('exp:xlsx', 'XLSX completo')}</div>
      <div class="btnrow">${btn('ptz:csv', 'Cuadro de presets PTZ (CSV)')} ${btn('ptz:doc', 'Cuadro de presets PTZ (PDF)')}</div>
      <div class="btnrow">${btn('lpr:csv', 'Cuadro LPR (CSV)')} ${btn('an:csv', 'Cuadro de reglas de analítica (CSV)')} ${btn('fiber:csv', 'Cuadro de fibra (CSV)')} ${btn('ana:csv', 'Cuadro analógico (CSV)')}</div>`) +
    (v ? card('Última validación', `<p>${v.ok ? '✅ ' : '⚠ '}${esc(v.summary)}</p>`) : '');
}

/* ------------------------------ validación ------------------------------ */
function validationPanel(app) {
  const v = app.results.validation;
  const head = `<div class="btnrow">${btn('val:run', '▶ Validar proyecto', 'primary')}</div>`;
  if (!v) return head + `<p class="muted">La validación revisa las diez comprobaciones exigidas por el contrato antes de cerrar el proyecto (§30).</p>`;
  return head + `<div class="valsum ${v.ok ? 'ok' : 'err'}">${v.ok ? '✅ Proyecto validado sin errores' : '⛔ ' + esc(v.summary)}</div>` +
    v.issues.map((i) => `<details class="val ${i.severity}" ${i.severity === 'error' ? 'open' : ''}>
      <summary>${i.severity === 'ok' ? '✅' : i.severity === 'warn' ? '⚠' : i.severity === 'info' ? 'ℹ' : '⛔'} ${esc(i.title)} <span class="muted">(${i.count})</span></summary>
      ${i.items.length ? `<ul>${i.items.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p class="muted small">Sin incidencias.</p>'}
      ${i.advice && i.severity !== 'ok' ? `<p class="advice">${i.advice.map(esc).join(' · ')}</p>` : ''}
    </details>`).join('');
}

/* ------------------------------ reglas ------------------------------ */
function rulesPanel(app) {
  const groups = {};
  for (const d of RULE_DEFS) (groups[d.group] = groups[d.group] || []).push(d);
  return Object.entries(groups).map(([g, defs]) => card(g, defs.map((d) =>
    row(d.label + (d.unit ? ` (${d.unit})` : ''), input('rule:set:' + d.key, app.prj.rules[d.key], d.type === 'text' ? '' : 'type="number" step="0.01"'), d.help)).join(''))).join('') +
    `<div class="btnrow">${btn('rules:reset', 'Restaurar valores por defecto')}${btn('rules:export', 'Exportar reglas JSON')}</div>`;
}

/* ------------------------------ recorrido §41 ------------------------------ */
function walkthroughPanel(app) {
  const w = app.walkthrough();
  return card('Criterio de finalización (§41)', `<p class="muted small">Los 18 pasos que el contrato exige completar sobre un plano real, sin ARQ GEN.</p>` +
    `<ol class="walk">${w.map((s) => `<li class="${s.done ? 'done' : ''}"><span>${s.done ? '✓' : s.n}</span><b>${esc(s.name)}</b><em>${esc(s.detail)}</em>${s.act ? btn(s.act, s.label || 'Ejecutar') : ''}</li>`).join('')}</ol>`);
}

/* ------------------------------ capas ------------------------------ */
function layersPanel(app) {
  return planoImportadoCard(app) + card('Capas (§11)', table(['', 'Capa', 'Color', 'Ver'], app.prj.layers.map((l) => [
    `<input type="radio" name="curLayer" data-act="layer:current" value="${esc(l.id)}" ${app.cad.layer === l.id ? 'checked' : ''}>`,
    esc(l.name), `<input type="color" data-act="layer:color" data-id="${esc(l.id)}" value="${esc(l.color)}">`,
    `<input type="checkbox" data-act="layer:visible" data-id="${esc(l.id)}" ${l.visible === false ? '' : 'checked'}>`])) +
    `<div class="btnrow">${btn('layer:add', '+ Nueva capa')}${btn('layer:isolate', 'Aislar capa actual')}${btn('layer:all', 'Ver todas')}</div>`);
}

/* ------------------------------ proyecto ------------------------------ */
function projectPanel(app) {
  const m = app.prj.meta;
  return card('Datos del proyecto (§6)', `
    ${row('Nombre', input('meta:name', m.name))}
    ${row('Código', input('meta:code', m.code))}
    ${row('Cliente', input('meta:client', m.client))}
    ${row('Dirección', input('meta:address', m.address))}
    ${row('Autor', input('meta:author', m.author))}
    ${row('Empresa', input('meta:company', m.company))}
    ${row('Notas', `<textarea data-act="meta:notes">${esc(m.notes)}</textarea>`)}
    <div class="specs">Creado ${new Date(m.created).toLocaleString('es-ES')}<br>Modificado ${new Date(m.modified).toLocaleString('es-ES')}<br>
    ${app.prj.entities.length} entidades · ${app.prj.entities.filter((e) => e.type === 'camera').length} cámaras</div>`);
}

/* ------------------------------ módulo PTZ (§38) ------------------------------ */
const ptzField = (act, i, k, value, attrs = '') =>
  `<input class="ptzf" data-act="${act}" data-i="${i}" data-k="${k}" value="${esc(value === null || value === undefined ? '' : value)}" ${attrs}>`;
const ptzBtn = (act, i, label, title = '') => `<button class="btn tiny" data-act="${act}" data-i="${i}" title="${esc(title)}">${label}</button>`;

/** Editor de presets y patrulla dentro de Propiedades de la cámara. */
function ptzEditor(app, cam) {
  const cat = app.prj.catalog;
  const lim = presetLimits(cam, cat);
  const presets = cameraPresets(cam);
  const cycle = patrolCycle(cam, cat, app.prj.rules);
  const cov = app.results.coverage && (app.results.coverage.cameras || []).find((c) => c.id === cam.id);
  const live = presets.length && cam.data.ptzPatrol !== false;
  const rows = presets.map((p, i) => [
    ptzField('ptz:set', i, 'name', p.name),
    ptzField('ptz:set', i, 'azimuth', p.azimuth, 'type="number" step="5"'),
    ptzField('ptz:set', i, 'tilt', p.tilt, 'type="number" step="1"'),
    ptzField('ptz:set', i, 'focal', p.focal || '', `type="number" step="0.5" title="Zoom: ${lim.focalMin}–${lim.focalMax} mm"`),
    `<select data-act="ptz:set" data-i="${i}" data-k="objective">${Object.entries(OBJECTIVES).map(([k, v]) =>
      `<option value="${k}" ${p.objective === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}</select>`,
    ptzField('ptz:set', i, 'dwell', p.dwell, 'type="number" step="5"'),
    `${num(p.duty * 100, 0)} %`,
    num(((cov && cov.presetAreas) || [])[i] || 0, 1),
    `${ptzBtn('ptz:goto', i, '⤓', 'Llevar la cámara a esta posición')}${ptzBtn('ptz:del', i, '🗑', 'Eliminar preset')}`,
  ]);
  return card('PTZ — presets y patrulla (§38)', `
    <div class="specs">Recorrido ${num(lim.pan[0], 0)}–${num(lim.pan[1], 0)}° · inclinación ${num(lim.tilt[0], 0)}–${num(lim.tilt[1], 0)}°
      · zoom ${num(lim.focalMin, 1)}–${num(lim.focalMax, 1)} mm · ${esc((getItem(cat, cam.data.catalogId) || {}).model || '')}</div>
    ${presets.length ? table(['Posición', 'Az°', 'Inc°', 'mm', 'Objetivo', 's', '%', 'm²', ''], rows, 'ptztable tight')
      : '<p class="muted small">Sin posiciones memorizadas: la cámara cubrirá únicamente la vista actual.</p>'}
    <div class="btnrow">${btn('ptz:add', '＋ Añadir vista actual')}${btn('ptz:spread', '⚙ Repartir barrido…')}${btn('ptz:show', '👁 Ver presets')}</div>
    ${row('Patrulla activa', `<input type="checkbox" data-act="ptz:patrol" ${cam.data.ptzPatrol === false ? '' : 'checked'}>`,
      'Si se desactiva, la cámara queda fija en la vista principal aunque conserve los presets')}
    <div class="specs">${cycle.count
      ? `Ciclo completo <b>${num(cycle.cycleSec, 0)} s</b> (permanencias ${num(cycle.dwellTotal, 0)} s + giros ${num(cycle.moveTotal, 0)} s) ·
         se repite ${num(cycle.perHour, 1)} veces/hora`
      : 'Sin ciclo de patrulla definido'}</div>
    <div class="specs">${live && cov
      ? `Cobertura en un instante: <b>${num(cov.area)} m²</b> · media ponderada por tiempo: <b>${num(cov.weightedArea)} m²</b>`
      : 'La cobertura PTZ se calcula como la unión de todas las posiciones.'}</div>`);
}

/** Panel del módulo PTZ: resumen de todas las cámaras de barrido del proyecto. */
function ptzPanel(app) {
  const cat = app.prj.catalog;
  const cams = app.prj.entities.filter((e) => e.type === 'camera' && isPtz(e, cat));
  const head = card('Módulo PTZ (§38)', `
    <p class="muted small">Cada cámara PTZ barre una secuencia de posiciones memorizadas. El módulo convierte esa
    secuencia en datos técnicos: huella de cada preset, cobertura ponderada por tiempo, ciclo de patrulla,
    bitrate de grabación y documentación.</p>
    <div class="btnrow">${btn('ptz:add', '＋ Añadir vista a la selección')}${btn('ptz:spread', '⚙ Repartir barrido…')}
      ${btn('ptz:show', '👁 Ver presets en el plano')}${btn('ptz:csv', '⬇ Cuadro de presets (CSV)')}${btn('ptz:doc', '⬇ Cuadro PTZ (PDF)')}</div>`);
  if (!cams.length) return head + `<p class="muted">No hay cámaras PTZ en el proyecto. Añada una desde el catálogo
    (familia «Cámaras», modelo con especificación PTZ) y defina sus posiciones.</p>`;
  const sum = ptzSummary(app.prj, cat, app.prj.rules, app.results.coverage);
  const sched = ptzSchedule(app.prj, cat, app.prj.rules);
  // La cámara se escribe una sola vez y las posiciones se agrupan debajo (tabla legible en el panel)
  let lastCam = null;
  const rows = sched.map((r) => {
    const first = r.camera !== lastCam;
    lastCam = r.camera;
    return [first ? `<b>${esc(r.camera)}</b>` : '<span class="muted">↳</span>', esc(r.preset),
      num(r.azimuth, 0), num(r.tilt, 0), r.focal,
      r.dwell === '' ? '—' : num(r.dwell, 0), r.duty === '' ? '—' : num(r.duty, 0) + ' %'];
  });
  return head + card('Resumen', `<div class="kpi">
      <div><b>${sum.cameras}</b><span>cámaras PTZ</span></div>
      <div><b>${sum.presets}</b><span>presets</span></div>
      <div><b>${num(sum.cycleMax, 0)} s</b><span>ciclo mayor</span></div>
      <div><b>${num(sum.weightedArea)} m²</b><span>cobertura media</span></div></div>
      ${sum.rows.map((r) => `<div class="specs"><b>${esc(r.label)}</b> · ${r.count} presets · ciclo ${num(r.cycleSec, 0)} s ·
        unión ${num(r.unionArea)} m² · media ponderada ${num(r.weightedArea)} m² · ${r.patrol ? 'patrulla activa' : 'patrulla detenida'}</div>`).join('')}`) +
    card('Cuadro de posiciones', rows.length ? table(['Cámara', 'Posición', 'Az°', 'Inc°', 'mm', 's', '%'], rows, 'tight')
      : '<p class="muted small">Defina presets en una cámara PTZ para generar el cuadro.</p>') +
    card('Cómo se calcula', `<p class="muted small">La huella de cada preset se proyecta con su propio azimut, inclinación y zoom,
      y se recorta con los obstáculos del plano igual que una cámara fija (§13). El análisis de cobertura suma la
      <b>unión</b> de todas las posiciones; la <b>media ponderada</b> (Σ permanencia · área / ciclo) es la cifra realista
      de vigilancia permanente. La patrulla incrementa el bitrate de grabación con el factor definido en Reglas.</p>`);
}

/* ------------------------------ módulos del sistema (§38) ------------------------------ */
function modulesPanel(app) {
  const mods = detectedModules(app.prj, app.prj.catalog);
  const rows = mods.map((m) => [`<b>${esc(m.name)}</b><br><span class="muted small">${esc(m.ref)}</span>`,
    badge(m.status === 'activo' ? 'ACTIVO' : m.status === 'detectado' ? 'DETECTADO' : 'PREPARADO',
      m.status === 'activo' ? 'ok' : m.status === 'detectado' ? 'info' : 'warn'), esc(m.detail)]);
  return card('Modularidad (§38)', `<p class="muted small">El contrato exige poder incorporar nuevas disciplinas sin reconstruir el programa.
    Cada módulo es independiente: si no se usa, el resto del cálculo no cambia. El estado «preparado» indica que el modelo de
    datos, el catálogo y la documentación ya lo contemplan, a la espera de su módulo de cálculo.</p>
    ${table(['Módulo / componente', 'Estado', 'Situación en el proyecto'], rows)}
    <div class="specs">${mods.filter((m) => m.status === 'activo').length} módulo(s) activo(s) ·
      ${mods.filter((m) => m.status === 'detectado').length} detectado(s) por el catálogo ·
      ${mods.filter((m) => m.status === 'preparado').length} preparado(s)</div>`) +
    escritorioCard(app);
}

/* ------------------------------ shell de escritorio (§32, §35, §9) ------------------------------ */

/**
 * Estado del ejecutable de escritorio: base de datos propia y conversor DWG local.
 * En el navegador explica qué falta sin que nada deje de funcionar.
 */
function escritorioCard(app) {
  const est = app._shellInfo;
  const shell = typeof window !== 'undefined' && !!(window.__TAURI__ && window.__TAURI__.core && typeof window.__TAURI__.core.invoke === 'function');
  if (!shell || !est || !est.disponible) {
    return card('Escritorio: SQLite y conversor DWG (§32, §35)', `
      <p class="muted small">Esta ventana es el programa en un <b>navegador</b>: el catálogo y las reglas viven en la sesión.
      El ejecutable <b>CCTVDesign.exe</b> abre exactamente la misma aplicación con la <b>base de datos propia</b>
      (<span class="mono">database/cctv.sqlite</span>) y con el <b>conversor DWG local</b> de
      <span class="mono">tools/converter/</span>. Ningún cálculo, documento ni exportación depende de ellos.</p>
      <div class="btnrow">${btn('db:estado', 'Estado de la base de datos')}${btn('db:convertir', 'Convertir DWG e importar')}</div>`);
  }
  const bd = est.baseDeDatos || {};
  const conv = est.conversores || [];
  return card('Escritorio: SQLite y conversor DWG (§32, §35)', `
    <div class="kpi">
      <div><b>${esc(bd.sqlite || '—')}</b><span>SQLite</span></div>
      <div><b>${bd.articulos || 0}</b><span>artículos en la base</span></div>
      <div><b>${bd.reglas || 0}</b><span>reglas</span></div>
      <div><b>${conv.length}</b><span>conversor(es) DWG</span></div>
    </div>
    <div class="specs">Ejecutable ${esc(est.version || '')} · ${esc(est.plataforma || '')}/${esc(est.arquitectura || '')}<br>
      Carpeta del programa: <span class="mono">${esc(est.raiz || '')}</span><br>
      Base de datos: <span class="mono">${esc(bd.ruta || '')}</span>${conv.length ? '<br>Conversor: ' + conv.map((c) => esc(c.nombre) + ' ' + esc(c.version)).join(' · ') : '<br>Conversor DWG no instalado: el programa sigue funcionando con DXF.'}</div>
    ${table(['Herramienta', 'Comando', ''], [
      ['Guardar catálogo y reglas en la base', 'Escribe el catálogo y las reglas vigentes en SQLite', btn('db:guardar', 'Guardar')],
      ['Recargar desde la base', 'Trae el catálogo y las reglas guardados', btn('db:cargar', 'Cargar')],
      ['Guardar proyecto en la base', 'Proyecto completo + copia anterior (§37)', btn('db:proyecto', 'Guardar')],
      ['Copias y auditoría', 'Historial de versiones y movimientos', btn('db:historial', 'Ver')],
      ['Convertir DWG', 'Ejecuta el conversor local y lee el DXF con el lector propio (§9)', btn('db:convertir', 'Convertir')],
    ])}
    <p class="muted small">La carpeta del programa es copiable (§35): el ejecutable lleva la interfaz dentro,
      y junto a él viven la base de datos, el conversor y las carpetas de trabajo.</p>`);
}

/* ------------------------------ módulo LPR (§38) ------------------------------ */
/** Editor de la cámara LPR dentro de Propiedades. */
function lprEditor(app, cam) {
  const o = lprOptics(cam, app.prj.catalog, app.prj.rules);
  const maxSpeed = maxSpeedFor(cam, app.prj.catalog, app.prj.rules);
  const checks = [
    ['Altura de carácter', `${num(o.charPx, 1)} px`, o.charPx >= o.minCharPx, `mínimo ${o.minCharPx} px`],
    ['Densidad sobre la placa', `${num(o.ppm, 0)} ppm`, o.ppm >= o.minPpm, `mínimo ${o.minPpm} ppm`],
    ['Ángulo de lectura', `${num(o.mountingAngle, 0)}°`, o.mountingAngle <= o.maxAngle, `máximo ${o.maxAngle}°`],
    ['Emborronamiento', `${num(o.blurPct, 1)} %`, o.blurPct <= o.blurLimit, `máximo ${o.blurLimit} % del carácter`],
  ];
  return card('LPR — lectura de matrículas (§38)', `
    ${row('Módulo de lectura', `<input type="checkbox" data-act="lpr:enable" ${o.enabled ? 'checked' : ''}>`)}
    ${row('Función', select('lpr:mode', Object.entries(LPR_MODES_PANEL).map(([k, v]) => [k, v]), o.mode))}
    ${row('Carril', input('lpr:lane', o.lane))}
    ${row('Distancia de captura (m)', input('lpr:distance', o.captureDistance, 'type="number" step="0.5"'))}
    ${row('Ángulo con la marcha (°)', input('lpr:angle', o.mountingAngle, 'type="number" step="5"'))}
    ${row('Velocidad de diseño (km/h)', input('lpr:speed', o.speedLimit, 'type="number" step="5"'))}
    ${row('Obturación (1/s)', input('lpr:shutter', o.shutter, 'type="number" step="250"'), 'El emborronamiento se mide sobre el carácter (47 mm en placa UE)')}
    ${row('Iluminación IR', `<input type="checkbox" data-act="lpr:ir" ${o.irIlluminator ? 'checked' : ''}>`)}
    <div class="specs">Placa ${num(o.plateWidth * 1000, 0)} mm · ventana de lectura <b>${num(o.minReadDistance, 1)}–${num(o.maxReadDistance, 1)} m</b> ·
      velocidad máxima admitida <b>${num(maxSpeed, 0)} km/h</b> con 1/${o.shutter} s</div>
    ${table(['Criterio', 'Valor', '', 'Límite'], checks.map((c) => [c[0], c[1], badge(c[2] ? 'CUMPLE' : 'REVISAR', c[2] ? 'ok' : 'err'), c[3]]), 'tight')}
    <div class="btnrow">${btn('lpr:zone', '👁 Ver zona de captura')}${btn('lpr:panel', 'Panel del módulo LPR')}</div>`);
}

const LPR_MODES_PANEL = { ENTRADA: 'Entrada de vehículos', SALIDA: 'Salida de vehículos', BIDIRECCIONAL: 'Doble sentido', VIA: 'Vía / control de paso' };

/** Panel del módulo LPR: todas las cámaras de matrículas del proyecto. */
function lprPanel(app) {
  const s = lprSummary(app.prj, app.prj.catalog, app.prj.rules);
  const head = card('Módulo LPR (§38)', `
    <p class="muted small">El diseño de un LPR no se mide por campo de visión sino por <b>carácter legible</b>:
    se exige suficiente densidad sobre la placa, un ángulo pequeño respecto a la marcha y un tiempo de
    obturación que congele el movimiento del vehículo.</p>
    <div class="btnrow">${btn('lpr:csv', '⬇ Cuadro LPR (CSV)')}${btn('lpr:doc', '⬇ Cuadro LPR (PDF)')}${btn('lpr:zone', '👁 Ver zonas de captura')}</div>`);
  if (!s.count) return head + `<p class="muted">No hay cámaras LPR en el proyecto. Coloque una cámara del catálogo con especificación LPR
    (familia «Cámaras») y defina su carril, distancia de captura y ángulo de montaje.</p>`;
  const rows = s.rows.map((r) => [esc(r.label), esc(r.lane), esc(r.mode), num(r.distance, 1), r.focal,
    num(r.ppm, 0), num(r.charPx, 1), num(r.angle, 0), num(r.blurPct, 1) + ' %', num(r.maxSpeed, 0),
    badge(r.ok ? 'CORRECTO' : 'REVISAR', r.ok ? 'ok' : 'err')]);
  return head + card('Resumen', `<div class="kpi">
      <div><b>${s.count}</b><span>cámaras LPR</span></div>
      <div><b>${s.laneCount}</b><span>carriles</span></div>
      <div><b>${num(s.rows[0].charPx, 1)}</b><span>px de carácter</span></div>
      <div><b>${num(s.rows[0].maxReadDistance, 1)} m</b><span>alcance de lectura</span></div>
      <div><b>${s.status}</b><span>estado</span></div></div>`) +
    card('Cámaras de matrículas', table(['Cámara', 'Carril', 'Función', 'Dist. m', 'mm', 'ppm', 'px car.', 'Áng. °', 'Emborrona.', 'V. máx km/h', 'Estado'], rows)) +
    card('Criterios aplicados', table(['Criterio', 'Regla', 'Valor'], [
      ['Altura de carácter', 'LPR_ALTURA_CARACTER', `${num(app.prj.rules.LPR_ALTURA_CARACTER, 0)} px`],
      ['Densidad mínima', 'LPR_PPM', `${num(app.prj.rules.LPR_PPM, 0)} ppm`],
      ['Ángulo máximo', 'LPR_ANGULO_MAX', `${num(app.prj.rules.LPR_ANGULO_MAX, 0)}°`],
      ['Emborronamiento máximo', 'LPR_EMBORRON_PCT', `${num(app.prj.rules.LPR_EMBORRON_PCT, 0)} % del ancho de carácter`],
      ['Placa de referencia', '—', '520 × 110 mm (UE), carácter de 47 × 75 mm'],
    ], 'tight') + `<p class="muted small">La velocidad máxima admitida se obtiene del tiempo de obturación:
      v = (emborronamiento admisible · ancho de carácter) / tiempo de exposición.</p>`);
}

/* ------------------------------ vídeo analógico (§38) ------------------------------ */
/** Editor del enlace analógico dentro de Propiedades de la cámara. */
function analogCameraEditor(app, cam) {
  const l = analogLink(cam, app.prj, app.prj.catalog, app.prj.rules);
  const cableEnt = app.prj.entities.find((e) => e.type === 'cable' && e.data.from === cam.id);
  const dvr = app.prj.entities.find((e) => e.id === cam.data.switchId && e.type === 'device');
  return card('Vídeo analógico (§38)', `
    <div class="specs">Este equipo <b>no</b> es IP: no consume PoE ni ocupa puerto de switch. La señal viaja
      por cable de vídeo hasta un grabador híbrido (DVR) y la alimentación es de 12 V por dos hilos.</div>
    ${row('Formato', select('ana:format', Object.entries(ANALOG_FORMATS).map(([k, v]) => [k, v.label]), l.format.id))}
    ${row('Medio de transmisión', select('ana:cable', Object.entries(ANALOG_CABLES).map(([k, v]) => [k, v.label]), l.cable.id))}
    ${row('Distancia del enlace (m)', input('ana:distance', l.distance.toFixed(1), 'type="number" step="1"'), 'Se recalcula al generar las rutas')}
    ${row('Sección de alimentación (mm²)', input('ana:section', l.section, 'type="number" step="0.1"'))}
    ${row('Grabador asignado', esc(dvr ? (dvr.data.label || dvr.id) : '— sin grabador —'))}
    <div class="specs">Alcance del medio: <b>${num(l.limit, 0)} m</b> (${esc(l.format.label)} por ${esc(l.cable.label)}) ·
      uso <b>${num(l.pct, 0)} %</b> ${badge(l.status, l.status === 'NORMAL' ? 'ok' : l.status === 'PROXIMA' ? 'warn' : 'err')} ·
      canal <b>${l.format.mp >= 2 ? 'alta definición' : 'SD'}</b></div>
    <div class="specs">Alimentación 12 V: ${num(l.watts, 1)} W (${num(l.current * 1000, 0)} mA) ·
      caída ${num(l.power.drop, 2)} V · <b>${num(l.power.volts, 2)} V</b> en la cámara
      ${badge(l.power.ok ? 'CORRECTO' : 'REVISAR', l.power.ok ? 'ok' : 'err')}</div>
    <div class="btnrow">${btn('ana:panel', 'Panel del módulo analógico')}${btn('cable:generate', '▶ Regenerar rutas')}</div>`);
}

/** Panel del módulo analógico: enlaces de vídeo, canales del grabador y alimentación. */
function analogPanel(app) {
  const cat = app.prj.catalog, rules = app.prj.rules;
  const plan = analogPlan(app.prj, cat, rules);
  const s = analogSummary(app.prj, cat, rules);
  const head = card('Vídeo analógico (§38)', `
    <p class="muted small">Un sistema analógico se dimensiona por tres límites físicos: la <b>distancia del cable de
    vídeo</b> (según formato y medio), los <b>canales del grabador híbrido</b> y la <b>caída de tensión</b> de los 12 V
    por dos hilos de cobre. El módulo calcula los tres y avisa cuando alguno se pasa.</p>
    <div class="btnrow">${btn('ana:csv', '⬇ Cuadro analógico (CSV)')}${btn('ana:doc', '⬇ Cuadro analógico (PDF)')}${btn('cable:generate', '▶ Generar rutas')}</div>`);
  if (!plan.count) return head + `<p class="muted">No hay cámaras analógicas en el proyecto. Coloque una cámara HD-TVI, AHD, HD-CVI o CVBS
    del catálogo (familia «Cámaras») junto con un grabador híbrido (DVR) y una fuente de 12 V: el módulo calculará distancias,
    canales y alimentación.</p>`;
  const rows = analogSchedule(app.prj, cat, rules).map((r) => [esc(r.camera), esc(r.format), esc(r.cable),
    num(r.distance, 1), num(r.limit, 0), num(r.margin, 1), num(r.pct, 0) + ' %', esc(r.channel),
    num(r.current, 0) + ' mA', num(r.drop, 2), num(r.volts, 2), badge(r.status, r.status === 'NORMAL' ? 'ok' : r.status === 'PROXIMA' ? 'warn' : 'err')]);
  const rec = plan.recording;
  return head + card('Resumen', `<div class="kpi">
      <div><b>${plan.count}</b><span>cámaras analógicas</span></div>
      <div><b>${num(plan.coaxMeters, 0)} m</b><span>de coaxial</span></div>
      <div><b>${rec.channels}</b><span>canales de grabación</span></div>
      <div><b>${num(s.voltsMin, 1)} V</b><span>en la cámara</span></div>
      <div><b>${plan.status}</b><span>estado</span></div></div>
      <div class="specs">${plan.formats.join(' · ')} · ${plan.baluns} enlace(s) por UTP con balún ·
        ${num(plan.utpMeters, 0)} m de UTP ·${rec.bandwidthOk ? '' : ' <b>caudal por encima del grabador</b> ·'} ${esc(rec.dvrs.map((d) => d.label + ' (' + d.model + ')').join(', ')) || 'sin grabador'}</div>`) +
    card('Cuadro analógico', table(['Cámara', 'Formato', 'Medio', 'Dist. m', 'Alcance m', 'Margen m', 'Uso', 'Canal', 'Consumo', 'Caída V', 'Tensión V', 'Estado'], rows)) +
    card('Alimentación (§38)', `<div class="kpi">
      <div><b>${num(plan.power.watts, 1)} W</b><span>consumo total</span></div>
      <div><b>${num(plan.power.amps, 2)} A</b><span>intensidad</span></div>
      <div><b>${num(plan.power.needAmps, 2)} A</b><span>con reserva ${num(plan.power.reserve, 0)} %</span></div>
      <div><b>${num(plan.power.psuAmps, 1)} A</b><span>fuentes instaladas</span></div>
      <div><b>${plan.power.ok ? 'SUFICIENTE' : 'REVISAR'}</b><span>alimentación</span></div></div>
      <div class="specs">Caída máxima ${num(plan.power.drop, 2)} V · tensión mínima en cámara ${num(s.voltsMin, 2)} V ·
        sección ${num(rules.ANALOG_SECCION, 2)} mm² · ρ cobre 0,0172 Ω·mm²/m (dos hilos)</div>
      ${row('Sección de alimentación (mm²)', input('rule:set:ANALOG_SECCION', rules.ANALOG_SECCION, 'type="number" step="0.1"'))}
      ${row('Tensión mínima en la cámara (V)', input('rule:set:ANALOG_TENSION_MIN', rules.ANALOG_TENSION_MIN, 'type="number" step="0.5"'))}
      ${row('Reserva de la fuente (%)', input('rule:set:ANALOG_RESERVA_FUENTE', rules.ANALOG_RESERVA_FUENTE, 'type="number" step="5"'))}`) +
    card('Grabación analógica', table(['Grabador', 'Modelo', 'Canales', 'Canales HD', 'Formatos', 'Bahías', 'Caudal máx.'],
      rec.dvrs.map((d) => [esc(d.label), esc(d.model), d.channels, d.hdChannels, d.formats.join('/'), d.bays, `${d.maxMbps} Mbps`]), 'tight') +
      `<div class="specs">Necesarios: <b>${rec.cameras}</b> canal(es), ${rec.needHd} en alta definición ·
        caudal de vídeo ${rec.bandwidth} Mbps sobre ${rec.maxMbps} Mbps admitidos ${badge(rec.ok ? 'CORRECTO' : 'REVISAR', rec.ok ? 'ok' : 'err')}</div>`) +
    card('Alcances del catálogo (§33)', table(['Formato', 'Resolución', 'Factor', 'RG-59', 'RG-6', 'UTP'],
      Object.values(ANALOG_FORMATS).map((f) => [esc(f.label), `${f.resW}×${f.resH}`, num(f.factor, 2),
        num(rules.ANALOG_RG59_MAX * f.factor, 0) + ' m', num(rules.ANALOG_RG6_MAX * f.factor, 0) + ' m',
        num(rules.ANALOG_UTP_MAX * f.factor, 0) + ' m']), 'tight') +
      `<p class="muted small">${esc(Object.values(ANALOG_FORMATS)[0].note)} ${esc(Object.values(ANALOG_FORMATS)[4].note)}</p>`);
}

/* ------------------------------ analítica de vídeo (§38) ------------------------------ */
/** Editor de reglas de analítica dentro de Propiedades de cámara. */
function analyticsEditor(app, cam) {
  const rules = cameraRules(cam);
  const zones = app.prj.entities.filter((e) => e.type === 'room');
  const cov = app.results.coverage;
  const rows = rules.map((r, i) => {
    const ev = app.ruleEval(cam, r);
    return [
      select('an:type', Object.entries(ANALYTICS_TYPES).map(([k, v]) => [k, v.label]), r.type).replace('data-act="an:type"', `data-act="an:type" data-i="${i}"`),
      select('an:zone', [['', '— sin zona —'], ...zones.map((z) => [z.id, z.data.name || z.id])], r.zoneId).replace('data-act="an:zone"', `data-act="an:zone" data-i="${i}"`),
      ptzField('an:sens', i, 'sensitivity', r.sensitivity, 'type="number" min="1" max="10" step="1"'),
      ptzField('an:events', i, 'eventsPerDay', r.eventsPerDay === null ? '' : r.eventsPerDay, 'type="number" step="5"'),
      ptzField('an:actions', i, 'actions', r.actions.join('+'), 'title="alarm / email / siren / doorlock / zoom / recording"'),
      ev ? `${num(ev.coveragePct, 0)} %` : '—',
      ev ? num(ev.worstPpm, 0) : '—',
      ev ? badge(ev.ok ? 'OK' : 'REVISAR', ev.ok ? 'ok' : 'err') : '—',
      ptzBtn('an:del', i, '🗑', 'Eliminar regla'),
    ];
  });
  const embedded = (supportsType(cam, app.prj.catalog, 'linecross') || supportsType(cam, app.prj.catalog, 'intrusion'));
  return card('Analítica de vídeo (§38)', `
    <div class="specs">${embedded ? 'Analítica embarcada en la cámara' : 'Requiere licencia por canal (se añade al presupuesto)'} ·
      sensibilidad 1 (estricta) a 10 (permisiva)</div>
    ${rows.length ? table(['Regla', 'Zona', 'Sens.', 'Eventos/día', 'Acciones', 'Cobertura zona', 'Peor ppm', 'Estado', ''], rows, 'ptztable tight')
      : '<p class="muted small">Sin reglas de analítica: la cámara graba y se vigila manualmente.</p>'}
    <div class="btnrow">${btn('an:add', '＋ Añadir regla')}${btn('an:panel', 'Panel de analítica')}</div>`);
}

/** Panel de analítica: reglas, eventos, metadatos y licencias. */
function analyticsPanel(app) {
  const s = analyticsSummary(app.prj, app.prj.catalog, app.prj.rules, app.results.coverage || {});
  const head = card('Analítica de vídeo (§38)', `
    <p class="muted small">Cada regla es una condición de disparo sobre una zona: el programa comprueba que esa zona
    esté cubierta y con densidad suficiente, estima el caudal de eventos, el ancho de banda de metadatos y la licencia
    de canal cuando la cámara no trae analítica embarcada.</p>
    <div class="btnrow">${btn('an:csv', '⬇ Cuadro de reglas (CSV)')}${btn('an:doc', '⬇ Cuadro de reglas (PDF)')}</div>`);
  if (!s.rules) return head + `<p class="muted">No hay reglas definidas. Seleccione una cámara y añada reglas desde Propiedades.</p>`;
  const rows = analyticsSchedule(app.prj, app.prj.catalog, app.prj.rules, app.results.coverage || {}).map((r) => [
    esc(r.camera), esc(r.type), esc(r.zone), num(r.sensitivity, 0), num(r.coveragePct, 0) + ' %',
    num(r.ppm, 0), num(r.events, 0), esc(r.actions), esc(r.license)]);
  return head + card('Resumen', `<div class="kpi">
      <div><b>${s.rules}</b><span>reglas</span></div>
      <div><b>${s.cameras}</b><span>cámaras</span></div>
      <div><b>${num(s.events, 0)}</b><span>eventos/día</span></div>
      <div><b>${s.licenses}</b><span>licencias</span></div>
      <div><b>${num(s.kbps, 0)} kbps</b><span>metadatos</span></div></div>
      <div class="specs">Estado: <b>${s.status}</b> · ${s.failed} regla(s) por revisar</div>`) +
    card('Cuadro de reglas', table(['Cámara', 'Regla', 'Zona', 'Sens.', 'Cobertura', 'Peor ppm', 'Eventos/día', 'Acciones', 'Analítica'], rows)) +
    card('Tipos de regla', table(['Regla', 'Descripción', 'ppm mínimos'], Object.entries(ANALYTICS_TYPES).map(([k, v]) =>
      [esc(v.label), esc(v.note) + (v.onlyPtz ? ' <b>Solo PTZ</b>' : '') + (v.onlyLpr ? ' <b>Solo LPR</b>' : ''), v.ppm]), 'tight'));
}

/* ------------------------------ fibra óptica (§38) ------------------------------ */
/**
 * Panel «Opciones de dibujo» (§8): todo lo configurable del espacio de trabajo, con la misma
 * organización que AutoCAD — puntero y cursor, colores del espacio, forzados y selección — más una
 * previsualización del puntero y una muestra de los conmutadores de la barra de estado.
 */
function optionsPanel(app) {
  const p = app.prefs;
  const problemas = revisarPrefs(p);
  const avisoCruz = avisoContraste(p.colorCruz, p.fondo);
  const avisoMira = avisoContraste(p.colorMira, p.fondo);
  const avisoSel = avisoContraste(p.colorSeleccion, p.fondo);
  const avisoMarq = avisoContraste(p.colorMarquesina, p.fondo);
  const avisoMarqCruce = avisoContraste(p.colorCruce, p.fondo);
  const control = (d) => {
    if (d.tipo === 'bool') {
      return `<input type="checkbox" data-act="pref:${d.clave}" ${p[d.clave] ? 'checked' : ''}>`;
    }
    if (d.tipo === 'color') {
      return `<span class="colorctl"><input type="color" data-act="pref:${d.clave}" value="${esc(p[d.clave])}">` +
        `<code>${esc(p[d.clave])}</code></span>`;
    }
    if (d.tipo === 'opcion') {
      return select(`pref:${d.clave}`, d.opciones, p[d.clave]);
    }
    return `<span class="numctl"><input type="range" min="${d.min}" max="${d.max}" step="${d.paso}" data-act="pref:${d.clave}:slider" value="${p[d.clave]}">` +
      `<input type="text" inputmode="decimal" autocomplete="off" class="num" data-act="pref:${d.clave}" value="${p[d.clave]}">` +
      `<span class="unit">${d.unidad || ''}</span></span>`;
  };
  const cuerpo = GRUPOS.map((g) => card(g.titulo + `<span class="muted small"> · ${esc(g.ref)}</span>`,
    defsDeGrupo(g.id).map((d) => {
      const tecla = TECLAS[d.clave] ? ` <kbd>${TECLAS[d.clave]}</kbd>` : '';
      const aviso = d.clave === 'colorCruz' ? avisoCruz.aviso : d.clave === 'colorMira' ? avisoMira.aviso
        : d.clave === 'colorSeleccion' ? avisoSel.aviso
        : d.clave === 'colorMarquesina' ? avisoMarq.aviso : d.clave === 'colorCruce' ? avisoMarqCruce.aviso : '';
      return `<div class="frow prefr"><label>${d.etiqueta}${tecla}</label>${control(d)}</div>` +
        `<div class="specs prefh">${esc(d.ayuda || '')}${aviso ? ` <b class="warn">⚠ ${esc(aviso)}</b>` : ''}</div>`;
    }).join(''), g.id === 'espacio'
      ? select('pref:tema', TEMAS_LISTA.map((t) => [t, TEMAS[t].etiqueta]), (TEMAS[p.tema] ? p.tema : 'programa'))
      : '')).join('');

  return `
  ${card('Previsualización del puntero',
    `<div class="prefcursor">
      <canvas id="prefcursor" width="420" height="150"></canvas>
      <div class="specs">${esc(resumenPrefs(p))}</div>
    </div>`,
    `<button class="btn" data-act="pref:panel" title="Volver a leer las preferencias">↻</button>`)}
  ${cuerpo}
  ${card('Barra de estado (conmutadores)',
    `<div class="stogbar">${CONMUTABLES.map((c) => {
      const d = PREF_DEFS.find((x) => x.clave === c);
      return `<button class="stog ${p[c] ? 'on' : ''}" data-act="pref:${c}" title="${esc(d.etiqueta)}">${LEYENDA_CONMUTABLE[c]}${TECLAS[c] ? ` · ${TECLAS[c]}` : ''}</button>`;
    }).join('')}</div>
    <div class="specs">Los mismos botones que aparecen abajo a la izquierda del lienzo; se pueden conmutar con las teclas de función, como en AutoCAD.</div>`)}
  ${card('Atajos y valores',
    `<div class="btnrow">
      ${btn('pref:tema:programa', 'Tema del programa')}${btn('pref:tema:autocad', 'AutoCAD gris')}
      ${btn('pref:tema:negro', 'AutoCAD negro')}${btn('pref:tema:claro', 'Claro (papel)')}
    </div>
    <div class="btnrow">${btn('pref:reset', 'Restablecer el espacio de trabajo', 'danger')}</div>
    <div class="specs">Tamaño de la cruz: <b>${p.tamanoCruz} %</b> de la ventana (${Math.round(tamanoCruzPx(p.tamanoCruz, 1600, 900))} px de brazo) · mira de selección <b>${p.tamanoMira} px</b> ·
    rejilla cada <b>${p.pasoRejilla} m</b>${p.orto ? ' · ortogonal' : ''}${p.polar ? ` · polar ${p.incrementoPolar}°` : ''}.
    ${problemas.length ? `<br><b class="warn">⚠ ${problemas.length} valor(es) fuera de rango: ${problemas.map((x) => x.etiqueta).join(', ')}</b>` : 'Todos los valores están dentro de rango.'}
    ${avisoCruz.aviso || avisoMira.aviso ? `<br>Sugerencia para este fondo: <code>${colorSugerido(p.fondo)}</code>.` : ''}</div>`)}
  <p class="muted small">Estas preferencias son del usuario y se guardan aparte del proyecto: valen para
  cualquier proyecto que se abra. El plano y sus colores no se ven afectados (§9).</p>`;
}

function fiberPanel(app) {
  const f = fiberSummary(app.prj, app.prj.catalog, app.prj.rules);
  const rules = app.prj.rules;
  const head = card('Fibra óptica (§38)', `
    <p class="muted small">Un enlace va por fibra cuando supera el máximo de UTP o cuando el proyectista lo decide
    (tramos exteriores, aislamiento galvánico, ampliación futura). El módulo elige el tipo de fibra y el transceptor SFP
    y comprueba el <b>presupuesto de potencia óptica</b>: atenuación, conectores, empalmes y margen de diseño.</p>
    <div class="btnrow">${btn('fiber:csv', '⬇ Cuadro de fibra (CSV)')}${btn('fiber:doc', '⬇ Cuadro de fibra (PDF)')}</div>`);
  if (!f.fiberLinks) return head + `<p class="muted">Ningún enlace va por fibra: ${f.mediaMix.copper} enlace(s) de cobre sobre ${num(rules.MAX_UTP, 0)} m.
    Cambie el medio de un enlace en el panel <b>Cableado</b> o coloque una cámara alejada del rack.</p>`;
  const rows = f.links.map((l) => [esc(l.camera), esc(l.switch), num(l.distance, 1), esc(l.typeLabel), `${esc(l.sfpModel)}`,
    num(l.atten, 2), num(l.connectors, 2), num(l.spliceLoss, 2), num(l.totalLoss, 2), num(l.margin, 1),
    num(l.remaining, 2), num(l.pct, 0) + ' %', badge(l.status, sev(l.status))]);
  return head + card('Resumen', `<div class="kpi">
      <div><b>${f.fiberLinks}</b><span>enlaces de fibra</span></div>
      <div><b>${num(f.meters, 0)} m</b><span>de fibra</span></div>
      <div><b>${f.splices}</b><span>empalmes</span></div>
      <div><b>${f.converters}</b><span>conversores</span></div>
      <div><b>${f.status}</b><span>estado</span></div></div>
      <div class="specs">${f.byType.MM} multimodo · ${f.byType.SM + f.byType.LH} monomodo · mezcla de medios ${f.mediaMix.fiber} fibra / ${f.mediaMix.copper} cobre</div>`) +
    card('Presupuesto de potencia', table(['Cámara', 'Switch', 'Dist. m', 'Fibra', 'Transceptor', 'Aten. dB', 'Conect. dB', 'Empal. dB', 'Pérdidas dB', 'Margen', 'Resto dB', 'Uso', 'Estado'], rows)) +
    card('Parámetros (§33)', `
      ${row('Atenuación multimodo (dB/km)', input('rule:set:FIBRA_ATEN_MM', rules.FIBRA_ATEN_MM, 'type="number" step="0.1"'))}
      ${row('Atenuación monomodo (dB/km)', input('rule:set:FIBRA_ATEN_SM', rules.FIBRA_ATEN_SM, 'type="number" step="0.05"'))}
      ${row('Pérdida por conector (dB)', input('rule:set:FIBRA_CONECTOR', rules.FIBRA_CONECTOR, 'type="number" step="0.05"'))}
      ${row('Pérdida por empalme (dB)', input('rule:set:FIBRA_EMPALME', rules.FIBRA_EMPALME, 'type="number" step="0.05"'))}
      ${row('Bobina de fibra (m)', input('rule:set:FIBRA_TRAMO_EMPALME', rules.FIBRA_TRAMO_EMPALME, 'type="number" step="100"'))}
      ${row('Margen de diseño (dB)', input('rule:set:FIBRA_MARGEN', rules.FIBRA_MARGEN, 'type="number" step="0.5"'))}`) +
    card('Transceptores disponibles', table(['Tipo', 'Fibra', 'λ nm', 'Alcance', 'Presupuesto'], Object.values(FIBER_TYPES).map((t) =>
      [esc(t.label), esc(t.id), t.wavelength, `${t.maxDist >= 1000 ? t.maxDist / 1000 + ' km' : t.maxDist + ' m'}`, `${t.txBudget} dB`]), 'tight'));
}

/* ================= Unidades y escala del plano importado (§9, §10) ================= */

/**
 * Panel «Unidades y escala».
 *
 * Resuelve las dos preguntas que deja un plano importado: ¿en qué unidad está dibujado? y, si no se
 * sabe (o se sabe tarde), ¿cómo se corrige después de importado? Se puede elegir la unidad, aplicar
 * un factor a mano o medir una distancia conocida sobre el plano.
 */
function escalaPanel(app) {
  const prj = app.prj;
  const plano = app._plano;
  const prop = app._unidades || null;
  const elegida = app._unidadElegida || (prop ? prop.id : 'm');
  const u = unidadPorId(elegida) || unidadPorId('m');
  const aplicada = app._unidadAplicada || (prj.settings && prj.settings.unidadPlano) || 'm';
  const escala = (prj.meta && prj.meta.escalaPlano) || null;
  const caja = plano ? plano.caja : null;
  const tam = tamanoEnMetros(caja, elegida);
  const factor = app.factorAEscalar ? app.factorAEscalar() : factorEscala(elegida, aplicada || 'm');
  const objetivo = app.objetivoEscala ? app.objetivoEscala() : { nombre: 'nada seleccionado', cuantos: 0 };

  const unidadesOpts = UNIDADES.map((x) => [x.id, `${x.etiqueta} (${x.abbr})`]);

  const aviso = !caja
    ? 'No hay plano importado: importe un DXF o un DWG (Archivo ▸ Importar plano) para poder hablar de unidades.'
    : (prop && prop.origen === 'declarada'
      ? `El fichero <b>declara</b> que está en ${esc(prop.unidad.etiqueta.toLowerCase())}.`
      : (prop ? `El fichero no declara unidad; se deduce: ${esc(prop.motivo)}.` : ''));

  const confianza = prop ? (prop.confianza === 'alta' ? 'ok' : prop.confianza === 'media' ? 'warn' : 'err') : 'info';

  return `
  ${card('Unidad del plano' + (prop ? ` ${badge(prop.origen === 'declarada' ? 'declarada' : 'deducida', sev(confianza))}` : ''),
    `${aviso ? `<div class="specs">${aviso}</div>` : ''}
     ${row('El plano está dibujado en', select('escala:unidad', unidadesOpts, elegida))}
     ${row('Tamaño resultante', `<b>${esc(formatearLongitud(tam.ancho, 'm', 2))} × ${esc(formatearLongitud(tam.alto, 'm', 2))}</b>`)}
     ${row('Factor que se aplicaría', `<code>${esc(formatearEscala(factor))}</code> <span class="muted">(${esc(factor.toFixed(6))} ×)</span>`)}
     <div class="frow">${btn('escala:aplicar', 'Aplicar y dejar el plano en metros', 'primary')} ${btn('escala:referencia', 'Medir una distancia conocida…')}</div>
     <div class="specs">Al aplicar, la geometría se convierte a metros, que es la unidad interna del programa (§10). El plano no se mueve de sitio: se escala sobre su centro.</div>`)}

  ${card('Corrección manual', `
    ${row('Factor directo', `<span class="numctl"><input type="number" step="0.0001" data-act="escala:factor" value="${esc(app._factorManual || 1)}"><span class="unit">×</span></span>`)}
    <div class="frow">${btn('escala:aplicarFactor', 'Aplicar el factor')} ${btn('escala:deshacer', 'Deshacer la última escala')}</div>
    ${row('Se aplica a', `<b>${esc(objetivo.nombre)}</b> <span class="muted">· ${objetivo.cuantos} elemento(s)</span>`)}
    <div class="specs">Un factor de 0,001 sirve para un plano dibujado en milímetros; 0,3048, para uno en pies. Si hay algo seleccionado, la escala se aplica solo a la selección; si no, al plano importado.</div>`)}

  ${card('Historial de la escala', `
    ${escala ? `<div class="specs">Última escala aplicada: <b>${esc(formatearEscala(escala.factor))}</b> · unidad de origen <b>${esc(escala.unidad || '—')}</b> · ${esc(escala.origen || 'manual')} · ${esc(String(escala.cuando).slice(0, 19).replace('T', ' '))}</div>
      ${escala.acumulado ? `<div class="specs">Acumulado desde la importación: <code>${esc(escala.acumulado.toFixed(6))} ×</code></div>` : ''}`
      : '<div class="specs muted">Todavía no se ha aplicado ninguna escala: la geometría está tal cual llegó del fichero.</div>'}
    ${prj.meta && prj.meta.scale && Math.abs(prj.meta.scale - 1) > 1e-9
      ? `<div class="specs warn">⚠ El proyecto guarda una calibración antigua (1 unidad = ${esc(prj.meta.scale.toFixed(4))} m) que <b>no</b> está aplicada a la geometría: se usa solo al exportar (§10). Aplique aquí la escala para que la geometría esté en metros.</div>` : ''}
    ${row('Unidad en la que está la geometría', `<b>${esc(!aplicada ? 'metros (origen desconocido)' : aplicada === 'm' ? 'la del fichero, sin convertir' : `metros (convertida desde ${(unidadPorId(aplicada) || {}).etiqueta || aplicada})`)}</b>`)}`)}
`;
}

/* ================ Obstáculos, muros y alturas (§9, §13) ================ */

/** Fila de la paleta: icono, nombre, altura y descripción de cada elemento. */
function fichaObstaculo(o, activa) {
  return `<button class="obsbtn ${activa ? 'on' : ''}" data-act="obs:${esc(o.id)}" title="${esc(o.descripcion)}">
    <span class="obsico">${esc(o.icono)}</span>
    <span class="obsname">${esc(o.etiqueta)}</span>
    <span class="obsh">${num(o.altura, 1)} m</span>
  </button>`;
}

/**
 * Panel «Obstáculos, muros y alturas».
 *
 * Es la paleta desde la que se dibuja todo lo que ocupa volumen (muros, tabiques, puertas, ventanas,
 * cercas, árboles, personas, mobiliario, techos…) y el sitio desde el que se dice **dónde están los
 * muros del plano importado** y a qué altura llegan, que es lo que permite extruirlo en 3D y afinar
 * la cobertura.
 */
function obstaculosPanel(app) {
  const prj = app.prj;
  const sel = [...(app.cad ? app.cad.selection : [])];
  const entidadesSel = prj.entities.filter((e) => sel.includes(e.id) && esElemento3d(e));
  const detectado = datosDe(entidadesSel[0] || { type: 'obstacle', data: {} });
  const alturaMuro = prj.settings.alturaMuro || ALTURA_MURO;
  const resumen = resumenMuros(prj);

  // Capas del plano importado (o de todo el dibujo) con geometría lineal: candidatas a ser muros
  const cuenta = new Map();
  for (const e of prj.entities) {
    if (e.type === 'text' || e.type === 'image' || e.type === 'camera' || e.type === 'device') continue;
    if (!(e.points || []).length) continue;
    const k = e.layer || 'ARQUITECTURA';
    const c = cuenta.get(k) || { capa: k, n: 0, muros: 0, delPlano: 0 };
    c.n++;
    if (e.data && e.data.muro) c.muros++;
    if (e.data && e.data.planoImportado) c.delPlano++;
    cuenta.set(k, c);
  }
  const capas = [...cuenta.values()].sort((a, b) => b.n - a.n).slice(0, 14);
  const capasMuro = capas.filter((c) => /muro|wall|tabi|pared|parti|awall|muros|murs|cloison/i.test(c.capa));

  // Elementos dibujados, agrupados por tipo
  const porTipo = new Map();
  for (const e of prj.entities) {
    if (!esElemento3d(e)) continue;
    const d = datosDe(e);
    const k = d.kind || (d.muro ? 'muro (marcado)' : 'otro');
    const c = porTipo.get(k) || { kind: k, n: 0, altura: d.altura, etiqueta: d.etiqueta };
    c.n++;
    porTipo.set(k, c);
  }

  return `
  ${card('Dibujar obstáculos',
    gruposDeObstaculos().map((g) =>
      `<div class="obsgrupo"><div class="obstit">${esc(g.grupo)}</div><div class="obsgrid">${
        g.elementos.map((o) => fichaObstaculo(o, app.cad && app.cad.tool === 'obstacle' && app.cad.toolKind === o.id)).join('')
      }</div></div>`).join('') +
    `<div class="specs">Cada elemento se dibuja como se pide en su ayuda (un clic, dos clics o una cadena de vértices). Después se puede cambiar su altura aquí mismo o en la vista 3D.</div>`)}

  ${card('Muros del plano importado' + (resumen.muros ? ` ${badge(resumen.muros + ' marcados', 'ok')}` : ''), `
    ${row('Altura de los muros', `<span class="numctl"><input type="number" step="0.1" min="0.2" max="12" data-act="muro:altura" value="${esc(alturaMuro)}"><span class="unit">m</span></span>`)}
    <div class="frow">${btn('muro:marcar', 'Marcar la selección como muro')} ${btn('muro:desmarcar', 'Quitar la marca')} ${btn('muro:detectar', 'Detectar muros por capa', 'primary')}</div>
    <div class="specs">Marcar la geometría como muro (sin duplicarla) la extruye en la vista 3D y la hace tapar la visión en el análisis de cobertura (§13). ${esc(capasMuro.length ? `Se han detectado ${capasMuro.length} capa(s) con nombre de muro: ${capasMuro.map((c) => c.capa).join(', ')}.` : 'Ninguna capa tiene nombre de muro: márquelas a mano o por selección.')}</div>
    ${capas.length ? `<div class="twrap"><table class="capas"><thead><tr><th>Capa</th><th>Elem.</th><th>Del plano</th><th>Muros</th><th></th></tr></thead><tbody>${
      capas.map((c) => `<tr><td>${esc(c.capa)}</td><td>${c.n}</td><td>${c.delPlano || '—'}</td><td>${c.muros || '—'}</td>
        <td><button class="btn ${c.muros ? 'on' : ''}" data-act="muro:capa:${esc(c.capa)}">${c.muros ? 'Quitar' : 'Son muros'}</button></td></tr>`).join('')
    }</tbody></table></div>` : ''}`)}

  ${entidadesSel.length ? card(`Elemento seleccionado (${entidadesSel.length})`, `
    ${row('Tipo', `<b>${esc(detectado.etiqueta)}</b>`)}
    ${detectado.kind === 'escalera' ? `
      ${row('Tipo de escalera', `<select data-act="obs:tipoEscalera">
        <option value="recta" ${detectado.tipoEscalera === 'recta' ? 'selected' : ''}>Recta (con zancas y barandilla)</option>
        <option value="en_l" ${detectado.tipoEscalera === 'en_l' ? 'selected' : ''}>En L (con descansillo)</option>
        <option value="caracol" ${detectado.tipoEscalera === 'caracol' ? 'selected' : ''}>Caracol / espiral</option>
      </select>`)}
      ${row('Barandilla y pasamanos', `<input type="checkbox" data-act="obs:barandilla" ${detectado.barandilla !== false ? 'checked' : ''}>`)}
      ${row('Peldaños (0 = auto)', `<span class="numctl"><input type="number" step="1" min="0" max="64" data-act="obs:numPeldanos" value="${esc(detectado.numPeldanos || 0)}"><span class="unit">ud</span></span>`)}
    ` : ''}
    ${row('Altura', `<span class="numctl"><input type="number" step="0.05" min="0.05" max="30" data-act="obs:altura" value="${esc(detectado.altura)}"><span class="unit">m</span></span>`)}
    ${row('Empieza a (base)', `<span class="numctl"><input type="number" step="0.05" min="0" max="30" data-act="obs:base" value="${esc(detectado.base)}"><span class="unit">m</span></span>`)}
    ${row('Tapa la visión', `<input type="checkbox" data-act="obs:opaco" ${detectado.opaco ? 'checked' : ''}>`)}
    <div class="specs">Una ventana va de 0,9 a 2,3 m (base 0,9 y altura 1,4): tapa lo que pasa por esa franja y deja ver el resto. Una mesa de 0,8 m no tapa a una persona de pie.</div>`) : ''}

  ${card('Lo que hay en el proyecto', porTipo.size
    ? table(['Elemento', 'Cantidad', 'Altura'], [...porTipo.values()].map((c) => [esc(c.etiqueta), String(c.n), `${num(c.altura, 2)} m`]))
      + `<div class="specs">Referencia: una persona mide ${num(ALTURA_PERSONA, 2)} m y la visión se comprueba a ${num(ALTURA_OBJETIVO, 2)} m del suelo (§13).</div>`
    : '<div class="specs muted">Todavía no hay obstáculos ni muros marcados. Dibújelos con la paleta de arriba o marque las líneas del plano importado.</div>')}

  ${card('Vista 3D', `
    <div class="frow">${btn('ver:3d', app.cad && app.cad.modo3d ? 'Volver a la planta (2D)' : 'Abrir la vista 3D', 'primary')} ${btn('panel:tresd', 'Opciones de la vista 3D')}</div>
    <div class="specs">La vista 3D extruye los muros y los obstáculos con su altura real y muestra el haz de cada cámara desde su altura de montaje hasta el suelo.</div>`)}
`;
}

/* ============================ Vista 3D (§8) ============================ */

/** Panel «Vista 3D»: orientación, qué se ve y con qué transparencia. */
function tresdPanel(app) {
  const cad = app.cad;
  if (!cad) return card('Vista 3D', '<div class="specs">Todavía no hay lienzo.</div>');
  const cam = cad.cam3d;
  const o = cad.opciones3d;
  const vistas = VISTAS.map((v) => `<button class="btn ${Math.abs(cam.azimut - v.azimut) < 1 && Math.abs(cam.elevacion - v.elevacion) < 1 ? 'on' : ''}" data-act="3d:vista:${esc(v.id)}">${esc(v.etiqueta)}</button>`).join(' ');
  const deslizador = (act, valor, min, max, paso, unidad, etiqueta) =>
    row(etiqueta, `<span class="numctl"><input type="range" min="${min}" max="${max}" step="${paso}" data-act="${act}" value="${esc(valor)}">` +
      `<input type="number" min="${min}" max="${max}" step="${paso}" data-act="${act}" value="${esc(Math.round(valor))}"><span class="unit">${unidad}</span></span>`);

  return `
  ${card('Vista 3D' + (cad.modo3d ? ` ${badge('activa', 'ok')}` : ''), `
    <div class="frow">${btn('ver:3d', cad.modo3d ? 'Volver a la planta (2D)' : 'Abrir la vista 3D', 'primary')} ${btn('3d:encuadrar', 'Encuadrar el proyecto')}</div>
    <div class="specs">Arrastre con el botón izquierdo para girar, con el central (o Mayús) para desplazar el punto de vista y la rueda para acercar. Un clic sin arrastrar selecciona el elemento que hay debajo.</div>
    <div class="frow vistas">${vistas}</div>`)}

  ${card('Orientación', `
    ${deslizador('3d:azimut', cam.azimut, 0, 359, 1, '°', 'Azimut')}
    ${deslizador('3d:elevacion', cam.elevacion, 2, 89, 1, '°', 'Elevación')}
    ${deslizador('3d:distancia', cam.distancia, 3, 500, 1, 'm', 'Distancia')}`)}

  ${card('Qué se ve', `
    ${row('Retícula del suelo', `<input type="checkbox" data-act="3d:rejilla" ${o.rejilla ? 'checked' : ''}>`)}
    ${row('Haces de las cámaras', `<input type="checkbox" data-act="3d:haces" ${o.mostrarHaz ? 'checked' : ''}>`)}
    ${row('Plano a la altura de una persona', `<input type="checkbox" data-act="3d:persona" ${o.mostrarPersona ? 'checked' : ''}>`)}
    ${row('Regla de alturas', `<input type="checkbox" data-act="3d:regla" ${o.referenciaAltura ? 'checked' : ''}>`)}
    ${row('Sombras en el suelo', `<input type="checkbox" data-act="3d:sombras" ${o.sombras ? 'checked' : ''}>`)}
    ${row('Niebla de profundidad', `<input type="checkbox" data-act="3d:niebla" ${o.niebla ? 'checked' : ''}>`)}
    ${row('Rótulos de distancia', `<input type="checkbox" data-act="3d:rotulos" ${o.rotulosSuelo ? 'checked' : ''}>`)}
    ${row('Ocultar techos y cubiertas', `<input type="checkbox" data-act="3d:techos" ${o.ocultarTechos ? 'checked' : ''}>`)}
    ${row('Suelo con degradado', `<input type="checkbox" data-act="3d:suelo" ${o.suelo ? 'checked' : ''}>`)}
    ${row('Degradado por altura', `<input type="checkbox" data-act="3d:degradado" ${o.degradado ? 'checked' : ''}>`)}
    ${row('Materiales (cristal, rejas)', `<input type="checkbox" data-act="3d:materiales" ${o.materiales ? 'checked' : ''}>`)}
    ${row('Penumbra en las sombras', `<input type="checkbox" data-act="3d:penumbra" ${o.penumbra ? 'checked' : ''}>`)}
    ${row('Sombra de contacto', `<input type="checkbox" data-act="3d:contacto" ${o.contactos ? 'checked' : ''}>`)}
    ${row('Rótulo de cada cámara', `<input type="checkbox" data-act="3d:rotuloscam" ${o.rotulosCamaras ? 'checked' : ''}>`)}
    ${row('Flecha de norte', `<input type="checkbox" data-act="3d:norte" ${o.norte ? 'checked' : ''}>`)}
    ${row('Cielo con degradado', `<input type="checkbox" data-act="3d:cielo" ${o.cielo ? 'checked' : ''}>`)}
    ${row('Juntas de fábrica', `<input type="checkbox" data-act="3d:juntas" ${o.juntas ? 'checked' : ''}>`)}
    ${row('Escala gráfica', `<input type="checkbox" data-act="3d:escala" ${o.escalaGrafica ? 'checked' : ''}>`)}
    ${row('Nombres de estancia', `<input type="checkbox" data-act="3d:estancias" ${o.nombresEstancias ? 'checked' : ''}>`)}
    ${row('Haz con degradado', `<input type="checkbox" data-act="3d:degradadohaz" ${o.degradadoHaz ? 'checked' : ''}>`)}
    ${row('Haz atenuado con la distancia', `<input type="checkbox" data-act="3d:atenuarhaz" ${o.atenuarHaz ? 'checked' : ''}>`)}
    ${row('Sombra de los haces en el suelo', `<input type="checkbox" data-act="3d:sombrahaz" ${o.sombraHaz ? 'checked' : ''}>`)}
    ${row('Soporte y plomada de la cámara', `<input type="checkbox" data-act="3d:soporte" ${o.soporteCamara ? 'checked' : ''}>`)}
    ${row('Zócalo y coronación de los muros', `<input type="checkbox" data-act="3d:zocalo" ${o.zocalo ? 'checked' : ''}>`)}
    ${row('Cámaras con su forma real', `<input type="checkbox" data-act="3d:formascamara" ${o.formasCamara ? 'checked' : ''}>`)}
    ${row('Aristas marcadas', `<input type="checkbox" data-act="3d:aristas" ${o.aristas ? 'checked' : ''}>`)}
    ${deslizador('3d:opacidad', Math.round(o.opacidadMuros * 100), 15, 100, 5, '%', 'Opacidad de los muros')}
    <div class="specs">Bajar la opacidad de los muros permite ver las cámaras y sus haces a través de ellos, como una maqueta de cristal.</div>`)}

  ${card('Ver desde una cámara', `
    <div class="frow">${btn('3d:desdecamara', 'Ver desde la cámara', 'primary')} ${btn('3d:orbital', 'Volver a la vista orbital')}</div>
    <div class="frow">${btn('mon:ver', '📺 Ver en el monitor')}</div>
    <div class="specs">Pone el ojo en la posición de montaje de la cámara y mira con su azimut, su inclinación y el campo visual de su lente. Es la forma de comprobar de verdad qué va a ver. Arrastre para mirar alrededor, rueda para el zoom óptico y Esc para volver.
      ${(() => {
        const sel = cad.selected().filter((e) => e.type === 'camera');
        return sel.length ? `<br><b>Seleccionada:</b> ${esc(sel.map((c) => (c.data || {}).name || c.id).join(', '))}` : '<br><i>Se usa la primera cámara del proyecto si no hay ninguna seleccionada.</i>';
      })()}</div>`)}

  ${card('Cómo interpretarlo', `
    <div class="specs">
      · El <b>haz</b> baja desde la altura de montaje de la cámara hasta su huella en el suelo: si tropieza con algo antes de llegar, ahí hay una sombra.<br>
      · La línea de puntos es la <b>línea de visión</b> al centro de la huella; la regla de la esquina da las alturas.<br>
      · Un muro de 2,8 m tapa por completo a una cámara montada a 2,8 m: para ver por encima hay que subir la cámara o buscar otro sitio.<br>
      · Lo que se ve en 3D es lo mismo que se tiene en cuenta al analizar la cobertura: los obstáculos cortan el rayo solo entre su base y su altura (§13).<br>
      · El cuerpo de cada cámara está <b>girado según su azimut</b> y lleva el objetivo por delante: se ve hacia dónde apunta sin mirar el dibujo.<br>
      · Las <b>sombras</b> siguen una luz fija cenital-inclinada: son una pista de altura, no un cálculo de iluminación real.
      · <b>Ocultar techos</b> quita cubiertas y falsos techos para poder ver las cámaras de dentro del edificio.<br>
      · La <b>sombra de contacto</b> es la mancha oscura donde cada cosa apoya en el suelo: sin ella los objetos parecen flotar.<br>
      · Las <b>aristas</b> se dibujan con cada cara, así que el algoritmo del pintor tapa las de lo que queda detrás.<br>
      · El <b>degradado por altura</b> oscurece la base de cada cara: es la oclusión ambiental más barata que hay.<br>
      · Los <b>materiales</b> pintan el cristal translúcido con dos brillos y las rejas con barrotes.<br>
      · La <b>penumbra</b> añade un halo más ancho y más flojo bajo cada sombra, para que el borde no parezca recortado.<br>
      · Las <b>juntas de fábrica</b> marcan las hiladas cada 45 cm: se calculan en 3D, así que la perspectiva las junta hacia el fondo.<br>
      · El <b>cielo con degradado</b> y la <b>retícula que se desvanece</b> quitan el corte del fondo; la <b>escala gráfica</b> dice a cuántos metros se mira.<br>
      · El <b>haz atenuado</b> se reparte en bandas que se apagan con la distancia, como un cono de luz, y con <b>haz con degradado</b> se funde de golpe en lugar de ir a bandas; la <b>sombra de los haces</b> los apoya en el suelo.<br>
      · El <b>soporte</b> se dibuja según cómo esté montada la cámara: escuadra en pared, tubo en techo o mástil hasta el suelo en poste. La <b>plomada</b> dice dónde cae.<br>
      · Con <b>cámaras con su forma real</b> cada una se dibuja como es: domo, bala, PTZ, turrón, ojo de pez, multisensor…, y con las medidas del catálogo si el fabricante las publica.<br>
      · El <b>zócalo</b> oscurece la base del muro y la <b>coronación</b> perfila su remate.
    </div>`)}
`;
}

/* ------------------------------ monitor de cámara (§8, §13, §15) ------------------------------ */

/**
 * Hacia dónde habría que girar la cámara en horizontal para que el elemento entre en cuadro.
 * La mira de la cámara es (sen azimut, cos azimut), así que el ángulo se mide con el eje Y
 * como referencia y girar «a más azimut» es girar a la derecha en el plano de planta.
 */
function giroNecesario(d, vista) {
  if (!vista || !d.centro) return '';
  const a = ((Number(vista.azimut) || 0) * Math.PI) / 180;
  const b = Math.atan2(d.centro.x - vista.posicion.x, d.centro.y - vista.posicion.y);
  let dif = b - a;
  while (dif > Math.PI) dif -= Math.PI * 2;
  while (dif < -Math.PI) dif += Math.PI * 2;
  const grados = Math.round((Math.abs(dif) * 180) / Math.PI);
  if (grados < 2) return 'la cámara ya apunta ahí: es la altura o el campo lo que falla';
  return `para verlo habría que girar ${grados}° hacia ${dif > 0 ? 'la derecha' : 'la izquierda'}`;
}

/**
 * Monitor: la pantalla del grabador simulada con la escena del propio proyecto. Se pinta desde
 * el ojo de la cámara, con el campo de su lente y la proporción de su sensor, y se mantiene en
 * marcha con una persona y un vehículo circulando a su velocidad real (§15).
 */
function monitorPanel(app) {
  const m = app.monitor;
  const op = m.op;
  const cams = (app.prj.entities || []).filter((e) => e.type === 'camera');
  const cam = m.camara();
  const vista = cam ? vistaDe(cam, app.prj.catalog, app.prj.rules || {}) : null;
  // La proporción del lienzo es la del sensor: solo así el campo horizontal de la imagen es el
  // real de la lente. Si se pusiera la de la ventana, la imagen saldría estirada y engañaría.
  const aspecto = vista && vista.aspecto > 0.5 && vista.aspecto < 4 ? vista.aspecto : 16 / 9;
  const alto = Math.round(640 / aspecto);
  const st = m.estado || {};
  const cerca = st.medida && st.medida.cercano;

  const lineas = [];
  if (vista) {
    lineas.push(`<b>Óptica:</b> ${num(vista.focal)} mm · campo ${Math.round(vista.hfov)}° × ${Math.round(vista.vfov)}°`
      + ` · ${vista.resW} × ${vista.resH}`);
    lineas.push(`<b>Alcance:</b> de ${num(vista.cerca)} a ${num(vista.lejos)} m`
      + ` · montada a ${num(vista.altura)} m · ${Math.round(vista.azimut)}° / ${Math.round(vista.inclinacion)}°`);
    if (vista.modelo) lineas.push(`<b>Equipo:</b> ${esc(vista.marca)} ${esc(vista.modelo)}`);
  }
  for (const a of (st.actores || [])) {
    lineas.push(`<b>${esc(a.etiqueta.replace(' a', ''))} a ${num(a.distancia)} m:</b>`
      + ` ${Math.round(a.densidad.ppm)} px/m · ${esc(a.densidad.etiqueta)}`
      + ` · ${Math.round(a.densidad.altoPx)} px de alto`
      + (a.visible ? '' : a.mascara ? ' · <span class="muted">oculto por una máscara de privacidad</span>'
        : ' · fuera de encuadre'));
  }
  // Máscaras de privacidad: cuántas le tocan a esta cámara y cuántas se ven en su imagen
  const masMon = st.mascaras || [];
  if (masMon.length) {
    const dentro = masMon.filter((m) => m.enCuadre).length;
    lineas.push(`<b>Máscaras de privacidad:</b> ${masMon.length} en esta cámara · ${dentro} dentro del encuadre`
      + (masMon.some((m) => m.cubreTodo)
        ? ' · <span class="warn">tapan la propia cámara: la imagen entera queda oculta</span>' : ''));
  }
  // Inventario: las personas y los vehículos dibujados en el plano, vistos —o no— desde aquí.
  // Si algo se ha quedado fuera, se dice por qué y a qué distancia está, que es justo lo que
  // explica que el monitor parezca vacío.
  const inv = st.inventario;
  if (inv && (inv.vistos.length || inv.fuera.length)) {
    for (const d of inv.vistos) {
      lineas.push(`<b>${d.tipo === 'vehiculo' ? 'Vehículo' : 'Persona'} del plano a ${num(d.distancia)} m:</b>`
        + ` ${Math.round(d.densidad.ppm)} px/m · ${Math.round(d.densidad.altoPx)} px de alto`
        + ` · ${esc(d.densidad.etiqueta)} · <span class="ok">dentro del encuadre</span>`);
    }
    for (const d of inv.fuera) {
      lineas.push(`<b>${d.tipo === 'vehiculo' ? 'Vehículo' : 'Persona'} del plano a ${num(d.distancia)} m:</b>`
        + ` <span class="warn">no sale en la imagen · ${esc(d.motivo)}</span>`
        + ` · ${esc(giroNecesario(d, vista))}`);
    }
  }
  lineas.push(`<b>Fotograma:</b> ${num(m.coste, 1)} ms · ${op.fps} por segundo`
    + ` · ${op.vivo ? 'en marcha' : 'en pausa'}`);

  return `
  ${card('Monitor' + (op.vivo ? ` ${badge('en directo', 'ok')}` : ` ${badge('en pausa', 'warn')}`), `
    <div class="monitor">
      <canvas id="moncanvas" width="640" height="${alto}"></canvas>
      ${op.completo ? `<div class="specs">El monitor está en <b>pantalla completa</b>.</div>` : ''}
    </div>
    <div class="frow">${btn('mon:play', op.vivo ? '⏸ Pausar' : '▶ Reanudar', 'primary')} ${btn('mon:full', '⛶ Pantalla completa')} ${btn('mon:captura', '📷 Captura')}</div>
    <div class="specs">${lineas.join('<br>') || 'Sin cámara en el proyecto.'}</div>
    <div class="btnrow">${btn('ver:3d', 'Ver la escena en 3D')}</div>`)}

  ${card('Qué se está viendo', `
    ${row('Cámara', `<select data-act="mon:cam">${cams.map((c) => `<option value="${esc(c.id)}" ${c === cam ? 'selected' : ''}>${esc((c.data && (c.data.name || c.data.nombre)) || c.id)}</option>`).join('')}</select>`)}
    ${row('Circulando', select('mon:actores', [['ambos', 'Persona y vehículo'], ['persona', 'Solo una persona'], ['vehiculo', 'Solo un vehículo'], ['ninguno', 'Nada: escena quieta']], op.actores))}
    ${row('Fotogramas por segundo', select('mon:fps', [['5', '5'], ['10', '10'], ['15', '15'], ['25', '25']], String(op.fps)))}`)}

  ${card('Aspecto de la imagen', `
    ${row('Rótulos sobre la imagen', `<input type="checkbox" data-act="mon:osd" ${op.osd ? 'checked' : ''}>`)}
    ${row('Ruido y líneas de barrido', `<input type="checkbox" data-act="mon:efecto" ${op.efecto ? 'checked' : ''}>`)}
    ${row('Distorsión óptica de lente', `<input type="checkbox" data-act="mon:distorsion" ${op.distorsion ? 'checked' : ''}>`)}
    ${row('Infrarrojos (noche)', `<input type="checkbox" data-act="mon:ir" ${op.ir ? 'checked' : ''}>`)}
    ${row('Máscaras de privacidad', `<input type="checkbox" data-act="mon:mascaras" ${op.mascaras ? 'checked' : ''}>`)}`)}

  ${card('Cómo interpretarlo', `
    <div class="specs">
      · La imagen tiene el <b>campo real de la lente</b> y la proporción del sensor: lo que cabe
        aquí es exactamente lo que cabrá en la pantalla del grabador.<br>
      · La <b>persona</b> cruza a 1,4 m/s y el <b>vehículo</b> a 30 km/h por el centro de lo que la
        cámara ve, recortado por las sombras: si pasan por donde la cámara no ve, no aparecen.<br>
      · Los <b>px/m</b> son la densidad de píxeles (EN 62676-4): 25 detectar, 63 observar,
        125 reconocer, 250 identificar. El rótulo dice cuál se alcanza a la distancia a la que está.<br>
      · La caja sobre la persona es lo que pintaría una <b>analítica de vídeo</b>, con los píxeles
        de alto que ocupa: por debajo de unos 20 px de alto, ninguna analítica fiable.<br>
      · Las cajas <b>discontinuas</b> son las personas y los vehículos que hay <b>dibujados en el
        plano</b>; las continuas, los que circulan. Si algo del plano no aparece, el monitor lo
        dice debajo de la imagen con la distancia a la que está, el motivo y el giro que haría
        falta: así se distingue «no lo ve» de «hay algo tapándolo».<br>
      · Con <b>infrarrojos</b> se ve como de noche: en blanco y negro y con el centro más iluminado,
        que es como alumbra el propio foco de IR de la cámara.<br>
      · Las <b>máscaras de privacidad</b> dibujadas en el plano salen aquí como las graba el equipo:
        un recuadro negro (o un mosaico, si la máscara es de desenfoque) que tapa lo que haya
        detrás. Es la comprobación de obra: si el recuadro no cubre el portal del vecino, aquí se
        ve antes de subirse a la escalera. Lo que quede debajo no se mide ni se cuenta.<br>
      · Al mover o girar la cámara en el plano, el monitor sigue los cambios al instante.
    </div>`)}
`;
}

/* ---------------------- privacidad y cumplimiento (§28) ---------------------- */

/**
 * Panel de privacidad: lo que se puede medir (qué ve cada cámara de lo que no es suyo) y lo
 * que hay que declarar (responsable, finalidad, funciones). La herramienta mide sobre el plano
 * y traduce el diseño a obligaciones; la valoración jurídica es del responsable.
 */
function privacyPanel(app) {
  const p = app.prj;
  const an = app.results.privacidad || analisisPrivacidad(p, p.catalog, p.rules, app.results);
  const cum = app.results.cumplimiento || evaluarCumplimiento(p, p.catalog, p.rules,
    Object.assign({}, app.results, { privacidad: an }));
  const declarado = (p.settings && p.settings.privacidad) || {};
  const zonas = zonasDe(p), mas = mascarasDe(p);
  const r = an.resumen || {};
  const cams = p.entities.filter((e) => e.type === 'camera');
  const nivelCum = { ok: 'ok', warn: 'warn', error: 'err', info: 'info' }[cum.nivel] || 'info';
  const selZona = app.cad.selected().find((e) => e.type === 'pzona');
  const selMascara = app.cad.selected().find((e) => e.type === 'mascara');

  const resumen = card('Qué ve el sistema de lo que no debe ver', `
    <div class="kpi">
      <div><b>${zonas.length}</b><span>zonas declaradas</span></div>
      <div><b>${mas.length}</b><span>máscaras</span></div>
      <div><b>${num(r.areaPublica || 0)} m²</b><span>vía pública</span></div>
      <div><b>${num(r.areaTerceros || 0)} m²</b><span>terceros</span></div>
      <div><b>${num(r.areaSensible || 0)} m²</b><span>intimidad</span></div>
      <div><b>${num(r.areaEnmascarada || 0)} m²</b><span>ocultos</span></div>
      <div><b>${r.camarasAfectadas || 0}</b><span>cámaras afectadas</span></div>
    </div>
    <div class="valsum ${nivelCum}">${cum.nivel === 'error' ? '⛔' : cum.nivel === 'warn' ? '⚠' : '✅'} ${esc(cum.resumen)}</div>
    <p class="muted small">${esc(cum.aviso)}</p>
    <div class="btnrow">${btn('priv:pdf', '⬇ Anexo de protección de datos (PDF)', 'primary')} ${btn('priv:hojas', '⬇ Hojas de cámara (PDF)')}</div>`);

  const cardZonas = card('Zonas de privacidad', zonas.length
    ? table(['Zona', 'Clase', 'Superficie', 'Vista', '%', 'Oculta', 'Cámaras'],
      an.zonas.map((z) => [`<b>${esc(z.nombre)}</b>`, esc(etiquetaClase(z.clase)), `${num(z.area)} m²`,
        `${num(z.areaVista)} m²`, `${num(z.pct, 0)} %`, `${num(z.areaEnmascarada)} m²`, z.camaras.length]))
    : `<p class="muted">No hay zonas declaradas. Dibuje un recinto con la herramienta «Zona privada» (o marque una zona existente) y
       la herramienta medirá cuánto ve cada cámara de la vía pública, de la finca vecina o de las zonas de intimidad.</p>`);

  const controlesZona = card('Marcar y clasificar', `
    ${row('Clase al marcar', select('priv:clase', CLASES_LISTA.map((c) => [c.id, c.etiqueta]), app._privClase || 'PUBLICA'),
      'Se aplica a la selección: cambia el régimen de la zona y su color en el plano')}
    ${selZona ? row('Nombre de la zona', input('priv:nombre', selZona.data.nombre || '')) : ''}
    ${selZona ? row('Observaciones', input('priv:notas', selZona.data.notas || '')) : ''}
    <div class="btnrow">
      ${btn('tool:pzona', '⛔ Dibujar zona')} ${btn('priv:zona', 'Marcar la selección')} ${btn('priv:quitar', 'Quitar de privacidad')}
    </div>
    <p class="muted small">Una zona de privacidad deja de contar como superficie a cubrir: la vía pública no es un hueco de cobertura,
      es superficie que no se debe grabar.</p>`);

  const cardMascaras = card('Máscaras de privacidad', mas.length
    ? table(['Máscara', 'Cámara', 'Tipo', 'Motivo', 'Superficie'],
      mas.map((m) => [`<b>${esc((m.camara ? (p.entities.find((x) => x.id === m.camara) || { data: {} }).data.label : null) || 'Todas')}</b>`,
        esc((p.entities.find((x) => x.id === m.camara) || { data: {} }).data.label || 'todas las cámaras'),
        esc(m.tipo === 'desenfoque' ? 'Desenfoque' : 'Opaca'), esc(m.motivo || '—'), `${num(m.area)} m²`]))
    : `<p class="muted">Sin máscaras. Una máscara es el recuadro que el equipo no graba: se dibuja sobre el plano, se descuenta de
       la cobertura real y se documenta en la hoja de la cámara.</p>`);

  const controlesMascara = card('Máscara: a qué cámara se aplica', `
    ${row('Cámara', select('priv:mascara:cam', [['', 'Todas las cámaras']].concat(
      cams.map((c) => [c.id, c.data.label || c.id])), selMascara ? (selMascara.data.camara || '') : (app._privCamara || '')))}
    ${selMascara ? row('Motivo', input('priv:mascara:motivo', selMascara.data.motivo || '')) : ''}
    ${selMascara ? row('Tipo', select('priv:mascara:tipo', [['opaca', 'Opaca (no se graba)'], ['desenfoque', 'Desenfoque']], selMascara.data.tipo || 'opaca')) : ''}
    ${selMascara ? row('Alto que tapa (m)', input('priv:mascara:altura', Number(selMascara.data.altura) > 0 ? num(selMascara.data.altura) : '', 'type="number" step="0.1" min="0.2"'),
      'En blanco: la altura de la instalación. Súbalo si hay que tapar una fachada o una ventana') : ''}
    <div class="btnrow">${btn('tool:mascara', '▨ Dibujar máscara')} ${btn('priv:mascara', 'Marcar la selección')}</div>
    ${mas.length ? `<div class="btnrow">${btn('mon:ver', '▶ Ver las máscaras en el monitor')}</div>
    <p class="muted small">En el monitor, cada máscara se ve como la graba el equipo: un recuadro negro sobre la
      imagen de la cámara a la que se ha asignado. Es la comprobación de que está bien puesta.</p>` : ''}`);

  const afectadas = (an.porCamara || []).filter((c) => c.afectada || c.areaEnmascarada > 0);
  const cardCamaras = afectadas.length ? card('Cámaras con zonas ajenas a la vista',
    table(['Cámara', 'Equipo', 'Vía pública', 'Terceros', 'Intimidad', 'Oculto'],
      afectadas.map((c) => [`${badge(c.afectada ? 'revisar' : 'ok', c.afectada ? '⚠' : '✓')} ${esc(c.etiqueta)}`, esc(c.modelo),
        `${num(c.areaPublica)} m²`, `${num(c.areaTerceros)} m²`, `${num(c.areaSensible)} m²`, `${num(c.areaEnmascarada)} m²`])))
    : '';

  const cardCarteles = cum.carteles.length ? card('Carteles informativos (deber de información)',
    table(['Dónde', 'Motivo', 'Texto'], cum.carteles.map((c) => [`<b>${esc(c.donde)}</b>`, esc(c.motivo),
      `<span class="muted small">${esc(c.texto)}</span>`]))) : '';

  const cardRat = card('Responsable y finalidad (registro de actividades)', `
    ${row('Responsable', input('priv:set:responsable', declarado.responsable || p.meta.client || ''), 'Quien decide sobre el tratamiento: aparece en los carteles')}
    ${row('NIF / CIF', input('priv:set:nif', declarado.nif || ''))}
    ${row('Finalidad', input('priv:set:finalidad', declarado.finalidad || 'Seguridad de personas, bienes e instalaciones'))}
    ${row('Dónde ejercer derechos', input('priv:set:contactoDerechos', declarado.contactoDerechos || ''))}
    ${row('Delegado de protección', input('priv:set:dpd', declarado.dpd || ''))}
    ${row('Plazo de conservación', `<b>${p.rules.DIAS_GRABACION} días</b>`, 'Límite general admitido: ' + p.rules.DIAS_MAXIMO_LEGAL + ' días')}`);

  const funciones = card('Funciones del sistema · Reglamento de IA de la UE', `
    ${FUNCIONES_IA.map((f) => `<div class="frow"><label>${esc(f.etiqueta)} <span class="hint" title="${esc(f.ayuda)}">?</span></label>
      <input type="checkbox" data-act="priv:fn:${f.id}" ${declarado[f.id] ? 'checked' : ''}></div>`).join('')}
    ${declarado.facial ? `<div class="frow"><label>Identificación en tiempo real</label>
      <input type="checkbox" data-act="priv:fn:facialTiempoReal" ${declarado.facialTiempoReal ? 'checked' : ''}></div>
      <div class="frow"><label>…en un espacio público accesible</label>
      <input type="checkbox" data-act="priv:fn:facialEspacioPublico" ${declarado.facialEspacioPublico ? 'checked' : ''}></div>` : ''}
    ${table(['Función', 'Nivel', 'Referencia', 'Exigible desde'],
      cum.ia.filas.map((f) => [`${esc(f.funcion)}`, `${badge(f.nivel === 'PROHIBIDO' ? 'err' : f.nivel === 'ALTO' ? 'warn' : 'info', NIVELES_IA[f.nivel].etiqueta)}`,
        esc(f.articulo), `<span class="muted small">${esc(f.desde)}</span>`]))}
    ${cum.ia.filas.filter((f) => f.obligaciones.length).map((f) => `<p class="advice"><b>${esc(f.funcion)}</b>: ${esc(f.obligaciones.join(' · '))}</p>`).join('')}
    <p class="muted small">Calendario: prácticas prohibidas en vigor desde el 2 de febrero de 2025; obligaciones de transparencia
      (art. 50) desde el 2 de agosto de 2026; sistemas de alto riesgo del anexo III desde el 2 de diciembre de 2027,
      según el Reglamento (UE) 2026/1744.</p>`);

  const comprobaciones = card('Comprobaciones de cumplimiento', cum.items.map((i) => `
    <details class="val ${i.estado === 'ok' ? 'ok' : i.estado === 'warn' ? 'warn' : i.estado === 'error' ? 'err' : 'info'}" ${i.estado === 'error' ? 'open' : ''}>
      <summary>${i.estado === 'ok' ? '✅' : i.estado === 'warn' ? '⚠' : i.estado === 'error' ? '⛔' : 'ℹ'} ${esc(i.titulo)}</summary>
      <p>${esc(i.detalle)}</p>
      <p class="advice"><b>Obligación:</b> ${esc(i.obligacion)}</p>
      <p class="muted small"><b>Referencia:</b> ${esc(i.base)}</p>
    </details>`).join(''));

  return resumen + cardZonas + controlesZona + cardMascaras + controlesMascara + cardCamaras + cardCarteles + cardRat + funciones + comprobaciones;
}

/**
 * Panel de Licencia y Activación (§42)
 */
export function renderLicensePanel(app) {
  const lic = app.licencia || { nivel: 'trial', esPro: false, machineId: 'CCTV-EVAL-DEMO', limiteCamaras: 1 };
  const cams = (app.prj.entities || []).filter((e) => e.type === 'camera').length;
  const esPro = lic.esPro;
  const claveSugerida = app.licencia ? app.licencia.clave : '';

  return `
    <div class="panel-section">
      <div class="card ${esPro ? 'ok' : 'warn'}">
        <h3>${esPro ? '🔒 Licencia PRO — Activada' : '⏳ Versión de Evaluación (Trial)'}</h3>
        <p>${esPro
          ? 'Dispone de privilegios profesionales completos sin límite de cámaras, sin marcas de agua y con soporte para proyectos de gran escala.'
          : 'La versión de evaluación permite ubicar y procesar <b>1 cámara</b> completa (cobertura, DORI 3D y monitor). Las cámaras adicionales requieren activación de licencia.'}</p>
        <div class="stat-grid" style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-top:8px;">
          <div><b>Estado:</b> <span class="badge ${esPro ? 'ok' : 'warn'}">${esPro ? 'PRO (Ilimitada)' : 'TRIAL (1 cámara)'}</span></div>
          <div><b>Cámaras en plano:</b> ${cams} / ${esPro ? '∞' : lic.limiteCamaras}</div>
          <div style="grid-column: span 2;"><b>Identificador de equipo (Machine-ID):</b> <code class="mono">${lic.machineId}</code></div>
        </div>
      </div>

      <div class="card" style="margin-top:12px;">
        <h3>🔑 Activación de Privilegios</h3>
        <p style="font-size:0.88em; color:var(--muted);">Introduzca la clave de licencia offline suministrada por el distribuidor para este identificador de equipo.</p>
        <div style="display:flex; flex-direction:column; gap:8px; margin-top:8px;">
          <input type="text" id="licenseKeyInput" class="mono" placeholder="PRO-CCTV-XXXX-XXXX-XXXX" value="${claveSugerida || ''}" style="width:100%; padding:6px; text-transform:uppercase;">
          <div style="display:flex; gap:8px;">
            <button class="btn primary" data-act="lic:activate">✓ Activar Licencia</button>
            ${esPro ? '<button class="btn" data-act="lic:deactivate">✕ Desactivar</button>' : ''}
          </div>
        </div>
      </div>

      <div class="card info" style="margin-top:12px;">
        <h3>📋 Tabla de Privilegios</h3>
        <table style="width:100%; font-size:0.85em; border-collapse:collapse; margin-top:6px;">
          <thead>
            <tr style="text-align:left; border-bottom:1px solid var(--border);">
              <th style="padding:4px;">Funcionalidad</th>
              <th style="padding:4px;">Trial</th>
              <th style="padding:4px;">PRO</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom:1px solid var(--border-light);">
              <td style="padding:4px;">Cámaras en simultáneo</td>
              <td style="padding:4px;"><b>1 cámara</b></td>
              <td style="padding:4px; color:var(--ok);"><b>Ilimitadas</b></td>
            </tr>
            <tr style="border-bottom:1px solid var(--border-light);">
              <td style="padding:4px;">Cálculo Cobertura / DORI</td>
              <td style="padding:4px;">1 cámara</td>
              <td style="padding:4px; color:var(--ok);">Proyecto completo</td>
            </tr>
            <tr style="border-bottom:1px solid var(--border-light);">
              <td style="padding:4px;">Simulación 3D y Monitor</td>
              <td style="padding:4px;">Cámara activa</td>
              <td style="padding:4px; color:var(--ok);">Todas las cámaras</td>
            </tr>
            <tr>
              <td style="padding:4px;">Exportación PDF / DWG</td>
              <td style="padding:4px;">Marca de agua</td>
              <td style="padding:4px; color:var(--ok);">Oficial limpia</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}
