/**
 * CCTV DESIGN PRO — Ayuda contextual offline (CP CCTV §31)
 * Ningún texto de ayuda se descarga: forma parte del programa.
 */
export const HELP = {
  topics: {
    plano: 'Importe un DXF o una imagen de fondo y calibre la escala midiendo una distancia conocida (§10).',
    camaras: 'Seleccione una cámara para modificar su orientación, altura, lente o campo de visión (§12).',
    cobertura: 'La huella de cobertura se recalcula dinámicamente al cambiar altura, inclinación o lente (§13).',
    zonas: 'Dibuje polígonos en la capa Zonas de interés: definen el área sobre la que se mide la cobertura (§14).',
    objetivos: 'Detección 25 ppm · Observación 63 ppm · Reconocimiento 125 ppm · Identificación 250 ppm (§15).',
    rutas: 'El generador evita muros y prioriza las bandejas de la capa Canalizaciones (§16).',
    distancia: 'El enlace supera la distancia configurada. Revise la ruta o agregue un punto de concentración (§18).',
    poe: 'Consumo individual y total frente al presupuesto del switch, con reserva configurable (§20).',
    almacenamiento: 'Bitrate × tiempo × días, con reserva por formateo e índice del sistema de archivos (§21).',
    privacidad: 'Declare las zonas de privacidad (vía pública, terceros, intimidad) y dibuje las máscaras: lo que la cámara no graba no cuenta como cubierto y sale como recuadro negro en el monitor (§28).',
    validacion: 'Revise los errores antes de exportar: el contrato exige validar antes de cerrar el proyecto (§30).',
  },

  /** Devuelve el mensaje de orientación más útil según el estado del proyecto. */
  contextual(prj, results) {
    if (!prj) return '';
    const cams = prj.entities.filter((e) => e.type === 'camera');
    const cables = prj.entities.filter((e) => e.type === 'cable');
    const devs = prj.entities.filter((e) => e.type === 'device');
    const arch = prj.entities.filter((e) => e.layer === 'ARQUITECTURA' && e.type !== 'image');
    if (!arch.length && !prj.entities.some((e) => e.type === 'image'))
      return 'Empiece importando un plano DXF o una imagen de fondo (Archivo → Importar).';
    if (!cams.length) return 'Coloque cámaras sobre el plano con la herramienta Cámara de la barra lateral.';
    if (!results.coverage) return 'Ejecute Cobertura → Analizar para obtener área cubierta, solapes y zonas ciegas.';
    if (!cams.every((c) => c.data.switchId) || !devs.some((d) => d.data.kind === 'switch'))
      return 'Añada un switch y ejecute Red → Asignación automática.';
    if (!cables.length) return 'Ejecute Cableado → Generar rutas para calcular longitudes y canalización.';
    if (results.links && results.links.some((l) => l.status === 'EXCESIVA'))
      return HELP.topics.distancia;
    if (results.poe && results.poe.overall === 'INSUFICIENTE')
      return 'Presupuesto PoE insuficiente: reparta cámaras entre más switches o elija un switch con mayor presupuesto.';
    if (results.storage && !results.storage.enough)
      return 'Almacenamiento insuficiente: aplique los discos recomendados o aumente la retención instalada.';
    if (results.validation && !results.validation.ok)
      return 'Quedan errores por resolver: abra el panel Validación para ver el detalle.';
    if (results.cumplimiento && results.cumplimiento.nivel === 'error')
      return 'El sistema ve vía pública o zonas de intimidad: dibuje una máscara de privacidad o reoriente la cámara (§28).';
    return 'Proyecto coherente. Genere la documentación y exporte el dossier (§28, §29).';
  },
};
