/**
 * CCTV DESIGN PRO — Hojas de cámara y anexo de cumplimiento (§28)
 * app/docsheets.js — páginas del dossier que se dibujan con el escritor PDF propio.
 *
 * Aquí vive lo que convierte el cálculo en un documento que se puede entregar:
 *   · la **hoja de cámara**: una página por equipo con su óptica, sus distancias DORI, su
 *     planta de cobertura dibujada, de dónde se alimenta y qué oculta por privacidad;
 *   · el **anexo de protección de datos**: qué ve cada cámara de lo que no debería ver, las
 *     comprobaciones de cumplimiento, los carteles, el registro de actividades y la
 *     clasificación de la analítica según el Reglamento de IA;
 *   · el **índice** y el **pie de página** del dossier, que se colocan al final porque hasta
 *     que no se ha escrito todo no se sabe cuántas páginas ocupa cada capítulo.
 */
import { PdfDoc } from './io/pdf.js?v=b441e3fc';
import { hojasDeCamaras } from './core/camsheet.js?v=b441e3fc';
import { evaluarCumplimiento, analisisPrivacidad, clasificacionIA, cartelesRequeridos,
  etiquetaClase, NIVELES_IA } from './core/privacy.js?v=b441e3fc';

export { PdfDoc };

const f = (n, d = 1) => (Number.isFinite(Number(n)) ? Number(n).toFixed(d).replace('.', ',') : '—');
const entero = (n) => (Number.isFinite(Number(n)) ? String(Math.round(Number(n))) : '—');

/**
 * Escritor de páginas: mantiene el cursor, envuelve el texto, numera los apartados y
 * dibuja tablas con cabecera. Es el mismo oficio que hacía el dossier a mano, pero en
 * un sitio para poder usarlo desde las hojas y desde el anexo.
 */
export class Escritor {
  constructor(pdf, opts = {}) {
    this.pdf = pdf;
    this.y = opts.y === undefined ? pdf.height - pdf.margin : opts.y;
    this.margen = pdf.margin;
    this.ancho = pdf.contentWidth;
    this.minimo = opts.minimo === undefined ? pdf.margin + 70 : opts.minimo;
    this.entradas = [];
  }
  get pagina() { return this.pdf.pages.length; }

  nuevaPagina() {
    this.pdf.addPage();
    this.y = this.pdf.height - this.pdf.margin;
    return this;
  }
  siCabe(alto) { if (this.y - alto < this.minimo) this.nuevaPagina(); return this; }

  /** Apartado: lo apunta en el índice con la página en la que empieza. */
  titulo(t, size = 13, nivel = 1) {
    this.siCabe(size + 40);
    this.pdf.text(this.margen, this.y, t, size, { bold: true });
    this.y -= size + 6;
    this.entradas.push({ texto: t, pagina: this.pagina, nivel });
    return this;
  }
  parrafo(t, size = 9) {
    const maxW = Math.max(20, Math.floor(this.ancho / (size * 0.5)));
    for (const linea of partirEnLineas(String(t), maxW)) {
      this.siCabe(size + 6);
      this.pdf.text(this.margen, this.y, linea, size);
      this.y -= size + 3;
    }
    this.y -= 4;
    return this;
  }
  /** Párrafo sin sangría y sin salto previo: para remates y notas al pie. */
  nota(t, size = 8) {
    return this.parrafo(t, size);
  }
  tabla(heads, filas, widths, size = 7.5) {
    const total = widths.reduce((a, b) => a + b, 0) || 1;
    const xw = widths.map((w) => (w / total) * this.ancho);
    const fila = (celdas, bold, bg) => {
      this.siCabe(16);
      if (bg) this.pdf.rect(this.margen, this.y - 3, this.ancho, 13, { fill: bg });
      let x = this.margen;
      celdas.forEach((c, i) => {
        this.pdf.text(x + 2, this.y, String(c === undefined || c === null ? '' : c).slice(0, 90), size, { bold });
        x += xw[i];
      });
      this.y -= 12;
    };
    this.siCabe(30);
    this.pdf.line(this.margen, this.y + 8, this.margen + this.ancho, this.y + 8, { width: 0.6 });
    fila(heads, true, '#e8ecef');
    for (const r of filas) fila(r);
    this.pdf.line(this.margen, this.y + 8, this.margen + this.ancho, this.y + 8, { width: 0.6 });
    this.y -= 10;
    return this;
  }
  /** Dos columnas de pares etiqueta/valor, que es como se lee una hoja de equipo. */
  ficha(pares, size = 8) {
    const colW = this.ancho / 2 - 4;
    let col = 0;
    const y0 = () => this.y;
    let yCol = [this.y, this.y];
    for (const [k, v] of pares) {
      const y = Math.min(yCol[0], yCol[1]);
      if (y - size - 6 < this.minimo) { this.nuevaPagina(); yCol = [this.y, this.y]; }
      const c = yCol[0] <= yCol[1] ? 0 : 1;
      const yy = yCol[c];
      this.pdf.text(this.margen + c * (colW + 8), yy, String(k), size, { color: '#555555' });
      this.pdf.text(this.margen + c * (colW + 8) + 96, yy, String(v), size, { bold: true });
      yCol[c] = yy - size - 5;
    }
    this.y = Math.min(yCol[0], yCol[1]) - 4;
    return this;
  }
  linea(color = '#cccccc') {
    this.siCabe(12);
    this.pdf.line(this.margen, this.y, this.margen + this.ancho, this.y, { width: 0.4, color });
    this.y -= 8;
    return this;
  }
}

/** Parte un texto en líneas de un ancho aproximado (la métrica del PDF es la del glifo medio). */
export function partirEnLineas(texto, ancho) {
  const out = [];
  for (const parrafo of String(texto).split('\n')) {
    const palabras = parrafo.split(' ');
    let linea = '';
    for (const w of palabras) {
      if ((linea + ' ' + w).trim().length > ancho) { out.push(linea.trim()); linea = w + ' '; }
      else linea += w + ' ';
    }
    if (linea.trim()) out.push(linea.trim());
  }
  return out.length ? out : [''];
}

/* ---------------------------------------------------------------------------
 * Hoja de cámara: una página por equipo
 * ------------------------------------------------------------------------- */

/**
 * Dibuja la planta de la cámara: su huella sobre el plano, los muros que la recortan,
 * el eje de visión, la escala gráfica y el norte. Es lo que permite montar la cámara
 * sabiendo qué va a ver, sin tener que abrir el plano.
 */
function plantaDeHoja(pdf, hoja, x, y, w, h) {
  const { caja, huellas, origen, azimut, muros } = hoja.planta;
  const anchoM = Math.max(0.5, caja.maxX - caja.minX);
  const altoM = Math.max(0.5, caja.maxY - caja.minY);
  const s = Math.min(w / anchoM, h / altoM);
  // El recuadro se dibuja de `y - h` a `y`: el origen del dibujo es su esquina inferior izquierda
  const ox = x + (w - anchoM * s) / 2;
  const oy = y - h + (h - altoM * s) / 2;
  // Y del mundo hacia arriba, Y del PDF hacia abajo
  const X = (px) => ox + (px - caja.minX) * s;
  const Y = (py) => oy + (altoM - (py - caja.minY)) * s;

  pdf.rect(x, y - h, w, h, { stroke: '#94a3b8', width: 0.5, fill: '#fbfcfd' });

  for (const p of huellas) {
    if (!p || p.length < 3) continue;
    pdf.polyline(p.map((q) => ({ x: X(q.x), y: Y(q.y) })),
      { close: true, fill: '#2f6f4f22', color: '#2f6f4f', width: 0.6 });
  }
  for (const sg of muros) {
    const r = recortarSegmento(sg, caja);
    if (!r) continue;
    pdf.line(X(r.a.x), Y(r.a.y), X(r.b.x), Y(r.b.y), { color: '#475569', width: 0.8 });
  }
  // Eje de visión y cámara
  const cx = X(origen.x), cy = Y(origen.y);
  const largo = Math.min(w, h) * 0.38;
  const a = (Number(azimut) || 0) * Math.PI / 180;
  pdf.line(cx, cy, cx + Math.cos(a) * largo, cy - Math.sin(a) * largo,
    { color: '#c0392b', width: 0.9, dash: [3, 2] });
  pdf.polyline(Array.from({ length: 13 }, (_, i) => {
    const t = (i / 12) * Math.PI * 2;
    return { x: cx + Math.cos(t) * 3.2, y: cy + Math.sin(t) * 3.2 };
  }), { close: true, fill: '#c0392b', color: '#7f1d1d', width: 0.5 });

  // Escala gráfica: un tramo redondo en metros, como en un plano
  const escalaM = redondearEscala(anchoM / 4);
  const px = escalaM * s;
  const sx = x + 8, sy = y - h + 10;
  pdf.line(sx, sy, sx + px, sy, { width: 1.2 });
  pdf.line(sx, sy - 2.5, sx, sy + 2.5, { width: 1.2 });
  pdf.line(sx + px, sy - 2.5, sx + px, sy + 2.5, { width: 1.2 });
  pdf.text(sx, sy - 4, `${f(escalaM, escalaM < 1 ? 1 : 0)} m`, 6, { color: '#475569' });

  // Norte
  const nx = x + w - 12, ny = y - 10;
  pdf.polyline([{ x: nx, y: ny }, { x: nx - 3, y: ny + 8 }, { x: nx, y: ny + 5 }, { x: nx + 3, y: ny + 8 }],
    { close: true, fill: '#334155', color: '#334155', width: 0.4 });
  pdf.text(nx - 2, ny - 1, 'N', 6, { color: '#334155' });

  pdf.text(x + 2, y + 8, `Planta de cobertura de ${hoja.etiqueta} · escala aprox. 1:${Math.round(2834.65 / s)}`, 6.5, { color: '#64748b' });
}

/** Recorta un segmento a la caja del dibujo (Liang–Barsky) para que nada se salga del marco. */
export function recortarSegmento(sg, c) {
  let t0 = 0, t1 = 1;
  const dx = sg.b.x - sg.a.x, dy = sg.b.y - sg.a.y;
  const lados = [[-dx, sg.a.x - c.minX], [dx, c.maxX - sg.a.x], [-dy, sg.a.y - c.minY], [dy, c.maxY - sg.a.y]];
  for (const [pr, q] of lados) {
    if (pr === 0) { if (q < 0) return null; continue; }
    const t = q / pr;
    if (pr < 0) { if (t > t1) return null; if (t > t0) t0 = t; }
    else { if (t < t0) return null; if (t < t1) t1 = t; }
  }
  if (t1 <= t0) return null;
  return { a: { x: sg.a.x + dx * t0, y: sg.a.y + dy * t0 }, b: { x: sg.a.x + dx * t1, y: sg.a.y + dy * t1 } };
}

const redondearEscala = (m) => {
  const pasos = [0.5, 1, 2, 5, 10, 20, 50, 100];
  for (const p of pasos) if (p >= m) return p;
  return 200;
};

/** Hoja completa de una cámara (una por página). */
export function dibujarHojaCamara(pdf, hoja, prj, rules, opts = {}) {
  const esc = new Escritor(pdf, { y: pdf.height - pdf.margin });
  const o = hoja.optica, m = hoja.montaje, c = hoja.cobertura, ins = hoja.instalacion, g = hoja.grabacion;

  // Cabecera
  esc.siCabe(120);
  pdf.rect(pdf.margin, esc.y - 34, pdf.contentWidth, 40, { fill: '#f1f5f9', stroke: '#cbd5e1', width: 0.5 });
  pdf.text(pdf.margin + 8, esc.y - 10, hoja.etiqueta, 14, { bold: true });
  pdf.text(pdf.margin + 8, esc.y - 22, `${hoja.fabricante} ${hoja.modelo}`, 8.5);
  pdf.text(pdf.margin + 8, esc.y - 30, `Ref. ${hoja.referencia} · ${hoja.nombre}`, 7.5, { color: '#475569' });
  pdf.text(pdf.margin + pdf.contentWidth - 8, esc.y - 10, `Cámara ${opts.numero || ''}${opts.total ? ' de ' + opts.total : ''}`, 8,
    { align: 'right', color: '#475569' });
  pdf.text(pdf.margin + pdf.contentWidth - 8, esc.y - 22, prj.meta.name || '', 7.5, { align: 'right', color: '#475569' });
  pdf.text(pdf.margin + pdf.contentWidth - 8, esc.y - 30, `HOJA DE CÁMARA · ${new Date().toLocaleDateString('es-ES')}`, 7,
    { align: 'right', color: '#64748b' });
  esc.y -= 46;

  // Planta a la izquierda, datos a la derecha
  const altoPlanta = 240;
  const anchoPlanta = pdf.contentWidth * 0.46;
  plantaDeHoja(pdf, hoja, pdf.margin, esc.y, anchoPlanta, altoPlanta);

  const xDatos = pdf.margin + anchoPlanta + 14;
  const anchoDatos = pdf.contentWidth - anchoPlanta - 14;
  // Bloque derecho escrito a mano para no mover el cursor del escritor
  let yD = esc.y - 4;
  const par = (k, v, x = xDatos) => {
    pdf.text(x, yD, k, 7.5, { color: '#555555' });
    pdf.text(x + anchoDatos * 0.52, yD, String(v), 7.5, { bold: true });
    yD -= 11;
  };
  const sub = (t) => { pdf.text(xDatos, yD, t, 8, { bold: true, color: '#0f172a' }); yD -= 12; };
  sub('Óptica');
  par('Resolución', `${o.resolucion}${o.mp ? ` (${o.mp} MP)` : ''}`);
  par('Sensor', o.sensor);
  par('Distancia focal', `${f(o.focal, 1)} mm${o.varifocal ? ' (varifocal)' : ''}`);
  par('Focales disponibles', o.focales.length ? o.focales.map((x) => f(x, 1)).join(' · ') : '—');
  par('Campo horizontal', `${f(o.hfov, 1)}°`);
  par('Campo vertical', `${f(o.vfov, 1)}°`);
  par('Infrarrojos', o.ir ? `${o.ir} m` : '—');
  par('Protección', o.proteccion);
  yD -= 4;
  sub('Montaje');
  par('Altura', `${f(m.altura)} m`);
  par('Azimut', `${f(m.azimut, 0)}°`);
  par('Inclinación', `${f(m.inclinacion, 0)}°`);
  par('Soporte', m.soporte);
  par('Objetivo', `${m.objetivoLabel} (${m.ppmExigidos} ppm)`);
  yD -= 4;
  sub('Prestaciones');
  par('WDR', o.wdr ? 'Sí' : 'No');
  par('Formato', o.forma);
  par('Codec / fps', `${g.codec} · ${g.fps} fps`);
  par('Bitrate', `${entero(g.kbps)} kbps`);

  // La columna de datos puede ser más alta que la planta: manda la que llegue más abajo
  esc.y = Math.min(esc.y - altoPlanta, yD) - 10;

  // Alcance por objetivo de vigilancia (EN 62676-4)
  esc.titulo('Alcance por objetivo de vigilancia (EN 62676-4)', 10, 3);
  esc.parrafo('Distancia máxima a la que la cámara cumple cada objetivo con la focal indicada. ' +
    'La distancia de detección no sirve para identificar: para eso hay que estar dentro del alcance de identificación.', 8);
  esc.tabla(['Objetivo de vigilancia', 'ppm exigidos', 'Alcance (m)'],
    [
      ['Detección', 25, f(hoja.dori.DETECCION)],
      ['Observación', 63, f(hoja.dori.OBSERVACION)],
      ['Reconocimiento', 125, f(hoja.dori.RECONOCIMIENTO)],
      ['Identificación', 250, f(hoja.dori.IDENTIFICACION)],
      ['Lectura de matrícula', 130, f(hoja.dori.MATRICULA)],
    ], [40, 25, 35], 7.5);
  esc.nota(`Densidad que entrega esta óptica: ${entero(c.ppmEn ? c.ppmEn(5) : 0)} ppm a 5 m · ` +
    `${entero(c.ppmEn ? c.ppmEn(10) : 0)} ppm a 10 m · ${entero(c.ppmEn ? c.ppmEn(20) : 0)} ppm a 20 m · ` +
    `${entero(c.ppmEn ? c.ppmEn(40) : 0)} ppm a 40 m. El objetivo declarado de la cámara es ` +
    `${m.objetivoLabel} (${m.ppmExigidos} ppm).`, 8);

  esc.titulo('Cobertura e instalación', 10, 3);
  esc.tabla(['Concepto', 'Valor', 'Concepto', 'Valor'], [
    ['Superficie cubierta', c.area === null ? '—' : `${f(c.area)} m²`, 'Switch', ins.etiquetaSwitch],
    ['Huella teórica', c.areaTeorica === null ? '—' : `${f(c.areaTeorica)} m²`, 'Ruta del cable', ins.ruta === null ? '—' : `${f(ins.ruta)} m`],
    ['En sombra por obstáculos', c.sombraPct === null ? '—' : `${f(c.sombraPct, 0)} %`, 'Suministro', ins.suministro === null ? '—' : `${f(ins.suministro)} m`],
    ['Distancia útil', c.efectivaMax ? `${f(c.efectivaMax)} m` : '—', 'Uso del enlace', ins.pctUtp === null ? '—' : `${f(ins.pctUtp, 0)} %`],
    ['Cumple el objetivo', c.cumple === null ? '—' : (c.cumple ? 'Sí' : 'No'), 'Alimentación', ins.poe ? `PoE clase ${ins.clasePoe}` : 'Fuente externa'],
    ['Alcance visual', c.lejos ? `${f(c.cerca)} – ${f(c.lejos)} m` : '—', 'Consumo', `${f(ins.consumo)} W`],
    ['Dirección IP', ins.ip, 'Grabación', g.gbDia === null ? '—' : `${f(g.gbDia, 2)} GB/día`],
    ['Medio de transmisión', ({ copper: 'Cobre (UTP)', fiber: 'Fibra óptica', coax: 'Coaxial', utp: 'Cobre (UTP)' })[ins.medio] || ins.medio, 'Retención', `${g.dias} días`],
  ], [28, 22, 26, 24], 7.5);

  if (hoja.ptz.esPtz) {
    esc.titulo('Posiciones memorizadas (PTZ)', 10, 3);
    esc.tabla(['Posición', 'Azimut (°)', 'Inclinación (°)', 'Focal (mm)', 'Objetivo', 'Permanencia (s)', 'Reparto (%)'],
      hoja.ptz.posiciones.map((p) => [p.nombre, f(p.azimut, 0), f(p.inclinacion, 0), f(p.focal, 1),
        p.objetivo, entero(p.permanencia), p.tiempo === null ? '—' : f(p.tiempo, 0)]),
      [26, 14, 16, 14, 20, 16, 14], 7.5);
    esc.nota(`Ciclo de patrulla completo: ${entero(hoja.ptz.ciclo)} s. Un PTZ solo vigila una posición cada vez: ` +
      'la cobertura media ponderada por el tiempo de permanencia es la cifra representativa.', 7.5);
  }

  const p = hoja.privacidad;
  if (p.areaPublica || p.areaTerceros || p.areaSensible || p.areaEnmascarada) {
    esc.titulo('Privacidad', 10, 3);
    esc.tabla(['Concepto', 'Valor'], [
      ['Vía pública a la vista', `${f(p.areaPublica)} m²`],
      ['Propiedad de terceros a la vista', `${f(p.areaTerceros)} m²`],
      ['Zonas de intimidad a la vista', `${f(p.areaSensible)} m²`],
      ['Superficie oculta con máscaras', `${f(p.areaEnmascarada)} m²`],
      ['Máscaras aplicadas a esta cámara', entero(p.mascaras)],
    ], [55, 45], 7.5);
    esc.nota('Lo que la cámara vea de vía pública o de propiedad de terceros debe limitarse a la franja ' +
      'imprescindible del acceso, preferiblemente con máscara de privacidad configurada en el propio equipo.', 7.5);
  }

  if (m.notas) { esc.titulo('Observaciones', 10, 3); esc.parrafo(m.notas, 8.5); }

  esc.y -= 6;
  pdf.line(pdf.margin, esc.y, pdf.margin + pdf.contentWidth, esc.y, { width: 0.4, color: '#cbd5e1' });
  return esc.y;
}

/** Todas las hojas del proyecto, una cámara por página. */
export function hojasEnPdf(pdf, prj, catalog, rules, res = {}, opts = {}) {
  const { hojas, resumen } = hojasDeCamaras(prj, catalog, rules, res);
  const escritor = new Escritor(pdf, { y: pdf.height - pdf.margin });
  if (!hojas.length) {
    escritor.titulo('Hojas de cámara', 13, 1);
    escritor.parrafo('El proyecto no tiene cámaras que documentar.');
    return { hojas, resumen, entradas: escritor.entradas };
  }
  // Portadilla del capítulo con el resumen del conjunto
  escritor.titulo('Hojas de cámara', 15, 1);
  escritor.parrafo('Una hoja por cámara: cómo se monta, qué alcanza a ver, de dónde se alimenta y qué ' +
    'oculta por privacidad. Las cifras salen del diseño; si cambia la focal, la altura o la orientación, ' +
    'hay que volver a generar el documento.', 9);
  escritor.tabla(['Concepto', 'Valor'], [
    ['Cámaras documentadas', resumen.camaras],
    ['Superficie cubierta en total', `${f(resumen.areaCubierta)} m²`],
    ['Cámaras que alcanzan su objetivo', `${resumen.cumplen} de ${resumen.conObjetivo}`],
    ['Cámaras con máscara de privacidad', resumen.conMascara],
    ['Consumo total en PoE', `${f(resumen.consumo)} W`],
    ['Ancho de banda de vídeo', `${entero(resumen.kbps)} kbps`],
  ], [50, 50], 8);
  escritor.entradas.push({ texto: 'Hojas de cámara', pagina: 1, nivel: 1 });

  const entradas = escritor.entradas.slice();
  hojas.forEach((h, i) => {
    pdf.addPage();
    dibujarHojaCamara(pdf, h, prj, rules, { numero: i + 1, total: hojas.length });
  });
  entradas.push({ texto: `Hojas individuales (${hojas.length})`, pagina: 2, nivel: 2 });
  return { hojas, resumen, entradas };
}

/* ---------------------------------------------------------------------------
 * Anexo de protección de datos y cumplimiento
 * ------------------------------------------------------------------------- */

/** Anexo completo: qué se ve, qué obliga la norma, carteles, registro y Reglamento de IA. */
export function anexoPrivacidad(pdf, prj, catalog, rules, res = {}) {
  const an = res.privacidad || analisisPrivacidad(prj, catalog, rules, res);
  const cum = evaluarCumplimiento(prj, catalog, rules, Object.assign({}, res, { privacidad: an }));
  const esc = new Escritor(pdf, { y: pdf.height - pdf.margin });
  const r = an.resumen;

  esc.titulo('Anexo · Protección de datos y cumplimiento normativo', 15, 1);
  esc.parrafo('Este anexo documenta el tratamiento de imágenes que implica la instalación: qué ve cada ' +
    'cámara de los espacios que no son propios, cuánto se conserva, cómo se informa a las personas y ' +
    'qué obligaciones lleva aparejada la analítica del sistema. Es una comprobación documental hecha ' +
    'sobre el diseño: no sustituye al asesoramiento jurídico del responsable del tratamiento.', 9);
  esc.tabla(['Resumen', 'Valor'], [
    ['Zonas de privacidad declaradas', an.zonas.length],
    ['Máscaras de privacidad', an.resumen.mascaras],
    ['Vía pública a la vista', `${f(r.areaPublica)} m²`],
    ['Propiedad de terceros a la vista', `${f(r.areaTerceros)} m²`],
    ['Zonas de intimidad a la vista', `${f(r.areaSensible)} m²`],
    ['Superficie oculta con máscaras', `${f(r.areaEnmascarada)} m²`],
    ['Cámaras afectadas', r.camarasAfectadas],
    ['Resultado', cum.resumen],
  ], [50, 50], 8);

  if (an.zonas.length) {
    esc.titulo('A.1 Zonas declaradas y lo que ve cada cámara', 11, 2);
    esc.tabla(['Zona', 'Clase', 'Superficie (m²)', 'Vista (m²)', '% vista', 'Oculta (m²)', 'Cámaras'],
      an.zonas.map((z) => [z.nombre, etiquetaClase(z.clase), f(z.area), f(z.areaVista), f(z.pct, 0),
        f(z.areaEnmascarada), z.camaras.length]),
      [26, 20, 14, 12, 10, 13, 9], 7.5);
  }

  const afectadas = an.porCamara.filter((c) => c.afectada || c.areaEnmascarada > 0);
  if (afectadas.length) {
    esc.titulo('A.2 Detalle por cámara', 11, 2);
    esc.tabla(['Cámara', 'Equipo', 'Vía pública (m²)', 'Terceros (m²)', 'Intimidad (m²)', 'Oculto (m²)', 'Máscaras'],
      afectadas.map((c) => [c.etiqueta, c.modelo, f(c.areaPublica), f(c.areaTerceros), f(c.areaSensible),
        f(c.areaEnmascarada), c.mascaras]),
      [22, 20, 15, 14, 14, 13, 10], 7.5);
  }

  esc.titulo('A.3 Comprobaciones de cumplimiento', 11, 2);
  esc.tabla(['Comprobación', 'Estado', 'Detalle', 'Lo que exige la norma', 'Referencia'],
    cum.items.map((i) => [i.titulo,
      { ok: 'Correcto', warn: 'Revisar', error: 'Incumplimiento', info: 'Información' }[i.estado] || i.estado,
      i.detalle, i.obligacion, i.base]),
    [22, 11, 24, 26, 17], 7);

  if (cum.carteles.length) {
    esc.titulo('A.4 Carteles informativos', 11, 2);
    esc.parrafo('Hay que colocar un cartel visible en cada acceso a zona vigilada. El texto se genera con ' +
      'los datos del proyecto: responsable, finalidad, plazo y dónde ejercer los derechos.', 8.5);
    esc.tabla(['Dónde', 'Motivo', 'Texto del cartel'],
      cum.carteles.map((c) => [c.donde, c.motivo, c.texto]), [16, 22, 62], 7);
  }

  esc.titulo('A.5 Registro de actividades de tratamiento (art. 30 RGPD)', 11, 2);
  const rat = cum.rat;
  esc.tabla(['Campo', 'Contenido'], [
    ['Responsable', rat.responsable || '—'],
    ['NIF / CIF', rat.nif || '—'],
    ['Domicilio', rat.domicilio || '—'],
    ['Delegado de protección de datos', rat.delegado || '—'],
    ['Finalidad', rat.finalidad],
    ['Base jurídica', rat.baseJuridica],
    ['Categorías de datos', rat.categorias],
    ['Colectivos', rat.colectivos],
    ['Destinatarios', rat.destinatarios],
    ['Transferencias internacionales', rat.transferencias],
    ['Plazo de conservación', rat.plazo],
    ['Derechos de las personas', rat.derechos],
  ], [26, 74], 7.5);
  esc.titulo('Medidas de seguridad previstas', 9, 3);
  for (const m of rat.medidas) esc.parrafo('· ' + m, 8);

  esc.titulo('A.6 Reglamento de IA de la UE: clasificación de las funciones', 11, 2);
  esc.parrafo('Clasificación de lo que hace el sistema según el Reglamento (UE) 2024/1689. Las prácticas ' +
    'prohibidas están en vigor desde el 2 de febrero de 2025; las obligaciones de transparencia del ' +
    'artículo 50 desde el 2 de agosto de 2026 y las de los sistemas de alto riesgo del anexo III desde ' +
    'el 2 de diciembre de 2027, conforme al calendario revisado por el Reglamento (UE) 2026/1744.', 8.5);
  esc.tabla(['Función', 'Nivel de riesgo', 'Referencia', 'Exigible desde', 'Obligaciones'],
    cum.ia.filas.map((fila) => [fila.funcion, NIVELES_IA[fila.nivel].etiqueta, fila.articulo, fila.desde,
      fila.obligaciones.join(' · ') || '—']),
    [24, 14, 15, 17, 30], 7);
  if (cum.ia.filas.some((x) => x.detalle)) {
    for (const fila of cum.ia.filas.filter((x) => x.detalle)) {
      esc.parrafo(`${fila.funcion}: ${fila.detalle}`, 8);
    }
  }

  esc.titulo('A.7 Nota de alcance', 10, 2);
  esc.parrafo('Las superficies se miden sobre el plano con una malla de ' + f(an.celda, 2) + ' m y con la ' +
    'misma comprobación de obstáculos que el análisis de cobertura, a la altura del objetivo. La ' +
    'herramienta mide el diseño y señala las obligaciones; la valoración jurídica y la firma de los ' +
    'documentos corresponden al responsable del tratamiento.', 8);
  return { entradas: esc.entradas, cumplimiento: cum, analisis: an };
}

/* ---------------------------------------------------------------------------
 * Índice y pie de página: se colocan cuando ya se sabe cuántas páginas hay
 * ------------------------------------------------------------------------- */

/**
 * Inserta el índice como página `despues + 1` (después de la portada) y numera.
 * Las páginas se apuntan mientras se escribe, así que al insertar hay que desplazar
 * las que vienen detrás: por eso se suma el hueco que ocupa el índice.
 */
export function colocarIndice(pdf, entradas, opts = {}) {
  const despues = opts.despues === undefined ? 0 : opts.despues;
  const ops = [];
  const push = (o) => ops.push(o);
  const x = pdf.margin, w = pdf.contentWidth;
  let y = pdf.height - pdf.margin - 20;
  push({ t: 'text', x, y, s: 'Índice', size: 16, bold: true, color: '#000000', align: 'left' });
  y -= 26;
  push({ t: 'line', x1: x, y1: y + 10, x2: x + w, y2: y + 10, width: 0.8, color: '#333333', dash: null });
  y -= 10;
  for (const e of entradas) {
    if (e.pagina === undefined) continue;
    const pag = e.pagina + (e.pagina > despues ? 1 : 0);
    const sangria = e.nivel >= 3 ? 26 : e.nivel === 2 ? 13 : 0;
    push({ t: 'text', x: x + sangria, y, s: e.texto, size: e.nivel <= 1 ? 10 : 9,
      bold: e.nivel <= 1, color: '#000000', align: 'left' });
    push({ t: 'text', x: x + w, y, s: String(pag), size: 9, bold: false, color: '#333333', align: 'right' });
    y -= 15;
  }
  pdf.pages.splice(despues + 1, 0, ops);
  return ops.length;
}

/** Pie de todas las páginas: nombre del proyecto a la izquierda y «Página n de N» a la derecha. */
export function pieDePagina(pdf, opts = {}) {
  const texto = opts.texto || '';
  const trial = opts.trial || false;
  const total = pdf.pages.length;
  pdf.pages.forEach((pg, i) => {
    if (trial) {
      // Marca de agua Trial en cabecera de página
      pg.push({ t: 'text', x: pdf.width / 2, y: pdf.height - 15, s: '*** VERSIÓN DE EVALUACIÓN (TRIAL) — 1 CÁMARA PROCESADA ***', size: 8, bold: true, color: '#ef4444', align: 'center' });
    }
    const y = pdf.margin - 14;
    pg.push({ t: 'line', x1: pdf.margin, y1: y + 9, x2: pdf.width - pdf.margin, y2: y + 9, width: 0.3, color: '#cbd5e1', dash: null });
    pg.push({ t: 'text', x: pdf.margin, y, s: texto, size: 7, bold: false, color: '#64748b', align: 'left' });
    pg.push({ t: 'text', x: pdf.width - pdf.margin, y, s: `Página ${i + 1} de ${total}`, size: 7, bold: false, color: '#64748b', align: 'right' });
  });
  return total;
}
