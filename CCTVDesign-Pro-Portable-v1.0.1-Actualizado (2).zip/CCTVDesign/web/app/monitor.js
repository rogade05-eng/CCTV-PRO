/**
 * CCTV DESIGN PRO — Monitor de cámara (§8, §13, §15)
 *
 * El visor que simula la pantalla del grabador: pinta **la escena del propio proyecto** desde el ojo
 * de una cámara, con el campo de su lente y la proporción de su sensor, y la mantiene en marcha con
 * una persona y un vehículo circulando por delante a su velocidad real.
 *
 * No hay un motor nuevo: la escena es la de la vista 3D (`construirEscena` + `pintar3d`) con los
 * rótulos de diseño apagados, y lo que se añade son los actores, el reloj y el «aire» de vídeo.
 * Así lo que se ve en el monitor y lo que se calcula en la cobertura son la misma cosa.
 */
import { construirEscena, pintar3d } from './render3d.js?v=b441e3fc';
import { sombraDe, contactoDe, LUZ } from './core/view3d.js?v=b441e3fc';
import { polyArea } from './core/geometry.js?v=b441e3fc';
import {
  opcionesMonitor, vistaDe, recorridoDe, actoresEn, densidadDe, osdDe, distanciaA,
  cajaEnPantalla, visibleEn, inventarioDe, resumenDeInventario, ETIQUETA_ACTOR, VELOCIDAD,
  mascarasEnPantalla, puntoEnMascaras, ALTO_MASCARA,
} from './core/monitor.js?v=b441e3fc';

// El fondo del monitor es algo más claro que el del 3D: con el cielo casi negro la mitad superior
// de la imagen parecía un agujero, y una cámara real expone el cielo (o el techo) mucho más alto.
const FONDO = '#161d29';
const ahoraMs = () => (typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now());

/** Cuadro negro del monitor cuando no hay nada que mostrar: el clásico «SIN SEÑAL». */
function sinSenal(ctx, w, h, texto = 'SIN SEÑAL') {
  ctx.save();
  ctx.fillStyle = '#05070a';
  ctx.fillRect(0, 0, w, h);
  const u = h / 270;
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  for (let i = 0; i < 60; i++) {
    ctx.fillRect(Math.random() * w, Math.random() * h, 2 * u, 1.5 * u);
  }
  ctx.fillStyle = 'rgba(190,205,220,0.75)';
  ctx.font = `600 ${Math.round(15 * u)}px system-ui, "Segoe UI", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(texto, w / 2, h / 2);
  ctx.restore();
}

export class Monitor {
  /**
   * @param {object} app la aplicación (para leer el proyecto y el motor del lienzo)
   * @param {object} opciones ajustes del monitor (`core/monitor.js`)
   */
  constructor(app, opciones = {}) {
    this.app = app;
    this.op = opcionesMonitor(opciones);
    this.t = 0;                 // segundos de simulación: de aquí salen los actores y el reloj
    this._ultimo = 0;           // marca de tiempo del último tick
    this._pintado = 0;          // marca de tiempo del último fotograma pintado
    this._sucio = true;         // hay que repintar aunque esté en pausa
    this._ms = 0;               // coste del último fotograma
    this._estado = null;        // último estado pintado: lo leen el panel y las pruebas
    this._escena = null; this._clave = '';
    this._recorrido = null; this._recClave = '';
    this._teselas = null;       // ruido y líneas, pintados una sola vez
    this._patrones = null;
    this._vinieta = null;
    this._mascaras = [];        // máscaras de privacidad proyectadas en el último fotograma
    this._masClave = '';
    this._mosaico = null;       // lienzo pequeño para el desenfoque de una máscara
  }

  /* ------------------------------------------------------------------ estado */

  fijar(clave, valor) {
    this.op = opcionesMonitor({ ...this.op, [clave]: valor });
    this._sucio = true;
    return this.op;
  }

  alternar(clave) {
    if (clave === 'completo') { this.op.completo = !this.op.completo; this._sucio = true; return this.op.completo; }
    return this.fijar(clave, !this.op[clave]);
  }

  /** El lienzo que toca: el del panel o el de la pantalla completa. */
  lienzo() {
    return document.getElementById(this.op.completo ? 'monfullcanvas' : 'moncanvas');
  }

  activo() {
    return this.app.panel === 'monitor' && !!this.lienzo();
  }

  /** Cámara que se está viendo: la elegida, si no la seleccionada y si no la primera. */
  camara() {
    const cams = (this.app.prj.entities || []).filter((e) => e.type === 'camera');
    if (!cams.length) return null;
    if (this.op.camara) {
      const c = cams.find((x) => x.id === this.op.camara);
      if (c) return c;
    }
    try {
      const sel = this.app.cad.selected().find((e) => e.type === 'camera');
      if (sel) return sel;
    } catch { /* sin selección */ }
    return cams[0];
  }

  /* ------------------------------------------------------------------ escena */

  /**
   * Escena del monitor: la del 3D sin ningún rótulo de diseño (ni retícula, ni haces, ni nombres),
   * que es lo que ve una cámara de verdad. Se recalcula solo cuando cambia el proyecto.
   */
  escena(cam) {
    const app = this.app;
    const clave = [cam.id, app.cad._escena3dKey, (app.prj.entities || []).length].join('|');
    if (this._escena && this._clave === clave) return this._escena;
    this._escena = construirEscena(app.prj, app.prj.catalog, app.prj.rules || {}, {
      desdeCamara: cam.id,          // su propio cuerpo y su haz no se pintan: se está dentro
      mostrarHaz: false,
      soporteCamara: false,
      rotulosCamaras: false,
      nombresEstancias: false,
      sombras: true, contactos: true, penumbra: true,
      formasCamara: true,
      ocultarTechos: app.cad.opciones3d ? app.cad.opciones3d.ocultarTechos : false,
    });
    this._clave = clave;
    return this._escena;
  }

  /**
   * Recorrido de los actores. Se apoya en la huella **recortada por las sombras** si el proyecto
   * tiene la cobertura calculada (§13): por donde la cámara no ve, no circula nadie.
   */
  recorrido(cam, vista) {
    const clave = [cam.id, vista.huella.length, vista.azimut, vista.inclinacion, vista.focal].join('|');
    if (this._recorrido && this._recClave === clave) return this._recorrido;
    let huella = null;
    try {
      const cov = this.app.results && this.app.results.coverage;
      const grupos = cov && ((cov._sombras || {})[cam.id] || (cov._footprints || {})[cam.id]);
      if (grupos && grupos.length) {
        let mejor = null, area = 0;
        for (const g of grupos) {
          for (const p of (g || [])) {
            if (!p || p.length < 3) continue;
            const a = Math.abs(polyArea(p));
            if (a > area) { area = a; mejor = p; }
          }
        }
        huella = mejor;
      }
    } catch { huella = null; }
    this._recorrido = recorridoDe(cam, this.app.prj.catalog, this.app.prj.rules || {}, huella);
    this._recClave = clave;
    return this._recorrido;
  }

  /* ------------------------------------------------------------------- bucle */

  /**
   * Un paso del bucle. Devuelve `true` si ha pintado. El reloj de la simulación avanza con el
   * tiempo real mientras está en marcha, y se detiene al pausar, como una grabación.
   */
  tick(ahora = ahoraMs()) {
    if (!this.activo()) return false;
    const dt = this._ultimo ? Math.min(0.25, Math.max(0, (ahora - this._ultimo) / 1000)) : 0;
    this._ultimo = ahora;
    if (this.op.vivo) this.t += dt;
    const espera = 1000 / Math.max(1, this.op.fps);
    const toca = this._sucio || (this.op.vivo && (ahora - this._pintado) >= espera - 1);
    if (!toca) return false;
    this._pintado = ahora;
    this.pintar();
    this._sucio = false;
    return true;
  }

  /* ----------------------------------------------------------------- pintado */

  pintar() {
    const cv = this.lienzo();
    if (!cv) return null;
    const w = cv.width, h = cv.height;
    if (!w || !h) return null;
    const ctx = cv.getContext('2d');
    const t0 = ahoraMs();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const cam = this.camara();
    if (!cam) {
      sinSenal(ctx, w, h, 'SIN CÁMARA');
      this._estado = { vacio: true, osd: null };
      this._ms = ahoraMs() - t0;
      return this._estado;
    }
    const cams = (this.app.prj.entities || []).filter((e) => e.type === 'camera');
    const idxCam = cams.findIndex((x) => x.id === cam.id);
    if (this.app.licencia && this.app.licencia.esTrial && idxCam >= 1) {
      sinSenal(ctx, w, h, 'BLOQUEADO EN EVALUACIÓN (TRIAL)');
      ctx.save();
      ctx.fillStyle = '#ef4444';
      ctx.font = 'bold 13px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('🔒 La versión Trial solo procesa 1 cámara activa', w / 2, h / 2 + 30);
      ctx.font = '11px system-ui';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Active la licencia PRO para monitorear todas las cámaras', w / 2, h / 2 + 50);
      ctx.restore();
      this._estado = { vacio: true, osd: null, trialBloqueado: true };
      this._ms = ahoraMs() - t0;
      return this._estado;
    }
    const app = this.app;
    const vista = vistaDe(cam, app.prj.catalog, app.prj.rules || {});
    if (this.op.distorsion) {
      vista.cam3d.distorsion = vista.distorsion;
    } else {
      vista.cam3d.distorsion = 0;
    }
    const escena = this.escena(cam);
    const rec = this.recorrido(cam, vista);
    const actores = actoresEn(rec, this.t, this.op);

    // Los actores entran en la escena como un volumen más: con su sombra y su mancha de contacto,
    // que son las dos cosas que los pegan al suelo y dejan claro que se mueven por la escena.
    const caras = escena.caras.slice();
    const sombras = escena.sombras.slice();
    const contactos = escena.contactos.slice();
    for (const a of actores) {
      for (const v of a.volumenes) {
        for (const f of v.caras) caras.push({ ...f, id: 'actor', kind: a.tipo, tipo: v.tipo });
        const s = sombraDe(v, LUZ, 0.36);
        if (s) sombras.push(s);
        for (const c of contactoDe(v, { capasContacto: 2 })) contactos.push(c);
      }
    }

    pintar3d(ctx, { ...escena, caras, sombras, contactos }, vista.cam3d, {
      w, h, fondo: FONDO,
      rejilla: false, rotulosSuelo: false, escalaGrafica: false, norte: false, referenciaAltura: false,
      suelo: true, cielo: true, sombras: true, contactos: true, penumbra: true,
      aristas: true, degradado: true, materiales: true, juntas: true, zocalo: true,
      opacidadMuros: 1, seleccion: [],
      // La niebla se aleja a propósito: la cámara del monitor no tiene la distancia orbital de la
      // vista 3D, y con el rango por defecto la imagen salía lavada desde los 3 m.
      niebla: true, cantidadNiebla: 0.4, nieblaD0: 15, nieblaD1: 90,
      // Una cámara ajusta la imagen; una escena pintada con una luz fija sale más apagada que por
      // vídeo. Aquí la exposición la da el pintor multiplicando la luz de cada cara: un filtro del
      // lienzo (`ctx.filter`) daría el mismo resultado revelando la imagen ya pintada, pero medido
      // en la máquina de pruebas cuesta 2,9 ms de los 5,7 de un fotograma, y no hay GPU (§36).
      luz: 1.16,
    });
    // Máscaras de privacidad: van **sobre** la imagen pintada, como las graba el equipo, y antes
    // del ruido y del viñeteado, porque el equipo las mete en el propio sensor.
    const mascaras = this.op.mascaras ? this.mascarasDe(cam, vista, escena, w, h) : [];
    this.pintarMascaras(ctx, w, h, mascaras);
    const medida = this.medir(vista, actores, w, h, mascaras);
    // Lo que hay dibujado en el proyecto y se ve —o no— desde aquí: es lo que permite saber si las
    // personas que se han puesto en el plano entran en el encuadre o se han quedado fuera.
    const inventario = resumenDeInventario(inventarioDe(escena.volumenes, vista, vista.cam3d, w, h));
    // Quien quede dentro de una máscara no se ve: el equipo no registra lo que hay debajo
    for (const d of inventario.vistos) {
      const c = d.caja;
      if (!c) continue;
      const m = puntoEnMascaras(mascaras, (c.x0 + c.x1) / 2, c.y1);
      if (m) { d.mascara = true; d.mascaraId = m.id; }
    }
    inventario.ocultos = inventario.vistos.filter((d) => d.mascara).length;
    if (this.op.ir) this.infrarrojos(ctx, w, h);
    if (this.op.efecto) this.efectos(ctx, w, h);
    const estado = {
      t: this.t, camara: cam.id, vista, medida, actores: medida.lista, inventario, fps: this.op.fps,
      vivo: this.op.vivo, ir: this.op.ir, ms: 0, mascaras,
      distancia: medida.cercano ? medida.cercano.distancia : 0,
      densidad: medida.cercano ? medida.cercano.densidad : null,
      tipoActor: medida.cercano ? medida.cercano.tipo : '',
    };
    estado.osd = osdDe(vista, estado, new Date());
    if (this.op.osd) this.rotular(ctx, w, h, estado);
    this._ms = ahoraMs() - t0;
    estado.ms = this._ms;
    this._estado = estado;
    return estado;
  }

  /**
   * Mide a quien circula por delante: a qué distancia está, cuántos píxeles ocupa y para qué da.
   * Si pisa una máscara, no cuenta como visto: el equipo no registra lo que hay debajo del negro,
   * y ninguna analítica detecta ahí, así que el monitor tampoco debe medirlo.
   */
  medir(vista, actores, w, h, mascaras = null) {
    const lista = [];
    // La densidad es la del sensor (1920 px de ancho), pero el lienzo del monitor es más pequeño:
    // con esta escala los píxeles que se rotulan son los que se ven dibujados, no los del sensor.
    const escala = w / (vista.resW || w);
    for (const a of actores) {
      const distancia = distanciaA(vista, a.actor);
      const caja = cajaEnPantalla(a.volumenes, vista.cam3d, w, h);
      const visible = visibleEn(caja, w, h);
      const densidad = densidadDe(vista.item, distancia, vista.focal, a.alto, a.tipo);
      // Los pies es lo que dice si está dentro de la mancha negra: la cabeza puede asomar por
      // encima del prisma de la máscara, pero quien pisa lo enmascarado no se está grabando.
      const tapado = caja && mascaras && mascaras.length
        ? puntoEnMascaras(mascaras, (caja.x0 + caja.x1) / 2, caja.y1) : null;
      lista.push({
        tipo: a.tipo, etiqueta: ETIQUETA_ACTOR[a.tipo] || 'Objetivo a', distancia, caja,
        visible: visible && !tapado,
        mascara: !!tapado,
        velocidad: VELOCIDAD[a.tipo] || 0, alto: a.alto, densidad, escala,
        altoPxLienzo: densidad.altoPx * escala,
      });
    }
    // Para el rótulo se elige lo que esté dentro del encuadre y, entre varios, lo más cercano
    let cercano = null;
    for (const d of lista) {
      if (!d.visible) continue;
      if (!cercano || d.distancia < cercano.distancia) cercano = d;
    }
    if (!cercano) for (const d of lista) if (!cercano || d.distancia < cercano.distancia) cercano = d;
    return { lista, cercano };
  }

  /* ---------------------------------------------------------------- máscaras */

  /**
   * Máscaras de privacidad de la cámara que se está viendo, proyectadas sobre su imagen.
   * El cálculo se guarda mientras no cambien ni la cámara ni el recinto: el fotograma se repinta
   * quince veces por segundo, pero la mancha negra solo se recalcula cuando algo se ha movido.
   */
  mascarasDe(cam, vista, escena, w, h) {
    const prj = this.app.prj;
    const alto = (escena && escena.alturaMuro)
      || (prj.settings && prj.settings.alturaMuro) || ALTO_MASCARA;
    const c3 = vista.cam3d;
    const firma = (prj.entities || [])
      .filter((e) => e.type === 'mascara')
      .map((e) => [e.id, (e.points || []).length, e.data.tipo || '', e.data.altura || '',
        e.data.camara || '', (e.points || []).reduce((s, p) => s + p.x * 3.7 + p.y * 1.3, 0).toFixed(3)].join('·'))
      .join(';');
    const clave = [cam.id, w, h, alto, c3.azimut, c3.elevacion, c3.distancia, c3.fov,
      c3.objetivo.x, c3.objetivo.y, c3.objetivo.z, firma].join('|');
    if (this._masClave === clave) return this._mascaras;
    this._masClave = clave;
    this._capa = null;
    this._mascaras = mascarasEnPantalla(prj, cam.id, c3, w, h, alto);
    return this._mascaras;
  }

  /**
   * Pinta las máscaras sobre la escena, como las graba el equipo: la opaca deja un recuadro
   * negro y la de desenfoque un mosaico. El negro no es un filtro ni una capa de la interfaz:
   * es lo que sale del sensor, así que va antes de los infrarrojos y del ruido.
   */
  pintarMascaras(ctx, w, h, mascaras) {
    if (!mascaras || !mascaras.length) return;
    if (mascaras.some((m) => m.cubreTodo)) {
      ctx.save();
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }
    const suaves = mascaras.filter((m) => m.tipo === 'desenfoque' && m.poligonos.length);
    if (suaves.length) this.mosaico(ctx, w, h, suaves);
    const capa = this.capaDeMascaras(w, h, mascaras);
    if (capa) ctx.drawImage(capa, 0, 0);
  }

  /**
   * Capa con el negro de las máscaras opacas y el filo de todas. Se dibuja una vez y se reutiliza
   * en cada fotograma: el recuadro es parte de la imagen, y la imagen cambia, el recuadro no.
   */
  capaDeMascaras(w, h, mascaras) {
    const clave = `${this._masClave}|${w}x${h}`;
    if (this._capa && this._capa.clave === clave) return this._capa.cv;
    const opacas = mascaras.filter((m) => m.poligonos.length && m.tipo !== 'desenfoque');
    if (!opacas.length && !mascaras.length) return null;
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, w); cv.height = Math.max(1, h);
    const c = cv.getContext('2d');
    const trazar = (cc, lista) => {
      cc.beginPath();
      for (const m of lista) {
        for (const p of m.poligonos) {
          if (p.length < 3) continue;
          cc.moveTo(p[0].x, p[0].y);
          for (let i = 1; i < p.length; i++) cc.lineTo(p[i].x, p[i].y);
          cc.closePath();
        }
      }
    };
    if (opacas.length) {
      c.fillStyle = '#000';
      trazar(c, opacas);
      c.fill();
    }
    // El filo se saca por erosion: se pinta la mancha, se le quita la misma mancha movida un
    // píxel en las cuatro direcciones y lo que queda es el contorno. Sin él, un recuadro negro
    // sobre una escena de noche no se distingue; con él, se ve dónde acaba la máscara.
    const filo = document.createElement('canvas');
    filo.width = Math.max(1, w); filo.height = Math.max(1, h);
    const f = filo.getContext('2d');
    const todas = mascaras.filter((m) => m.poligonos.length);
    if (todas.length) {
      f.fillStyle = '#fff';
      trazar(f, todas);
      f.fill();
      f.globalCompositeOperation = 'destination-out';
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        f.save();
        f.translate(d[0], d[1]);
        trazar(f, todas);
        f.fill();
        f.restore();
      }
      f.globalCompositeOperation = 'source-in';
      f.fillStyle = 'rgba(158,180,208,0.5)';
      f.fillRect(0, 0, filo.width, filo.height);
      c.drawImage(filo, 0, 0);
    }
    this._capa = { clave, cv };
    return cv;
  }

  /**
   * Desenfoque: se reduce la imagen a bloques y se vuelve a ampliar, solo dentro de la máscara.
   * Se trabaja únicamente con el rectángulo que ocupan las máscaras, no con la imagen entera: a
   * 15 fotogramas por segundo, reducir todo el lienzo para luego usar cuatro manchas costaba
   * más del doble que reducir solo lo que se va a pixelar.
   */
  mosaico(ctx, w, h, mascaras, bloque = 14) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const m of mascaras) {
      for (const p of m.poligonos) {
        for (const q of p) {
          if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x;
          if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
        }
      }
    }
    if (!isFinite(x0)) return;
    x0 = Math.max(0, Math.floor(x0)); y0 = Math.max(0, Math.floor(y0));
    x1 = Math.min(w, Math.ceil(x1)); y1 = Math.min(h, Math.ceil(y1));
    const aw = Math.max(1, x1 - x0), ah = Math.max(1, y1 - y0);
    const tw = Math.max(1, Math.ceil(aw / bloque)), th = Math.max(1, Math.ceil(ah / bloque));
    if (!this._mosaico) {
      const cv = document.createElement('canvas');
      this._mosaico = { cv, ctx: cv.getContext('2d') };
    }
    const t = this._mosaico;
    if (t.cv.width !== tw || t.cv.height !== th) { t.cv.width = tw; t.cv.height = th; }
    t.ctx.clearRect(0, 0, tw, th);
    t.ctx.drawImage(ctx.canvas, x0, y0, aw, ah, 0, 0, tw, th);
    ctx.save();
    ctx.beginPath();
    for (const m of mascaras) {
      for (const p of m.poligonos) {
        if (p.length < 3) continue;
        ctx.moveTo(p[0].x, p[0].y);
        for (let i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y);
        ctx.closePath();
      }
    }
    ctx.clip();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(t.cv, 0, 0, tw, th, x0, y0, aw, ah);
    ctx.restore();
  }

  /* ----------------------------------------------------------------- efectos */

  /**
   * Visión nocturna por infrarrojos: la imagen se queda en blanco y negro, como la de una cámara
   * cuando conmuta al modo noche. Se hace mezclando con la composición «saturation», que es una
   * operación del propio lienzo: un filtro (`ctx.filter`) haría lo mismo, pero cuesta 2,9 ms por
   * fotograma sin GPU (§36), así que aquí no sale a cuenta.
   */
  infrarrojos(ctx, w, h) {
    ctx.save();
    ctx.globalCompositeOperation = 'saturation';
    ctx.fillStyle = 'hsl(0, 0%, 50%)';
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
    // Ajuste de contraste y tinte característico de sensor CMOS en modo noche monocromo
    ctx.save();
    ctx.globalCompositeOperation = 'multiply';
    ctx.fillStyle = 'rgb(220, 230, 240)';
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
    // Foco iluminador IR frontal de la cámara: haz focalizado y caída radial de luz
    const g = ctx.createRadialGradient(w / 2, h * 0.52, Math.min(w, h) * 0.05, w / 2, h * 0.52, Math.max(w, h) * 0.82);
    g.addColorStop(0, 'rgba(235, 245, 255, 0.22)');
    g.addColorStop(0.35, 'rgba(200, 225, 245, 0.12)');
    g.addColorStop(0.7, 'rgba(15, 20, 30, 0.35)');
    g.addColorStop(1, 'rgba(2, 4, 8, 0.78)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  /** Ruido, líneas de barrido y viñeteado: lo que hace que parezca vídeo y no un dibujo. */
  efectos(ctx, w, h) {
    const tes = this.teselas();
    const pat = this.patrones(ctx);
    if (pat.ruido) {
      ctx.save();
      ctx.globalAlpha = this.op.ir ? 0.09 : 0.045;
      ctx.translate(-Math.floor(Math.random() * tes.ruido.width), -Math.floor(Math.random() * tes.ruido.height));
      ctx.fillStyle = pat.ruido;
      ctx.fillRect(0, 0, w + tes.ruido.width, h + tes.ruido.height);
      ctx.restore();
    }
    if (pat.lineas) {
      ctx.save();
      ctx.globalAlpha = 0.07;
      ctx.fillStyle = pat.lineas;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
    }
    this.vinieta(ctx, w, h, this.op.ir ? 0.42 : 0.18);
  }

  /** Teselas de ruido y de líneas: se pintan una vez y se reutilizan como patrón. */
  teselas() {
    if (this._teselas) return this._teselas;
    const ruido = document.createElement('canvas');
    ruido.width = 64; ruido.height = 64;
    const r = ruido.getContext('2d');
    const img = r.createImageData(64, 64);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 120 + Math.floor(Math.random() * 135);
      img.data[i] = v; img.data[i + 1] = v; img.data[i + 2] = v; img.data[i + 3] = 255;
    }
    r.putImageData(img, 0, 0);
    const lineas = document.createElement('canvas');
    lineas.width = 1; lineas.height = 3;
    const l = lineas.getContext('2d');
    l.fillStyle = 'rgba(0,0,0,0.55)';
    l.fillRect(0, 0, 1, 1);
    this._teselas = { ruido, lineas };
    return this._teselas;
  }

  /** Los patrones dependen del contexto, así que se guardan con él. */
  patrones(ctx) {
    if (this._patrones && this._patrones.ctx === ctx) return this._patrones;
    const tes = this.teselas();
    this._patrones = {
      ctx,
      ruido: ctx.createPattern(tes.ruido, 'repeat'),
      lineas: ctx.createPattern(tes.lineas, 'repeat'),
    };
    return this._patrones;
  }

  /** Viñeteado: la imagen se oscurece hacia las esquinas, como en cualquier óptica. */
  vinieta(ctx, w, h, fuerza = 0.32) {
    if (!this._vinieta || this._vinieta.w !== w || this._vinieta.h !== h || this._vinieta.f !== fuerza) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.72);
      g.addColorStop(0, 'rgba(0,0,0,0)');
      g.addColorStop(1, `rgba(0,0,0,${fuerza})`);
      this._vinieta = { w, h, f: fuerza, g };
    }
    ctx.fillStyle = this._vinieta.g;
    ctx.fillRect(0, 0, w, h);
  }

  /* ------------------------------------------------------------------ rótulos */

  /** Rótulos sobre la imagen: nombre, reloj, REC, óptica y calidad de la imagen (px/m). */
  rotular(ctx, w, h, estado) {
    const u = h / 270;                              // unidad: con ella todo crece igual
    const osd = estado.osd || {};
    const pad = Math.round(9 * u);
    const texto = (t, x, y, o = {}) => {
      const tam = Math.round((o.tam || 11) * u);
      ctx.font = `${o.peso || 600} ${tam}px system-ui, "Segoe UI", Roboto, sans-serif`;
      ctx.textAlign = o.align || 'left';
      ctx.textBaseline = o.base || 'top';
      const m = ctx.measureText(t);
      const x0 = o.align === 'right' ? x - m.width : x;
      if (o.fondo !== false) {
        ctx.fillStyle = 'rgba(4,7,12,0.5)';
        ctx.fillRect(x0 - pad * 0.4, y - pad * 0.25, m.width + pad * 0.8, tam + pad * 0.5);
      }
      ctx.fillStyle = o.color || 'rgba(232,238,245,0.95)';
      ctx.fillText(t, x, y);
    };

    // Cajas de detección: lo que un analítica pintaría, con la distancia y los píxeles de alto
    for (const a of estado.actores || []) {
      if (!a.caja || !a.visible) continue;
      const c = a.caja;
      // Con infrarrojos no hay color ni en la escena ni en los rótulos: se van en blanco, como
      // los dibuja una cámara de verdad cuando conmuta a blanco y negro.
      const color = this.op.ir ? 'rgba(232,240,248,0.92)' : (a.tipo === 'vehiculo' ? 'rgba(160,220,255,0.95)' : 'rgba(170,255,200,0.95)');
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, u * 0.7);
      ctx.strokeRect(c.x0, c.y0, Math.max(2, c.x1 - c.x0), Math.max(2, c.y1 - c.y0));
      const rot = `${a.tipo === 'vehiculo' ? 'VEHÍCULO' : 'PERSONA'} · ${Math.round(a.altoPxLienzo || a.densidad.altoPx)} px`;
      texto(rot, c.x0, Math.max(pad, c.y0 - Math.round(15 * u)), { tam: 9, color });
    }

    // Cajas discontinuas: las personas y los vehículos **dibujados en el plano**. Van en otro
    // color y con la línea partida para que no se confundan con las de los que circulan.
    for (const d of (estado.inventario ? estado.inventario.vistos : [])) {
      if (!d.caja || d.mascara) continue;      // lo que tapa una máscara no se ve, luego no se rotula
      const c = d.caja;
      const color = this.op.ir ? 'rgba(232,240,248,0.8)' : 'rgba(255,193,120,0.92)';
      ctx.save();
      ctx.setLineDash([Math.round(5 * u), Math.round(3 * u)]);
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, u * 0.6);
      ctx.strokeRect(c.x0, c.y0, Math.max(2, c.x1 - c.x0), Math.max(2, c.y1 - c.y0));
      ctx.restore();
      texto(`${d.tipo === 'vehiculo' ? 'VEHÍCULO' : 'PERSONA'} · ${Math.round(d.densidad.altoPx)} px`,
        c.x0, Math.min(h - Math.round(14 * u), c.y1 + Math.round(2 * u)), { tam: 9, color });
    }

    ctx.save();
    texto(osd.nombre || 'CÁMARA', pad, pad, { tam: 12 });
    const arriba = w - pad;
    texto(osd.reloj || '', arriba, pad, { align: 'right', tam: 11 });
    if (osd.rec && osd.punto) {
      // El punto de grabación parpadea: es la señal de que el monitor está en marcha
      const r = Math.max(2, Math.round(3.5 * u));
      ctx.beginPath();
      ctx.arc(arriba - ctx.measureText(osd.reloj || '').width - pad * 1.6, pad + r + Math.round(2 * u), r, 0, Math.PI * 2);
      ctx.fillStyle = '#e8443a';
      ctx.fill();
      texto('REC', arriba - ctx.measureText(osd.reloj || '').width - pad * 2.4, pad,
        { align: 'right', tam: 10, color: '#ff8a80' });
    }
    // Aviso cuando se han dibujado personas o vehículos que esta cámara NO ve: es la manera de
    // que el monitor conteste a «he puesto dos personas y no las veo» en lugar de dejar dudando.
    const inv = estado.inventario;
    if (inv && inv.fuera.length) {
      texto(`${inv.fuera.length} elemento(s) del proyecto fuera de cuadro`, w / 2,
        pad + Math.round(17 * u), { align: 'center', tam: 10, color: '#ffc178' });
    }
    // Quién queda tapado por una máscara de privacidad: el equipo no lo graba, y conviene que se
    // vea que es cosa de la máscara y no de que la cámara esté mal puesta.
    if (inv && inv.ocultos) {
      texto(`${inv.ocultos} elemento(s) ocultos por máscara de privacidad`, w / 2,
        pad + Math.round((inv.fuera.length ? 30 : 17) * u), { align: 'center', tam: 10, color: '#9fb4d0' });
    }
    const abajo = h - pad - Math.round(12 * u);
    texto(osd.izq || '', pad, abajo, { tam: 10, color: 'rgba(205,215,228,0.9)' });
    texto(osd.der || '', w - pad, abajo, { align: 'right', tam: 10, color: 'rgba(205,215,228,0.9)' });
    ctx.restore();
  }

  /* ------------------------------------------------------------------ extras */

  /** Último estado pintado: lo usan el panel (para el texto de debajo) y las pruebas. */
  get estado() { return this._estado; }
  get coste() { return this._ms; }

  /** Captura el fotograma actual como PNG (para pegarlo en un informe). */
  capturar() {
    const cv = this.lienzo();
    if (!cv) return '';
    const nombre = `monitor-${(this._estado && this._estado.camara) || 'cam'}-${Date.now()}.png`;
    try {
      const url = cv.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = url; a.download = nombre;
      document.body.appendChild(a); a.click(); a.remove();
      return nombre;
    } catch { return ''; }
  }
}
