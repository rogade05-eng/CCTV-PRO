import { CATALOGO_DISTRIBUIDOR, CATALOGO_DISTRIBUIDOR_FECHA } from './catalogo-distribuidor.js?v=b441e3fc';

/**
 * CCTV DESIGN PRO — Catálogo de equipos (CP CCTV §24, §25, §27)
 *
 * Los precios incluidos son VALORES DE REFERENCIA de un catálogo de demostración con
 * marcas ficticias. Deben sustituirse por el catálogo real del distribuidor mediante
 * Catálogo → Importar CSV. Ningún cálculo depende de estos valores.
 */

const C = (o) => Object.assign({ unit: 'ud', price: 0, stock: true }, o);

export const CATEGORIES = {
  camera: 'Cámaras', nvr: 'Grabadores NVR', switch: 'Switches', switch_poe: 'Switches PoE',
  router: 'Routers', patchpanel: 'Patch panels', rack: 'Racks', ups: 'UPS', disk: 'Discos de vigilancia',
  cable: 'Cables', connector: 'Conectores', box: 'Cajas y soportes', conduit: 'Canalización',
  fiber: 'Fibra óptica', accessory: 'Accesorios',
};

const cameras = [
  C({ id: 'CAM-2MP-BULLET', category: 'camera', manufacturer: 'ProVision', model: 'PV-B240', name: 'Bullet 2 MP IR 30 m',
    price: 62, specs: { mp: 2, resW: 1920, resH: 1080, sensorW: 6.4, sensorH: 3.6, lens: 2.8, focalOptions: [2.8, 4, 6],
      fps: 25, codec: 'H.265', bitrate: 2048, poe: true, power: 5.5, poeClass: '2', ip: 'IP67', ik: 'IK10', ir: 30, wdr: true, form: 'bullet' } }),
  C({ id: 'CAM-4MP-BULLET', category: 'camera', manufacturer: 'ProVision', model: 'PV-B460', name: 'Bullet 4 MP IR 60 m',
    price: 98, specs: { mp: 4, resW: 2560, resH: 1440, sensorW: 6.4, sensorH: 3.6, lens: 4, focalOptions: [2.8, 4, 6, 8],
      fps: 25, codec: 'H.265', bitrate: 4096, poe: true, power: 8, poeClass: '3', ip: 'IP67', ik: 'IK10', ir: 60, wdr: true, form: 'bullet' } }),
  C({ id: 'CAM-4MP-DOME', category: 'camera', manufacturer: 'ProVision', model: 'PV-D430', name: 'Domo antivandálico 4 MP IR 30 m',
    price: 105, specs: { mp: 4, resW: 2560, resH: 1440, sensorW: 6.4, sensorH: 3.6, lens: 2.8, focalOptions: [2.8, 4, 6],
      fps: 25, codec: 'H.265', bitrate: 4096, poe: true, power: 7, poeClass: '3', ip: 'IP66', ik: 'IK10', ir: 30, wdr: true, form: 'dome' } }),
  C({ id: 'CAM-8MP-BULLET', category: 'camera', manufacturer: 'ProVision', model: 'PV-B880', name: 'Bullet 4K 8 MP IR 80 m',
    price: 210, specs: { mp: 8, resW: 3840, resH: 2160, sensorW: 8.8, sensorH: 4.95, lens: 4, focalOptions: [2.8, 4, 6, 8, 12],
      fps: 20, codec: 'H.265', bitrate: 8192, poe: true, power: 12, poeClass: '4', ip: 'IP67', ik: 'IK10', ir: 80, wdr: true, form: 'bullet',
      analytics: ['linecross', 'intrusion', 'loiter', 'count', 'abandoned'] } }),
  C({ id: 'CAM-4MP-VARIO', category: 'camera', manufacturer: 'ProVision', model: 'PV-V428', name: 'Bullet 4 MP varifocal 2,8–12 mm',
    price: 165, specs: { mp: 4, resW: 2560, resH: 1440, sensorW: 6.4, sensorH: 3.6, lens: 6, focalOptions: [2.8, 4, 6, 8, 12],
      varifocal: true, fps: 25, codec: 'H.265', bitrate: 4096, poe: true, power: 9, poeClass: '3', ip: 'IP67', ik: 'IK10', ir: 50, wdr: true, form: 'bullet',
      analytics: ['linecross', 'intrusion', 'loiter'] } }),
  C({ id: 'CAM-PTZ-4MP', category: 'camera', manufacturer: 'ProVision', model: 'PV-P425', name: 'PTZ 4 MP zoom 25×',
    price: 780, specs: { mp: 4, resW: 2560, resH: 1440, sensorW: 6.4, sensorH: 3.6, lens: 6, focalOptions: [4.8, 6, 12, 30, 60, 120],
      varifocal: true, ptz: true, fps: 25, codec: 'H.265', bitrate: 6144, poe: true, power: 30, poeClass: '4', ip: 'IP66', ik: 'IK10', ir: 150, wdr: true, form: 'ptz',
      analytics: ['linecross', 'intrusion', 'loiter', 'autotrack'],
      panRange: [0, 360], tiltRange: [-15, 90], speedPan: 120, speedTilt: 80, presets: 255 } }),
  C({ id: 'CAM-LPR-4MP', category: 'camera', manufacturer: 'Nexa', model: 'NX-LPR42', name: 'Lector de matrículas 4 MP',
    price: 690, specs: { mp: 4, resW: 2560, resH: 1440, sensorW: 6.4, sensorH: 3.6, lens: 12, focalOptions: [8, 12, 16, 25],
      varifocal: true, lpr: true, fps: 30, codec: 'H.265', bitrate: 4096, poe: true, power: 14, poeClass: '4', ip: 'IP67', ik: 'IK10', ir: 40, wdr: true, form: 'bullet',
      analytics: ['linecross', 'lpr'], lprDistance: [3, 25], plateWidth: 0.52 } }),
  C({ id: 'CAM-FISHEYE-6MP', category: 'camera', manufacturer: 'Nexa', model: 'NX-F636', name: 'Fisheye 360° 6 MP',
    price: 320, specs: { mp: 6, resW: 3072, resH: 2048, sensorW: 7.2, sensorH: 4.8, lens: 1.4, focalOptions: [1.4],
      fisheye: true, fps: 20, codec: 'H.265', bitrate: 8192, poe: true, power: 10, poeClass: '4', ip: 'IP66', ik: 'IK10', ir: 10, wdr: true, form: 'fisheye' } }),
  C({ id: 'CAM-ANAL-2MP', category: 'camera', manufacturer: 'OptiCam', model: 'OC-A210', name: 'Analógica HD 2 MP (coaxial)',
    price: 45, specs: { mp: 2, resW: 1920, resH: 1080, sensorW: 6.4, sensorH: 3.6, lens: 3.6, focalOptions: [2.8, 3.6, 6],
      fps: 25, codec: '-', bitrate: 0, poe: false, power: 4, analog: true, ip: 'IP66', ik: '-', ir: 20, wdr: false, form: 'dome' } }),
];

const rest = [
  C({ id: 'NVR-8', category: 'nvr', manufacturer: 'ProVision', model: 'PV-N0816', name: 'NVR 8 canales · 1 bahía',
    price: 215, specs: { channels: 8, maxMbps: 80, bays: 1, maxDiskTB: 10, poePorts: 0, rackU: 1, power: 15 } }),
  C({ id: 'NVR-16', category: 'nvr', manufacturer: 'ProVision', model: 'PV-N1624', name: 'NVR 16 canales · 2 bahías',
    price: 340, specs: { channels: 16, maxMbps: 160, bays: 2, maxDiskTB: 12, poePorts: 0, rackU: 1, power: 20 } }),
  C({ id: 'NVR-16P', category: 'nvr', manufacturer: 'ProVision', model: 'PV-N1624P', name: 'NVR 16 canales · 16 puertos PoE',
    price: 470, specs: { channels: 16, maxMbps: 160, bays: 2, maxDiskTB: 12, poePorts: 16, poeBudget: 150, rackU: 1, power: 25 } }),
  C({ id: 'NVR-32', category: 'nvr', manufacturer: 'ProVision', model: 'PV-N3248', name: 'NVR 32 canales · 4 bahías',
    price: 690, specs: { channels: 32, maxMbps: 320, bays: 4, maxDiskTB: 14, poePorts: 0, rackU: 2, power: 35 } }),
  C({ id: 'NVR-64', category: 'nvr', manufacturer: 'ProVision', model: 'PV-N6496', name: 'NVR 64 canales · 8 bahías',
    price: 1290, specs: { channels: 64, maxMbps: 640, bays: 8, maxDiskTB: 16, poePorts: 0, rackU: 2, power: 55 } }),

  C({ id: 'SW-8P', category: 'switch_poe', manufacturer: 'Nexa', model: 'NX-SW8P', name: 'Switch PoE 8 puertos · 65 W',
    price: 92, specs: { ports: 8, poePorts: 8, poeBudget: 65, poeStandard: '802.3af', uplink: 1, gbps: 1, rackU: 0.5, power: 10 } }),
  C({ id: 'SW-16P', category: 'switch_poe', manufacturer: 'Nexa', model: 'NX-SW16P', name: 'Switch PoE 16 puertos · 150 W',
    price: 185, specs: { ports: 16, poePorts: 16, poeBudget: 150, poeStandard: '802.3at', uplink: 2, gbps: 1, rackU: 1, power: 15 } }),
  C({ id: 'SW-24P', category: 'switch_poe', manufacturer: 'Nexa', model: 'NX-SW24P', name: 'Switch PoE 24 puertos · 370 W',
    price: 320, specs: { ports: 24, poePorts: 24, poeBudget: 370, poeStandard: '802.3at', uplink: 4, gbps: 1, rackU: 1, power: 22 } }),
  C({ id: 'SW-24P-PRO', category: 'switch_poe', manufacturer: 'Nexa', model: 'NX-SW24PA', name: 'Switch PoE+ 24 puertos gestionable · 400 W',
    price: 545, specs: { ports: 24, poePorts: 24, poeBudget: 400, poeStandard: '802.3at', uplink: 4, gbps: 1, managed: true, rackU: 1, power: 26 } }),
  C({ id: 'SW-8', category: 'switch', manufacturer: 'Nexa', model: 'NX-SW8G', name: 'Switch 8 puertos Gigabit (sin PoE)',
    price: 42, specs: { ports: 8, poePorts: 0, poeBudget: 0, uplink: 1, gbps: 1, rackU: 0.5, power: 6 } }),
  C({ id: 'SW-FIBER', category: 'switch', manufacturer: 'Nexa', model: 'NX-SW8F', name: 'Switch 8 puertos + 2 SFP (agregación)',
    price: 138, specs: { ports: 8, poePorts: 0, poeBudget: 0, sfp: 2, uplink: 2, gbps: 1, rackU: 1, power: 12 } }),

  C({ id: 'RT-GW', category: 'router', manufacturer: 'Nexa', model: 'NX-GW12', name: 'Router / pasarela 1 Gbps',
    price: 88, specs: { ports: 4, gbps: 1, rackU: 1, power: 12 } }),
  C({ id: 'RT-VPN', category: 'router', manufacturer: 'Nexa', model: 'NX-GW30', name: 'Router VPN 4 puertos Gigabit',
    price: 240, specs: { ports: 4, gbps: 1, vpn: true, rackU: 1, power: 18 } }),

  C({ id: 'PP-24', category: 'patchpanel', manufacturer: 'Nexa', model: 'NX-PP24', name: 'Patch panel 24 puertos Cat6 1U',
    price: 34, specs: { ports: 24, rackU: 1, power: 0 } }),
  C({ id: 'PP-12', category: 'patchpanel', manufacturer: 'Nexa', model: 'NX-PP12', name: 'Patch panel 12 puertos Cat6 1U',
    price: 22, specs: { ports: 12, rackU: 1, power: 0 } }),
  C({ id: 'ORG-1U', category: 'accessory', manufacturer: 'Nexa', model: 'NX-ORG1', name: 'Organizador horizontal 1U',
    price: 12, specs: { rackU: 1, power: 0 } }),

  C({ id: 'RACK-42', category: 'rack', manufacturer: 'Nexa', model: 'NX-RK42', name: 'Rack 19" 42U 800×800',
    price: 520, specs: { u: 42, depth: 800, maxLoad: 800 } }),
  C({ id: 'RACK-22', category: 'rack', manufacturer: 'Nexa', model: 'NX-RK22', name: 'Rack 19" 22U mural 600×600',
    price: 260, specs: { u: 22, depth: 600, maxLoad: 60 } }),
  C({ id: 'RACK-12', category: 'rack', manufacturer: 'Nexa', model: 'NX-RK12', name: 'Rack 19" 12U mural 600×450',
    price: 145, specs: { u: 12, depth: 450, maxLoad: 40 } }),
  C({ id: 'RACK-9', category: 'rack', manufacturer: 'Nexa', model: 'NX-RK09', name: 'Rack 19" 9U mural 550×450',
    price: 108, specs: { u: 9, depth: 450, maxLoad: 30 } }),

  C({ id: 'UPS-850', category: 'ups', manufacturer: 'Nexa', model: 'NX-UPS850', name: 'UPS 850 VA · 510 W',
    price: 165, specs: { va: 850, watts: 510, rackU: 2, power: 0 } }),
  C({ id: 'UPS-1500', category: 'ups', manufacturer: 'Nexa', model: 'NX-UPS1500', name: 'UPS 1500 VA · 900 W',
    price: 285, specs: { va: 1500, watts: 900, rackU: 2, power: 0 } }),
  C({ id: 'UPS-3000', category: 'ups', manufacturer: 'Nexa', model: 'NX-UPS3000', name: 'UPS 3000 VA · 2700 W rack',
    price: 690, specs: { va: 3000, watts: 2700, rackU: 3, power: 0 } }),

  C({ id: 'HDD-2TB', category: 'disk', manufacturer: 'VigilStore', model: 'VS-2TB', name: 'HDD vigilancia 2 TB', price: 78, specs: { tb: 2 } }),
  C({ id: 'HDD-4TB', category: 'disk', manufacturer: 'VigilStore', model: 'VS-4TB', name: 'HDD vigilancia 4 TB', price: 112, specs: { tb: 4 } }),
  C({ id: 'HDD-6TB', category: 'disk', manufacturer: 'VigilStore', model: 'VS-6TB', name: 'HDD vigilancia 6 TB', price: 158, specs: { tb: 6 } }),
  C({ id: 'HDD-8TB', category: 'disk', manufacturer: 'VigilStore', model: 'VS-8TB', name: 'HDD vigilancia 8 TB', price: 198, specs: { tb: 8 } }),
  C({ id: 'HDD-10TB', category: 'disk', manufacturer: 'VigilStore', model: 'VS-10TB', name: 'HDD vigilancia 10 TB', price: 245, specs: { tb: 10 } }),

  C({ id: 'CBL-UTP6', category: 'cable', manufacturer: 'Nexa', model: 'NX-U6PVC', name: 'Cable U/UTP Cat6 PVC — bobina 305 m',
    price: 96, unit: 'bobina', specs: { category: 'Cat6', metersPerUnit: 305, shielded: false, maxLink: 90 } }),
  C({ id: 'CBL-UTP6A', category: 'cable', manufacturer: 'Nexa', model: 'NX-U6ALSZH', name: 'Cable U/UTP Cat6A LSZH — bobina 305 m',
    price: 148, unit: 'bobina', specs: { category: 'Cat6A', metersPerUnit: 305, shielded: false, maxLink: 90 } }),
  C({ id: 'CBL-FTP6', category: 'cable', manufacturer: 'Nexa', model: 'NX-F6EXT', name: 'Cable F/UTP Cat6 exterior gel — bobina 305 m',
    price: 132, unit: 'bobina', specs: { category: 'Cat6', metersPerUnit: 305, shielded: true, maxLink: 90 } }),
  C({ id: 'CBL-COAX', category: 'cable', manufacturer: 'Nexa', model: 'NX-RG59P', name: 'Cable coaxial RG59 + alimentación — rollo 305 m',
    price: 88, unit: 'rollo', specs: { metersPerUnit: 305, maxLink: 300 } }),
  C({ id: 'CBL-FO-MM', category: 'fiber', manufacturer: 'Nexa', model: 'NX-OM3-2', name: 'Fibra OM3 multimodo 2 hilos — metro',
    price: 2.4, unit: 'm', specs: { metersPerUnit: 1, maxLink: 550, fiber: 'MM', atten: 3.5 } }),
  C({ id: 'CBL-FO-SM', category: 'fiber', manufacturer: 'Nexa', model: 'NX-OS2-2', name: 'Fibra OS2 monomodo 2 hilos — metro',
    price: 1.9, unit: 'm', specs: { metersPerUnit: 1, maxLink: 10000, fiber: 'SM', atten: 0.35 } }),

  C({ id: 'CON-RJ45', category: 'connector', manufacturer: 'Nexa', model: 'NX-RJ45C6', name: 'Conector RJ45 Cat6 (bolsa 100)',
    price: 24, unit: 'bolsa', specs: { perUnit: 100 } }),
  C({ id: 'CON-KEY', category: 'connector', manufacturer: 'Nexa', model: 'NX-KEY6', name: 'Keystone Cat6', price: 1.6, specs: {} }),
  C({ id: 'ACC-PATCH1', category: 'accessory', manufacturer: 'Nexa', model: 'NX-PC1', name: 'Latiguillo Cat6 1 m', price: 2.2, specs: {} }),
  C({ id: 'ACC-PATCH2', category: 'accessory', manufacturer: 'Nexa', model: 'NX-PC2', name: 'Latiguillo Cat6 2 m', price: 2.8, specs: {} }),
  C({ id: 'ACC-SFP', category: 'fiber', manufacturer: 'Nexa', model: 'NX-SFP-MM', name: 'Transceptor SFP 1 G multimodo 850 nm · 550 m', price: 32, specs: { sfpType: 'MM', maxDist: 550, budget: 7.5 } }),
  C({ id: 'ACC-SFP-SM', category: 'fiber', manufacturer: 'Nexa', model: 'NX-SFP-SM10', name: 'Transceptor SFP 1 G monomodo 1310 nm · 10 km', price: 46, specs: { sfpType: 'SM', maxDist: 10000, budget: 11 } }),
  C({ id: 'ACC-SFP-LH', category: 'fiber', manufacturer: 'Nexa', model: 'NX-SFP-LH40', name: 'Transceptor SFP 1 G monomodo 1550 nm · 40 km', price: 96, specs: { sfpType: 'LH', maxDist: 40000, budget: 20 } }),
  C({ id: 'ACC-MC', category: 'fiber', manufacturer: 'Nexa', model: 'NX-MC1G', name: 'Conversor de medio 1 G RJ45 ↔ SFP', price: 38, specs: {} }),
  C({ id: 'ACC-ODF', category: 'fiber', manufacturer: 'Nexa', model: 'NX-ODF12', name: 'Panel de fibra (ODF) 12 puertos 1U', price: 54, specs: { rackU: 1, ports: 12 } }),
  C({ id: 'ACC-FO-PIG', category: 'fiber', manufacturer: 'Nexa', model: 'NX-PIG-LC', name: 'Latiguillo de fibra LC 2 m', price: 4.6, specs: {} }),
  C({ id: 'ACC-FO-SPL', category: 'fiber', manufacturer: 'Nexa', model: 'NX-SPL-100', name: 'Protector de empalme (bolsa 100)', price: 12, unit: 'bolsa', specs: { perUnit: 100 } }),
  // --- vídeo analógico (§38): HD-TVI / AHD / HD-CVI y CVBS, con su grabador y su alimentación ---
  C({ id: 'CAM-A-1080-BULLET', category: 'camera', manufacturer: 'TecnoVis', model: 'TV-TVI200B', name: 'Bullet HD-TVI 1080p IR 20 m',
    price: 68, specs: { mp: 2, resW: 1920, resH: 1080, sensorW: 4.8, sensorH: 2.7, lens: 3.6, analog: true, analogFormat: 'TVI',
      fps: 25, codec: 'H.265', bitrate: 4096, poe: false, power: 3.6, volts: 12, ir: 20, ip: 'IP66', form: 'bullet',
      maxCoax: 250, maxUtp: 120, note: 'Salida conmutable TVI/AHD/CVI/CVBS por OSD.' } }),
  C({ id: 'CAM-A-1080-DOME', category: 'camera', manufacturer: 'TecnoVis', model: 'TV-TVI200D', name: 'Domo HD-TVI 1080p antivandálico IR 15 m',
    price: 61, specs: { mp: 2, resW: 1920, resH: 1080, sensorW: 4.8, sensorH: 2.7, lens: 2.8, analog: true, analogFormat: 'TVI',
      fps: 25, codec: 'H.265', bitrate: 4096, poe: false, power: 2.4, volts: 12, ir: 15, ip: 'IP67', ik: 'IK10', form: 'dome',
      maxCoax: 250, maxUtp: 120 } }),
  C({ id: 'CAM-A-5MP-VARIFOCAL', category: 'camera', manufacturer: 'TecnoVis', model: 'TV-CVI500V', name: 'Bullet HD-CVI 5 MP varifocal 2,8–12 mm',
    price: 118, specs: { mp: 5, resW: 2560, resH: 1944, sensorW: 5.7, sensorH: 3.2, lens: 6, focalOptions: [2.8, 4, 6, 8, 12],
      varifocal: true, analog: true, analogFormat: 'CVI', fps: 20, codec: 'H.265', bitrate: 6144, poe: false, power: 4.2, volts: 12,
      ir: 40, ip: 'IP67', ik: 'IK10', form: 'bullet', maxCoax: 160, maxUtp: 80 } }),
  C({ id: 'CAM-A-960H', category: 'camera', manufacturer: 'TecnoVis', model: 'TV-CVBS100', name: 'Bullet CVBS 960H IR 25 m (recambio de instalación existente)',
    price: 34, specs: { mp: 0.4, resW: 976, resH: 494, sensorW: 4.9, sensorH: 3.7, lens: 3.6, analog: true, analogFormat: 'CVBS',
      fps: 25, codec: 'H.264', bitrate: 2048, poe: false, power: 2.2, volts: 12, ir: 25, ip: 'IP66', form: 'bullet',
      maxCoax: 300, maxUtp: 250 } }),
  C({ id: 'DVR-8H', category: 'nvr', manufacturer: 'TecnoVis', model: 'TV-DVR8H5', name: 'DVR híbrido 8 canales 5 en 1 (5 MP) · 1 bahía',
    price: 235, specs: { channels: 8, hdChannels: 8, analogFormats: ['CVBS', 'TVI', 'AHD', 'CVI', 'TVI5'], bays: 1, maxMbps: 96,
      rackU: 1, power: 20, ip: true, hybrid: true } }),
  C({ id: 'DVR-16H', category: 'nvr', manufacturer: 'TecnoVis', model: 'TV-DVR16H5', name: 'DVR híbrido 16 canales 5 en 1 (5 MP) · 2 bahías',
    price: 398, specs: { channels: 16, hdChannels: 16, analogFormats: ['CVBS', 'TVI', 'AHD', 'CVI', 'TVI5'], bays: 2, maxMbps: 192,
      rackU: 1, power: 30, ip: true, hybrid: true } }),
  C({ id: 'CBL-RG59', category: 'cable', manufacturer: 'Cables Ibéricos', model: 'CI-RG59-75', name: 'Coaxial RG-59 75 Ω — metro',
    price: 0.55, unit: 'm', specs: { metersPerUnit: 1, ohm: 75, maxLink: 250, analog: true } }),
  C({ id: 'CBL-RG6', category: 'cable', manufacturer: 'Cables Ibéricos', model: 'CI-RG6-75', name: 'Coaxial RG-6 75 Ω — metro',
    price: 0.85, unit: 'm', specs: { metersPerUnit: 1, ohm: 75, maxLink: 340, analog: true } }),
  C({ id: 'ACC-BALUN', category: 'accessory', manufacturer: 'Nexa', model: 'NX-BL2P', name: 'Par de balunes pasivos vídeo/alimentación (UTP)', price: 13.4, unit: 'par', specs: { balun: true } }),
  C({ id: 'ACC-BNC', category: 'connector', manufacturer: 'Nexa', model: 'NX-BNC-C', name: 'Conector BNC a compresión (bolsa de 10)', price: 9.8, unit: 'bolsa', specs: { perUnit: 10 } }),
  C({ id: 'ACC-PSU12', category: 'accessory', manufacturer: 'Nexa', model: 'NX-PS12-5', name: 'Fuente conmutada 12 V 5 A con distribución', price: 27.5, specs: { volts: 12, amps: 5, power12: true } }),
  C({ id: 'ACC-BARRIER', category: 'accessory', manufacturer: 'Nexa', model: 'NX-BAR4', name: 'Barrera de acceso vehicular 4 m con mando', price: 690, specs: {} }),
  C({ id: 'ACC-ANLIC', category: 'accessory', manufacturer: 'Nexa', model: 'NX-AN-LIC', name: 'Licencia de analítica de vídeo por canal', price: 45, unit: 'licencia', specs: {} }),

  C({ id: 'BOX-WALL', category: 'box', manufacturer: 'Nexa', model: 'NX-BW1', name: 'Caja de conexión estanca IP65 pared', price: 6.5, specs: {} }),
  C({ id: 'BOX-POLE', category: 'box', manufacturer: 'Nexa', model: 'NX-BP1', name: 'Caja de conexión para poste IP65', price: 14, specs: {} }),
  C({ id: 'ACC-BRACKET', category: 'box', manufacturer: 'ProVision', model: 'PV-BRK', name: 'Soporte de pared para cámara', price: 9, specs: {} }),
  C({ id: 'ACC-JBOX', category: 'box', manufacturer: 'ProVision', model: 'PV-JB', name: 'Caja de empalme para domo', price: 12, specs: {} }),
  C({ id: 'ACC-PSU', category: 'accessory', manufacturer: 'Nexa', model: 'NX-PSU12', name: 'Fuente de alimentación 12 V 2 A', price: 8.5, specs: {} }),

  C({ id: 'CAN-PVC20', category: 'conduit', manufacturer: 'Nexa', model: 'NX-T20', name: 'Tubo PVC rígido 20 mm — barra 3 m',
    price: 2.1, unit: 'barra', specs: { metersPerUnit: 3 } }),
  C({ id: 'CAN-PVC25', category: 'conduit', manufacturer: 'Nexa', model: 'NX-T25', name: 'Tubo PVC rígido 25 mm — barra 3 m',
    price: 2.9, unit: 'barra', specs: { metersPerUnit: 3 } }),
  C({ id: 'CAN-BAND50', category: 'conduit', manufacturer: 'Nexa', model: 'NX-BJ50', name: 'Bandeja metálica 50×30 — tramo 3 m',
    price: 18, unit: 'tramo', specs: { metersPerUnit: 3 } }),
];

/**
 * Fusiona una lista de artículos en el catálogo: los que ya existían (mismo `id`) se actualizan y
 * el resto se añaden. Así el catálogo de demostración convive con el del distribuidor y los
 * proyectos hechos con uno siguen encontrando sus referencias (§24).
 */
export function fusionarArticulos(catalog, items = []) {
  let anadidos = 0, actualizados = 0;
  for (const it of items) {
    if (!it || !it.id) continue;
    const prev = catalog.items.find((i) => i.id === it.id);
    const rec = { unit: 'ud', price: 0, stock: true, ...it, specs: { ...(it.specs || {}) } };
    if (prev) { Object.assign(prev, rec); actualizados++; }
    else { catalog.items.push(rec); anadidos++; }
  }
  return { anadidos, actualizados, total: items.length };
}

/**
 * Carga el **catálogo del distribuidor** (§24): el que genera `tools/gen-catalogo.mjs` desde los
 * ficheros que publica el distribuidor. El módulo se importa **bajo demanda** —son cerca de
 * mil artículos—, de modo que quien no lo usa no paga el coste de tenerlo cargado.
 */
export async function cargarCatalogoDistribuidor(catalog) {
  const mod = await import('./catalogo-distribuidor.js?v=b441e3fc');
  const r = fusionarArticulos(catalog, mod.CATALOGO_DISTRIBUIDOR || []);
  r.fecha = mod.CATALOGO_DISTRIBUIDOR_FECHA || '';
  return r;
}

/**
 * Catálogo de serie. Los artículos se **copian**: si se devolvieran los mismos objetos, dos
 * proyectos abiertos a la vez compartirían el catálogo y lo que se le cambie a uno (un precio, una
 * focal) se le cambiaría al otro sin avisar.
 */
export function seedCatalog(incluirDistribuidor = false) {
  const copia = (i) => ({ ...i, specs: { ...(i.specs || {}) } });
  const baseItems = [...cameras, ...rest].map(copia);
  if (incluirDistribuidor) {
    const distItems = (CATALOGO_DISTRIBUIDOR || []).map(copia);
    const ids = new Set(baseItems.map((i) => i.id));
    for (const it of distItems) {
      if (!ids.has(it.id)) {
        baseItems.push(it);
        ids.add(it.id);
      }
    }
  }
  return { version: 1, currency: 'EUR', updated: CATALOGO_DISTRIBUIDOR_FECHA || '2026-01-01', items: baseItems };
}

export const getItem = (catalog, id) => catalog.items.find((i) => i.id === id) || null;

/** Convierte texto CSV en matriz de filas (detecta separador , o ;). */
export function parseCsv(text) {
  // Un CSV guardado desde Excel llega con marca de orden de bytes (\ufeff) y con ella puesta la
  // primera columna se llama «\ufeffid»: la importación entera fallaría sin este quite.
  const lines = String(text || '').replace(/^\ufeff/, '').split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return [];
  const first = lines[0];
  const sep = ((first.match(/;/g) || []).length > (first.match(/,/g) || []).length) ? ';' : ',';
  return lines.map((line) => {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) {
        if (c === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === sep) { out.push(cur); cur = ''; }
      else cur += c;
    }
    out.push(cur);
    return out.map((x) => x.trim());
  });
}

/** Aplica una matriz de filas (primera = cabecera) sobre el catálogo actual (§25). */
export function importCatalogRows(catalog, rows) {
  if (!rows.length) return { catalog, added: 0, errors: ['Archivo vacío'] };
  const head = rows[0].map((h) => String(h).trim().toLowerCase());
  const col = (...names) => { for (const n of names) { const i = head.indexOf(n); if (i >= 0) return i; } return -1; };
  const iId = col('id', 'codigo', 'código', 'sku');
  const iCat = col('categoria', 'category', 'categoría');
  const iMan = col('fabricante', 'manufacturer', 'marca');
  const iMod = col('modelo', 'model');
  const iName = col('nombre', 'name', 'descripcion', 'descripción');
  const iPrice = col('precio', 'precio_compra', 'price', 'coste');
  const iUnit = col('unidad', 'unit');
  const iSpecs = col('specs', 'especificaciones', 'json');
  if (iId < 0) return { catalog, added: 0, errors: ['La primera fila debe incluir una columna "id"'] };
  let added = 0, updated = 0;
  const errors = [];
  rows.slice(1).forEach((f, n) => {
    const id = String(f[iId] ?? '').trim();
    if (!id) { errors.push(`Fila ${n + 2}: sin id`); return; }
    let specs = {};
    if (iSpecs >= 0 && f[iSpecs]) { try { specs = JSON.parse(f[iSpecs]); } catch { errors.push(`Fila ${n + 2}: JSON de specs inválido`); } }
    const existing = catalog.items.find((i) => i.id === id);
    const rec = {
      id,
      category: (iCat >= 0 && f[iCat]) || (existing && existing.category) || 'accessory',
      manufacturer: (iMan >= 0 && f[iMan]) || (existing && existing.manufacturer) || '',
      model: (iMod >= 0 && f[iMod]) || (existing && existing.model) || id,
      name: (iName >= 0 && f[iName]) || (existing && existing.name) || id,
      price: parseFloat(String(iPrice >= 0 && f[iPrice] !== undefined ? f[iPrice] : '0').replace(',', '.')) || 0,
      unit: (iUnit >= 0 && f[iUnit]) || (existing && existing.unit) || 'ud',
      specs: Object.assign({}, existing ? existing.specs : {}, specs),
    };
    if (existing) { Object.assign(existing, rec); updated++; }
    else { catalog.items.push(rec); added++; }
  });
  return { catalog, added, updated, errors };
}

/** Importa un catálogo CSV (separador , o ;) sobre el catálogo actual. */
export function importCatalogCsv(catalog, text) { return importCatalogRows(catalog, parseCsv(text)); }

/** Importa un catálogo XLSX (primera hoja) sobre el catálogo actual (§25). */
export function importCatalogXlsx(catalog, u8, fromXlsx) {
  const { sheets } = fromXlsx(u8);
  if (!sheets.length || !sheets[0].rows.length) return { catalog, added: 0, errors: ['El XLSX no contiene hojas con datos'] };
  return importCatalogRows(catalog, sheets[0].rows);
}
