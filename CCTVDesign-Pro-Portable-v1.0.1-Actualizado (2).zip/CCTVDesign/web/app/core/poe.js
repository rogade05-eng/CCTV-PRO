/**
 * CCTV DESIGN PRO — Motor PoE y alimentación (CP CCTV §19, §20)
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

export const POE_OK = 'SUFICIENTE', POE_LOW = 'RESERVA BAJA', POE_BAD = 'INSUFICIENTE', POE_NA = 'NO APLICA';

export function computePoe(prj, catalog, rules) {
  const reservePct = ruleNum(rules, 'RESERVA_POE');
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const switches = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'switch');
  const groups = [];
  const unassigned = [];
  const perCamera = [];

  for (const cam of cams) {
    const item = getItem(catalog, cam.data.catalogId);
    const s = (item && item.specs) || {};
    const power = Number(s.power) || 0;
    const poe = !!s.poe && cam.data.power !== 'psu' && !s.analog;
    perCamera.push({
      id: cam.id, label: cam.data.label || cam.id, model: item ? item.model : '?',
      poe, power, poeClass: s.poeClass || '-', analog: !!s.analog,
      switchId: cam.data.switchId || '',
    });
    if (!cam.data.switchId) { unassigned.push(cam); continue; }
  }

  for (const sw of switches) {
    const item = getItem(catalog, sw.data.catalogId);
    const s = (item && item.specs) || {};
    const assigned = perCamera.filter((c) => c.switchId === sw.id);
    const poeCams = assigned.filter((c) => c.poe && !c.analog);
    const totalPower = poeCams.reduce((a, c) => a + c.power, 0);
    const budget = Number(s.poeBudget) || 0;
    const ports = Number(s.ports) || 0;
    const uplinks = Number(s.uplink) || 0;
    const usablePorts = Math.max(0, ports - uplinks);
    let status = POE_NA, reason = '';
    if (budget > 0) {
      if (totalPower > budget) { status = POE_BAD; reason = `Consumo ${totalPower.toFixed(1)} W > presupuesto ${budget} W`; }
      else if (totalPower > budget * (1 - reservePct / 100)) { status = POE_LOW; reason = `Reserva inferior al ${reservePct} % (quedan ${(budget - totalPower).toFixed(1)} W)`; }
      else { status = POE_OK; reason = `Reserva de ${(budget - totalPower).toFixed(1)} W (${((1 - totalPower / budget) * 100).toFixed(0)} %)`; }
    }
    groups.push({
      id: sw.id, label: sw.data.label || sw.id, model: item ? item.model : '?', catalogId: sw.data.catalogId,
      budget, totalPower, spare: budget - totalPower, reservePct, status, reason,
      cameras: assigned.length, poeCameras: poeCams.length,
      ports, usablePorts, portsFree: usablePorts - assigned.length,
      portsStatus: assigned.length > usablePorts ? 'EXCEDIDO' : assigned.length > usablePorts - 1 ? 'JUSTO' : 'OK',
      uplinkUsed: 1, uplinks,
    });
  }

  const totalPower = perCamera.filter((c) => c.poe && !c.analog).reduce((a, c) => a + c.power, 0);
  const totalBudget = groups.reduce((a, g) => a + g.budget, 0);
  const nonPoe = perCamera.filter((c) => !c.poe || c.analog);

  // Carga del resto de equipos para dimensionar el UPS.
  const others = prj.entities.filter((e) => e.type === 'device' && e.data.kind !== 'switch');
  let headPower = 0;
  for (const d of others) {
    const it = getItem(catalog, d.data.catalogId);
    headPower += Number((it && it.specs && it.specs.power) || 0);
  }
  const swPower = switches.reduce((a, s) => {
    const it = getItem(catalog, s.data.catalogId);
    return a + Number((it && it.specs && it.specs.power) || 0);
  }, 0);
  const totalLoad = totalPower + swPower + headPower;
  const upsNeeded = Math.ceil(totalLoad * 1.25);

  return {
    reservePct, groups, perCamera, unassigned,
    totalPower, totalBudget, spare: totalBudget - totalPower,
    nonPoeCount: nonPoe.length, nonPoe,
    totalLoad, upsNeeded,
    overall: !groups.length ? POE_BAD
      : groups.some((g) => g.status === POE_BAD) ? POE_BAD
      : groups.some((g) => g.status === POE_LOW) ? POE_LOW
      : groups.every((g) => g.status === POE_NA) ? POE_NA : POE_OK,
  };
}

/** Reparte automáticamente las cámaras entre los switches PoE disponibles. */
export function autoAssignSwitches(prj, catalog, rules) {
  // La reserva de PoE es un criterio de diseño, no solo de validación: se respeta al asignar
  const reserve = (ruleNum(rules || {}, 'RESERVA_POE') || 20) / 100;
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const switches = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'switch')
    .map((s) => {
      const it = getItem(catalog, s.data.catalogId);
      const sp = (it && it.specs) || {};
      const rawBudget = Number(sp.poeBudget) || 0;
      return { ent: s, ports: Math.max(0, (Number(sp.ports) || 0) - (Number(sp.uplink) || 0)), budget: rawBudget, usable: rawBudget * (1 - reserve), used: 0, load: 0, poe: rawBudget > 0 };
    })
    .sort((a, b) => (b.poe - a.poe) || (b.ports - a.ports));
  const changes = [];
  for (const cam of cams) {
    const it = getItem(catalog, cam.data.catalogId);
    const s = (it && it.specs) || {};
    const power = Number(s.power) || 0;
    let best = null, bd = Infinity;
    for (const sw of switches) {
      if (s.poe && !sw.poe) continue;
      if (sw.used >= sw.ports) continue;
      if (sw.load + power > sw.usable) continue;
      const d = Math.hypot(sw.ent.points[0].x - cam.points[0].x, sw.ent.points[0].y - cam.points[0].y);
      if (d < bd) { bd = d; best = sw; }
    }
    if (!best) continue;
    best.used++; best.load += power;
    if (cam.data.switchId !== best.ent.id) {
      cam.data.switchId = best.ent.id;
      changes.push({ camera: cam.data.label || cam.id, switch: best.ent.data.label || best.ent.id });
    }
  }
  return { changes, unassigned: cams.filter((c) => !c.data.switchId).length };
}
