/**
 * CCTV DESIGN PRO — Vista 3D: cámara, proyección y escena (CP CCTV §8, §13)
 *
 * Una vista 3D sencilla para poder juzgar lo que en planta no se ve: a qué altura queda una cámara
 * respecto de los muros, si el haz tropieza con una estantería antes de llegar al suelo, si un árbol
 * tapa el acceso o si una cámara montada en techo queda por encima del falso techo.
 *
 * Es deliberadamente simple (y por eso cabe en la restricción §36: sin GPU dedicada y sin WebGL):
 *
 *   · La escena es una lista de **caras** (polígonos de 3 o 4 vértices en coordenadas de mundo).
 *   · Se pintan ordenadas de lejos a cerca (algoritmo del pintor) con sombreado plano: cada cara se
 *     oscurece o se aclara según el ángulo de su normal con una luz fija. Es suficiente para leer
 *     volúmenes y no necesita z-buffer.
 *   · La cámara orbita alrededor de un punto: azimut, elevación, distancia y campo visual.
 *
 * Módulo puro: no toca el DOM. El pintado (lienzo) vive en `app/render3d.js`.
 */
import { cierreConvexo } from './geometry.js?v=b441e3fc';
import { footprint } from './dori.js?v=b441e3fc';
import { tambor } from './obstacles.js?v=b441e3fc';

/* ------------------------------------------------------------------- cámara */

/** Cámara orbital en torno a un punto del mundo. */
export function nuevaCamara(opts = {}) {
  return {
    azimut: opts.azimut !== undefined ? opts.azimut : 35,      // grados, 0 = mirando desde el sur
    elevacion: opts.elevacion !== undefined ? opts.elevacion : 35,  // grados sobre el horizonte
    distancia: opts.distancia !== undefined ? opts.distancia : 60,  // metros al punto al que mira
    objetivo: { x: opts.x || 0, y: opts.y || 0, z: opts.z !== undefined ? opts.z : 1.2 },
    fov: opts.fov || 45,                                       // campo visual vertical, en grados
  };
}

/** Posición del ojo en coordenadas de mundo. */
export function ojoDe(cam) {
  const a = (cam.azimut * Math.PI) / 180, e = (cam.elevacion * Math.PI) / 180;
  const d = Math.max(0.5, cam.distancia);
  return {
    x: cam.objetivo.x + d * Math.cos(e) * Math.sin(a),
    y: cam.objetivo.y + d * Math.cos(e) * Math.cos(a),
    z: cam.objetivo.z + d * Math.sin(e),
  };
}

/** Base ortonormal de la vista (hacia delante, hacia la derecha y hacia arriba). */
export function baseDe(cam) {
  const ojo = ojoDe(cam);
  const t = cam.objetivo;
  let f = { x: t.x - ojo.x, y: t.y - ojo.y, z: t.z - ojo.z };
  const lf = Math.hypot(f.x, f.y, f.z) || 1;
  f = { x: f.x / lf, y: f.y / lf, z: f.z / lf };
  // derecha = f × arribaMundo (arribaMundo = +Z)
  let r = { x: f.y * 1 - f.z * 0, y: f.z * 0 - f.x * 1, z: 0 };
  r = { x: f.y, y: -f.x, z: 0 };
  const lr = Math.hypot(r.x, r.y, r.z) || 1;
  r = { x: r.x / lr, y: r.y / lr, z: r.z / lr };
  const u = {
    x: r.y * f.z - r.z * f.y,
    y: r.z * f.x - r.x * f.z,
    z: r.x * f.y - r.y * f.x,
  };
  return { ojo, f, r, u };
}

/**
 * Proyecta un punto del mundo a la pantalla.
 * @returns {object} `{x, y, z}` donde `z` es la profundidad (negativa si queda detrás del ojo).
 */
export function proyectar(p, cam, w, h, distorsion = 0) {
  const b = baseDe(cam);
  const v = { x: p.x - b.ojo.x, y: p.y - b.ojo.y, z: p.z - b.ojo.z };
  const cz = v.x * b.f.x + v.y * b.f.y + v.z * b.f.z;
  const cx = v.x * b.r.x + v.y * b.r.y + v.z * b.r.z;
  const cy = v.x * b.u.x + v.y * b.u.y + v.z * b.u.z;
  const dist = Math.max(1e-6, Math.abs(cz));
  const f = (h / 2) / Math.tan((cam.fov * Math.PI) / 360);
  const k = f / dist;
  let px = w / 2 + cx * k;
  let py = h / 2 - cy * k;
  const kDist = typeof distorsion === 'number' && distorsion !== 0 ? distorsion : (cam && cam.distorsion ? cam.distorsion : 0);
  if (kDist !== 0 && cz > 0.01) {
    const rx = (px - w / 2) / (w / 2);
    const ry = (py - h / 2) / (h / 2);
    const r2 = rx * rx + ry * ry;
    const factor = 1 + kDist * r2;
    px = w / 2 + rx * factor * (w / 2);
    py = h / 2 + ry * factor * (h / 2);
  }
  return { x: px, y: py, z: cz, detras: cz <= 0.01 };
}

/* ------------------------------------------------- ver desde una cámara (primera persona) */

/**
 * Cámara orbital equivalente a **mirar desde una cámara de vigilancia**: el ojo se coloca en su
 * posición de montaje y apunta con su azimut y su inclinación reales, con el campo visual vertical
 * de su lente (§13). Es un cambio de variables, no un motor nuevo: la cámara orbital del 3D ya da
 * de sí para esto porque el ojo se calcula desde el objetivo, y aquí el objetivo se pone delante.
 *
 *   ojo      = posición de la cámara (a su altura de montaje)
 *   objetivo = ojo + d · (cos τ·sen α , cos τ·cos α , −sen τ)      τ = inclinación hacia abajo
 *   azimut   = α + 180°   (el ojo se coloca "detrás" del objetivo)
 *   elevación= τ
 */
export function camaraDesdeVigilancia(cam, catalog, rules, distancia = 12) {
  const data = (cam && cam.data) || {};
  const p = (cam.points && cam.points[0]) || { x: 0, y: 0 };
  const h = Number(data.height) || 2.8;
  const az = Number(data.azimuth) || 0;
  const tilt = Math.max(0, Math.min(89, Number(data.tilt) || 0));
  let vfov = 45;
  try {
    const fp = footprint(cam, catalog, rules || {}, {});
    if (fp && fp.vfov) vfov = fp.vfov;
  } catch { vfov = 45; }
  const a = (az * Math.PI) / 180, t = (tilt * Math.PI) / 180;
  const d = Math.max(1, distancia);
  return {
    azimut: (az + 180) % 360,
    elevacion: tilt,
    distancia: d,
    objetivo: { x: p.x + d * Math.cos(t) * Math.sin(a), y: p.y + d * Math.cos(t) * Math.cos(a), z: h - d * Math.sin(t) },
    fov: Math.max(5, Math.min(120, vfov)),
    desdeCamara: cam.id,
  };
}

/* --------------------------------------------------------- oclusión y aristas */

/**
/** Abre un polígono `d` metros hacia fuera desde su baricentro: para la penumbra de las sombras. */
export function expandir(poligono, d) {
  let cx = 0, cy = 0;
  for (const q of poligono) { cx += q.x; cy += q.y; }
  cx /= Math.max(1, poligono.length); cy /= Math.max(1, poligono.length);
  return poligono.map((q) => {
    const dx = q.x - cx, dy = q.y - cy, l = Math.hypot(dx, dy) || 1;
    return { x: q.x + (dx / l) * d, y: q.y + (dy / l) * d };
  });
}

/**
 * Mancha de contacto de un volumen: la sombra suave justo donde apoya en el suelo, que es lo que de
 * verdad «pega» los objetos al plano (sin ella parecen flotar).
 *
 * Se toma la planta del volumen, su cierre convexo, y se devuelven **tres anillos concéntricos** de
 * menos a más oscuros: es un degradado con tres polígonos, que no cuesta nada y evita el borde duro
 * de una sola mancha. La anchura crece con el tamaño de la pieza (una persiana no mancha lo mismo
 * que un edificio), con un mínimo de 30 cm.
 */
export function contactoDe(volumen, opciones = {}) {
  const capas = opciones.capasContacto === undefined ? 3 : Math.max(1, Math.min(5, opciones.capasContacto));
  const puntos = [];
  let z0 = Infinity;
  for (const cara of (volumen && volumen.caras) || []) {
    for (const p of cara.puntos || []) if (p && p.z !== undefined) z0 = Math.min(z0, p.z);
  }
  if (!isFinite(z0) || z0 > 0.05) return [];                   // no apoya en el suelo: sin contacto
  for (const cara of volumen.caras) {
    for (const p of cara.puntos || []) if (p && Math.abs((p.z || 0) - z0) < 1e-6) puntos.push({ x: p.x, y: p.y });
  }
  if (puntos.length < 3) return [];
  const hull = cierreConvexo(puntos);
  if (hull.length < 3) return [];
  let cx = 0, cy = 0, minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const q of hull) {
    cx += q.x; cy += q.y;
    minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
    minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
  }
  cx /= hull.length; cy /= hull.length;
  const diagonal = Math.hypot(maxX - minX, maxY - minY);
  const ancho = Math.max(0.3, Math.min(2.5, 0.3 + diagonal * 0.09));
  const opacidad = opciones.opacidadContacto === undefined ? 0.4 : opciones.opacidadContacto;
  const color = opciones.colorContacto || '#070a10';
  const out = [];
  for (let i = capas; i >= 1; i--) {
    const fraccion = i / capas;                                // el anillo exterior es el más tenue
    const expansion = ancho * fraccion;
    const abierto = hull.map((q) => {
      const dx = q.x - cx, dy = q.y - cy, l = Math.hypot(dx, dy) || 1;
      return { x: q.x + (dx / l) * expansion, y: q.y + (dy / l) * expansion };
    });
    out.push({
      puntos: abierto.map((q) => ({ x: q.x, y: q.y, z: 0.02 })),
      color, opacidad: opacidad * (0.45 + 0.55 * (1 - fraccion)),
      plana: true, contacto: true,
    });
  }
  return out;
}

/** Manchas de contacto de todos los volúmenes del proyecto. */
export function contactosDelSuelo(volumenes, opciones = {}) {
  const out = [];
  for (const v of (volumenes || [])) {
    if (!v || v.kind === 'techo' || v.kind === 'cubierta') continue;
    for (const capa of contactoDe(v, opciones)) out.push(capa);
  }
  return out;
}

/** Aristas de una lista de caras, sin repetir: para el modo alambre encima de las caras. */
export function aristasDe(caras, tolerancia = 1e-4) {
  const clave = (p, q) => {
    const a = `${p.x.toFixed(3)},${p.y.toFixed(3)},${p.z.toFixed(3)}`;
    const b = `${q.x.toFixed(3)},${q.y.toFixed(3)},${q.z.toFixed(3)}`;
    return a < b ? a + '|' + b : b + '|' + a;
  };
  const vistas = new Set();
  const out = [];
  for (const cara of caras || []) {
    const pts = cara.puntos || [];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      if (!a || !b) continue;
      if (Math.hypot(a.x - b.x, a.y - b.y, (a.z || 0) - (b.z || 0)) < tolerancia) continue;
      const k = clave(a, b);
      if (vistas.has(k)) continue;
      vistas.add(k);
      out.push({ a, b, kind: cara.kind });
    }
  }
  return out;
}

/** Distancia media de una cara al ojo: con la que se ordena el algoritmo del pintor. */
export function profundidadDe(cara, ojo) {
  let s = 0;
  for (const p of cara.puntos) s += Math.hypot(p.x - ojo.x, p.y - ojo.y, p.z - ojo.z);
  return s / Math.max(1, cara.puntos.length);
}

/** Normal (sin normalizar) de una cara, por la regla de Newell. */
export function normalDe(cara) {
  const p = cara.puntos;
  let nx = 0, ny = 0, nz = 0;
  for (let i = 0; i < p.length; i++) {
    const a = p[i], b = p[(i + 1) % p.length];
    nx += (a.y - b.y) * (a.z + b.z);
    ny += (a.z - b.z) * (a.x + b.x);
    nz += (a.x - b.x) * (a.y + b.y);
  }
  return { x: nx, y: ny, z: nz };
}

/** Dirección de la luz: alta y desde el noroeste, como un día nublado. */
export const LUZ = (() => {
  const v = { x: -0.45, y: 0.5, z: 0.74 };
  const l = Math.hypot(v.x, v.y, v.z);
  return { x: v.x / l, y: v.y / l, z: v.z / l };
})();

/**
 * Sombreado plano de una cara: 0,55 (en sombra) a 1,25 (de cara a la luz).
 * Se usa para dar volumen sin iluminación por píxel (§36).
 */
export function sombreado(cara) {
  const n = normalDe(cara);
  const l = Math.hypot(n.x, n.y, n.z) || 1;
  const d = (n.x * LUZ.x + n.y * LUZ.y + n.z * LUZ.z) / l;
  return 0.55 + 0.7 * Math.max(0, d) + 0.12 * Math.max(0, n.z / l);
}

/** Ordena las caras de lejos a cerca. */
export function ordenar(caras, ojo) {
  return caras
    .map((c) => ({ cara: c, d: profundidadDe(c, ojo) }))
    .sort((a, b) => b.d - a.d)
    .map((c) => c.cara);
}

/** ¿La cara mira hacia el ojo? (las caras traseras se pueden saltar para pintar más rápido). */
export function caraVisible(cara, ojo) {
  const n = normalDe(cara);
  const p = cara.puntos[0];
  const v = { x: ojo.x - p.x, y: ojo.y - p.y, z: ojo.z - p.z };
  return n.x * v.x + n.y * v.y + n.z * v.z > 0;
}

/* -------------------------------------------------------------- navegación */

/** Orbita: arrastrar el ratón gira la vista (y con Mayús desplaza el punto al que mira). */
export function orbitar(cam, dx, dy, opts = {}) {
  const sens = opts.sensibilidad || 0.35;
  if (opts.panear) {
    const b = baseDe(cam);
    const k = (cam.distancia * 0.0022);
    cam.objetivo.x -= (b.r.x * dx - b.u.x * dy) * k * 10;
    cam.objetivo.y -= (b.r.y * dx - b.u.y * dy) * k * 10;
    cam.objetivo.z -= (b.r.z * dx - b.u.z * dy) * k * 10;
    return cam;
  }
  cam.azimut = ((cam.azimut - dx * sens) % 360 + 360) % 360;
  cam.elevacion = Math.max(2, Math.min(89, cam.elevacion + dy * sens));
  return cam;
}

/** Acerca o aleja con la rueda, como en la vista 2D (§8). */
export function zoom3d(cam, delta) {
  const f = Math.exp(delta * 0.0016);
  cam.distancia = Math.max(2, Math.min(4000, cam.distancia * f));
  return cam;
}

/** Encuadra una caja del mundo (o del proyecto) en la vista 3D. */
export function encuadrarCaja(cam, caja, alto = 0) {
  if (!caja) return cam;
  const ancho = Math.max(1e-3, caja.maxX - caja.minX);
  const altoY = Math.max(1e-3, caja.maxY - caja.minY);
  const lado = Math.max(ancho, altoY, alto || 3);
  cam.objetivo = {
    x: (caja.minX + caja.maxX) / 2,
    y: (caja.minY + caja.maxY) / 2,
    z: Math.max(0.4, (alto || 0) / 2),
  };
  cam.distancia = Math.max(4, (lado * 1.35) / Math.tan((cam.fov * Math.PI) / 360) / 2);
  return cam;
}

/* ------------------------------------------------------------------ escena */

/**
 * Caras del suelo: una retícula de `paso` metros dentro de la caja, más el propio plano z = 0.
 * Se devuelven como líneas (segmentos 3D) porque la retícula se traza, no se rellena.
 */
export function lineasSuelo(caja, paso = 2) {
  const out = [];
  if (!caja) return out;
  const p = Math.max(0.5, paso);
  const x0 = Math.floor(caja.minX / p) * p, x1 = Math.ceil(caja.maxX / p) * p;
  const y0 = Math.floor(caja.minY / p) * p, y1 = Math.ceil(caja.maxY / p) * p;
  for (let x = x0; x <= x1 + 1e-9; x += p) out.push({ a: { x, y: y0, z: 0 }, b: { x, y: y1, z: 0 } });
  for (let y = y0; y <= y1 + 1e-9; y += p) out.push({ a: { x: x0, y, z: 0 }, b: { x: x1, y, z: 0 } });
  return out;
}

/** Cara plana (polígono a una cota) para zonas, huellas y techos translúcidos. */
export function lamina(poligono, z, color, opacidad = 0.3) {
  return { puntos: poligono.map((p) => ({ x: p.x, y: p.y, z })), color, opacidad, plana: true };
}

/* --------------------------------------------------------- sombras en el suelo */

/**
 * Mancha que un volumen deja en el suelo con la luz `LUZ`: se proyecta cada punto del volumen sobre
 * el plano z = 0 siguiendo la dirección de la luz y se toma el **cierre convexo**, así la sombra se
 * pinta de una sola vez (si se pintara una mancha por cara, los solapes se oscurecerían).
 * Es una aproximación: para contornos muy cóncavos la mancha sale algo mayor que la real.
 */
export function sombraDe(volumen, luz = LUZ, opacidad = 0.32, color = '#05070c') {
  const puntos = [];
  for (const cara of (volumen && volumen.caras) || []) {
    for (const p of cara.puntos || []) {
      if (!p || p.z === undefined) continue;
      const k = p.z / Math.max(0.2, luz.z);
      puntos.push({ x: p.x - luz.x * k, y: p.y - luz.y * k });
      puntos.push({ x: p.x, y: p.y });
    }
  }
  const hull = cierreConvexo(puntos);
  if (hull.length < 3) return null;
  return { puntos: hull.map((p) => ({ x: p.x, y: p.y, z: 0.01 })), color, opacidad, plana: true, sombra: true };
}

/** Sombras de todos los volúmenes que apoyan en el suelo (los techos no proyectan: taparían la vista). */
export function sombrasDelSuelo(volumenes, opciones = {}) {
  const out = [];
  for (const v of (volumenes || [])) {
    if (!v || !v.caras || !v.caras.length) continue;
    if (v.kind === 'techo' || v.kind === 'cubierta') continue;
    let z0 = Infinity;
    for (const c of v.caras) for (const p of c.puntos || []) z0 = Math.min(z0, p.z || 0);
    if (z0 > 0.05) continue;                    // colgado (falso techo, cámara): no deja mancha
    const s = sombraDe(v, LUZ, opciones.opacidadSombra === undefined ? 0.32 : opciones.opacidadSombra);
    if (!s || !s.puntos || s.puntos.length < 3) continue;
    // Penumbra: un halo más ancho y más flojo **debajo** de la sombra exacta, para que el borde no
    // parezca recortado con tijeras. El ojo lo lee como una sombra de día nublado.
    if (opciones.penumbra !== false) {
      const halo = opciones.haloSombra === undefined ? 0.45 : opciones.haloSombra;
      out.push({ ...s, puntos: expandir(s.puntos, halo).map((q) => ({ x: q.x, y: q.y, z: (s.puntos[0].z || 0) - 0.001 })),
        opacidad: (s.opacidad === undefined ? 0.32 : s.opacidad) * 0.5, penumbra: true });
    }
    out.push(s);
  }
  return out;
}

/**
 * Haz de una cámara: el volumen entre el objetivo (a su altura de montaje) y la huella que deja en
 * el suelo. Es una pirámide: la base es la huella y el vértice, la cámara. Se pinta translúcida.
 */
/** Anillo del haz: `f` = 0 en la cámara, 1 en la huella (que está en el suelo). */
function anilloDe(huella, apex, f) {
  return huella.map((p) => ({
    x: apex.x + (p.x - apex.x) * f,
    y: apex.y + (p.y - apex.y) * f,
    z: apex.z * (1 - f),
  }));
}

/**
 * Haz de una cámara: el volumen entre el objetivo y la huella que deja en el suelo.
 *
 * Hay tres formas de pintarlo, de peor a mejor, y todas salen de aquí:
 *
 *   · `degradado`  el cono se desvanece de verdad: **una sola silueta** por haz (el contorno del
 *                  cono visto desde donde se mire) rellena con un degradado radial denso junto a la
 *                  cámara y casi transparente al final. Es la opción por defecto y además la más
 *                  barata con diferencia: una cara por haz en vez de una por cada lado de la
 *                  huella —que son decenas— y sin los cercos que dejan los triángulos al solaparse.
 *   · `bandas` > 1 el triángulo se reparte en bandas, más densas junto a la cámara. Las bandas son
 *                  una **partición** del triángulo, no capas superpuestas, así que no se oscurecen
 *                  entre sí. Sirve de respaldo cuando no se quiere degradado por píxel.
 *   · plano        un triángulo de color plano por lado (lo que había antes).
 *
 * En el caso con degradado cada cara lleva `degradado: {desde, hasta}` en coordenadas de mundo: el
 * pintado las proyecta y tiende el degradado entre la cámara y el final de la huella (§8).
 */
export function hazDeCamara(origen, huella, color, opacidad = 0.16, bandas = 1, degradado = false) {
  const caras = [];
  const apex = { x: origen.x, y: origen.y, z: origen.z };
  const n = huella.length;
  const pasos = Math.max(1, Math.min(4, Number(bandas) || 1));
  let lejos = huella[0], dmax = -1;
  let cx = 0, cy = 0;
  for (const p of huella) {
    cx += p.x; cy += p.y;
    const d = Math.hypot(p.x - apex.x, p.y - apex.y);
    if (d > dmax) { dmax = d; lejos = p; }
  }
  cx /= n; cy /= n;
  const distCentro = Math.hypot(apex.x - cx, apex.y - cy);
  const esFisheye = distCentro < (dmax * 0.35) && n >= 16;

  if (esFisheye) {
    // Para cámaras Fisheye 360°, generamos un número óptimo de facetas (máximo 36) para mantener
    // alto rendimiento y una representación cónica/hemisférica limpia sin saturar el pintor 3D.
    const paso = Math.max(1, Math.floor(n / 36));
    for (let i = 0; i < n; i += paso) {
      const a = huella[i], b = huella[(i + paso) % n];
      caras.push({
        puntos: [apex, { x: a.x, y: a.y, z: 0 }, { x: b.x, y: b.y, z: 0 }],
        color, opacidad: opacidad * 0.75, haz: true, fisheye: true,
      });
    }
  } else if (degradado) {
    // La silueta para cámaras direccionales: el vértice y toda la huella en **una** cara.
    caras.push({
      puntos: [apex, ...huella.map((p) => ({ x: p.x, y: p.y, z: 0 }))],
      color, opacidad, haz: true, silueta: true,
      degradado: { desde: apex, hasta: { x: lejos.x, y: lejos.y, z: 0 } },
    });
  } else if (pasos === 1) {
    for (let i = 0; i < n; i++) {
      const a = huella[i], b = huella[(i + 1) % n];
      caras.push({
        puntos: [apex, { x: a.x, y: a.y, z: 0 }, { x: b.x, y: b.y, z: 0 }],
        color, opacidad, haz: true,
      });
    }
  } else {
    for (let i = 0; i < n; i++) {
      const arista = [huella[i], huella[(i + 1) % n]];
      for (let k = 0; k < pasos; k++) {
        const f0 = k / pasos, f1 = (k + 1) / pasos;
        const A = anilloDe(arista, apex, f0);
        const B = anilloDe(arista, apex, f1);
        caras.push({
          puntos: [A[0], B[0], B[1], A[1]],
          color, opacidad: opacidad * (1 - 0.72 * f0), haz: true,
        });
      }
    }
  }
  if (n >= 3) {
    // Charco de luz en el suelo: se atenúa también con la distancia, así la huella no parece un
    // recorte de papel pegado en el suelo.
    const charco = lamina(huella, 0, color, opacidad * 2.2);
    if (degradado) {
      let cx = 0, cy = 0;
      for (const p of huella) { cx += p.x; cy += p.y; }
      charco.degradado = { desde: apex, hasta: { x: cx / n, y: cy / n, z: 0 } };
    }
    caras.push(charco);
  }
  return caras;
}

/**
 * Sombra que el propio haz deja en el suelo. Un cono de luz no «tapa» la luz del sol, pero sin esta
 * mancha el haz flota: todo lo que hay en la escena apoya en el suelo menos él. Se proyecta la
 * pirámide (cámara + huella) siguiendo la dirección de `LUZ` y se toma el cierre convexo, igual que
 * con cualquier volumen:como la huella ya está en el suelo, la mancha es la huella ensanchada hacia
 * el lado contrario de la luz, que es lo que se ve de reojo y da profundidad (§8).
 */
export function sombraDeHaz(origen, huella, luz = LUZ, opacidad = 0.2, color = '#05070c') {
  if (!huella || huella.length < 3 || !origen) return null;
  const k = Math.max(0, Number(origen.z) || 0) / Math.max(0.2, luz.z);
  const puntos = [{ x: origen.x - luz.x * k, y: origen.y - luz.y * k }];
  for (const p of huella) puntos.push({ x: p.x, y: p.y });
  const hull = cierreConvexo(puntos);
  if (hull.length < 3) return null;
  return { puntos: hull.map((p) => ({ x: p.x, y: p.y, z: 0.012 })),
    color, opacidad, plana: true, sombra: true, sombraHaz: true };
}

/**
 * Cuerpo de una cámara: caja **orientada** según su azimut y con el objetivo por delante, para que
 * se vea de un vistazo hacia dónde mira (§8). Antes era una cajita alineada con los ejes y no se
 * sabía si miraba al norte o al sur, que en un proyecto de CCTV es justo lo que importa.
 */
export function cuerpoDeCamara(pos, color = '#d8dee9', lado = 0.22, giro = 0) {
  const h = lado, w = lado, l = lado * 2.2;
  const cs = Math.cos(giro), sn = Math.sin(giro);
  // «u» es el través de la caja y «v» su eje largo: +v apunta en la dirección de mira
  const punto = (u, v, dz) => ({ x: pos.x + u * cs + v * sn, y: pos.y - u * sn + v * cs, z: pos.z + dz });
  const caja = (v0, v1, dz0, dz1, col) => {
    const esquinas = [punto(-w / 2, v0, 0), punto(w / 2, v0, 0), punto(w / 2, v1, 0), punto(-w / 2, v1, 0)];
    const tapaAbajo = esquinas.map((p) => ({ ...p, z: pos.z + dz0 }));
    const tapaArriba = esquinas.map((p) => ({ ...p, z: pos.z + dz1 }));
    const caras = [{ puntos: tapaArriba.slice().reverse(), color: col, opacidad: 1 },
      { puntos: tapaAbajo, color: col, opacidad: 1 }];
    for (let i = 0; i < 4; i++) {
      const j = (i + 1) % 4;
      caras.push({ puntos: [tapaAbajo[i], tapaAbajo[j], tapaArriba[j], tapaArriba[i]], color: col, opacidad: 1 });
    }
    return caras;
  };
  return {
    tipo: 'camara', color, opacidad: 1,
    caras: [
      ...caja(-l / 2, l / 2, 0, h, color),                            // cuerpo
      ...caja(l / 2, l / 2 + lado * 0.8, h * 0.15, h * 0.85, '#111827'), // objetivo, por delante
    ],
  };
}

/* ------------------------------------------ cámaras y equipos con su forma real (§8, §24) */

/** Medidas típicas de cada forma, en metros, para cuando el catálogo no trae las suyas. */
const MEDIDAS = {
  dome: { r: 0.08, alto: 0.12 }, fisheye: { r: 0.075, alto: 0.05 }, bullet: { r: 0.04, largo: 0.18 },
  box: { l: 0.09, w: 0.08, alto: 0.24 }, ptz: { r: 0.10, alto: 0.28 },
  multisensor: { r: 0.12, alto: 0.09 }, thermal: { r: 0.045, largo: 0.2 },
  dual: { r: 0.05, largo: 0.22 }, pinhole: { r: 0.025, largo: 0.06 },
};

/**
 * Traduce las dimensiones del catálogo (`specs.dim`, en milímetros) a metros según la forma:
 * en un domo el segundo número es el **alto** de la cazoleta y en una bala el **largo** del tubo,
 * así que la misma cifra no significa lo mismo en los dos casos.
 */
export function medidasDe(forma, dim) {
  const base = MEDIDAS[forma] || MEDIDAS.dome;
  if (!dim) return { ...base };
  const d = Math.max(0.02, (Number(dim.d) || 0) / 1000);
  const otro = Math.max(0.02, (Number(dim.h) || 0) / 1000);
  if (dim.forma === 'cilindro') {
    const r = Math.max(0.015, Math.min(0.3, d / 2));
    if (forma === 'bullet' || forma === 'thermal' || forma === 'dual' || forma === 'pinhole') {
      return { r, largo: Math.max(0.06, Math.min(0.45, otro)) };
    }
    return { r, alto: Math.max(0.03, Math.min(0.4, otro)) };
  }
  return { l: Math.max(0.03, Math.min(0.4, (Number(dim.l) || 90) / 1000)),
    w: Math.max(0.03, Math.min(0.4, (Number(dim.w) || 80) / 1000)),
    alto: Math.max(0.03, Math.min(0.4, (Number(dim.h) || 240) / 1000)) };
}

/**
 * Cuerpo de una cámara dibujado con la **forma de su tipo** y, si el catálogo las trae, con sus
 * medidas reales (§8, §24): un domo es una cazoleta que cuelga del techo, una bala un tubo tumbado
 * con visera y objetivo, un PTZ una carcasa con brazo, una caja un cuerpo prismático con el
 * objetivo delante. Antes todas eran la misma cajita girada, y así no se sabía qué se había
 * montado: en CCTV el tipo de cámara dice qué se ve y qué no.
 *
 * `pos` es el punto de montaje (a la altura de la cámara) y `giro` su azimut: +v mira al frente.
 * Devuelve volúmenes `{{tipo, caras}}` igual que los obstáculos, así que se pintan en la misma
 * pasada que el resto de la escena.
 */
export function cuerpoDeEquipo(pos, giro = 0, forma = 'dome', dim = null, color = '#e2e8f0', opciones = {}) {
  const cs = Math.cos(giro), sn = Math.sin(giro);
  // «v» avanza en la dirección de mira y «u» cruza: +v es delante, como en `cuerpoDeCamara`
  const P = (u, v, dz) => ({ x: pos.x + u * cs + v * sn, y: pos.y - u * sn + v * cs, z: pos.z + dz });
  const LADOS = 6;
  const cristal = '#1b2430', metal = '#8b95a6';
  const m = medidasDe(forma, dim);
  const out = [];
  // Caja orientada: las cuatro esquinas en planta y sus dos cotas
  const caja = (v0, v1, u0, u1, z0, z1, col, op = 1) => {
    const esq = [P(u0, v0, 0), P(u1, v0, 0), P(u1, v1, 0), P(u0, v1, 0)];
    const abajo = esq.map((p) => ({ ...p, z: p.z + z0 }));
    const arriba = esq.map((p) => ({ ...p, z: p.z + z1 }));
    const cara = (pts) => ({ puntos: pts, color: col, opacidad: op });
    const caras = [cara(arriba.slice()), cara(abajo.slice().reverse())];
    for (let i = 0; i < 4; i++) {
      const j = (i + 1) % 4;
      caras.push(cara([abajo[i], abajo[j], arriba[j], arriba[i]]));
    }
    return { tipo: 'caja', color: col, opacidad: op, caras };
  };
  // Objetivo: un tambor corto mirando al frente y algo caído, que es como se montan. `u` lo
  // desplaza a un lado y `giroLocal` lo saca apuntando en otra dirección (multisensor).
  const objetivo = (v, dz, r, largo, caida = 0.55, col = cristal, op = 1, u = 0, giroLocal = 0) => {
    const a = P(u, v, dz);
    const g = giro + giroLocal;
    const b = { x: a.x + Math.sin(g) * largo, y: a.y + Math.cos(g) * largo, z: a.z - largo * caida };
    return tambor(a, b, r, col, LADOS, op);
  };

  if (forma === 'dome' || forma === 'fisheye') {
    const r = m.r, alto = m.alto;
    out.push(tambor(P(0, 0, -0.012), P(0, 0, 0.004), r * 1.06, metal, LADOS, 1));  // base
    out.push(tambor(P(0, 0, -alto * 0.55), P(0, 0, -0.012), r, color, LADOS, 1));   // cuerpo
    // La cúpula: un cono truncado de cristal, que es lo que se ve desde el suelo
    out.push(tambor(P(0, 0, -alto * 0.62), P(0, 0, -alto), r * 0.94, cristal, LADOS, 0.55, r * 0.42));
    out.push(objetivo(r * 0.1, -alto * 0.72, r * 0.2, r * 0.5, 0.35, cristal, 1));
  } else if (forma === 'ptz') {
    const r = m.r, alto = m.alto;
    out.push(tambor(P(0, 0, -0.02), P(0, 0, 0.06), r * 0.55, metal, LADOS, 1));     // brazo
    out.push(tambor(P(0, 0, -alto), P(0, 0, -0.02), r, color, LADOS, 1));           // carcasa
    out.push(tambor(P(0, 0, -alto - r * 0.55), P(0, 0, -alto), r * 0.92, cristal, LADOS, 0.5, r * 0.5));
    out.push(objetivo(r * 0.55, -alto - r * 0.2, r * 0.26, r * 0.5, 0.35, cristal, 1));
  } else if (forma === 'multisensor') {
    const r = m.r, alto = m.alto;
    out.push(tambor(P(0, 0, -alto), P(0, 0, 0), r, color, LADOS, 1));
    // Un objetivo por sensor, repartido alrededor: es lo que distingue un multisensor de un domo
    const n = Math.max(2, Math.min(4, Number(opciones.sensores) || 3));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + Math.PI / n;
      out.push(objetivo(Math.sin(a) * r * 0.6, -alto * 0.5, r * 0.17, r * 0.45, 0.55,
        cristal, 1, Math.cos(a) * r * 0.6, a));
    }
  } else if (forma === 'box') {
    // Un turrón: el cuerpo prismático tumbado (244 × 82 × 89 mm) y el objetivo asomando delante
    const largo = m.alto, ancho = m.l, alto = m.w;
    out.push(caja(-largo * 0.5, largo * 0.5, -ancho / 2, ancho / 2, -alto * 0.5, alto * 0.5, color));
    out.push(objetivo(largo * 0.5, 0, alto * 0.3, largo * 0.2, 0.02, cristal, 1));
  } else if (forma === 'pinhole') {
    const r = m.r, largo = m.largo;
    out.push(caja(-largo * 0.5, largo * 0.5, -r, r, -r, r, color));
    out.push(objetivo(largo * 0.5, 0, r * 0.45, largo * 0.25, 0.02, cristal, 1));
  } else {                                              // bullet, thermal, dual: tubo tumbado
    const r = m.r, largo = m.largo;
    out.push(tambor(P(0, -largo * 0.5, 0), P(0, largo * 0.5, 0), r, color, LADOS, 1));
    out.push(tambor(P(0, largo * 0.5, 0), P(0, largo * 0.5 + r * 0.3, 0), r * 0.86, cristal, LADOS, 0.85));
    // Visera: la chapa que llevan encima para que el sol no deslumbre (y que las delata de lejos)
    out.push(caja(largo * 0.02, largo * 0.56, -r * 1.02, r * 1.02, r * 0.55, r * 0.82, metal));
    if (forma === 'thermal' || forma === 'dual') {
      // Dos objetivos: una térmica y una dual-lente se reconocen por eso
      out.push(objetivo(largo * 0.5 + r * 0.28, -r * 0.28, r * 0.24, r * 0.3, 0.02, cristal, 1));
      out.push(objetivo(largo * 0.5 + r * 0.28, r * 0.28, r * 0.24, r * 0.3, 0.02, '#2b3a4a', 1));
    }
  }
  return out;
}

/**
 * Accesorio de montaje de la cámara (§24): en **pared**, una escuadra que sale hacia atrás; en
 * **techo**, el tubo que la cuelga; en **poste**, el mástil que sube desde el suelo. Es lo que dice
 * de qué va sujeta y, de paso, lo que hay que pedir al distribuidor.
 */
export function montajeDeCamara(pos, giro = 0, tipo = 'pared', forma = 'dome') {
  const cs = Math.cos(giro), sn = Math.sin(giro);
  const P = (u, v, dz) => ({ x: pos.x + u * cs + v * sn, y: pos.y - u * sn + v * cs, z: pos.z + dz });
  const metal = '#6b7482';
  const out = [];
  const caja = (v0, v1, u0, u1, z0, z1, col) => {
    const esq = [P(u0, v0, 0), P(u1, v0, 0), P(u1, v1, 0), P(u0, v1, 0)];
    const abajo = esq.map((p) => ({ ...p, z: p.z + z0 }));
    const arriba = esq.map((p) => ({ ...p, z: p.z + z1 }));
    const caras = [{ puntos: arriba.slice(), color: col, opacidad: 1 },
      { puntos: abajo.slice().reverse(), color: col, opacidad: 1 }];
    for (let i = 0; i < 4; i++) {
      const j = (i + 1) % 4;
      caras.push({ puntos: [abajo[i], abajo[j], arriba[j], arriba[i]], color: col, opacidad: 1 });
    }
    return { tipo: 'caja', color: col, opacidad: 1, caras };
  };
  if (tipo === 'poste') {
    // Mástil desde el suelo: deja claro que la cámara no está colgada de la pared
    out.push(tambor({ x: pos.x, y: pos.y, z: 0 }, { x: pos.x, y: pos.y, z: pos.z }, 0.05, metal, 6, 1));
    out.push(caja(-0.02, 0.1, -0.03, 0.03, -0.12, 0.02, metal));
  } else if (tipo === 'techo') {
    out.push(tambor(P(0, 0, 0), P(0, 0, 0.3), 0.035, metal, 6, 1));
  } else {
    // Escuadra de pared: un brazo corto hacia atrás y la plaquita que atornilla al paramento
    const atras = forma === 'bullet' || forma === 'thermal' || forma === 'dual' || forma === 'box' ? 0.14 : 0.1;
    out.push(caja(-atras, 0.02, -0.035, 0.035, -0.03, 0.03, metal));
    out.push(caja(-atras - 0.02, -atras + 0.01, -0.075, 0.075, -0.1, 0.1, '#59636f'));
  }
  return out;
}


/**
 * Caja envolvente de la escena (incluida la altura), para encuadrar y para la retícula del suelo.
 */
export function cajaDelProyecto(prj, alturaMuro = 2.8) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = 0;
  for (const e of (prj && prj.entities) || []) {
    const pts = (e.points || []).filter(Boolean);
    if (!pts.length) continue;
    for (const p of pts) {
      minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
    }
    const d = (e.data || {});
    const h = d.altura !== undefined ? d.altura : d.h !== undefined ? d.h : (d.muro ? alturaMuro : 0);
    maxZ = Math.max(maxZ, (d.base || 0) + h);
  }
  if (!isFinite(minX)) return null;
  const margen = Math.max(2, (maxX - minX) * 0.06);
  return { minX: minX - margen, minY: minY - margen, maxX: maxX + margen, maxY: maxY + margen, maxZ: Math.max(2.8, maxZ) };
}

/** Vista isométrica predefinida, la que se usa al entrar en 3D. */
export const VISTAS = [
  { id: 'iso', etiqueta: 'Isométrica', azimut: 35, elevacion: 35 },
  { id: 'norte', etiqueta: 'Desde el norte', azimut: 0, elevacion: 25 },
  { id: 'sur', etiqueta: 'Desde el sur', azimut: 180, elevacion: 25 },
  { id: 'este', etiqueta: 'Desde el este', azimut: 90, elevacion: 25 },
  { id: 'oeste', etiqueta: 'Desde el oeste', azimut: 270, elevacion: 25 },
  { id: 'cenital', etiqueta: 'Cenital (como la planta)', azimut: 0, elevacion: 88 },
  { id: 'baja', etiqueta: 'A la altura de los ojos', azimut: 35, elevacion: 6 },
];

export function aplicarVista(cam, id) {
  const v = VISTAS.find((x) => x.id === id);
  if (!v) return cam;
  cam.azimut = v.azimut;
  cam.elevacion = v.elevacion;
  return cam;
}
