/**
 * CCTV DESIGN PRO — Paletas de herramientas (CP CCTV §7, §8)
 * core/palettes.js — cómo se agrupan las herramientas en la barra lateral.
 *
 * Módulo **declarativo y puro**: solo describe grupos y botones. Quien los pinta es `main.js`, así
 * que reorganizar la interfaz es tocar esta lista y nada más.
 *
 * La agrupación es la de siempre en AutoCAD y en las herramientas de diseño de vídeo: **Dibujo**
 * (crear), **Modificar** (editar lo creado) y **Anotación** (textos y medidas), más las pestañas
 * del oficio (obstáculos), la de **Vista** y la de **Proyecto** (cálculos). Dentro de cada pestaña
 * las herramientas van en **grupos** («Dibujar», «Transformar», «Portapapeles»…), como en la cinta
 * de AutoCAD, y cada botón lleva icono, texto y una explicación para el `title`: lo que antes era
 * una ristra de 40 iconos sin rótulo, donde costaba encontrar cada cosa.
 *
 * Cada herramienta es `{ grupo, act, icono, etiqueta, title }` y todas las acciones existen en el
 * mapa de acciones de `main.js`.
 */

/** Busca herramientas por nombre: es la forma rápida de encontrar una sin recorrer las paletas. */
export function buscarEnPaletas(texto, paletas = PALETAS) {
  const q = String(texto || '').trim().toLowerCase();
  if (!q) return [];
  const fuera = [];
  for (const p of paletas) {
    for (const it of p.items) {
      const donde = `${it.etiqueta} ${it.title || ''} ${it.act} ${p.titulo}`.toLowerCase();
      if (donde.includes(q)) fuera.push(Object.assign({}, it, { paleta: p.titulo }));
    }
  }
  return fuera;
}

/** Todas las herramientas en una lista plana (para contar y para las pruebas). */
export function todasLasHerramientas(paletas = PALETAS) {
  return paletas.flatMap((p) => p.items.map((it) => Object.assign({}, it, { paleta: p.id })));
}

export const PALETAS = [
  {
    id: 'dibujo', titulo: 'Dibujo', icono: '✎', abierta: true,
    nota: 'Crear geometría y colocar equipos',
    items: [
      { grupo: 'Navegar', act: 'tool:select', icono: '➤', etiqueta: 'Seleccionar', title: 'Seleccionar y editar objetos (tiradores, mover, girar…). Esc vuelve a esta herramienta desde cualquier otra' },
      { grupo: 'Navegar', act: 'tool:lasso', icono: '⌇', etiqueta: 'Lazo', title: 'Lazo: arrastrar dibuja un polígono libre. Antihorario → coge solo lo que cabe dentro (azul); horario → coge lo que toca (verde). Mayús añade; Esc cancela' },
      { grupo: 'Navegar', act: 'tool:pan', icono: '✥', etiqueta: 'Desplazar', title: 'Desplazar la vista — también rueda pulsada o arrastrando el botón derecho' },
      { grupo: 'Dibujar', act: 'tool:line', icono: '╱', etiqueta: 'Línea', title: 'Línea: dos clics' },
      { grupo: 'Dibujar', act: 'tool:polyline', icono: '⟋', etiqueta: 'Polilínea', title: 'Polilínea: un clic por vértice, Enter o doble clic para terminar' },
      { grupo: 'Dibujar', act: 'tool:rect', icono: '▭', etiqueta: 'Rectángulo', title: 'Rectángulo: dos esquinas' },
      { grupo: 'Dibujar', act: 'tool:circle', icono: '◯', etiqueta: 'Círculo', title: 'Círculo: centro y radio' },
      { grupo: 'Dibujar', act: 'tool:arc', icono: '◜', etiqueta: 'Arco', title: 'Arco: centro, inicio y fin (tres clics)' },
      { grupo: 'Insertar', act: 'tool:room', icono: '▢', etiqueta: 'Zona', title: 'Zona de interés: contorno cerrado' },
      { grupo: 'Insertar', act: 'tool:pzona', icono: '⛔', etiqueta: 'Zona privada', title: 'Zona de privacidad: vía pública, finca vecina o zona de intimidad. Lo que caiga dentro no cuenta como superficie a cubrir' },
      { grupo: 'Insertar', act: 'tool:mascara', icono: '▨', etiqueta: 'Máscara', title: 'Máscara de privacidad: recuadro que la cámara no graba. Se descuenta de la cobertura real' },
      { grupo: 'Insertar', act: 'tool:camera', icono: '📷', etiqueta: 'Cámara', title: 'Colocar una cámara del catálogo' },
      { grupo: 'Insertar', act: 'tool:device', icono: '🖧', etiqueta: 'Equipo', title: 'Colocar switch, NVR, router, patch panel o UPS' },
    ],
  },
  {
    id: 'modificar', titulo: 'Modificar', icono: '✧', abierta: true,
    nota: 'Editar lo seleccionado: M mover · R girar · S escalar · E espejo · Ctrl+C/V copiar y pegar',
    items: [
      { grupo: 'Transformar', act: 'cmd:mover', icono: '✥', etiqueta: 'Mover', title: 'Mover: punto base y destino (M)' },
      { grupo: 'Transformar', act: 'cmd:rotar', icono: '⟳', etiqueta: 'Girar', title: 'Girar: centro de giro y ángulo, arrastrando o escribiéndolo (R)' },
      { grupo: 'Transformar', act: 'cmd:escalar', icono: '⤢', etiqueta: 'Escalar', title: 'Escalar: base, longitud de referencia y nueva longitud (S)' },
      { grupo: 'Transformar', act: 'cmd:espejo', icono: '⇋', etiqueta: 'Espejo', title: 'Espejo: dos puntos definen el eje (E)' },
      { grupo: 'Portapapeles', act: 'edit:copiar', icono: '⧉', etiqueta: 'Copiar', title: 'Copiar al portapapeles (Ctrl+C)' },
      { grupo: 'Portapapeles', act: 'edit:pegar', icono: '📋', etiqueta: 'Pegar', title: 'Pegar: haga clic donde irá (Ctrl+V)' },
      { grupo: 'Portapapeles', act: 'edit:cortar', icono: '✂', etiqueta: 'Cortar', title: 'Cortar al portapapeles (Ctrl+X)' },
      { grupo: 'Portapapeles', act: 'edit:duplicate', icono: '⧉⧉', etiqueta: 'Duplicar', title: 'Duplicar en el sitio (Ctrl+D)' },
      { grupo: 'Geometría', act: 'edit:vertice:mas', icono: '＋', etiqueta: 'Insertar vértice', title: 'Añade un vértice en el último tramo' },
      { grupo: 'Geometría', act: 'edit:vertice:menos', icono: '－', etiqueta: 'Quitar vértice', title: 'Quita el último vértice' },
      { grupo: 'Geometría', act: 'edit:cerrar', icono: '⬡', etiqueta: 'Cerrar o abrir', title: 'Cierra o abre la figura seleccionada' },
      { grupo: 'Geometría', act: 'edit:delete', icono: '🗑', etiqueta: 'Eliminar', title: 'Eliminar la selección (Supr)', danger: true },
      { grupo: 'Geometría', act: 'edit:propiedades', icono: '⚙', etiqueta: 'Propiedades', title: 'Panel de propiedades del objeto seleccionado' },
      { grupo: 'Historial', act: 'edit:undo', icono: '↶', etiqueta: 'Deshacer', title: 'Deshacer (Ctrl+Z)' },
      { grupo: 'Historial', act: 'edit:redo', icono: '↷', etiqueta: 'Rehacer', title: 'Rehacer (Ctrl+Mayús+Z)' },
    ],
  },
  {
    id: 'anotacion', titulo: 'Anotación', icono: '🏷', abierta: false,
    nota: 'Textos, medidas y escala del plano (§9, §10)',
    items: [
      { grupo: 'Anotar', act: 'tool:text', icono: 'T', etiqueta: 'Texto', title: 'Texto de anotación: se escribe y se coloca' },
      { grupo: 'Anotar', act: 'panel:project', icono: '🗒', etiqueta: 'Notas del plano', title: 'Datos y notas del proyecto, que acompañan a la documentación' },
      { grupo: 'Medir', act: 'tool:measure', icono: '📏', etiqueta: 'Medir', title: 'Medir distancias: dos clics' },
      { grupo: 'Medir', act: 'escala:referencia', icono: '⇲', etiqueta: 'Escalar por referencia', title: 'Mida una distancia conocida y escale el plano a la medida real' },
      { grupo: 'Medir', act: 'panel:escala', icono: '⚖', etiqueta: 'Unidades y escala', title: 'Unidad del plano importado y factor de escala (§9, §10)' },
    ],
  },
  {
    id: 'obstaculos', titulo: 'Obstáculos', icono: '🧱', abierta: false,
    nota: 'Muros y elementos con altura (§9, §13)',
    items: [
      { grupo: 'Cerramientos', act: 'obs:muro', icono: '🧱', etiqueta: 'Muro', title: 'Muro (2,80 m): clic en cada vértice' },
      { grupo: 'Cerramientos', act: 'obs:tabique', icono: '▮', etiqueta: 'Tabique', title: 'Tabique (2,60 m)' },
      { grupo: 'Cerramientos', act: 'obs:puerta', icono: '🚪', etiqueta: 'Puerta', title: 'Puerta (hueco): dos clics' },
      { grupo: 'Cerramientos', act: 'obs:ventana', icono: '🪟', etiqueta: 'Ventana', title: 'Ventana (de 0,90 a 2,30 m): dos clics' },
      { grupo: 'Cerramientos', act: 'obs:cerca', icono: '⛓', etiqueta: 'Cerca', title: 'Cerca perimetral (2,00 m)' },
      { grupo: 'Elementos', act: 'obs:arbol', icono: '🌳', etiqueta: 'Árbol', title: 'Árbol (4,00 m): un clic' },
      { grupo: 'Elementos', act: 'obs:persona', icono: '🧍', etiqueta: 'Persona', title: 'Persona (1,75 m): referencia de altura' },
      { grupo: 'Elementos', act: 'obs:mobiliario', icono: '🪑', etiqueta: 'Mobiliario', title: 'Mobiliario bajo (0,80 m)' },
      { grupo: 'Elementos', act: 'obs:escalera', icono: '🪜', etiqueta: 'Escalera', title: 'Escalera (2,80 m): peldaños, descansillos y barandilla' },
      { grupo: 'Herramientas', act: 'panel:obstaculos', icono: '▣', etiqueta: 'Paleta completa', title: 'Los obstáculos del catálogo, los muros del plano y las alturas' },
      { grupo: 'Herramientas', act: 'muro:detectar', icono: '⌗', etiqueta: 'Detectar muros', title: 'Marca como muros las capas del plano importado (MUROS, WALL…)' },
    ],
  },
  {
    id: 'vista', titulo: 'Vista', icono: '👁', abierta: false,
    nota: 'Zoom, rejilla, 3D y aspecto del espacio de trabajo',
    items: [
      { grupo: 'Zoom', act: 'plan:fit', icono: '⤢', etiqueta: 'Zoom extensión', title: 'Ver todo el dibujo (Z)' },
      { grupo: 'Zoom', act: 'plan:zoomVentana', icono: '⛶', etiqueta: 'Zoom ventana', title: 'Zoom a una ventana: dos clics (W)' },
      { grupo: 'Zoom', act: 'plan:zoomPrev', icono: '↩', etiqueta: 'Zoom anterior', title: 'Volver a la vista anterior (R sin selección)' },
      { grupo: 'Zoom', act: 'plan:zoomReal', icono: '1:1', etiqueta: 'Zoom 1:1', title: '1 píxel = 1 metro' },
      { grupo: 'Zoom', act: 'plan:planoEncuadrar', icono: '🗺', etiqueta: 'Encuadrar plano', title: 'Encuadrar el plano importado' },
      { grupo: 'Espacio', act: 'ver:3d', icono: '🎲', etiqueta: 'Vista 3D', title: 'Vista 3D: muros extruidos y haces de las cámaras' },
      { grupo: 'Espacio', act: 'plan:grid', icono: '▦', etiqueta: 'Rejilla', title: 'Rejilla visible (F7)' },
      { grupo: 'Espacio', act: 'plan:snap', icono: '🧲', etiqueta: 'Forzado', title: 'Forzado a rejilla (F9)' },
      { grupo: 'Espacio', act: 'panel:layers', icono: '🗂', etiqueta: 'Capas', title: 'Capas y colores' },
      { grupo: 'Espacio', act: 'panel:options', icono: '🖱', etiqueta: 'Opciones de dibujo', title: 'Puntero, colores, forzados y espacio de trabajo' },
    ],
  },
  {
    id: 'proyecto', titulo: 'Proyecto', icono: '📐', abierta: false,
    nota: 'Cálculos del proyecto (§13 a §30)',
    items: [
      { grupo: 'Calcular', act: 'calc:all', icono: '∑', etiqueta: 'Calcular todo', title: 'Recalcular cobertura, cableado, PoE, disco y presupuesto' },
      { grupo: 'Calcular', act: 'cov:analyze', icono: '◔', etiqueta: 'Cobertura', title: 'Analizar la cobertura de las cámaras' },
      { grupo: 'Calcular', act: 'cable:generate', icono: '⇢', etiqueta: 'Rutas', title: 'Generar rutas de cable' },
      { grupo: 'Calcular', act: 'net:assign', icono: '⚡', etiqueta: 'Red', title: 'Asignación automática de switches' },
      { grupo: 'Calcular', act: 'rack:auto', icono: '▤', etiqueta: 'Rack', title: 'Distribuir el rack' },
      { grupo: 'Calcular', act: 'val:run', icono: '✔', etiqueta: 'Validar', title: 'Validar el proyecto (§30)' },
    ],
  },
];
