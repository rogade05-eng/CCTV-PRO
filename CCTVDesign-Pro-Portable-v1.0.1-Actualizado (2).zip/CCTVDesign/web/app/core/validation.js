/**
 * CCTV DESIGN PRO — Sistema de validación (CP CCTV §30)
 * Las diez comprobaciones exigidas antes de cerrar un proyecto, más ampliaciones.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { isPtz, validatePtz } from './ptz.js?v=b441e3fc';
import { validateLpr, isLpr } from './lpr.js?v=b441e3fc';
import { validateAnalytics, cameraRules } from './analytics.js?v=b441e3fc';
import { validateFiber } from './fiber.js?v=b441e3fc';
import { validateAnalog, analogPlan } from './analog.js?v=b441e3fc';
import { analisisPrivacidad, clasificacionIA, zonasDe, mascarasDe, NIVELES_IA } from './privacy.js?v=b441e3fc';

export function validateProject(prj, catalog, rules, res) {
  const issues = [];
  const add = (code, title, severity, items, advice) => issues.push({ code, title, severity, count: items.length, items, advice });
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const devices = prj.entities.filter((e) => e.type === 'device');
  const cables = prj.entities.filter((e) => e.type === 'cable');
  const name = (e) => (e.data && (e.data.label || e.data.name)) || e.id;

  // 1. Cámaras sin datos
  const noData = cams.filter((c) => !c.data.catalogId || !c.data.label || !c.data.height || c.data.azimuth === undefined || !getItem(catalog, c.data.catalogId));
  add('CAM_SIN_DATOS', 'Cámaras sin datos completos', noData.length ? 'error' : 'ok', noData.map(name),
    ['Asigne fabricante y modelo desde el catálogo', 'Complete etiqueta, altura y orientación']);

  // 2. Cámaras sin cobertura
  const noCov = (res.coverage && res.coverage.cameras ? res.coverage.cameras : []).filter((c) => c.area <= 0);
  add('CAM_SIN_COBERTURA', 'Cámaras sin cobertura útil', noCov.length ? 'error' : 'ok', noCov.map((c) => c.label),
    ['Compruebe que la cámara está orientada hacia una zona de interés', 'Verifique que un muro no bloquee por completo el cono de visión', 'Aumente la altura o cambie la lente']);

  // 3. Objetivos de vigilancia no alcanzados
  const objFail = (res.coverage && res.coverage.cameras ? res.coverage.cameras : []).filter((c) => !c.meetsObjective);
  add('OBJETIVO_NO_ALCANZADO', 'Cámaras que no alcanzan su objetivo de vigilancia', objFail.length ? 'warn' : 'ok',
    objFail.map((c) => `${c.label} (${c.objectiveLabel})`),
    ['Aumente la distancia focal', 'Acerque la cámara a la zona a vigilar', 'Seleccione una cámara de mayor resolución']);

  // 4. Cables excesivos
  const overLen = cables.filter((c) => c.data.distanceStatus === 'EXCESIVA');
  add('CABLE_EXCESIVO', 'Enlaces que superan la distancia máxima', overLen.length ? 'error' : 'ok',
    overLen.map((c) => `${(prj.entities.find((e) => e.id === c.data.from) || { data: {} }).data.label || c.data.from} — ${Math.round(c.data.net)} m`),
    ['Agregar switch o punto de concentración', 'Modificar la ruta', 'Utilizar fibra óptica con conversores']);

  // 5. Rutas inexistentes
  const noRoute = cams.filter((c) => !cables.some((cb) => cb.data.from === c.id));
  add('RUTA_INEXISTENTE', 'Cámaras sin ruta de cable calculada', noRoute.length ? 'error' : 'ok', noRoute.map(name),
    ['Ejecute Cableado → Generar rutas', 'Asigne un switch a la cámara', 'Revise que existan pasos accesibles entre la cámara y el switch']);

  // 6. PoE insuficiente
  const poeBad = (res.poe && res.poe.groups ? res.poe.groups : []).filter((g) => g.status === 'INSUFICIENTE');
  const poeLow = (res.poe && res.poe.groups ? res.poe.groups : []).filter((g) => g.status === 'RESERVA BAJA');
  add('POE_INSUFICIENTE', 'Presupuesto PoE insuficiente', poeBad.length ? 'error' : poeLow.length ? 'warn' : 'ok',
    [...poeBad, ...poeLow].map((g) => `${g.label}: ${g.totalPower.toFixed(1)} / ${g.budget} W`),
    ['Reparta cámaras entre más switches', 'Seleccione un switch con mayor presupuesto PoE', 'Alimente alguna cámara con fuente externa']);

  // 7. NVR insuficiente
  const nvrIssues = [];
  if (res.storage) {
    if (res.storage.channelsOk === false) nvrIssues.push(`Canales: ${cams.length} cámaras > ${res.storage.channels} canales del NVR`);
    if (res.storage.capacityOk === false) nvrIssues.push(`Ancho de banda: ${res.storage.totalMbps.toFixed(1)} Mbps > ${res.storage.capacityMbps} Mbps`);
    if (!res.storage.nvrInfo.length) nvrIssues.push('No hay ningún NVR definido');
  }
  add('NVR_INSUFICIENTE', 'NVR insuficiente o ausente', nvrIssues.length ? 'error' : 'ok', nvrIssues,
    ['Seleccione un NVR con más canales', 'Reduzca bitrate o fps de alguna cámara', 'Añada un segundo grabador']);

  // 8. Almacenamiento insuficiente
  const stIssue = [];
  if (res.storage) {
    if (!res.storage.enough) stIssue.push(`Instalado ${res.storage.installedTb} TB < necesario ${res.storage.requiredTb.toFixed(2)} TB (${rules.DIAS_GRABACION} días)`);
    if (res.storage.retentionDays && res.storage.retentionDays < Number(rules.DIAS_GRABACION) - 0.5)
      stIssue.push(`Retención real ${res.storage.retentionDays.toFixed(1)} días`);
  }
  add('ALMAC_INSUFICIENTE', 'Almacenamiento insuficiente', stIssue.length ? 'error' : 'ok', stIssue,
    res.storage && res.storage.recommendation
      ? [`Instale ${res.storage.recommendation.qty} × ${res.storage.recommendation.model} (${res.storage.recommendation.totalTb} TB)`]
      : ['Añada discos de vigilancia', 'Reduzca días de retención o active grabación por movimiento']);

  // 9. Equipos sin precio
  const noPrice = [];
  const seen = new Set();
  for (const e of [...cams, ...devices]) {
    const it = getItem(catalog, e.data.catalogId);
    if (it && !Number(it.price) && !seen.has(it.id)) { seen.add(it.id); noPrice.push(`${it.manufacturer} ${it.model}`); }
  }
  add('EQUIPO_SIN_PRECIO', 'Equipos sin precio en catálogo', noPrice.length ? 'warn' : 'ok', noPrice,
    ['Importe el catálogo real del distribuidor (CSV/XLSX)', 'Edite el precio en Catálogo → Precios']);

  // 10. Equipos incompatibles
  const incompat = [];
  for (const c of cams) {
    const it = getItem(catalog, c.data.catalogId);
    if (!it) continue;
    if (it.specs && it.specs.analog && c.data.switchId) incompat.push(`${name(c)} es analógica y está asignada a un switch IP`);
    if (it.specs && it.specs.poe && c.data.switchId) {
      const sw = prj.entities.find((e) => e.id === c.data.switchId);
      const sit = sw && getItem(catalog, sw.data.catalogId);
      if (sit && !(sit.specs.poeBudget > 0)) incompat.push(`${name(c)} requiere PoE pero ${name(sw)} no lo suministra`);
    }
  }
  const groups = (res.poe && res.poe.groups) || [];
  for (const g of groups) if (g.portsStatus === 'EXCEDIDO') incompat.push(`${g.label}: ${g.cameras} cámaras en ${g.usablePorts} puertos útiles`);
  if (res.rack && res.rack.used > res.rack.capacity) incompat.push(`Rack: ${res.rack.used} U ocupadas de ${res.rack.capacity} U`);
  add('EQUIPO_INCOMPATIBLE', 'Equipos incompatibles', incompat.length ? 'error' : 'ok', incompat,
    ['Revise la alimentación de cada cámara', 'Amplíe puertos o añada switches', 'Cambie a un rack de mayor capacidad']);

  // 11. Elementos sin ubicación
  const noPos = [...cams, ...devices].filter((e) => !e.points || !e.points.length || !isFinite(e.points[0].x) || !isFinite(e.points[0].y));
  add('SIN_UBICACION', 'Elementos sin ubicación', noPos.length ? 'error' : 'ok', noPos.map(name),
    ['Coloque el elemento sobre el plano', 'Compruebe las coordenadas introducidas manualmente']);

  // 12. Zonas críticas descubiertas
  const crit = (res.coverage && res.coverage.criticalGaps) || [];
  add('ZONA_CRITICA', 'Zonas críticas con áreas descubiertas', crit.length ? 'warn' : 'ok',
    crit.map((z) => `${z.name}: ${z.pct.toFixed(0)} % cubierto`),
    ['Añada una cámara dedicada', 'Reoriente una cámara próxima', 'Revise obstáculos que generen sombras']);

  // 13. Cámaras sin switch
  const noSw = cams.filter((c) => !c.data.switchId);
  add('CAM_SIN_SWITCH', 'Cámaras sin switch asignado', noSw.length ? 'error' : 'ok', noSw.map(name),
    ['Ejecute Red → Asignación automática', 'Añada un switch PoE cerca de la cámara']);

  // 14. Módulo PTZ (§38): presets dentro de los límites mecánicos, permanencias y ciclo de patrulla
  const ptzCams = cams.filter((c) => isPtz(c, catalog));
  const ptzIssues = ptzCams.flatMap((c) => validatePtz(c, catalog, rules));
  const ptzBad = ptzIssues.filter((i) => i.severity === 'error');
  const ptzWarn = ptzIssues.filter((i) => i.severity === 'warn');
  if (ptzCams.length) {
    add('PTZ_PRESETS', 'Cámaras PTZ: presets, patrulla y límites mecánicos',
      ptzBad.length ? 'error' : ptzWarn.length ? 'warn' : 'ok',
      [...ptzBad, ...ptzWarn].map((i) => i.text),
      ['Revise el azimut y la inclinación de cada preset', 'Aumente la permanencia de las posiciones críticas',
       'Acorte el ciclo de patrulla repartiendo las posiciones entre varias cámaras']);
    const info = ptzIssues.filter((i) => i.severity === 'info');
    if (info.length) add('PTZ_ALIMENTACION', 'Alimentación de las cámaras PTZ', 'info', info.map((i) => i.text),
      ['Confirme que el switch entrega PoE+ (802.3at/bt)', 'Revise la reserva de presupuesto PoE']);
  }

  // 15. Módulo LPR (§38): caracteres legibles, ángulo de lectura y emborronamiento
  const lprCams = cams.filter((c) => isLpr(c, catalog));
  const lprIssues = validateLpr(prj, catalog, rules);
  if (lprCams.length) {
    const bad = lprIssues.filter((i) => i.severity === 'error');
    const warn = lprIssues.filter((i) => i.severity === 'warn');
    add('LPR_LECTURA', 'Cámaras de lectura de matrículas (LPR)', bad.length ? 'error' : warn.length ? 'warn' : 'ok',
      (bad.length + warn.length === 0 ? [`${lprCams.length} cámara(s) LPR: caracteres legibles, ángulo y emborronamiento dentro de los criterios`] : [])
        .concat([...bad, ...warn, ...lprIssues.filter((i) => i.severity === 'info')].map((i) => i.text)),
      ['Acerque la cámara al punto de lectura o aumente la focal', 'Reduzca el ángulo de montaje por debajo de 30°',
       'Baje el tiempo de obturación (1/2000 s o menos) para congelar el movimiento', 'Añada iluminación IR para la lectura nocturna']);
  }

  // 16. Módulo de analítica de vídeo (§38)
  const anIssues = validateAnalytics(prj, catalog, rules, res.coverage || {});
  const anRuleCount = cams.reduce((a, c) => a + cameraRules(c).length, 0);
  if (anRuleCount) {
    const bad = anIssues.filter((i) => i.severity === 'error');
    const warn = anIssues.filter((i) => i.severity === 'warn');
    const info = anIssues.filter((i) => i.severity === 'info');
    add('ANALITICA', 'Analítica de vídeo: zonas, densidad y licencias',
      bad.length ? 'error' : warn.length ? 'warn' : info.length ? 'info' : 'ok',
      (bad.length + warn.length === 0 ? [`${anRuleCount} regla(s) de analítica con zona cubierta y densidad suficiente`] : [])
        .concat([...bad, ...warn, ...info].map((i) => i.text)),
      ['Asegure que la zona de la regla está dentro del campo de visión', 'Suba la resolución o acerque la cámara para ganar ppm',
       'Añada acciones (alarma, correo, cierre) a las reglas críticas']);
  }

  // 17. Módulo de fibra óptica (§38)
  const fbIssues = validateFiber(prj, catalog, rules);
  const fbLinks = prj.entities.filter((e) => e.type === 'cable' && (e.data.media === 'fiber' || (Number(e.data.net) || 0) > Number(rules.MAX_UTP || 90)));
  if (fbLinks.length) {
    const bad = fbIssues.filter((i) => i.severity === 'error');
    const warn = fbIssues.filter((i) => i.severity === 'warn');
    const info = fbIssues.filter((i) => i.severity === 'info');
    add('FIBRA', 'Enlaces de fibra óptica: presupuesto de potencia',
      bad.length ? 'error' : warn.length ? 'warn' : info.length ? 'info' : 'ok',
      [...bad, ...warn, ...info].map((i) => i.text),
      ['Atenúe el presupuesto con un transceptor de mayor alcance', 'Revise conectores y empalmes de la ruta',
       'Añada ODF y latiguillos en ambos extremos']);
  }

  // 18. Módulo de vídeo analógico (§38): coaxial, canales del DVR y alimentación a 12 V
  const anPl = analogPlan(prj, catalog, rules);
  if (anPl.count) {
    const anIssues = validateAnalog(prj, catalog, rules);
    const bad = anIssues.filter((i) => i.severity === 'error');
    const warn = anIssues.filter((i) => i.severity === 'warn');
    add('ANALOGICO', 'Vídeo analógico: distancias, canales y alimentación',
      bad.length ? 'error' : warn.length ? 'warn' : 'ok',
      (bad.length + warn.length === 0
        ? [`${anPl.count} cámara(s) analógica(s) dentro del alcance, con ${anPl.recording.channels} canal(es) de grabación y ${anPl.power.voltsMin.toFixed(2)} V en la cámara más desfavorable`]
        : []).concat([...bad, ...warn].map((i) => i.text)),
      ['Acorte el tramo o suba a coaxial RG-6', 'Añada un grabador híbrido con los canales que faltan',
       'Suba la sección del cable de 12 V o coloque una fuente junto a las cámaras más lejanas']);
  }

  /* 19. Privacidad y protección de datos.
     Módulo **aditivo**: solo aparece si el proyecto declara zonas de privacidad o máscaras,
     igual que PTZ, LPR, analítica o fibra. Un proyecto sin zonas declaradas no cambia. */
  const hayPrivacidad = zonasDe(prj).length > 0 || mascarasDe(prj).length > 0;
  if (hayPrivacidad) {
    const an = (res && res.privacidad) || analisisPrivacidad(prj, catalog, rules, res || {});
    const r = an.resumen || {};
    const privItems = [];
    const terceros = (r.areaPublica || 0) + (r.areaTerceros || 0);
    const umbral = Number(rules.PRIV_UMBRAL_M2) || 0.5;
    if (terceros > umbral) privItems.push(`Vía pública o terceros a la vista: ${terceros.toFixed(1)} m²`);
    if ((r.areaSensible || 0) > 0) privItems.push(`Zonas de intimidad a la vista: ${r.areaSensible.toFixed(1)} m²`);
    if ((r.areaEnmascarada || 0) > 0) privItems.push(`${r.areaEnmascarada.toFixed(1)} m² ocultos con ${r.mascaras} máscara(s)`);
    const sensible = (r.areaSensible || 0) > 0;
    add('PRIVACIDAD', 'Captación de vía pública y zonas de intimidad',
      sensible || terceros > umbral ? 'error' : 'ok',
      privItems.length ? privItems : ['Ninguna cámara ve vía pública, propiedad de terceros ni zonas de intimidad'],
      ['Dibuje una máscara de privacidad sobre la zona ajena y recalcule',
        'Reoriente la cámara para que no alcance la vía pública',
        'Retire la cámara de las zonas de intimidad (vestuarios, baños, descanso)',
        'Configure el borrado automático al cumplir el plazo de conservación']);
  }

  /* 20. Reglamento de IA de la UE: aparece si el sistema hace algo más que grabar. */
  const ia = clasificacionIA(prj, catalog, rules);
  if (ia.cuenta.PROHIBIDO || ia.cuenta.ALTO || ia.cuenta.LIMITADO) {
    const malas = ia.filas.filter((f) => f.nivel === 'PROHIBIDO' || f.nivel === 'ALTO');
    add('AI_ACT', 'Reglamento de IA: clasificación de las funciones del sistema',
      ia.cuenta.PROHIBIDO ? 'error' : ia.cuenta.ALTO ? 'warn' : 'info',
      ia.filas.map((f) => `${f.funcion}: ${NIVELES_IA[f.nivel].etiqueta} (${f.articulo})`),
      malas.length ? malas.flatMap((f) => f.obligaciones) : ['Revise las obligaciones de transparencia del art. 50']);
  }

  const errors = issues.filter((i) => i.severity === 'error');
  const warns = issues.filter((i) => i.severity === 'warn');
  return {
    issues, errors, warnings: warns,
    ok: errors.length === 0,
    summary: `${errors.length} error(es), ${warns.length} aviso(s), ${issues.filter((i) => i.severity === 'ok').length} comprobación(es) correcta(s)`,
    checkedAt: new Date().toISOString(),
  };
}
