/**
 * CCTV DESIGN PRO — Unidades del plano importado y escalado (CP CCTV §9, §10)
 *
 * Un plano DXF/DWG guarda sus coordenadas en «unidades de dibujo»: para saber cuántos metros mide
 * una pared hay que saber en qué unidad se dibujó. El formato lo declara en la variable de cabecera
 * `$INSUNITS` (y orienta con `$MEASUREMENT`: 0 imperial, 1 métrico), pero hay tres problemas:
 *
 *   1. Muchísimos planos traen `$INSUNITS = 0` («sin unidad»), sobre todo los exportados por
 *      programas antiguos o por conversores.
 *   2. Los que sí lo declaran a veces mienten (un plano dibujado en milímetros y guardado como
 *      «metros» para que «cupiera» en el papel).
 *   3. Aunque la unidad sea correcta, el usuario puede querer importar en otra.
 *
 * Este módulo resuelve las tres cosas:
 *   · `inferirUnidad` deduce la unidad más probable a partir del tamaño del plano (un plano de
 *     30.000 unidades de ancho dibujado en metros mediría 30 km: casi seguro son milímetros).
 *   · `unidadPorInsunits` traduce la declaración del fichero.
 *   · `factorEscala` da el factor para dejar el plano en metros, que es la unidad interna (§10).
 *
 * Y, como el usuario pide, la escala se puede **corregir después de importar**: por unidad, por
 * factor directo o midiendo una distancia conocida (`escalarPorReferencia`).
 *
 * Módulo puro: sin DOM, sin cad y sin proyecto, para poder probarlo bajo Node.
 */

/* ------------------------------------------------------------------ catálogo */

/**
 * Unidades reconocidas. `metros` es el valor de una unidad de dibujo expresado en metros
 * (el factor que hay que aplicar para dejar el plano en metros). `insunits` es el código de la
 * variable de cabecera $INSUNITS del DXF (§9).
 */
export const UNIDADES = [
  { id: 'mm', etiqueta: 'Milímetros', abbr: 'mm', metros: 0.001, insunits: 4, familia: 'metrico', dibujo: 'métrico' },
  { id: 'cm', etiqueta: 'Centímetros', abbr: 'cm', metros: 0.01, insunits: 5, familia: 'metrico', dibujo: 'métrico' },
  { id: 'dm', etiqueta: 'Decímetros', abbr: 'dm', metros: 0.1, insunits: 14, familia: 'metrico', dibujo: 'métrico' },
  { id: 'm', etiqueta: 'Metros', abbr: 'm', metros: 1, insunits: 6, familia: 'metrico', dibujo: 'métrico' },
  { id: 'km', etiqueta: 'Kilómetros', abbr: 'km', metros: 1000, insunits: 7, familia: 'metrico', dibujo: 'métrico' },
  { id: 'in', etiqueta: 'Pulgadas', abbr: 'in', metros: 0.0254, insunits: 1, familia: 'imperial', dibujo: 'imperial' },
  { id: 'ft', etiqueta: 'Pies', abbr: 'ft', metros: 0.3048, insunits: 2, familia: 'imperial', dibujo: 'imperial' },
  { id: 'yd', etiqueta: 'Yardas', abbr: 'yd', metros: 0.9144, insunits: 10, familia: 'imperial', dibujo: 'imperial' },
  { id: 'mi', etiqueta: 'Millas', abbr: 'mi', metros: 1609.344, insunits: 3, familia: 'imperial', dibujo: 'imperial' },
  { id: 'mil', etiqueta: 'Milésimas de pulgada', abbr: 'mil', metros: 0.0000254, insunits: 9, familia: 'imperial', dibujo: 'imperial' },
];

/** Unidad que se usa cuando no se sabe nada: 1 unidad de dibujo = 1 metro. */
export const UNIDAD_POR_DEFECTO = 'm';

/** Unidad interna de cálculo de todo el programa (§10). */
export const UNIDAD_INTERNA = 'm';

/** Tamaño «normal» de una planta, en metros: sirve de referencia para la deducción. */
export const LADO_PLAUSIBLE_M = 40;

/** Margen de tamaños que se consideran una planta de edificio (en metros). */
export const RANGO_PLAUSIBLE_M = { min: 2, max: 1200 };

const POR_ID = new Map(UNIDADES.map((u) => [u.id, u]));
const POR_INSUNITS = new Map(UNIDADES.map((u) => [u.insunits, u]));

export function unidadPorId(id) {
  return POR_ID.get(String(id || '').toLowerCase()) || null;
}

/** Traduce el código de `$INSUNITS` del DXF (0 = sin declarar → null). */
export function unidadPorInsunits(codigo) {
  const c = parseInt(codigo, 10);
  if (!c) return null;
  return POR_INSUNITS.get(c) || null;
}

export function listaUnidades() {
  return UNIDADES.map((u) => ({ ...u }));
}

/* ------------------------------------------------------------- conversiones */

/** Pasa un valor expresado en `unidadId` a metros. */
export function aMetros(valor, unidadId) {
  const u = unidadPorId(unidadId);
  const f = u ? u.metros : 1;
  return (Number(valor) || 0) * f;
}

/** Pasa un valor en metros a `unidadId`. */
export function desdeMetros(metros, unidadId) {
  const u = unidadPorId(unidadId);
  const f = u ? u.metros : 1;
  return (Number(metros) || 0) / f;
}

/** Factor que hay que aplicar a un dibujo en `origen` para dejarlo en `destino`. */
export function factorEscala(origen, destino = UNIDAD_INTERNA) {
  const a = unidadPorId(origen), b = unidadPorId(destino);
  const fa = a ? a.metros : 1, fb = b ? b.metros : 1;
  if (!fa || !fb) return 1;
  return fa / fb;
}

/** Tamaño de una caja `{minX,minY,maxX,maxY}` expresada en `unidadId`, en metros. */
export function tamanoEnMetros(caja, unidadId) {
  if (!caja) return { ancho: 0, alto: 0, profundo: 0 };
  const f = (unidadPorId(unidadId) || { metros: 1 }).metros;
  return {
    ancho: (Number(caja.maxX) || 0) - (Number(caja.minX) || 0) * 1 === 0 ? 0 : ((caja.maxX - caja.minX) * f),
    alto: ((caja.maxY - caja.minY) * f),
  };
}

/* -------------------------------------------------------------- deducción */

/**
 * Deducir la unidad más probable de un plano a partir de su tamaño.
 *
 * La idea: probamos cada unidad y nos quedamos con la que deja la planta en un tamaño «de edificio».
 * Un plano de 30.000 unidades de ancho son 30 km en metros, 300 m en centímetros y 30 m en
 * milímetros → milímetros. Si el fichero declara `$MEASUREMENT` (0 imperial, 1 métrico) se favorece
 * la familia correspondiente, y si no, se respeta el orden natural.
 *
 * @param {object} caja caja envolvente en unidades de dibujo `{minX,minY,maxX,maxY}`
 * @param {number} [measurement] valor de `$MEASUREMENT` (0 imperial, 1 métrico, undefined = no sabe)
 * @returns {object} `{id, unidad, metros, confianza, motivo, candidatas}`
 */
export function inferirUnidad(caja, measurement) {
  const ancho = caja ? Math.abs((Number(caja.maxX) || 0) - (Number(caja.minX) || 0)) : 0;
  const alto = caja ? Math.abs((Number(caja.maxY) || 0) - (Number(caja.minY) || 0)) : 0;
  const lado = Math.max(ancho, alto);
  if (!(lado > 0)) {
    return { id: UNIDAD_POR_DEFECTO, unidad: unidadPorId(UNIDAD_POR_DEFECTO), metros: 0, confianza: 'ninguna',
      motivo: 'el plano no declara extensión', candidatas: [] };
  }
  const familia = measurement === 0 ? 'imperial' : measurement === 1 ? 'metrico' : null;
  const candidatas = [];
  for (const u of UNIDADES) {
    const m = lado * u.metros;
    if (m < RANGO_PLAUSIBLE_M.min || m > RANGO_PLAUSIBLE_M.max) continue;
    // Distancia (en escala logarítmica) al tamaño «normal» de una planta
    let puntos = Math.abs(Math.log10(m / LADO_PLAUSIBLE_M));
    if (familia && u.familia !== familia) puntos *= 1.6;      // penaliza la familia que no es la del fichero
    candidatas.push({ id: u.id, unidad: u, metros: m, puntos });
  }
  if (!candidatas.length) {
    // Ninguna encaja: el plano es enorme o minúsculo. Se devuelve la unidad que lo acerque al rango.
    let mejor = UNIDADES[0], mejorP = Infinity;
    for (const u of UNIDADES) {
      const m = lado * u.metros;
      const p = m < RANGO_PLAUSIBLE_M.min ? Math.log10(RANGO_PLAUSIBLE_M.min / m) : Math.log10(m / RANGO_PLAUSIBLE_M.max);
      if (p < mejorP) { mejorP = p; mejor = u; }
    }
    return { id: mejor.id, unidad: mejor, metros: lado * mejor.metros, confianza: 'baja',
      motivo: `el tamaño (${redondear(lado)} unidades) no encaja con ninguna unidad habitual`, candidatas: [] };
  }
  candidatas.sort((a, b) => a.puntos - b.puntos);
  const mejor = candidatas[0];
  const segunda = candidatas[1];
  let confianza = 'alta';
  if (segunda && mejor.puntos > 0.35) confianza = 'media';
  if (segunda && mejor.puntos > 0.9) confianza = 'baja';
  if (segunda && Math.abs(mejor.puntos - segunda.puntos) < 0.08) confianza = 'media';
  const motivo = `el plano mide ${redondear(lado)} unidades de lado: en ${mejor.unidad.etiqueta.toLowerCase()} serían ${formatearLongitud(mejor.metros, 'm', 1)}`
    + (segunda ? ` (y ${formatearLongitud(segunda.metros, 'm', 1)} en ${segunda.unidad.etiqueta.toLowerCase()})` : '');
  return { id: mejor.id, unidad: mejor.unidad, metros: mejor.metros, confianza, motivo,
    candidatas: candidatas.slice(0, 3).map((c) => ({ id: c.id, etiqueta: c.unidad.etiqueta, metros: c.metros, puntos: c.puntos })) };
}

/**
 * Unidad que se propone al importar: la que declara el fichero si la declara, y si no la deducida.
 * @param {object} rep informe del importador (`report` de `importDxfAuto`)
 */
export function unidadPropuesta(rep) {
  const r = rep || {};
  const declarada = unidadPorInsunits(r.units && r.units.code);
  if (declarada) {
    return {
      id: declarada.id, unidad: declarada, origen: 'declarada', confianza: 'alta',
      motivo: `el fichero declara $INSUNITS = ${declarada.insunits} (${declarada.etiqueta.toLowerCase()})`,
      alternativas: [],
    };
  }
  const inf = inferirUnidad(r.extents, r.measurement);
  return {
    id: inf.id, unidad: inf.unidad, origen: 'deducida', confianza: inf.confianza,
    motivo: inf.motivo, alternativas: inf.candidatas || [],
  };
}

/* ---------------------------------------------------------------- factores */

/**
 * Factor de escala a partir de dos medidas: la distancia dibujada (en unidades del plano) y la
 * distancia real que el usuario introduce (en la unidad que indique).
 */
export function escalarPorReferencia(distanciaDibujada, distanciaReal, unidadReal = UNIDAD_INTERNA) {
  const d = Number(distanciaDibujada), real = Number(distanciaReal);
  if (!(d > 0) || !(real > 0)) return null;
  const metros = aMetros(real, unidadReal);
  return { factor: metros / d, metros, dibujada: d, escala: `1 : ${redondear(d / metros, 3)}` };
}

/* --------------------------------------------------------------- formateo */

/** Redondeo estable para mensajes (evita «0.30000000000000004»). */
export function redondear(n, decimales = 2) {
  const f = Math.pow(10, decimales);
  return Math.round((Number(n) || 0) * f) / f;
}

/** Longitud en metros expresada en la unidad que se pida, con su abreviatura. */
export function formatearLongitud(metros, unidadId = UNIDAD_INTERNA, decimales) {
  const u = unidadPorId(unidadId);
  const v = desdeMetros(metros, unidadId);
  const dec = decimales === undefined ? (Math.abs(v) >= 100 ? 1 : Math.abs(v) >= 1 ? 2 : 3) : decimales;
  return `${redondear(v, dec)} ${u ? u.abbr : unidadId}`;
}

/** «1 : 100» a partir del factor que convierte unidades de dibujo en metros. */
export function formatearEscala(factor) {
  if (!factor || !isFinite(factor)) return '—';
  if (Math.abs(factor - 1) < 1e-9) return '1 : 1';
  return factor < 1 ? `1 : ${redondear(1 / factor, 2)}` : `${redondear(factor, 2)} : 1`;
}

/**
 * Aplica un factor de escala a una lista de entidades alrededor de un centro.
 * Devuelve el número de puntos modificados (para poder informar).
 */
export function escalarEntidades(entidades, factor, centro = { x: 0, y: 0 }) {
  const f = Number(factor);
  if (!isFinite(f) || Math.abs(f - 1) < 1e-12) return 0;
  const cx = Number(centro.x) || 0, cy = Number(centro.y) || 0;
  let n = 0;
  for (const e of entidades) {
    if (e.points && e.points.length) {
      for (const p of e.points) {
        p.x = cx + (p.x - cx) * f;
        p.y = cy + (p.y - cy) * f;
        n++;
      }
    }
    if (e.radius) { e.radius = e.radius * f; n++; }
    if (e.data && typeof e.data.height === 'number' && e.type === 'text') e.data.height *= f;
    if (e.data && typeof e.data.altura === 'number') e.data.altura *= f;      // la altura también escala
    if (e.data && typeof e.data.ancho === 'number') e.data.ancho *= f;
    if (e.data && typeof e.data.radio === 'number') e.data.radio *= f;
  }
  return n;
}
