/**
 * CCTV DESIGN PRO — Motor de materiales y presupuesto (CP CCTV §26, §27)
 * Cada elemento dibujado genera partidas reales: la regla maestra del §42.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum, rule } from './rules.js?v=b441e3fc';
import { fiberSummary } from './fiber.js?v=b441e3fc';
import { analogPlan } from './analog.js?v=b441e3fc';
import { analyticsSummary } from './analytics.js?v=b441e3fc';

export function buildBom(prj, catalog, rules, storage = {}) {
  const lines = [];
  const push = (itemId, qty, note = '', customPrice = null, unit = null) => {
    if (!qty || qty <= 0) return;
    const item = getItem(catalog, itemId);
    if (!item) { lines.push({ itemId, label: itemId + ' (no está en catálogo)', qty, unit: unit || 'ud', price: 0, total: 0, note, missing: true }); return; }
    const perUnit = Number((item.specs && item.specs.perUnit) || 1);
    const packUnits = Number((item.specs && item.specs.metersPerUnit) || 0);
    let units = qty, packs = qty, packLabel = item.unit || 'ud';
    if (packUnits > 0) { packs = Math.ceil(qty / packUnits); units = packs * packUnits; }
    else if (perUnit > 1) { packs = Math.ceil(qty / perUnit); units = packs * perUnit; }
    const price = customPrice === null ? Number(item.price) || 0 : customPrice;
    lines.push({
      itemId, label: `${item.manufacturer} ${item.model} — ${item.name}`, category: item.category,
      qty: packs, unit: packLabel, units, note, price, total: packs * price,
    });
  };

  const cams = prj.entities.filter((e) => e.type === 'camera');
  const cables = prj.entities.filter((e) => e.type === 'cable');
  const devices = prj.entities.filter((e) => e.type === 'device');
  const maxUtp = ruleNum(rules, 'MAX_UTP');

  // 1. Cámaras
  const camTally = new Map();
  for (const c of cams) camTally.set(c.data.catalogId, (camTally.get(c.data.catalogId) || 0) + 1);
  for (const [id, qty] of camTally) push(id, qty, 'Cámaras del diseño');

  // 2. Soportes y cajas por tipo de cámara
  for (const c of cams) {
    const it = getItem(catalog, c.data.catalogId);
    const form = it && it.specs ? it.specs.form : 'dome';
    if (form === 'dome' || form === 'fisheye') push('ACC-JBOX', 1, `${c.data.label || c.id}: caja de empalme`);
    else push('ACC-BRACKET', 1, `${c.data.label || c.id}: soporte de pared`);
    push('BOX-WALL', 1, `${c.data.label || c.id}: caja de conexión`);
    if ((it && it.specs && !it.specs.poe) || c.data.power === 'psu') push('ACC-PSU', 1, `${c.data.label || c.id}: alimentación 12 V`);
  }

  // 3. Cable por tipo: el medio lo manda el módulo de fibra (§38)
  const fiber = fiberSummary(prj, catalog, rules);
  const fiberIds = new Set(fiber.links.map((l) => l.id));
  const cableMeters = new Map();
  for (const cb of cables) {
    if (fiberIds.has(cb.id)) continue;
    const L = Number(cb.data.supply) || 0;
    cableMeters.set(cb.data.cableId || 'CBL-UTP6', (cableMeters.get(cb.data.cableId || 'CBL-UTP6') || 0) + L);
  }
  // Cableado estructurado de los enlaces IP (los analógicos van aparte, en su propio medio)
  for (const [id, m] of cableMeters) push(id, m, `Cableado de ${cables.length - fiber.links.length} enlace(s) de cobre`);

  // Módulo analógico (§38): coaxial o UTP con balun, conectores, fuente de 12 V y conversión
  const an = analogPlan(prj, catalog, rules);
  if (an.count) {
    const coax = an.rows.filter((l) => !l.balun);
    const rg59 = coax.filter((l) => l.cable.id === 'RG59');
    const rg6 = coax.filter((l) => l.cable.id === 'RG6');
    if (rg59.length) push('CBL-RG59', rg59.reduce((a, l) => a + l.distance * (1 + ruleNum(rules, 'RESERVA_CABLE') / 100), 0),
      `Coaxial RG-59 para ${rg59.length} cámara(s) analógica(s)`);
    if (rg6.length) push('CBL-RG6', rg6.reduce((a, l) => a + l.distance * (1 + ruleNum(rules, 'RESERVA_CABLE') / 100), 0),
      `Coaxial RG-6 para ${rg6.length} cámara(s) analógica(s)`);
    if (an.baluns) push('ACC-BALUN', an.baluns, 'Pares de balunes para los enlaces por UTP');
    push('ACC-BNC', Math.ceil((an.count * 2) / 10), `Conectores BNC (${an.count * 2} unidades en bolsas de 10)`);
    // El grabador híbrido (DVR) entra en el BOM como cualquier equipo colocado en el proyecto
    const psu = an.power.psuAmps > 0 ? Math.max(1, Math.ceil(an.power.needAmps / 5)) : Math.max(1, Math.ceil(an.power.needAmps / 5));
    push('ACC-PSU12', psu, `Fuentes de 12 V para ${an.rows.length} cámara(s) analógica(s) (${an.power.needAmps.toFixed(1)} A con reserva)`);
  }
  if (fiber.links.length) {
    const mm = fiber.links.filter((l) => l.type === 'MM');
    const sm = fiber.links.filter((l) => l.type !== 'MM');
    if (mm.length) push('CBL-FO-MM', mm.reduce((a, l) => a + l.supply, 0), `${mm.length} enlace(s) de fibra multimodo`);
    if (sm.length) push('CBL-FO-SM', sm.reduce((a, l) => a + l.supply, 0), `${sm.length} enlace(s) de fibra monomodo`);
    const sfpMM = mm.length * 2, sfpSM = sm.length * 2;
    if (sfpMM) push('ACC-SFP', sfpMM, 'Transceptores SFP multimodo (850 nm)');
    if (sfpSM) push('ACC-SFP-SM', sfpSM, 'Transceptores SFP monomodo (1310 nm)');
    push('ACC-FO-PIG', fiber.links.length * 2, 'Latiguillos de fibra en los dos extremos');
    if (fiber.splices > 0) push('ACC-FO-SPL', fiber.splices, `Protectores de empalme (${fiber.splices} empalmes)`);
    push('ACC-ODF', Math.max(1, Math.ceil(fiber.links.length / 12)), 'Panel de fibra (ODF) en el rack principal');
    if (fiber.converters > 0) push('ACC-MC', fiber.converters, 'Conversores de medio en los extremos sin puerto SFP');
  }

  // 4. Conectorizado
  const links = cables.length;
  if (links) {
    push('CON-RJ45', links * 2, `2 conectores por enlace (${links} enlaces)`);
    push('CON-KEY', links, 'Keystone en patch panel');
    push('ACC-PATCH1', links, 'Latiguillo cámara/patch');
    push('ACC-PATCH2', links, 'Latiguillo patch/switch');
  }

  // 5. Canalización
  const conduitMeters = new Map();
  for (const cb of cables) {
    const id = cb.data.conduitId || 'CAN-PVC20';
    conduitMeters.set(id, (conduitMeters.get(id) || 0) + (Number(cb.data.geometric) || 0));
  }
  for (const [id, m] of conduitMeters) push(id, m, 'Canalización de las rutas');

  // 6. Equipos de red y cabecera
  const devTally = new Map();
  for (const d of devices) devTally.set(d.data.catalogId, (devTally.get(d.data.catalogId) || 0) + 1);
  for (const [id, qty] of devTally) push(id, qty, 'Equipos de red y cabecera');

  // 7. Rack
  push(prj.rack.catalogId, 1, `Rack ${prj.rack.label}`);
  for (const it of prj.rack.items || []) {
    const item = getItem(catalog, it.itemId);
    if (item && (item.category === 'accessory' || item.category === 'patchpanel')) push(it.itemId, it.qty, 'Contenido del rack');
  }

  // 7.b Licencias de analítica cuando la cámara no la trae embarcada (§38)
  const analytics = analyticsSummary(prj, catalog, rules, storage.analytics && storage.analytics.coverage);
  if (analytics.licenses > 0) push('ACC-ANLIC', analytics.licenses, `Licencias de analítica: ${analytics.rules - analytics.licenses} regla(s) embarcada(s) y ${analytics.licenses} con licencia`);

  // 8. Almacenamiento
  const installedDisks = (storage.nvrInfo || []).reduce((a, n) => a + (n.disks || []).length, 0);
  const rec = storage.recommendation;
  if (!installedDisks && rec && !rec.infeasible) push(rec.itemId, rec.qty, `Almacenamiento para ${ruleNum(rules, 'DIAS_GRABACION')} días`);
  for (const n of storage.nvrInfo || [])
    for (const d of n.disks || []) push(d.itemId, d.qty, `Discos instalados en ${n.label}`);

  // Agrupa partidas repetidas
  const merged = new Map();
  for (const l of lines) {
    const k = l.itemId + '|' + (l.price || 0);
    if (merged.has(k)) {
      const m = merged.get(k);
      m.qty += l.qty; m.units = (m.units || 0) + (l.units || 0); m.total += l.total;
      m.note = m.note.includes(l.note) ? m.note : `${m.note}; ${l.note}`;
    } else merged.set(k, { ...l });
  }
  return Array.from(merged.values()).sort((a, b) => (a.category || '').localeCompare(b.category || '') || b.total - a.total);
}

export function buildBudget(bom, rules) {
  const margin = ruleNum(rules, 'MARGEN_PRESUPUESTO');
  const tax = ruleNum(rules, 'IMPUESTOS');
  const discount = ruleNum(rules, 'DESCUENTO');
  const transport = ruleNum(rules, 'COSTO_TRANSPORTE');
  const install = ruleNum(rules, 'COSTO_INSTALACION');
  const currency = rule(rules, 'MONEDA') || 'EUR';

  const lines = bom.map((l) => ({
    ...l,
    saleUnit: l.price * (1 + margin / 100),
    saleTotal: l.price * (1 + margin / 100) * l.qty,
    costTotal: l.price * l.qty,
  }));
  const costSum = lines.reduce((a, l) => a + l.costTotal, 0);
  const saleSum = lines.reduce((a, l) => a + l.saleTotal, 0);
  const discountAmt = (saleSum * discount) / 100;
  const base = saleSum - discountAmt + transport + install;
  const taxAmt = (base * tax) / 100;
  return {
    lines, currency, margin, tax, discount, transport, install,
    costSum, saleSum, discountAmt, base, taxAmt, total: base + taxAmt,
    profit: base - costSum, profitPct: base ? ((base - costSum) / base) * 100 : 0,
  };
}
