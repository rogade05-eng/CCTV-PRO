/**
 * CCTV DESIGN PRO — Edición de objetos (CP CCTV §8, §9, §11, §13)
 * core/edit.js — tiradores (grips), transformaciones y campos editables de cualquier entidad.
 *
 * Módulo **puro**: no toca el DOM ni el lienzo. El lienzo (`cad.js`) lo usa para que el usuario
 * arrastre los vértices con el ratón, y el panel de propiedades lo usa para saber qué campos de
 * cada objeto se pueden cambiar y con qué unidades y límites.
 *
 * La idea es la de siempre en este programa: una sola definición de cada cosa. Si aquí se dice que
 * una circunferencia se edita por centro y radio, el tirador del lienzo y la ficha del panel lo
 * leen del mismo sitio, y no pueden discrepar.
 */
import { dist } from './geometry.js?v=b441e3fc';
import { datosDe, obstaculoDe, OBSTACULOS, ALTURA_MURO } from './obstacles.js?v=b441e3fc';

/* ------------------------------------------------------------------ ángulos y medidas */

export const rad = (d) => (Number(d) || 0) * Math.PI / 180;
export const deg = (r) => (Number(r) || 0) * 180 / Math.PI;

/** Ángulo en grados de `desde` a `hasta`, en sentido antihorario y con el 0° en el este (+X). */
export function anguloDeg(desde, hasta) {
  const a = deg(Math.atan2((hasta.y || 0) - (desde.y || 0), (hasta.x || 0) - (desde.x || 0)));
  return normalizarAngulo(a);
}

export const normalizarAngulo = (d) => ((Number(d) || 0) % 360 + 360) % 360;

/** Punto situado a `r` metros de `centro` en la dirección `grados` (0° = este, antihorario). */
export function puntoEnAngulo(centro, grados, r) {
  const a = rad(grados);
  return { x: (centro.x || 0) + Math.cos(a) * r, y: (centro.y || 0) + Math.sin(a) * r };
}

export const ETIQUETA_TIPO = {
  line: 'Línea', polyline: 'Polilínea', cable: 'Canalización', room: 'Zona', rect: 'Rectángulo',
  circle: 'Circunferencia', arc: 'Arco', text: 'Texto', image: 'Imagen', obstacle: 'Obstáculo',
  camera: 'Cámara', device: 'Equipo', hatch: 'Sombreado',
};

/** Tipos cuya geometría se puede modificar vértice a vértice. */
export const TIPOS_GEOMETRICOS = ['line', 'polyline', 'cable', 'room', 'rect', 'circle', 'arc', 'text', 'image', 'obstacle'];

export const puedeEditarGeometria = (e) => !!e && TIPOS_GEOMETRICOS.includes(e.type);

/* ------------------------------------------------------------------ medidas útiles */

export function centroideDe(e) {
  const pts = (e && e.points) || [];
  if (!pts.length) return { x: 0, y: 0 };
  if (e.type === 'rect' || (e.type === 'obstacle' && pts.length === 2)) {
    return { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };
  }
  return {
    x: pts.reduce((a, p) => a + p.x, 0) / pts.length,
    y: pts.reduce((a, p) => a + p.y, 0) / pts.length,
  };
}

export function cajaDe(e) {
  const pts = (e && e.points) || [];
  if (!pts.length) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
    minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
  }
  const r = (e.type === 'circle' || e.type === 'arc') ? (e.radius || 0) : 0;
  if (r) { minX -= r; maxX += r; minY -= r; maxY += r; }
  return { minX, minY, maxX, maxY };
}

/** Longitud de la entidad: perímetro si está cerrada, desarrollo del arco, circunferencia… */
export function longitudDe(e) {
  const pts = (e && e.points) || [];
  if (!pts.length) return 0;
  if (e.type === 'circle') return 2 * Math.PI * (e.radius || 0);
  if (e.type === 'arc') return (e.radius || 0) * rad(Math.abs(barridoDe(e)));
  if (e.type === 'rect') return 2 * (Math.abs(pts[1].x - pts[0].x) + Math.abs(pts[1].y - pts[0].y));
  let s = 0;
  for (let i = 0; i < pts.length - 1; i++) s += dist(pts[i], pts[i + 1]);
  if (e.closed && pts.length > 2) s += dist(pts[pts.length - 1], pts[0]);
  return s;
}

/** Ángulo que abre un arco, en grados y en positivo (de inicio a fin en sentido antihorario). */
export function barridoDe(e) {
  const a = normalizarAngulo(e.startAngle), b = normalizarAngulo(e.endAngle);
  return b >= a ? b - a : 360 - a + b;
}

/** Área en planta (solo para figuras cerradas). */
export function areaDe(e) {
  const pts = (e && e.points) || [];
  if (e.type === 'circle') return Math.PI * (e.radius || 0) ** 2;
  if (e.type === 'arc') return Math.PI * (e.radius || 0) ** 2 * (Math.abs(barridoDe(e)) / 360);
  if (e.type === 'rect' && pts.length >= 2) return Math.abs(pts[1].x - pts[0].x) * Math.abs(pts[1].y - pts[0].y);
  if (e.type === 'obstacle' && pts.length === 2) return Math.abs(pts[1].x - pts[0].x) * Math.abs(pts[1].y - pts[0].y);
  if (pts.length < 3 || !e.closed) return 0;
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    s += a.x * b.y - b.x * a.y;
  }
  return Math.abs(s) / 2;
}

/* ------------------------------------------------------------------ rectángulos */

/** Las cuatro esquinas de un rectángulo guardado como dos esquinas opuestas. */
export function esquinasRect(e) {
  const [a, b] = (e.points || [{ x: 0, y: 0 }, { x: 0, y: 0 }]);
  const x0 = Math.min(a.x, b.x), x1 = Math.max(a.x, b.x);
  const y0 = Math.min(a.y, b.y), y1 = Math.max(a.y, b.y);
  return [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }];
}

/** Reescribe las dos esquinas opuestas a partir de las cuatro esquinas (normalizadas). */
function guardarEsquinas(e, esq) {
  const xs = esq.map((p) => p.x), ys = esq.map((p) => p.y);
  e.points = [{ x: Math.min(...xs), y: Math.min(...ys) }, { x: Math.max(...xs), y: Math.max(...ys) }];
}

/* ------------------------------------------------------------------ tiradores */

/**
 * Tiradores (grips) de una entidad: los puntos que el usuario puede arrastrar para cambiar su
 * geometría, como en AutoCAD. Cada tirador dice qué es (`papel`), dónde está y cómo se llama.
 *
 * Papeles: `vertice` (mover un vértice), `medio` (insertar uno nuevo en ese tramo), `esquina` y
 * `lado` (rectángulos), `radio`, `anguloInicio`, `anguloFin` (arcos), `altura` (alto del texto),
 * `direccion` (hacia dónde mira una cámara) y `rotacion` (girar el objeto completo, como un
 * bloque de AutoCAD: se arrastra el mango y el objeto gira sobre su centro).
 */
export function tiradoresDe(e, opts = {}) {
  if (!e) return [];
  const pts = (e.points || []).filter(Boolean);
  if (!pts.length) return [];
  const out = [];
  const push = (p, papel, indice, etiqueta, extra) =>
    out.push(Object.assign({ p: { x: p.x, y: p.y }, papel, indice, etiqueta }, extra || {}));

  switch (e.type) {
    case 'line': case 'polyline': case 'cable': case 'room': {
      pts.forEach((p, i) => push(p, 'vertice', i, `Vértice ${i + 1}`));
      const tramos = pts.length - 1 + (e.closed ? 1 : 0);
      for (let i = 0; i < tramos; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, 'medio', i, `Insertar vértice en el tramo ${i + 1}`);
      }
      break;
    }
    case 'rect': {
      const esq = esquinasRect(e);
      esq.forEach((p, i) => push(p, 'esquina', i, `Esquina ${i + 1}`));
      ['inferior', 'derecho', 'superior', 'izquierdo'].forEach((nom, i) => {
        const a = esq[i], b = esq[(i + 1) % 4];
        push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, 'lado', i, `Lado ${nom}`);
      });
      break;
    }
    case 'circle': {
      const r = e.radius || 0;
      push(pts[0], 'vertice', 0, 'Centro');
      for (const a of [0, 90, 180, 270]) push(puntoEnAngulo(pts[0], a, r), 'radio', a, 'Radio');
      break;
    }
    case 'arc': {
      const r = e.radius || 0;
      const ini = normalizarAngulo(e.startAngle), fin = normalizarAngulo(e.endAngle);
      push(pts[0], 'vertice', 0, 'Centro');
      push(puntoEnAngulo(pts[0], ini, r), 'anguloInicio', 0, 'Inicio del arco');
      push(puntoEnAngulo(pts[0], fin, r), 'anguloFin', 1, 'Fin del arco');
      push(puntoEnAngulo(pts[0], ini + barridoDe(e) / 2, r), 'radio', 2, 'Radio');
      break;
    }
    case 'text': {
      const h = Number(e.data && e.data.height) || 0.4;
      push(pts[0], 'vertice', 0, 'Ancla del texto');
      push({ x: pts[0].x, y: pts[0].y + h }, 'altura', 0, 'Alto del texto');
      push(puntoEnAngulo(pts[0], 0, Math.max(0.6, h * 2)), 'rotacion', 0, 'Girar el texto', { ang0: 0 });
      break;
    }
    case 'image': {
      const w = Number(e.data && e.data.width) || 10;
      const h = Number(e.data && e.data.heightM) || w;
      push(pts[0], 'esquina', 0, 'Esquina inferior izquierda');
      push({ x: pts[0].x + w, y: pts[0].y + h }, 'esquina', 1, 'Esquina superior derecha');
      break;
    }
    case 'camera': {
      const alcance = opts.alcanceMango || 2;
      push(pts[0], 'vertice', 0, 'Posición de la cámara');
      push(puntoEnAngulo(pts[0], e.data.azimuth || 0, alcance), 'direccion', 0, 'Orientación de la cámara');
      break;
    }
    case 'device': push(pts[0], 'vertice', 0, 'Posición del equipo'); break;
    case 'obstacle': {
      const d = datosDe(e);
      const def = obstaculoDe((e.data && e.data.kind) || (e.data && e.data.muro ? 'muro' : null));
      const dibujo = def ? def.dibujo : (pts.length > 2 ? 'cadena' : 'segmento');
      if (dibujo === 'rectangulo' && pts.length >= 2) {
        const esq = esquinasRect(e);
        esq.forEach((p, i) => push(p, 'esquina', i, `Esquina ${i + 1}`));
        ['inferior', 'derecho', 'superior', 'izquierdo'].forEach((nom, i) => {
          const a = esq[i], b = esq[(i + 1) % 4];
          push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, 'lado', i, `Lado ${nom}`);
        });
      } else {
        pts.forEach((p, i) => push(p, 'vertice', i, `Vértice ${i + 1}`));
        if (dibujo !== 'punto' && pts.length >= 2) {
          const tramos = pts.length - 1 + (e.closed ? 1 : 0);
          for (let i = 0; i < tramos; i++) {
            const a = pts[i], b = pts[(i + 1) % pts.length];
            push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, 'medio', i, `Insertar vértice en el tramo ${i + 1}`);
          }
        }
        if (d.radio > 0 && pts.length === 1) push(puntoEnAngulo(pts[0], 0, d.radio), 'radio', 0, 'Radio');
      }
      pushMangoGiro(e, push, pts);
      break;
    }
    default: pts.forEach((p, i) => push(p, 'vertice', i, `Vértice ${i + 1}`));
  }
  return out;
}

/**
 * Mango de giro: un tirador redondo a la derecha del centro del objeto que, al arrastrarlo, gira
 * todo el elemento sobre su centro, exactamente como un bloque en AutoCAD (§9). Los obstáculos de
 * un solo punto (un árbol, una persona) no lo llevan: girar un punto no cambia nada en planta y su
 * símbolo se ve igual desde cualquier lado.
 */
function pushMangoGiro(e, push, pts) {
  if (pts.length < 2 && !(e.radius > 0)) return;
  const c = centroideDe(e);
  const caja = cajaDe(e);
  const radio = Math.max(0.5, Math.max(caja.maxX - caja.minX, caja.maxY - caja.minY) * 0.6);
  push(puntoEnAngulo(c, 0, radio), 'rotacion', 0, 'Girar el objeto sobre su centro', { ang0: 0 });
}

/**
 * Aplica el arrastre de un tirador: mueve el punto que toca de la entidad.
 * Devuelve el tirador «siguiente»: al arrastrar un punto medio se inserta un vértice nuevo, y a
 * partir de ese instante se arrastra **ese** vértice (como en AutoCAD).
 */
export function aplicarTirador(e, t, p, opts = {}) {
  if (!e || !t) return t;
  const pts = e.points || (e.points = []);
  switch (t.papel) {
    case 'medio': {
      const i = t.indice + 1;
      insertarVertice(e, i, p);
      return { p: { x: p.x, y: p.y }, papel: 'vertice', indice: i, etiqueta: `Vértice ${i + 1}` };
    }
    case 'esquina': {
      if (e.type === 'image') {
        // La esquina 0 es el ancla (mueve la imagen sin cambiar su tamaño) y la 1, el tamaño
        if (t.indice === 0) e.points[0] = { x: p.x, y: p.y };
        else {
          e.data = Object.assign({}, e.data, {
            width: Math.max(0.1, Math.abs(p.x - pts[0].x)),
            heightM: Math.max(0.1, Math.abs(p.y - pts[0].y)),
          });
        }
        break;
      }
      const esq = esquinasRect(e);
      esq[t.indice] = { x: p.x, y: p.y };
      guardarEsquinas(e, esq);
      break;
    }
    case 'lado': {
      const esq = esquinasRect(e);
      // Mover un lado arrastra sus dos esquinas; el lado opuesto se queda quieto
      if (t.indice === 0) { esq[0].y = p.y; esq[1].y = p.y; }
      else if (t.indice === 1) { esq[1].x = p.x; esq[2].x = p.x; }
      else if (t.indice === 2) { esq[2].y = p.y; esq[3].y = p.y; }
      else { esq[3].x = p.x; esq[0].x = p.x; }
      guardarEsquinas(e, esq);
      break;
    }
    case 'radio':
      if (e.type === 'obstacle') {
        e.radius = Math.max(0.05, dist(pts[0], p));
        if (e.data) e.data.radio = e.radius;
      } else {
        e.radius = Math.max(0.01, dist(pts[0], p));
      }
      break;
    case 'anguloInicio': e.startAngle = anguloDeg(pts[0], p); break;
    case 'anguloFin': e.endAngle = anguloDeg(pts[0], p); break;
    case 'altura':
      e.data = Object.assign({}, e.data, { height: Math.max(0.05, p.y - pts[0].y) });
      break;
    case 'rotacion': {
      // Girar es siempre relativo: se rota la diferencia entre el ángulo que tenía el mango al
      // agarrarlo y el que tiene ahora, así el objeto sigue al ratón como un bloque de AutoCAD.
      const c = e.type === 'text' ? pts[0] : centroideDe(e);
      const ang = anguloDeg(c, p);
      const paso = normalizarAngulo(ang - (Number(t.ang0) || 0));
      const giro = paso > 180 ? paso - 360 : paso;      // el camino corto: nunca da la vuelta entera
      if (e.type === 'text') e.data = Object.assign({}, e.data, { rotacion: normalizarAngulo((e.data.rotacion || 0) + giro) });
      else rotarEntidad(e, giro, c);
      return Object.assign({}, t, { ang0: ang, p: puntoEnAngulo(c, ang, Math.max(0.05, dist(c, t.p))) });
    }
    case 'direccion':
      e.data = Object.assign({}, e.data, { azimuth: redondear(anguloDeg(pts[0], p), 1) });
      return Object.assign({}, t, { p: puntoEnAngulo(pts[0], e.data.azimuth, opts.alcanceMango || 2) });
    default:
      if (pts[t.indice]) pts[t.indice] = { x: p.x, y: p.y };
  }
  return Object.assign({}, t, { p: { x: p.x, y: p.y } });
}

const redondear = (v, n = 3) => Math.round(v * 10 ** n) / 10 ** n;

/* ------------------------------------------------------------------ vértices */

/** Inserta un vértice en la posición `i` (0 = antes del primero). */
export function insertarVertice(e, i, p) {
  const pts = (e.points || (e.points = []));
  if (e.type === 'line' || e.type === 'polyline' || e.type === 'cable' || e.type === 'room') {
    if (pts.length < 2) return false;
    pts.splice(Math.max(0, Math.min(i, pts.length)), 0, { x: p.x, y: p.y });
    return true;
  }
  if (e.type === 'obstacle') {
    if (pts.length < 1) return false;
    pts.splice(Math.max(0, Math.min(i, pts.length)), 0, { x: p.x, y: p.y });
    return true;
  }
  return false;
}

/** Borra el vértice `i`, con el mínimo que aguante la figura (2 en abierto, 3 en cerrado). */
export function borrarVertice(e, i) {
  const pts = (e.points || []);
  const minimo = e.closed ? 3 : 2;
  if (i < 0 || i >= pts.length || pts.length <= minimo) return false;
  if (e.type === 'rect') return false;            // el rectángulo se edita por esquinas y lados
  pts.splice(i, 1);
  return true;
}

/** Abre o cierra una polilínea (o un contorno de obstáculo). */
export function cerrarEntidad(e, flag) {
  if (!e || (e.type !== 'polyline' && e.type !== 'room' && e.type !== 'obstacle')) return false;
  if (e.points.length < 3 && flag) return false;
  e.closed = flag === undefined ? !e.closed : !!flag;
  return true;
}

/* ------------------------------------------------------------------ transformaciones */

export function trasladar(e, dx, dy) {
  if (!e || !e.points) return e;
  e.points = e.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
  return e;
}

export function rotarEntidad(e, grados, base) {
  if (!e || !e.points) return e;
  const c = base || centroideDe(e);
  e.points = e.points.map((p) => {
    const dx = p.x - c.x, dy = p.y - c.y, a = rad(grados);
    return { x: c.x + dx * Math.cos(a) - dy * Math.sin(a), y: c.y + dx * Math.sin(a) + dy * Math.cos(a) };
  });
  if (e.data && e.data.azimuth !== undefined) e.data.azimuth = normalizarAngulo(e.data.azimuth + grados);
  if (e.startAngle !== undefined) e.startAngle = normalizarAngulo(e.startAngle + grados);
  if (e.endAngle !== undefined) e.endAngle = normalizarAngulo(e.endAngle + grados);
  if (e.data && e.data.rotacion !== undefined) e.data.rotacion = normalizarAngulo(e.data.rotacion + grados);
  return e;
}

export function escalarEntidad(e, factor, base) {
  if (!e || !e.points) return e;
  const f = Number(factor) || 1;
  if (!f) return e;
  const c = base || centroideDe(e);
  e.points = e.points.map((p) => ({ x: c.x + (p.x - c.x) * f, y: c.y + (p.y - c.y) * f }));
  if (e.radius) e.radius = e.radius * Math.abs(f);
  if (e.data && e.data.radio) e.data.radio = e.data.radio * Math.abs(f);
  if (e.data && e.data.height && e.type === 'text') e.data.height = e.data.height * Math.abs(f);
  return e;
}

/**
 * Espejo de la entidad: `eje` 'v' refleja respecto de la vertical que pasa por `base`
 * (izquierda ↔ derecha) y 'h' respecto de la horizontal (arriba ↔ abajo), como en AutoCAD.
 */
export function espejarEntidad(e, eje, base) {
  if (!e || !e.points) return e;
  const c = base || centroideDe(e);
  e.points = e.points.map((p) => (eje === 'h'
    ? { x: p.x, y: 2 * c.y - p.y }
    : { x: 2 * c.x - p.x, y: p.y }));
  if (e.data && e.data.azimuth !== undefined) e.data.azimuth = eje === 'h'
    ? normalizarAngulo(180 - e.data.azimuth) : normalizarAngulo(360 - e.data.azimuth);
  if (e.startAngle !== undefined) e.startAngle = eje === 'h' ? normalizarAngulo(180 - e.startAngle) : normalizarAngulo(360 - e.startAngle);
  if (e.endAngle !== undefined) e.endAngle = eje === 'h' ? normalizarAngulo(180 - e.endAngle) : normalizarAngulo(360 - e.endAngle);
  if (e.type === 'rect') { /* las dos esquinas ya están reflejadas */ }
  return e;
}

/**
 * Espejo respecto del eje que pasa por `a` y `b` (el comando ESPEJO de AutoCAD: se señalan dos
 * puntos y la figura se refleja respecto de la recta que los une).
 */
export function espejarPorEje(e, a, b) {
  if (!e || !e.points) return e;
  const dx = (b.x || 0) - (a.x || 0), dy = (b.y || 0) - (a.y || 0);
  const norma = Math.hypot(dx, dy);
  if (!norma) return e;
  const ux = dx / norma, uy = dy / norma;      // vector unitario del eje
  e.points = e.points.map((p) => {
    // Proyección del punto sobre el eje (componente paralela) y reflejo de la perpendicular
    const vx = p.x - a.x, vy = p.y - a.y;
    const paralela = vx * ux + vy * uy;
    const px = a.x + ux * paralela, py = a.y + uy * paralela;
    return { x: 2 * px - p.x, y: 2 * py - p.y };
  });
  if (e.data && e.data.azimuth !== undefined) {
    // El acimut se refleja respecto de la dirección del eje: 2·ángulo(eje) − acimut
    e.data.azimuth = normalizarAngulo(2 * anguloDeg({ x: 0, y: 0 }, { x: ux, y: uy }) - e.data.azimuth);
  }
  if (e.startAngle !== undefined) e.startAngle = normalizarAngulo(2 * anguloDeg({ x: 0, y: 0 }, { x: ux, y: uy }) - e.startAngle);
  if (e.endAngle !== undefined) e.endAngle = normalizarAngulo(2 * anguloDeg({ x: 0, y: 0 }, { x: ux, y: uy }) - e.endAngle);
  return e;
}

/** Copia profunda de una entidad, desplazada y con identificador nuevo. */
export function clonar(e, dx = 0, dy = 0, id) {
  const c = JSON.parse(JSON.stringify(e));
  c.id = id || e.id + '_c' + Math.random().toString(36).slice(2, 6);
  if (c.points) c.points = c.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
  return c;
}

/* ------------------------------------------------------------------ campos editables */

/**
 * Descripción de los campos que se pueden editar de una entidad. El panel de propiedades pinta un
 * control por campo a partir de aquí, así que añadir un campo nuevo es tocar solo este módulo.
 *
 * Cada campo: `{ clave, etiqueta, tipo, unidad, min, max, paso, opciones, nota }`.
 * `tipo` puede ser `numero`, `texto`, `lista`, `logico` o `color`.
 */
export function camposDe(e, prj = {}) {
  if (!e) return [];
  const capas = (prj.layers || []).map((l) => [l.id, l.name || l.id]);
  const comunes = [
    { clave: 'layer', etiqueta: 'Capa', tipo: 'lista', opciones: capas },
    { clave: 'color', etiqueta: 'Color', tipo: 'color', nota: 'Color propio; si se deja vacío manda el de la capa.' },
  ];
  const d = e.data || {};
  switch (e.type) {
    case 'circle':
      return [{ clave: 'radio', etiqueta: 'Radio', tipo: 'numero', unidad: 'm', min: 0.01, paso: 0.05 }, ...comunes];
    case 'arc':
      return [
        { clave: 'radio', etiqueta: 'Radio', tipo: 'numero', unidad: 'm', min: 0.01, paso: 0.05 },
        { clave: 'anguloInicio', etiqueta: 'Ángulo inicial', tipo: 'numero', unidad: '°', paso: 5 },
        { clave: 'anguloFin', etiqueta: 'Ángulo final', tipo: 'numero', unidad: '°', paso: 5 },
        ...comunes,
      ];
    case 'text':
      return [
        { clave: 'texto', etiqueta: 'Texto', tipo: 'texto' },
        { clave: 'altura', etiqueta: 'Alto del texto', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 },
        { clave: 'rotacion', etiqueta: 'Giro', tipo: 'numero', unidad: '°', paso: 15 },
        ...comunes,
      ];
    case 'image':
      return [
        { clave: 'ancho', etiqueta: 'Ancho', tipo: 'numero', unidad: 'm', min: 0.1, paso: 0.1 },
        { clave: 'alto', etiqueta: 'Alto', tipo: 'numero', unidad: 'm', min: 0.1, paso: 0.1 },
        { clave: 'opacidad', etiqueta: 'Opacidad', tipo: 'numero', min: 0.05, max: 1, paso: 0.05 },
        ...comunes,
      ];
    case 'rect': case 'line': case 'polyline': case 'cable': case 'room': {
      const f = [];
      if (e.type === 'rect') f.push(
        { clave: 'ancho', etiqueta: 'Ancho', tipo: 'numero', unidad: 'm', min: 0.01, paso: 0.05 },
        { clave: 'alto', etiqueta: 'Alto', tipo: 'numero', unidad: 'm', min: 0.01, paso: 0.05 },
      );
      if (e.type === 'polyline' || e.type === 'room' || e.type === 'cable') {
        f.push({ clave: 'cerrada', etiqueta: 'Figura cerrada', tipo: 'logico' });
      }
      if (e.type === 'room') f.unshift({ clave: 'nombre', etiqueta: 'Nombre de la zona', tipo: 'texto' });
      return [...f, ...comunes];
    }
    case 'obstacle': {
      const def = obstaculoDe(d.kind);
      const f = [
        { clave: 'kind', etiqueta: 'Tipo de elemento', tipo: 'lista', opciones: OBSTACULOS.map((o) => [o.id, `${o.icono} ${o.etiqueta}`]) },
        { clave: 'etiqueta', etiqueta: 'Etiqueta', tipo: 'texto' },
        { clave: 'altura', etiqueta: 'Altura', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 },
        { clave: 'base', etiqueta: 'Cota de la base', tipo: 'numero', unidad: 'm', paso: 0.05, nota: 'A qué altura empieza (una ventana, un falso techo…).' },
      ];
      if (d.kind === 'columna') {
        f.push({
          clave: 'forma', etiqueta: 'Forma del pilar', tipo: 'lista',
          opciones: [['redonda', 'Redonda / circular'], ['cuadrada', 'Cuadrada'], ['rectangular', 'Rectangular']]
        });
        const forma = d.forma || 'redonda';
        if (forma === 'redonda') {
          f.push({ clave: 'radio', etiqueta: 'Radio', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 });
        } else if (forma === 'cuadrada') {
          f.push({ clave: 'ancho', etiqueta: 'Lado', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 });
          f.push({ clave: 'rotacion', etiqueta: 'Giro', tipo: 'numero', unidad: '°', paso: 15 });
        } else {
          f.push({ clave: 'ancho', etiqueta: 'Ancho (X)', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 });
          f.push({ clave: 'largo', etiqueta: 'Largo (Y)', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.05 });
          f.push({ clave: 'rotacion', etiqueta: 'Giro', tipo: 'numero', unidad: '°', paso: 15 });
        }
      } else if (d.kind === 'escalera') {
        f.push({
          clave: 'tipoEscalera', etiqueta: 'Tipo de escalera', tipo: 'lista',
          opciones: [['recta', 'Recta (con zancas y barandilla)'], ['en_l', 'En L (con descansillo intermedio)'], ['caracol', 'Caracol / espiral']]
        });
        f.push({ clave: 'rotacion', etiqueta: 'Orientación / Giro', tipo: 'numero', unidad: '°', paso: 15 });
        f.push({ clave: 'barandilla', etiqueta: 'Barandilla y pasamanos', tipo: 'logico' });
        f.push({ clave: 'numPeldanos', etiqueta: 'Número de peldaños', tipo: 'numero', min: 3, max: 64, paso: 1, nota: '0 = automático según la altura.' });
      } else {
        if (def && def.ancho) f.push({ clave: 'ancho', etiqueta: 'Espesor o ancho', tipo: 'numero', unidad: 'm', min: 0.02, paso: 0.02 });
        if (def && def.radio) f.push({ clave: 'radio', etiqueta: 'Radio', tipo: 'numero', unidad: 'm', min: 0.05, paso: 0.1 });
      }
      f.push({ clave: 'opaco', etiqueta: 'Tapa la visión', tipo: 'logico' });
      if (def && def.hueco) f.push({ clave: 'hueco', etiqueta: 'Es un hueco (no tapa)', tipo: 'logico' });
      return [...f, ...comunes];
    }
    case 'camera': case 'device': case 'text': default: {
      const f = [];
      if ((e.points || []).length === 1) {
        f.push({ clave: 'x', etiqueta: 'X', tipo: 'numero', unidad: 'm', paso: 0.05 });
        f.push({ clave: 'y', etiqueta: 'Y', tipo: 'numero', unidad: 'm', paso: 0.05 });
      }
      return [...f, ...comunes];
    }
  }
}

/** Valor actual de un campo, tal y como lo pide el panel. */
export function leerCampo(e, campo) {
  if (!e) return undefined;
  const d = e.data || {};
  switch (campo) {
    case 'layer': return e.layer;
    case 'color': return d.color || '';
    case 'radio': return e.type === 'obstacle' ? (d.radio !== undefined ? d.radio : e.radius || 0) : (e.radius || 0);
    case 'anguloInicio': return normalizarAngulo(e.startAngle);
    case 'anguloFin': return normalizarAngulo(e.endAngle);
    case 'texto': return d.text || '';
    case 'altura': return e.type === 'text' ? (d.height || 0.4) : (d.altura !== undefined ? d.altura : d.h || 0);
    case 'rotacion': return d.rotacion || 0;
    case 'ancho': return e.type === 'image' ? (d.width || 10) : Math.abs((e.points[1] || {}).x - (e.points[0] || {}).x || 0);
    case 'alto': return e.type === 'image' ? (d.heightM || d.width || 10) : Math.abs((e.points[1] || {}).y - (e.points[0] || {}).y || 0);
    case 'opacidad': return d.opacity === undefined ? 0.5 : d.opacity;
    case 'cerrada': return !!e.closed;
    case 'nombre': return d.name || '';
    case 'etiqueta': return d.etiqueta || '';
    case 'base': return d.base || 0;
    case 'opaco': return d.opaco !== false;
    case 'hueco': return !!d.hueco;
    case 'kind': return d.kind || '';
    case 'tipoEscalera': return d.tipoEscalera || 'recta';
    case 'barandilla': return d.barandilla !== false;
    case 'numPeldanos': return d.numPeldanos || 0;
    case 'x': return (e.points[0] || {}).x || 0;
    case 'y': return (e.points[0] || {}).y || 0;
    default: return d[campo];
  }
}

/**
 * Escribe un campo con su valor. Los numéricos se limitan a su rango; cambiar el tipo de un
 * obstáculo conserva la geometría y toma del catálogo los valores por defecto del tipo nuevo.
 */
export function escribirCampo(e, campo, valor) {
  if (!e) return false;
  const d = Object.assign({}, e.data || {});
  e.data = d;
  // Número del control, con la coma decimal que se usa en español. Un campo vacío **no** es un
  // cero: devuelve null y quien llama deja el objeto como estaba (borrar para volver a escribir
  // no puede dejar el obstáculo con altura 0).
  const numerico = () => {
    if (valor === undefined || valor === null) return null;
    if (typeof valor === 'string' && valor.trim() === '') return null;
    const v = typeof valor === 'number' ? valor : parseFloat(String(valor).trim().replace(',', '.'));
    return isFinite(v) ? v : null;
  };
  const n = (defecto = 0) => { const v = numerico(); return v === null ? defecto : v; };
  switch (campo) {
    case 'layer': e.layer = valor; return true;
    case 'color': if (valor) d.color = valor; else delete d.color; return true;
    case 'radio': {
      if (numerico() === null) return false;
      const v = Math.max(0.01, n(0));
      if (e.type === 'obstacle') { e.radius = v; d.radio = v; } else e.radius = v;
      return true;
    }
    case 'anguloInicio': { const v = numerico(); if (v === null) return false; e.startAngle = normalizarAngulo(v); return true; }
    case 'anguloFin': { const v = numerico(); if (v === null) return false; e.endAngle = normalizarAngulo(v); return true; }
    case 'texto': d.text = String(valor); return true;
    case 'altura':
      if (numerico() === null) return false;
      if (e.type === 'text') d.height = Math.max(0.05, n(0.4));
      else d.altura = Math.max(0.05, n(ALTURA_MURO));
      return true;
    case 'rotacion': { const v = numerico(); if (v === null) return false; d.rotacion = normalizarAngulo(v); return true; }
    case 'ancho': {
      if (numerico() === null) return false;
      if (e.type === 'image') { d.width = Math.max(0.1, n(10)); return true; }
      if (e.type === 'obstacle') { d.ancho = Math.max(0.02, n(0.2)); return true; }
      const p0 = e.points[0], p1 = e.points[1];
      if (!p0 || !p1) return false;
      e.points[1] = { x: p0.x + Math.max(0.01, n(0)) * (p1.x >= p0.x ? 1 : -1), y: p1.y };
      return true;
    }
    case 'alto': {
      if (numerico() === null) return false;
      if (e.type === 'image') { d.heightM = Math.max(0.1, n(10)); return true; }
      const p0 = e.points[0], p1 = e.points[1];
      if (!p0 || !p1) return false;
      e.points[1] = { x: p1.x, y: p0.y + Math.max(0.01, n(0)) * (p1.y >= p0.y ? 1 : -1) };
      return true;
    }
    case 'opacidad': { const v = numerico(); if (v === null) return false; d.opacity = Math.min(1, Math.max(0.05, v)); return true; }
    case 'cerrada': return cerrarEntidad(e, !!valor);
    case 'nombre': d.name = String(valor); return true;
    case 'etiqueta': d.etiqueta = String(valor); return true;
    case 'base': { const v = numerico(); if (v === null) return false; d.base = Math.max(-50, v); return true; }
    case 'forma': d.forma = String(valor); return true;
    case 'largo': { const v = numerico(); if (v === null) return false; d.largo = Math.max(0.02, v); return true; }
    case 'tipoEscalera': d.tipoEscalera = String(valor); return true;
    case 'barandilla': d.barandilla = !!valor; return true;
    case 'numPeldanos': { const v = numerico(); if (v === null) return false; d.numPeldanos = Math.max(0, Math.round(v)); return true; }
    case 'opaco': d.opaco = !!valor; return true;
    case 'hueco': d.hueco = !!valor; return true;
    case 'x': { const v = numerico(); if (v === null || !e.points[0]) return false; e.points[0] = { x: v, y: e.points[0].y }; return true; }
    case 'y': { const v = numerico(); if (v === null || !e.points[0]) return false; e.points[0] = { x: e.points[0].x, y: v }; return true; }
    case 'kind': return cambiarTipoObstaculo(e, valor);
    default: d[campo] = valor; return true;
  }
}

/** Cambia el tipo de un obstáculo conservando su geometría (§9). */
export function cambiarTipoObstaculo(e, kind) {
  const def = obstaculoDe(kind);
  if (!def || !e || e.type !== 'obstacle') return false;
  const d = Object.assign({}, e.data || {});
  d.kind = def.id;
  d.altura = d.altura !== undefined ? d.altura : def.altura;
  d.base = d.base !== undefined ? d.base : def.base;
  d.ancho = d.ancho !== undefined ? d.ancho : def.ancho;
  d.opaco = d.opaco !== undefined ? d.opaco : def.opaco;
  d.color = def.color;
  d.etiqueta = def.etiqueta;
  if (def.dibujo === 'punto') {
    e.radius = e.radius || d.radio || def.radio || 0.5;
    d.radio = e.radius;
  }
  e.data = d;
  return true;
}

/* ------------------------------------------------------------------ resumen */

/** Una línea que describe la entidad para la cabecera del panel. */
export function resumenDe(e) {
  if (!e) return '';
  const pts = (e.points || []).length;
  const m = (v, u = 2) => Number(v).toFixed(u).replace('.', ',');
  const partes = [];
  switch (e.type) {
    case 'line': partes.push(`${m(longitudDe(e))} m de longitud`); break;
    case 'polyline': case 'cable': case 'room':
      partes.push(`${pts} vértice${pts === 1 ? '' : 's'}`, `${m(longitudDe(e))} m`);
      if (e.closed) partes.push(`cerrada · ${m(areaDe(e))} m²`);
      break;
    case 'rect':
      partes.push(`${m(Math.abs(e.points[1].x - e.points[0].x))} × ${m(Math.abs(e.points[1].y - e.points[0].y))} m`,
        `${m(areaDe(e))} m²`);
      break;
    case 'circle': partes.push(`radio ${m(e.radius || 0)} m`, `${m(areaDe(e))} m²`); break;
    case 'arc': partes.push(`radio ${m(e.radius || 0)} m`, `abre ${m(barridoDe(e), 1)}°`); break;
    case 'text': partes.push(`«${(e.data && e.data.text) || ''}»`, `${m(e.data && e.data.height, 2)} m de alto`); break;
    case 'image': partes.push(`${m(e.data && e.data.width, 2)} × ${m(e.data && (e.data.heightM || e.data.width), 2)} m`); break;
    case 'obstacle': {
      const d = datosDe(e);
      partes.push(d.etiqueta, `${m(d.altura)} m de alto`);
      if (d.base) partes.push(`base a ${m(d.base)} m`);
      if (d.radio) partes.push(`radio ${m(d.radio)} m`);
      if (d.ancho) partes.push(`espesor ${m(d.ancho)} m`);
      break;
    }
    default: partes.push(`${pts} punto${pts === 1 ? '' : 's'}`);
  }
  return partes.filter(Boolean).join(' · ');
}
