/**
 * CCTV DESIGN PRO — Espacio de trabajo y puntero, al estilo de AutoCAD (§8, §11)
 *
 * Reúne **todo lo que el usuario puede configurar del entorno de dibujo**, con los mismos ajustes
 * que AutoCAD y sus mismas referencias:
 *
 *   · Opciones → Visual → Tamaño de la cruz / Colores           → puntero y colores del espacio
 *   · Opciones → Selección → Tamaño de mira                    → mira de selección (pickbox)
 *   · Parámetros de dibujo (DSETTINGS) → Rejilla, Forzado, Orto → forzados y rastreo polar
 *   · Tiradores (grips)                                        → selección y resaltado
 *
 * El módulo es **puro**: no toca el DOM ni el lienzo. Calcula, normaliza y valida; el motor CAD
 * (`app/cad.js`) dibuja y la interfaz (`app/main.js`, `app/panels.js`) edita. Así todo esto se
 * comprueba bajo Node, sin navegador.
 *
 * Criterio de diseño: **los valores del usuario mandan**. Si un color queda poco visible sobre el
 * fondo elegido no se cambia por su cuenta: se avisa (`avisoContraste`), igual que AutoCAD, que
 * dibuja el color que le pidan.
 */
import { contraste, ajustarParaFondo, normalizarHex } from '../io/aci.js?v=b441e3fc';

/* ------------------------------- catálogo de ajustes ------------------------------- */

/** Grupos de ajustes tal como se muestran en el panel «Opciones de dibujo». */
export const GRUPOS = [
  { id: 'puntero', titulo: 'Puntero y cursor', ref: 'AutoCAD: Opciones → Visual → Tamaño de la cruz · Opciones → Selección → Tamaño de mira' },
  { id: 'espacio', titulo: 'Espacio de trabajo', ref: 'AutoCAD: Opciones → Visual → Colores' },
  { id: 'forzados', titulo: 'Dibujo y forzados', ref: 'AutoCAD: Parámetros de dibujo (DSETTINGS)' },
  { id: 'seleccion', titulo: 'Selección', ref: 'AutoCAD: tiradores (grips) y resaltado al pasar' },
];

/**
 * Definición de cada ajuste. `tipo`: `bool` | `num` | `color` | `opcion`.
 * `unidad` se muestra junto al valor; `ayuda` explica qué hace (y qué haría en AutoCAD).
 */
export const PREF_DEFS = [
  /* — puntero — */
  { clave: 'tipoPuntero', grupo: 'puntero', etiqueta: 'Tipo de puntero', tipo: 'opcion', porDefecto: 'cruz_mira',
    opciones: [['cruz_mira', 'Cruz con mira de selección'], ['cruz', 'Solo cruz'], ['flecha', 'Flecha estándar']],
    ayuda: 'La cruz con mira es el puntero de AutoCAD: dos líneas que se cruzan y un cuadrado pequeño en el centro.' },
  { clave: 'tamanoCruz', grupo: 'puntero', etiqueta: 'Tamaño de la cruz', tipo: 'num', porDefecto: 5, min: 1, max: 100, paso: 1, unidad: '%',
    ayuda: 'Tamaño de la cruz en porcentaje de la pantalla (AutoCAD: 1-100 %). El 100 % cubre toda la ventana.' },
  { clave: 'colorCruz', grupo: 'puntero', etiqueta: 'Color de la cruz', tipo: 'color', porDefecto: '#dbe4ee',
    ayuda: 'Color de las líneas de la cruz (AutoCAD: Opciones → Visual → Colores → Crosshairs).' },
  { clave: 'tamanoMira', grupo: 'puntero', etiqueta: 'Tamaño de la mira', tipo: 'num', porDefecto: 8, min: 0, max: 40, paso: 1, unidad: 'px',
    ayuda: 'Lado del cuadrado de la mira en píxeles. Es también la apertura de selección: cuánto hay que acercarse a un objeto para elegirlo (AutoCAD: pickbox).' },
  { clave: 'colorMira', grupo: 'puntero', etiqueta: 'Color de la mira', tipo: 'color', porDefecto: '#ffffff',
    ayuda: 'Color del cuadrado de selección.' },
  { clave: 'marcasJuntoCursor', grupo: 'puntero', etiqueta: 'Coordenadas junto al cursor', tipo: 'bool', porDefecto: true,
    ayuda: 'Muestra las coordenadas del punto y el modo de forzado al lado del puntero (AutoCAD: entrada dinámica).' },
  { clave: 'colorReferencia', grupo: 'puntero', etiqueta: 'Marca de referencia', tipo: 'color', porDefecto: '#facc15',
    ayuda: 'Color del marcador que aparece al engancharse a un vértice del dibujo (AutoCAD: marcador de referencia a objetos).' },

  /* — espacio de trabajo — */
  { clave: 'tema', grupo: 'espacio', etiqueta: 'Tema del espacio', tipo: 'opcion', porDefecto: 'programa',
    opciones: [['programa', 'Predeterminado del programa'], ['autocad', 'AutoCAD (gris azulado)'], ['negro', 'AutoCAD clásico (negro)'], ['claro', 'Claro (papel)']],
    ayuda: 'Cambia de una vez el fondo, la rejilla, los ejes y los colores del puntero. Después se puede ajustar cada color.' },
  { clave: 'fondo', grupo: 'espacio', etiqueta: 'Color del fondo', tipo: 'color', porDefecto: '#12151a',
    ayuda: 'Fondo del espacio modelo (AutoCAD: Opciones → Visual → Colores → Espacio modelo 2D).' },
  { clave: 'colorRejilla', grupo: 'espacio', etiqueta: 'Color de la rejilla', tipo: 'color', porDefecto: '#1c2129',
    ayuda: 'Color de las líneas de la rejilla.' },
  { clave: 'colorEjes', grupo: 'espacio', etiqueta: 'Color de los ejes', tipo: 'color', porDefecto: '#2a323d',
    ayuda: 'Color de las dos líneas del origen (X = 0 e Y = 0).' },
  { clave: 'iconoEjes', grupo: 'espacio', etiqueta: 'Icono de ejes', tipo: 'bool', porDefecto: true,
    ayuda: 'Dibuja el icono de ejes X/Y del origen, como el icono del SCP (UCS) de AutoCAD.' },
  { clave: 'iconoEsquina', grupo: 'espacio', etiqueta: 'Icono en la esquina', tipo: 'bool', porDefecto: false,
    ayuda: 'Con el origen fuera de la vista, AutoCAD deja el icono en la esquina inferior izquierda; actívelo para hacer lo mismo.' },

  /* — forzados — */
  { clave: 'rejillaVisible', grupo: 'forzados', etiqueta: 'Rejilla visible (F7)', tipo: 'bool', porDefecto: true,
    ayuda: 'Muestra la rejilla del espacio de trabajo.' },
  { clave: 'pasoRejilla', grupo: 'forzados', etiqueta: 'Intervalo de rejilla', tipo: 'num', porDefecto: 1, min: 0.05, max: 100, paso: 0.05, unidad: 'm',
    ayuda: 'Separación entre líneas de rejilla en metros (AutoCAD: intervalo de rejilla).' },
  { clave: 'referenciaObjetos', grupo: 'forzados', etiqueta: 'Referencia a objetos (F3)', tipo: 'bool', porDefecto: true,
    ayuda: 'Al acercarse a un vértice del dibujo, el cursor se engancha a él y lo marca (AutoCAD: referencia a objetos, OSNAP).' },
  { clave: 'forzadoRejilla', grupo: 'forzados', etiqueta: 'Forzar a la rejilla (F9)', tipo: 'bool', porDefecto: true,
    ayuda: 'El cursor se pega al intervalo de rejilla (AutoCAD: forzado de cursor, SNAP).' },
  { clave: 'orto', grupo: 'forzados', etiqueta: 'Modo ortogonal (F8)', tipo: 'bool', porDefecto: false,
    ayuda: 'Al dibujar, el segundo punto se limita a horizontal o vertical respecto al primero (AutoCAD: ORTO).' },
  { clave: 'polar', grupo: 'forzados', etiqueta: 'Rastreo polar (F10)', tipo: 'bool', porDefecto: false,
    ayuda: 'Al dibujar, el cursor se pega a incrementos angulares (AutoCAD: rastreo polar).' },
  { clave: 'incrementoPolar', grupo: 'forzados', etiqueta: 'Incremento polar', tipo: 'num', porDefecto: 45, min: 5, max: 90, paso: 5, unidad: '°',
    ayuda: 'Ángulos del rastreo polar: 15°, 30°, 45° o 90°, como en AutoCAD.' },

  /* — selección — */
  { clave: 'colorSeleccion', grupo: 'seleccion', etiqueta: 'Color de la selección', tipo: 'color', porDefecto: '#22d3ee',
    ayuda: 'Color del contorno y de los tiradores de lo seleccionado (AutoCAD: color de tiradores).' },
  { clave: 'tamanoTirador', grupo: 'seleccion', etiqueta: 'Tamaño del tirador', tipo: 'num', porDefecto: 6, min: 0, max: 16, paso: 1, unidad: 'px',
    ayuda: 'Lado del cuadradito de los tiradores (grips) en los vértices de lo seleccionado. 0 los oculta.' },
  { clave: 'resaltarAlPasar', grupo: 'seleccion', etiqueta: 'Resaltar al pasar el ratón', tipo: 'bool', porDefecto: true,
    ayuda: 'Marca el objeto que hay bajo el cursor antes de pulsar.' },
  { clave: 'colorResaltado', grupo: 'seleccion', etiqueta: 'Color del resaltado', tipo: 'color', porDefecto: '#22d3ee',
    ayuda: 'Color con el que se resalta el objeto bajo el cursor.' },
  { clave: 'colorVentana', grupo: 'seleccion', etiqueta: 'Color de la ventana', tipo: 'color', porDefecto: '#0ea5e9',
    ayuda: 'Color del rectángulo del zoom ventana.' },
  { clave: 'colorMarquesina', grupo: 'seleccion', etiqueta: 'Marquesina: ventana', tipo: 'color', porDefecto: '#38bdf8',
    ayuda: 'Color del rectángulo cuando se arrastra **hacia la derecha**: solo se coge lo que queda entero dentro (AutoCAD: selección por ventana).' },
  { clave: 'colorCruce', grupo: 'seleccion', etiqueta: 'Marquesina: cruce', tipo: 'color', porDefecto: '#4ade80',
    ayuda: 'Color del rectángulo cuando se arrastra **hacia la izquierda**: se coge todo lo que toca, aunque sea a medias (AutoCAD: selección por cruce).' },
  { clave: 'opacidadMarquesina', grupo: 'seleccion', etiqueta: 'Relleno de la marquesina', tipo: 'num', porDefecto: 18, min: 0, max: 45, paso: 1, unidad: '%',
    ayuda: 'Cuánto se rellena el rectángulo de selección. A 0 % solo se ve el borde.' },
  { clave: 'resaltarPrevio', grupo: 'seleccion', etiqueta: 'Ver qué se va a coger', tipo: 'bool', porDefecto: true,
    ayuda: 'Mientras se arrastra el rectángulo, los objetos que entrarían en la selección se marcan en el color de la selección.' },
  { clave: 'etiquetaMarquesina', grupo: 'seleccion', etiqueta: 'Rotular la marquesina', tipo: 'bool', porDefecto: true,
    ayuda: 'Escribe junto al rectángulo cuántos objetos se están cogiendo, el modo (ventana o cruce) y el tamaño en metros.' },
  { clave: 'lazoAlArrastrar', grupo: 'seleccion', etiqueta: 'Arrastrar siempre con lazo', tipo: 'bool', porDefecto: false,
    ayuda: 'Con esto puesto, todo arrastre sobre el vacío dibuja un **lazo** en vez de un rectángulo (es el «Allow press and drag for Lasso» de AutoCAD). Apagado, el lazo sale con la herramienta Lazo o manteniendo **Alt**.' },
  { clave: 'seleccionarPorCono', grupo: 'seleccion', etiqueta: 'Coger la cámara por el cono', tipo: 'bool', porDefecto: false,
    ayuda: 'Si se activa, se coge una cámara también pinchando **dentro de su huella de cobertura** o rozándola con la marquesina en modo cruce (en modo ventana se sigue usando el símbolo).' },
];

/** Valor de fábrica de cada ajuste, listo para usar. */
export const PREFS_POR_DEFECTO = Object.freeze(
  PREF_DEFS.reduce((o, d) => { o[d.clave] = d.porDefecto; return o; }, {}),
);

/** Definición de un ajuste por su clave. */
export const defDe = (clave) => PREF_DEFS.find((d) => d.clave === clave) || null;

/** Ajustes de un grupo, en orden. */
export const defsDeGrupo = (grupo) => PREF_DEFS.filter((d) => d.grupo === grupo);

/* ------------------------------- temas ------------------------------- */

/**
 * Temas de espacio de trabajo. Un tema solo fija colores (y el color de la cruz): el resto de los
 * ajustes del usuario no se toca al cambiarlo.
 */
export const TEMAS = {
  programa: {
    etiqueta: 'Predeterminado del programa',
    valores: { fondo: '#12151a', colorRejilla: '#1c2129', colorEjes: '#2a323d', colorCruz: '#dbe4ee',
      colorMira: '#ffffff', colorSeleccion: '#22d3ee', colorResaltado: '#22d3ee', colorVentana: '#0ea5e9', colorReferencia: '#facc15',
      colorMarquesina: '#38bdf8', colorCruce: '#4ade80' },
  },
  autocad: {
    etiqueta: 'AutoCAD (gris azulado)',
    valores: { fondo: '#212830', colorRejilla: '#2b333d', colorEjes: '#3d4854', colorCruz: '#ffffff',
      colorMira: '#ffffff', colorSeleccion: '#4da6ff', colorResaltado: '#4da6ff', colorVentana: '#2f80ed', colorReferencia: '#facc15',
      colorMarquesina: '#2f80ed', colorCruce: '#3ecf8e' },
  },
  negro: {
    etiqueta: 'AutoCAD clásico (negro)',
    valores: { fondo: '#000000', colorRejilla: '#161616', colorEjes: '#242424', colorCruz: '#ffffff',
      colorMira: '#ffffff', colorSeleccion: '#00e0ff', colorResaltado: '#00e0ff', colorVentana: '#2f80ed', colorReferencia: '#facc15',
      colorMarquesina: '#00e0ff', colorCruce: '#00e676' },
  },
  claro: {
    etiqueta: 'Claro (papel)',
    valores: { fondo: '#f7f9fb', colorRejilla: '#e3e9f0', colorEjes: '#c6d1dc', colorCruz: '#1f2937',
      colorMira: '#1d4ed8', colorSeleccion: '#0b6bcb', colorResaltado: '#0ea5e9', colorVentana: '#0284c7', colorReferencia: '#b45309',
      colorMarquesina: '#0b6bcb', colorCruce: '#0f9d58' },
  },
};

export const TEMAS_LISTA = Object.keys(TEMAS);

/**
 * Orden en el que rota el **botón de tema de la barra de estado**: se empieza por el oscuro del
 * programa (que es el que viene puesto), el primer clic pasa al **papel** (hoja clara), de ahí al
 * gris azulado de AutoCAD y al negro clásico, y se vuelve al principio. El botón siempre deja el
 * dibujo legible: al cambiar el fondo, los colores del plano se recalculan (`ajustarParaFondo`).
 */
export const ORDEN_TEMAS = ['programa', 'claro', 'autocad', 'negro'];

/** Nombre corto del tema, para el botón de la barra de estado. */
export const NOMBRE_CORTO_TEMA = {
  claro: 'Papel', programa: 'Oscuro', autocad: 'AutoCAD', negro: 'Negro', personalizado: 'Personal',
};

/** Tema siguiente en la rueda del botón (si el actual no está en la lista, empieza por el papel). */
export function siguienteTema(tema) {
  const i = ORDEN_TEMAS.indexOf(tema);
  return ORDEN_TEMAS[(i + 1 + ORDEN_TEMAS.length) % ORDEN_TEMAS.length];
}

/** Rótulo corto del tema, con el que se etiqueta el botón. */
export function nombreTemaCorto(tema) {
  return NOMBRE_CORTO_TEMA[tema] || NOMBRE_CORTO_TEMA.personalizado;
}

/** Aplica un tema a las preferencias (devuelve una copia normalizada). */
export function aplicarTema(prefs, tema) {
  const t = TEMAS[tema];
  if (!t) return normalizarPrefs(prefs);
  return normalizarPrefs(Object.assign({}, prefs, t.valores, { tema }));
}

/** Tema que corresponde a los colores actuales (o `personalizado` si no coincide con ninguno). */
export function temaDe(prefs) {
  for (const id of TEMAS_LISTA) {
    const v = TEMAS[id].valores;
    if (Object.keys(v).every((k) => String(prefs[k]).toLowerCase() === String(v[k]).toLowerCase())) return id;
  }
  return 'personalizado';
}

/* ------------------------------- validación ------------------------------- */

const esHex = (v) => /^#[0-9a-fA-F]{6}$/.test(String(v || ''));

/** Comprueba y ajusta un valor según su definición. Devuelve `undefined` si no sirve de nada. */
export function valorValido(def, v) {
  if (!def) return undefined;
  // Un control vacío **no es un valor**: significa «déjalo como está». Sin esta comprobación,
  // borrar el número para escribir otro dejaba el ajuste en su mínimo (por ejemplo, la cruz del
  // cursor a 0 px, que es como si desapareciera) porque Number('') es 0.
  if (v === undefined || v === null) return undefined;
  if (typeof v === 'string' && v.trim() === '') return undefined;
  if (def.tipo === 'bool') return !!v;
  if (def.tipo === 'color') {
    const hex = normalizarHex(v);
    return hex || undefined;
  }
  if (def.tipo === 'opcion') {
    return def.opciones.some((o) => o[0] === v) ? v : undefined;
  }
  // Se acepta la coma decimal, que es como se escriben los números en español
  const n = Number(typeof v === 'string' ? v.trim().replace(',', '.') : v);
  if (!isFinite(n)) return undefined;
  return Math.min(def.max, Math.max(def.min, n));
}

/**
 * Preferencias completas y seguras: parte de los valores de fábrica, aplica lo que venga y
 * **descarta lo que no valga** (un fichero de preferencias manipulado no puede romper el dibujo).
 */
export function normalizarPrefs(p, base = PREFS_POR_DEFECTO) {
  const out = Object.assign({}, base);
  for (const d of PREF_DEFS) {
    const v = valorValido(d, p ? p[d.clave] : undefined);
    if (v !== undefined) out[d.clave] = v;
  }
  // El tema se recalcula: es la etiqueta de los colores, no un ajuste independiente
  out.tema = temaDe(out);
  return out;
}

/**
 * Revision de un juego de preferencias **tal como llegó** (de un fichero, de la memoria del
 * navegador o de un control): informa de los ajustes que no valen o que se han tenido que limitar.
 * Los ajustes ausentes no se denuncian: se completan con el valor de fábrica.
 */
export function revisarPrefs(p) {
  const problemas = [];
  for (const d of PREF_DEFS) {
    const bruto = p ? p[d.clave] : undefined;
    if (bruto === undefined || bruto === null || bruto === '') continue;
    const v = valorValido(d, bruto);
    if (v === undefined) {
      problemas.push({ clave: d.clave, etiqueta: d.etiqueta, valor: bruto, motivo: 'no es un valor válido' });
    } else if (d.tipo === 'num' && Number(bruto) !== v) {
      problemas.push({ clave: d.clave, etiqueta: d.etiqueta, valor: bruto, min: d.min, max: d.max, motivo: 'fuera de rango' });
    } else if (d.tipo === 'color' && normalizarHex(bruto) !== String(bruto).toLowerCase()) {
      problemas.push({ clave: d.clave, etiqueta: d.etiqueta, valor: bruto, motivo: 'color normalizado' });
    }
  }
  return problemas;
}

/* ------------------------------- geometría del puntero ------------------------------- */

/**
 * Longitud de cada brazo de la cruz, en píxeles.
 * AutoCAD mide el tamaño de la cruz en porcentaje de la pantalla; aquí se toma la mitad del lado
 * menor de la ventana, de forma que el 100 % llega a los bordes.
 */
export function tamanoCruzPx(porcentaje, ancho, alto) {
  const pct = Math.min(100, Math.max(1, Number(porcentaje) || 0));
  const lado = Math.min(Number(ancho) || 0, Number(alto) || 0);
  return Math.max(6, (lado / 2) * (pct / 100));
}

/** Cuadrado de la mira: la mira de selección de AutoCAD, centrada en el puntero. */
export function cajaMira(x, y, tamano) {
  const lado = Math.max(0, Number(tamano) || 0);
  const mitad = lado / 2;
  return { x: x - mitad, y: y - mitad, lado, minX: x - mitad, minY: y - mitad, maxX: x + mitad, maxY: y + mitad };
}

/** ¿Cabe el puntero dentro de la mira? (apertura de selección: se elige lo que toca la mira) */
export function enMira(objetivo, centro, tamano) {
  if (!objetivo || !centro) return false;
  const c = cajaMira(centro.x, centro.y, tamano);
  const dentroX = objetivo.x >= c.minX && objetivo.x <= c.maxX;
  const dentroY = objetivo.y >= c.minY && objetivo.y <= c.maxY;
  return dentroX && dentroY;
}

/* ------------------------------- forzados ------------------------------- */

/** Ángulo (radianes) entre dos puntos. */
export function angulo(a, b) {
  return Math.atan2(b.y - a.y, b.x - a.x);
}

/** Pega el segmento base→punto a un incremento angular (rastreo polar). */
export function ajustarAPolar(base, p, incrementoGrados) {
  const inc = rad2(incrementoGrados);
  const d = Math.hypot(p.x - base.x, p.y - base.y);
  const a = Math.round(angulo(base, p) / inc) * inc;
  return { x: base.x + Math.cos(a) * d, y: base.y + Math.sin(a) * d, angulo: a, radio: d };
}

/** Limita el segmento base→punto a horizontal o vertical (modo ortogonal). */
export function ajustarAOrto(base, p) {
  const dx = p.x - base.x, dy = p.y - base.y;
  return Math.abs(dx) >= Math.abs(dy) ? { x: p.x, y: base.y } : { x: base.x, y: p.y };
}

export const rad2 = (grados) => (Number(grados) || 0) * Math.PI / 180;
export const grados2 = (rad) => (Number(rad) || 0) * 180 / Math.PI;

/**
 * Punto final tras aplicar los forzados del usuario al mover el cursor.
 *
 * Precedencia como en AutoCAD: **referencia a objetos → orto/polar → forzado a rejilla**. El punto
 * enganchado a un vértice manda sobre todo lo demás; el modo ortogonal manda sobre el forzado a
 * rejilla (si no, el segmento se «rompería» en la esquina).
 *
 * `referencia` es el vértice enganchado (si lo hay) y `base` el punto de partida del segmento.
 */
export function puntoForzado(p, { base = null, referencia = null, prefs, forzado = null } = {}) {
  const q = prefs || PREFS_POR_DEFECTO;
  const conForzado = forzado === null ? q.forzadoRejilla : !!forzado;
  if (referencia) return { x: referencia.x, y: referencia.y, modo: 'referencia' };
  if (base && q.orto) return Object.assign(ajustarAOrto(base, p), { modo: 'orto' });
  if (base && q.polar) return Object.assign(ajustarAPolar(base, p, q.incrementoPolar), { modo: 'polar' });
  if (conForzado) {
    const g = Number(q.pasoRejilla) || 1;
    return { x: Math.round(p.x / g) * g, y: Math.round(p.y / g) * g, modo: 'rejilla' };
  }
  return { x: p.x, y: p.y, modo: 'libre' };
}

/** Etiqueta del modo de forzado (lo que AutoCAD enseña junto al cursor). */
export const ETIQUETA_FORZADO = {
  referencia: 'Referencia',
  orto: 'Ortogonal',
  polar: 'Polar',
  rejilla: 'Forzado',
  libre: '',
};

/* ------------------------------- lectura ------------------------------- */

/** Texto de coordenadas como el de la barra de estado («12,50 · 3,20 m»). */
export function coordenadasTexto(p, decimales = 2) {
  if (!p) return '';
  const n = (v) => Number(v || 0).toFixed(decimales).replace('.', ',');
  return `${n(p.x)} · ${n(p.y)} m`;
}

/**
 * Aviso de visibilidad de un color sobre su fondo. No cambia nada: informa.
 * Se usa el contraste WCAG del módulo de color (`app/io/aci.js`).
 */
export function avisoContraste(color, fondo, minimo = 1.6) {
  const c = contraste(color, fondo);
  if (c >= minimo) return { contraste: c, aviso: '' };
  return {
    contraste: c,
    aviso: `poco visible sobre este fondo (contraste ${c.toFixed(2)}:1)`,
  };
}

/** Color recomendado para el puntero sobre un fondo dado (solo como sugerencia del panel). */
export function colorSugerido(fondo) {
  const ajuste = ajustarParaFondo('#ffffff', fondo);
  return ajuste.cambiado ? ajuste.color : '#ffffff';
}

/** Resumen de una línea para la barra de estado y los avisos. */
export function resumenPrefs(prefs) {
  const p = normalizarPrefs(prefs);
  const partes = [
    `cruz ${p.tamanoCruz} %`,
    `mira ${p.tamanoMira} px`,
    p.rejillaVisible ? `rejilla ${p.pasoRejilla} m` : 'rejilla oculta',
  ];
  if (p.forzadoRejilla) partes.push('forzado');
  if (p.orto) partes.push('ortogonal');
  if (p.polar) partes.push(`polar ${p.incrementoPolar}°`);
  partes.push(`tema ${TEMAS[p.tema] ? TEMAS[p.tema].etiqueta : p.tema}`);
  return partes.join(' · ');
}

/** Nombres de las teclas de función de los forzados, como en AutoCAD. */
export const TECLAS = { referenciaObjetos: 'F3', rejillaVisible: 'F7', orto: 'F8', forzadoRejilla: 'F9', polar: 'F10' };

/** Ajustes que se pueden conmutar con una tecla o desde la barra de estado (como en AutoCAD). */
export const CONMUTABLES = ['referenciaObjetos', 'rejillaVisible', 'forzadoRejilla', 'orto', 'polar'];

/** Leyenda corta de cada ajuste conmutable (barra de estado). */
export const LEYENDA_CONMUTABLE = {
  referenciaObjetos: 'REF', rejillaVisible: 'REJILLA', forzadoRejilla: 'FORZ', orto: 'ORTO', polar: 'POLAR',
};
