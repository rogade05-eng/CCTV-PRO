/**
 * CCTV DESIGN PRO — Sombras de los obstáculos sobre las áreas de cobertura (CP CCTV §13, §14)
 * core/shadows.js
 *
 * El cono de una cámara se dibujaba entero, como si nada se interpusiera: el análisis por celdas sí
 * descontaba los obstáculos, pero **el dibujo no**, de modo que en pantalla parecía que la cámara veía
 * a través de los muros. Aquí la huella se recorta con las sombras que proyectan los obstáculos,
 * **en tres dimensiones**: el rayo va de la altura de montaje de la cámara a la altura del objetivo
 * (1,00 m, la de una persona) y solo lo corta aquello que ocupa ese rango de alturas. Por eso una
 * mesa de 0,80 m no tapa y un muro de 2,80 m sí.
 *
 * MÉTODO: **polígono de visibilidad por barrido de eventos** (geometría computacional clásica),
 * restringido al sector del campo de visión, y recorte final con ese sector (Sutherland–Hodgman).
 *
 *   1. Los únicos ángulos en los que puede cambiar la distancia de corte son los de los **vértices**
 *      de los obstáculos: son los *eventos* del barrido. Se toma cada vértice tres veces: un pelo
 *      antes, en el vértice y un pelo después (ε = 1e-4 rad ≈ 0,006°).
 *   2. Entre dos eventos seguidos el rayo corta **el mismo segmento** (o ninguno), así que el borde
 *      de la sombra es exactamente la recta que une los dos puntos: **no hace falta muestrear**.
 *      Esa es la diferencia con un muestreo uniforme: aquí el resultado es exacto, no aproximado.
 *   3. Cuando no corta nada, el borde es el **arco** del alcance: ahí sí se muestrea, y solo lo
 *      justo para que la cuerda no se separe del arco más de una tolerancia (2 cm por defecto).
 *   4. Con las distancias de corte se cosen los **sectores visibles**: tramos seguidos de ángulos
 *      con visión, cerrados por detrás con el arco interior (la distancia mínima de la óptica).
 *   5. Por último se recorta con el sector del FOV para que nada se salga del campo teórico.
 *
 * Complejidad: O(v · log v + v · k) siendo v el número de vértices de obstáculo dentro del alcance
 * y k el coste de cada rayo contra el índice espacial (ya acotado por `IndiceOpacos`). No hay
 * muestreo en malla: el coste no depende de la resolución con la que se dibuje.
 *
 * Salida: **uno o varios sectores**. Si un muro parte el cono en dos, salen dos polígonos.
 *
 * Módulo puro: no toca el DOM ni el lienzo.
 */
import { parametroCruce, cortaRayo, ALTURA_OBJETIVO } from './obstacles.js?v=b441e3fc';
import { polyArea, recortarPoligono, sectorPoligono, distPointSeg } from './geometry.js?v=b441e3fc';

const TAU = Math.PI * 2;
const rad = (g) => (g * Math.PI) / 180;

/** Separación angular a cada lado de un vértice para ver qué hay delante y detrás de él. */
export const EPS_ANG = 1e-4;

/** Deja el ángulo en (−π, π]. */
export function normalizarAngulo(a) {
  let x = a % TAU;
  if (x <= -Math.PI) x += TAU;
  if (x > Math.PI) x -= TAU;
  return x;
}

/**
 * Primer corte del rayo que sale de `origen` con el ángulo dado.
 * @returns {{d: number, seg: object|null}} distancia al corte (`Infinity` si no lo tapa nada antes de
 *          `maxD`) y el **segmento** que lo ha cortado, que es lo que permite saber si dos rayos
 *          seguidos están viendo el mismo trozo de pared (y unirlos con una recta exacta).
 *
 * `hCam` es la altura de montaje y `hObjetivo` la altura a la que se mira: el rayo desciende de una a
 * otra de forma lineal, así que el corte se decide comparando esa altura con el rango [base, h].
 */
export function corteDelRayo(origen, angulo, hCam, hObjetivo, maxD, idx) {
  if (!(maxD > 0)) return { d: Infinity, seg: null };
  const fin = { x: origen.x + Math.cos(angulo) * maxD, y: origen.y + Math.sin(angulo) * maxD };
  let mejor = Infinity, segMejor = null;
  for (const s of idx.candidatos(origen, fin)) {
    const t = parametroCruce(origen, fin, s);
    if (t < 0) continue;
    if (!cortaRayo(s, hCam, hObjetivo, t)) continue;
    const d = t * maxD;
    if (d < mejor) { mejor = d; segMejor = s; }
  }
  if (mejor <= maxD) return { d: mejor, seg: segMejor };
  return { d: Infinity, seg: null };
}

/** Distancia a la que el rayo queda tapado por primera vez (sin decir quién lo tapa). */
export function distanciaBloqueo(origen, angulo, hCam, hObjetivo, maxD, idx) {
  return corteDelRayo(origen, angulo, hCam, hObjetivo, maxD, idx).d;
}

/** Punto a la distancia `d` de `origen` en la dirección `angulo`. */
const puntoA = (origen, angulo, d) => ({ x: origen.x + Math.cos(angulo) * d, y: origen.y + Math.sin(angulo) * d });

/**
 * Ángulos en los que el segmento `s` corta el círculo de radio `r` centrado en `o`.
 * Hacen falta porque la distancia visible es `min(alcance, distancia al obstáculo)`: en el punto
 * donde el muro se sale del círculo del alcance, el borde deja de apoyarse en el muro y pasa al
 * arco. Sin ese evento, el polígono cortaría por cuerda y se comería área.
 */
export function angulosDeCorte(o, s, r) {
  const ax = s.a.x - o.x, ay = s.a.y - o.y;
  const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y;
  const A = dx * dx + dy * dy;
  if (A < 1e-18) return [];
  const B = 2 * (ax * dx + ay * dy);
  const C = ax * ax + ay * ay - r * r;
  const disc = B * B - 4 * A * C;
  if (disc < 0) return [];
  const raiz = Math.sqrt(disc);
  const out = [];
  for (const t of [(-B - raiz) / (2 * A), (-B + raiz) / (2 * A)]) {
    if (t < -1e-9 || t > 1 + 1e-9) continue;
    out.push(Math.atan2(ay + dy * t, ax + dx * t));
  }
  return out;
}

/** Paso angular con el que la cuerda de un arco de radio `r` no se separa más de `tol` del arco. */
export const pasoDeArco = (r, tol, tope) => {
  const t = Math.min(0.25, Math.max(1e-6, tol) / Math.max(1e-6, r));
  const p = 2 * Math.acos(Math.max(-1, Math.min(1, 1 - t)));
  return Math.min(tope || Infinity, Math.max(1e-3, p));
};

/**
 * **Barrido de visibilidad** entre los ángulos `a0` y `a1` (rad), hasta la distancia `far`.
 * Devuelve las muestras ordenadas por ángulo, cada una con la distancia visible y el segmento que
 * la limita. Es el corazón del método: los ángulos son **los de los vértices de los obstáculos**,
 * no una rejilla, así que entre dos muestras seguidas el borde es una recta exacta.
 */
export function barridoVisibilidad(o, a0, a1, hCam, hObjetivo, far, idx, opciones = {}) {
  const tol = Number(opciones.tolCuerda ?? 0.02);        // 2 cm de separación cuerda-arco
  const tope = rad(Number(opciones.pasoGrados) || 2);    // y nunca más de 2° por tramo de arco
  const eventos = [a0, a1];
  let examinados = 0;
  for (const s of idx.candidatos({ x: o.x - far, y: o.y - far }, { x: o.x + far, y: o.y + far })) {
    examinados++;
    // Ojo: el segmento cuenta aunque sus **extremos** queden más allá del alcance. Un muro largo
    // puede tener las puntas a 50 m y pasar a 6 m de la cámara; si no se pusieran sus ángulos, el
    // barrido no sabría dónde empieza y acaba esa sombra y cortaría por cuerda, comiéndose área.
    if (distPointSeg(o, s.a, s.b) > far) continue;       // todo el segmento fuera del alcance
    const criticos = [];
    for (const p of [s.a, s.b]) {
      const dd = Math.hypot(p.x - o.x, p.y - o.y);
      if (dd < 1e-9) continue;                           // vértice encima de la cámara: sin ángulo
      criticos.push(Math.atan2(p.y - o.y, p.x - o.x));
    }
    for (const q of angulosDeCorte(o, s, far)) criticos.push(q);   // donde el muro sale del alcance
    for (const base of criticos) {
      for (const q of [base - EPS_ANG, base, base + EPS_ANG]) {
        let x = q;
        while (x < a0) x += TAU;                          // se baja al intervalo del abanico
        while (x > a1) x -= TAU;
        if (x >= a0 - 1e-12 && x <= a1 + 1e-12) eventos.push(Math.min(a1, Math.max(a0, x)));
      }
    }
  }
  eventos.sort((p, q) => p - q);
  const limpios = [];
  for (const a of eventos) if (!limpios.length || a - limpios[limpios.length - 1] > 1e-9) limpios.push(a);

  const muestras = limpios.map((a) => {
    const c = corteDelRayo(o, a, hCam, hObjetivo, far, idx);
    return { a, d: Math.min(far, c.d), seg: c.seg };
  });

  // Entre dos muestras **sin obstáculo** el borde es el arco: se le añaden los puntos que hacen falta
  // para que la poligonal no se coma el arco. Con obstáculo, la recta ya es exacta: no se añade nada.
  const paso = pasoDeArco(far, tol, tope);
  const salida = [];
  for (let i = 0; i < muestras.length; i++) {
    salida.push(muestras[i]);
    const A = muestras[i], B = muestras[i + 1];
    if (!B || A.seg || B.seg) continue;
    if (B.a - A.a <= paso) continue;
    for (let a = A.a + paso; a < B.a - 1e-9; a += paso) salida.push({ a, d: far, seg: null });
  }
  return { muestras: salida, examinados, eventos: limpios.length };
}

/**
 * Huella de una cámara **recortada por las sombras**.
 *
 * @param {object} huella   la que devuelve `footprint()` (con `origin`, `near`, `far`, `az`, `half`).
 * @param {number} hCam     altura de montaje de la cámara (m).
 * @param {number} hObjetivo altura a la que se comprueba la visión (m).
 * @param {IndiceOpacos} idx índice de segmentos opacos del proyecto.
 * @returns {{sectores: Array, area: number, teoria: number, pct: number, examinados: number,
 *            angulos: number, vertices: number}}
 */
export function huellaRecortada(huella, hCam, hObjetivo, idx, opciones = {}) {
  const o = huella && huella.origin;
  const near = Math.max(0, Number(huella && huella.near) || 0);
  const far = Number(huella && huella.far) || 0;
  const vacio = { sectores: [], area: 0, teoria: 0, pct: 0, examinados: 0, angulos: 0, vertices: 0 };
  if (!o || !(far > near)) return vacio;

  const circular = huella.hfov >= 359.9;               // ojo de pez: 360°
  const half = circular ? Math.PI : (huella.half !== undefined ? huella.half : rad((huella.hfov || 60) / 2));
  const az = circular ? 0 : (huella.az !== undefined ? huella.az : 0);
  const a0 = circular ? -Math.PI : az - half;
  const a1 = circular ? Math.PI : az + half;

  // 1. Barrido: solo los ángulos de los vértices de obstáculo (más los extremos del abanico)
  const { muestras, examinados } = barridoVisibilidad(o, a0, a1, hCam, hObjetivo, far, idx, opciones);

  // 2. Sectores: tramos seguidos de ángulos con visión, cerrados por la distancia mínima de la óptica.
  //    El borde exterior ya es exacto (recta sobre la pared o arco muestreado); el **arco interior**
  //    también se muestrea, porque una sola cuerda a la distancia mínima se come medio metro.
  const pasoDentro = near > 1e-6 ? pasoDeArco(near, Number(opciones.tolCuerda ?? 0.02), rad(Number(opciones.pasoGrados) || 2)) : 0;
  const sectores = [];
  let tramo = null;
  const cerrar = () => {
    if (tramo && tramo.length >= 2) {
      const pts = tramo.map((q) => puntoA(o, q.a, Math.max(near, Math.min(q.d, far))));
      if (near > 1e-6) {
        const vuelta = [];
        for (let i = tramo.length - 1; i > 0; i--) {
          const A = tramo[i], B = tramo[i - 1];
          vuelta.push(puntoA(o, A.a, near));
          for (let a = A.a - pasoDentro; a > B.a + 1e-9; a -= pasoDentro) vuelta.push(puntoA(o, a, near));
        }
        vuelta.push(puntoA(o, tramo[0].a, near));
        pts.push(...vuelta);
      } else {
        pts.push({ x: o.x, y: o.y });
      }
      if (pts.length >= 3) sectores.push(pts);
    }
    tramo = null;
  };
  for (const q of muestras) {
    if (q.d > near + 1e-9) (tramo = tramo || []).push(q);
    else cerrar();
  }
  cerrar();

  // 3. En las huellas de 360° el último sector y el primero son el mismo: se unen
  if (circular && sectores.length > 1) {
    const pri = muestras[0], ult = muestras[muestras.length - 1];
    if (pri && ult && pri.d > near && ult.d > near) {
      const primero = sectores.shift(), ultimo = sectores.pop();
      sectores.push(ultimo.concat(primero));
    }
  }

  // 4. Recorte final con el sector del campo de visión (Sutherland–Hodgman). El barrido ya va
  //    restringido al abanico, así que esto es una red de seguridad contra los bordes numéricos;
  //    si por cualquier caso el recorte diera más área que el original, se queda el original.
  let polis = sectores;
  if (!circular && sectores.length) {
    const sector = sectorPoligono(o, a0, a1, far * 1.02, Number(opciones.tolCuerda ?? 0.02));
    polis = sectores.map((p) => {
      const rec = recortarPoligono(p, sector);
      if (rec.length < 3) return p;
      return Math.abs(polyArea(rec)) <= Math.abs(polyArea(p)) * 1.000001 + 1e-9 ? rec : p;
    });
  }

  const area = polis.reduce((s, p) => s + Math.abs(polyArea(p)), 0);
  const teoria = Math.abs(polyArea(huella.polygon || []));
  return {
    sectores: polis, area, teoria, examinados,
    pct: teoria > 0 ? Math.max(0, Math.min(100, (1 - area / teoria) * 100)) : 0,
    angulos: muestras.length,
    vertices: polis.reduce((s, p) => s + p.length, 0),
  };
}

/**
 * Recorta todas las huellas de una cámara (una por preset si es PTZ, §38).
 * @returns {Array} una lista de resultados, uno por huella.
 */
export function recortarHuellas(huellas, hCam, hObjetivo, idx, opciones = {}) {
  return (huellas || []).map((fp) => huellaRecortada(fp, hCam, hObjetivo, idx, opciones));
}

export { ALTURA_OBJETIVO };
