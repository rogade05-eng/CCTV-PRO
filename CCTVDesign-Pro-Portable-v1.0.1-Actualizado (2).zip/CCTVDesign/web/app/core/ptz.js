/**
 * CCTV DESIGN PRO — Módulo PTZ (CP CCTV §38, §13, §15, §21)
 *
 * Un PTZ no tiene un campo de visión fijo: barre una secuencia de posiciones
 * memorizadas (presets) según una patrulla. Este módulo convierte esa secuencia
 * en datos técnicos: huella de cada preset, cobertura ponderada por tiempo de
 * permanencia, ciclo de patrulla, bitrate de grabación y documentación.
 *
 * El módulo es opcional: si no hay cámaras PTZ el resto del programa no cambia (§38).
 */
import { footprint, maxDistanceFor } from './dori.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

export const PRESET_DEFAULT = { name: '', azimuth: 0, tilt: 10, focal: null, objective: null, dwell: 20 };

/** ¿La cámara es PTZ según el catálogo? */
export function isPtz(cam, catalog) {
  const it = getItem(catalog, cam && cam.data && cam.data.catalogId);
  return !!(it && it.specs && it.specs.ptz);
}

/** Límites mecánicos y ópticos de la cámara (del catálogo, con valores por defecto). */
export function presetLimits(cam, catalog) {
  const it = getItem(catalog, cam && cam.data && cam.data.catalogId);
  const s = (it && it.specs) || {};
  const focals = (s.focalOptions || []).map(Number).filter((n) => n > 0);
  return {
    pan: s.panRange || [0, 360],
    tilt: s.tiltRange || [-15, 90],
    focalMin: focals.length ? Math.min(...focals) : Number(s.lens) || 4,
    focalMax: focals.length ? Math.max(...focals) : Number(s.lens) || 4,
    focalOptions: focals,
    speedPan: Number(s.speedPan) || 0 };
}

/** Presets normalizados de una cámara (siempre un array, aunque esté vacío). */
export function cameraPresets(cam) {
  const list = (cam && cam.data && cam.data.presets) || [];
  return list.map((p, i) => ({
    index: i,
    name: p.name || `Preset ${i + 1}`,
    azimuth: Number(p.azimuth) || 0,
    tilt: p.tilt === undefined ? PRESET_DEFAULT.tilt : Number(p.tilt),
    focal: Number(p.focal) || null,
    objective: p.objective || cam.data.objective || 'OBSERVACION',
    dwell: Number(p.dwell) > 0 ? Number(p.dwell) : PRESET_DEFAULT.dwell }));
}

/** Preset a partir de la posición actual de la cámara (captura de vista). */
export function presetFromCurrent(cam, name, dwell) {
  return {
    name: name || `Vista ${((cam.data.presets || []).length + 1)}`,
    azimuth: Number(cam.data.azimuth) || 0,
    tilt: cam.data.tilt === undefined ? PRESET_DEFAULT.tilt : Number(cam.data.tilt),
    focal: Number(cam.data.focal) || null,
    objective: cam.data.objective || 'OBSERVACION',
    dwell: Number(dwell) > 0 ? Number(dwell) : PRESET_DEFAULT.dwell };
}

/**
 * Reparte N presets uniformemente por el recorrido panorámico de la cámara.
 * Sirve para vigilancia de barrido (perímetro, gran superficie) sin definir vistas a mano.
 */
export function spreadPresets(cam, catalog, n = 4, opts = {}) {
  const lim = presetLimits(cam, catalog);
  const total = Math.max(1, n);
  const from = opts.from === undefined ? lim.pan[0] : opts.from;
  const to = opts.to === undefined ? lim.pan[1] : opts.to;
  const focus = opts.focal || cam.data.focal || null;
  const out = [];
  for (let i = 0; i < total; i++) {
    const az = from + ((to - from) * i) / total;
    out.push({
      name: opts.base ? `${opts.base} ${i + 1}` : `Barrido ${i + 1}`,
      azimuth: ((az % 360) + 360) % 360,
      tilt: opts.tilt === undefined ? PRESET_DEFAULT.tilt : opts.tilt,
      focal: focus,
      objective: opts.objective || cam.data.objective || 'OBSERVACION',
      dwell: opts.dwell || PRESET_DEFAULT.dwell });
  }
  return out;
}

/** Huella en planta de un preset concreto (azimut, inclinación y zoom propios). */
export function presetFootprint(cam, preset, catalog, rules) {
  const fp = footprint(cam, catalog, rules, {
    azimuth: preset.azimuth, tilt: preset.tilt, focal: preset.focal, objective: preset.objective });
  return {
    ...fp,
    preset,
    label: preset.name,
    objectiveLabel: preset.objective,
    far: fp.far, near: fp.near,
    maxObjDist: maxDistanceFor(getItem(catalog, cam.data.catalogId), preset.objective) };
}

/** Todas las huellas de una cámara: una sola si es fija, una por preset si es PTZ. */
export function footprintsOf(cam, catalog, rules) {
  if (!isPtz(cam, catalog)) return [footprint(cam, catalog, rules)];
  const list = cameraPresets(cam);
  if (!list.length) return [footprint(cam, catalog, rules)];
  return list.map((p) => presetFootprint(cam, p, catalog, rules));
}

/**
 * Ciclo de patrulla: tiempo de permanencia en cada preset más el tiempo de giro
 * entre ellos. Devuelve también el reparto de tiempo (duty) de cada posición.
 */
export function patrolCycle(cam, catalog, rules, presets) {
  const list = presets || cameraPresets(cam);
  const journey = Math.max(1, ruleNum(rules, 'PTZ_GIRO_S'));
  const dwellTotal = list.reduce((a, p) => a + p.dwell, 0);
  const moveTotal = list.length ? list.length * journey : 0;
  const cycleSec = dwellTotal + moveTotal;
  const positions = list.map((p) => ({
    ...p,
    duty: cycleSec ? p.dwell / cycleSec : 0,
    dwellPct: cycleSec ? (p.dwell / cycleSec) * 100 : 0 }));
  const perHour = cycleSec ? 3600 / cycleSec : 0;
  return {
    count: list.length, journey, dwellTotal, moveTotal, cycleSec,
    perHour, positions,
    // Cada posición se visita esta fracción del día
    visitsPerDay: perHour * 24 };
}

/** Fracción de tiempo que la cámara está grabando movimiento de patrulla. */

/** Tiempo medio de permanencia por posición; útil para documentación. */

/**
 * Resumen PTZ del proyecto: cámaras, presets, ciclos y cobertura media ponderada.
 * La cobertura ponderada es la esperanza del área vigilada: cada preset pesa su
 * fracción de tiempo en el ciclo (Σ duty · área). No sustituye al análisis de
 * cobertura —que suma la unión instantánea de todas las posiciones—, lo matiza.
 */
export function ptzSummary(prj, catalog, rules, coverage) {
  const cams = prj.entities.filter((e) => e.type === 'camera' && isPtz(e, catalog));
  const rows = [];
  let presets = 0, weighted = 0, cycleMax = 0;
  for (const cam of cams) {
    const cycle = patrolCycle(cam, catalog, rules);
    const cov = coverage && coverage.cameras ? coverage.cameras.find((c) => c.id === cam.id) : null;
    const areas = (cov && cov.presetAreas) || [];
    const w = cycle.positions.reduce((a, p, i) => a + p.duty * (areas[i] || 0), 0);
    presets += cycle.count;
    weighted += w;
    cycleMax = Math.max(cycleMax, cycle.cycleSec);
    rows.push({
      id: cam.id, label: cam.data.label || cam.id, count: cycle.count,
      cycleSec: cycle.cycleSec, cycle, unionArea: (cov && cov.area) || 0,
      weightedArea: w, patrol: cam.data.ptzPatrol !== false, positions: cycle.positions,
      presetAreas: areas });
  }
  return { cameras: cams.length, count: cams.length, presets, weightedArea: weighted, cycleMax, rows };
}

/** Cuadro de presets para documentación y exportación (§28, §29). */
export function ptzSchedule(prj, catalog, rules) {
  const rows = [];
  for (const cam of prj.entities.filter((e) => e.type === 'camera' && isPtz(e, catalog))) {
    const cycle = patrolCycle(cam, catalog, rules);
    if (!cycle.count) {
      rows.push({ camera: cam.data.label || cam.id, preset: '—', azimuth: '', tilt: '', focal: '', objective: '', dwell: '', duty: '', cycle: 0 });
      continue;
    }
    for (const p of cycle.positions) {
      rows.push({
        camera: cam.data.label || cam.id, preset: p.name,
        azimuth: p.azimuth, tilt: p.tilt,
        focal: p.focal || (getItem(catalog, cam.data.catalogId) || { specs: {} }).specs.lens,
        objective: p.objective, dwell: p.dwell,
        duty: p.dwellPct, cycle: cycle.cycleSec });
    }
  }
  return rows;
}

/** Incidencias propias del módulo PTZ (§30). */
export function validatePtz(cam, catalog, rules) {
  const out = [];
  const lim = presetLimits(cam, catalog);
  const list = cameraPresets(cam);
  const name = cam.data.label || cam.id;
  const max = ruleNum(rules, 'PTZ_PRESETS_MAX');
  const dwellMin = ruleNum(rules, 'PTZ_DWELL_MIN');
  const cicloMax = ruleNum(rules, 'PTZ_CICLO_MAX');

  if (!list.length) {
    out.push({ code: 'PTZ_SIN_PRESETS', severity: 'warn', text: `${name}: cámara PTZ sin presets definidos (cobertura de una sola vista)` });
    return out;
  }
  if (list.length > max) out.push({ code: 'PTZ_PRESET_EXCESO', severity: 'warn', text: `${name}: ${list.length} presets superan el máximo razonable de ${max}` });
  for (const p of list) {
    const az = ((p.azimuth % 360) + 360) % 360;
    const tilt = p.tilt;
    const insidePan = lim.pan[1] - lim.pan[0] >= 360 || (az >= lim.pan[0] && az <= lim.pan[1]);
    if (!insidePan) out.push({ code: 'PTZ_FUERA_RANGO', severity: 'error', text: `${name} · ${p.name}: azimut ${az}° fuera del recorrido ${lim.pan[0]}–${lim.pan[1]}°` });
    if (tilt < lim.tilt[0] || tilt > lim.tilt[1]) out.push({ code: 'PTZ_FUERA_RANGO', severity: 'error', text: `${name} · ${p.name}: inclinación ${tilt}° fuera del rango mecánico ${lim.tilt[0]}–${lim.tilt[1]}°` });
    if (p.focal && (p.focal < lim.focalMin - 0.01 || p.focal > lim.focalMax + 0.01))
      out.push({ code: 'PTZ_ZOOM_INVALIDO', severity: 'error', text: `${name} · ${p.name}: zoom ${p.focal} mm fuera del objetivo ${lim.focalMin}–${lim.focalMax} mm` });
    if (p.dwell < dwellMin) out.push({ code: 'PTZ_PERMANENCIA_CORTA', severity: 'warn', text: `${name} · ${p.name}: permanencia ${p.dwell} s por debajo del mínimo de ${dwellMin} s` });
  }
  const cycle = patrolCycle(cam, catalog, rules, list);
  if (cycle.cycleSec > cicloMax)
    out.push({ code: 'PTZ_CICLO_LARGO', severity: 'warn', text: `${name}: el ciclo completo dura ${Math.round(cycle.cycleSec)} s (máximo ${cicloMax} s): una posición puede tardar demasiado en repetirse` });

  // PoE: un PTZ en movimiento consume más que una cámara fija (§20)
  const it = getItem(catalog, cam.data.catalogId);
  const power = Number((it && it.specs && it.specs.power) || 0);
  if (power > 15.4) {
    const poeClass = (it && it.specs && it.specs.poeClass) || '4';
    out.push({ code: 'PTZ_POE_PLUS', severity: 'info', text: `${name}: ${power} W exigen PoE+ (clase ${poeClass}, 802.3at): verifique el presupuesto del switch` });
  }
  return out;
}
