/**
 * CCTV DESIGN PRO — Sistema de Plugins y Módulos Extensibles (§38)
 *
 * Permite registrar dinámicamente nuevos módulos y capacidades sin alterar el núcleo.
 * Los plugins pueden engancharse en el ciclo de cálculo, validación, dibujo CAD y exportación.
 */

class Registry {
  constructor() {
    this._plugins = new Map();
    this._hooks = new Map();
  }

  /**
   * Registra un nuevo plugin o módulo de cálculo.
   * @param {object} plugin Definición del plugin: { id, name, version, hooks, onInit, onCalculate, onValidate }
   */
  register(plugin) {
    if (!plugin || !plugin.id) throw new Error('El plugin debe tener un identificador (id) único');
    if (this._plugins.has(plugin.id)) {
      console.warn(`Plugin ${plugin.id} ya registrado; actualizando definición.`);
    }
    this._plugins.set(plugin.id, {
      ...plugin,
      registeredAt: new Date().toISOString()
    });

    if (plugin.hooks && typeof plugin.hooks === 'object') {
      for (const [hookName, handler] of Object.entries(plugin.hooks)) {
        this.addHook(hookName, handler);
      }
    }

    if (typeof plugin.onInit === 'function') {
      plugin.onInit(this);
    }
    return this;
  }

  /** Obtiene un plugin por ID. */
  get(id) {
    return this._plugins.get(id) || null;
  }

  /** Lista de todos los plugins registrados. */
  list() {
    return Array.from(this._plugins.values());
  }

  /** Añade un handler a un hook específico. */
  addHook(hookName, handler) {
    if (typeof handler !== 'function') return;
    if (!this._hooks.has(hookName)) {
      this._hooks.set(hookName, []);
    }
    this._hooks.get(hookName).push(handler);
  }

  /**
   * Ejecuta todos los handlers de un hook de forma síncrona o en cadena.
   * @param {string} hookName Nombre del hook
   * @param {object} context Contexto y datos compartidos
   */
  emit(hookName, context = {}) {
    const handlers = this._hooks.get(hookName) || [];
    let ctx = context;
    for (const h of handlers) {
      try {
        const res = h(ctx);
        if (res && typeof res === 'object') ctx = res;
      } catch (err) {
        console.error(`Error ejecutando hook ${hookName}:`, err);
      }
    }
    return ctx;
  }
}

export const PluginRegistry = new Registry();
