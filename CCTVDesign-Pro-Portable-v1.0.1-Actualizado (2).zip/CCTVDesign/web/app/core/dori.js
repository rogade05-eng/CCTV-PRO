/**
 * CCTV DESIGN PRO — Óptica y objetivos de vigilancia (CP CCTV §13, §15)
 * EN 62676-4: densidad de píxeles por metro (ppm) según el objetivo de vigilancia.
 */
import { rad, clamp } from './geometry.js?v=b441e3fc';
import { OBJECTIVES } from './project.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';

/**
 * Campo de visión horizontal/vertical a partir de focal y tamaño de sensor.
 * `focalOverride` permite usar la focal efectiva de la cámara (zoom, varifocal, preset PTZ).
 */
export function fieldOfView(item, focalOverride) {
  const s = (item && item.specs) || {};
  const focal = Number(focalOverride) || Number(s.lens) || 4;
  const sw = Number(s.sensorW) || 6.4;
  const sh = Number(s.sensorH) || 3.6;
  return {
    hfov: (2 * Math.atan(sw / (2 * focal)) * 180) / Math.PI,
    vfov: (2 * Math.atan(sh / (2 * focal)) * 180) / Math.PI,
    focal, sensorW: sw, sensorH: sh,
  };
}

/** Densidad de píxeles (ppm) a una distancia dada. `lens` permite usar el zoom efectivo. */
export function pixelDensity(item, distanceM, lens) {
  const s = (item && item.specs) || {};
  const d = Math.max(distanceM, 0.1);
  return ((Number(s.resW) || 1920) * (Number(lens) || Number(s.lens) || 4)) / ((Number(s.sensorW) || 6.4) * d);
}

/** Distancia máxima a la que se cumple un objetivo de vigilancia. */
export function maxDistanceFor(item, objectiveKey, lens) {
  const o = OBJECTIVES[objectiveKey];
  if (!o) return 0;
  const s = (item && item.specs) || {};
  return ((Number(s.resW) || 1920) * (Number(lens) || Number(s.lens) || 4)) / ((Number(s.sensorW) || 6.4) * o.ppm);
}

/** Objetivo más exigente que la cámara alcanza a esa distancia. */
export function objectiveAt(item, distanceM, lens) {
  const ppm = pixelDensity(item, distanceM, lens);
  const order = ['IDENTIFICACION', 'MATRICULA', 'RECONOCIMIENTO', 'OBSERVACION', 'DETECCION'];
  for (const k of order) if (ppm >= OBJECTIVES[k].ppm) return { key: k, ppm };
  return { key: null, ppm };
}

export const objectiveLabel = (key) => (OBJECTIVES[key] ? OBJECTIVES[key].label : '—');

/**
 * Huella de cobertura proyectada en planta (cono de visión cortado por el suelo).
 * Devuelve polígono cerrado + distancias útil mínima/máxima.
 */
export function footprint(camera, catalog, rules = {}, over = {}) {
  const p = camera.points[0] || { x: 0, y: 0 };
  const item = getItem(catalog, camera.data.catalogId);
  const s = (item && item.specs) || {};
  // `over` aplica la posición/zoom de un preset sin duplicar la cámara (módulo PTZ, §38)
  const data = Object.assign({}, camera.data, over);
  const focal = Number(data.focal) || Number(s.lens) || 4;
  const fov = fieldOfView(item, focal);
  const h = Number(data.height) || 2.8;
  const tilt = clamp(Number(data.tilt) || 0, 0, 89);
  const az = Number(data.azimuth) || 0;
  const ir = Number(s.ir) || 30;
  const maxRange = Math.min(Math.max(ir, 10), Number(rules.MAX_RANGE || 120));

  // Fisheye / Ojo de pez 360°: cobertura circular hemisférica completa.
  const esFisheye = !!(s.fisheye || data.fisheye || (s.tipo && s.tipo.toLowerCase().includes('pez')) || s.form === 'fisheye');
  if (esFisheye) {
    // Para 360° montada en techo, el radio de cobertura efectiva lo determina la altura de montaje
    // y el sensor (típicamente hasta 8–15 m de radio útil de visión según resolución)
    const rCalculado = Math.max(h * Math.tan(rad(70)), Math.min(maxRange, 12));
    const r = clamp(rCalculado, 3, maxRange);
    const pts = [];
    const nPts = 48; // Muestreo fino de 360 grados
    for (let i = 0; i < nPts; i++) {
      const a = (i / nPts) * Math.PI * 2;
      pts.push({ x: p.x + Math.cos(a) * r, y: p.y + Math.sin(a) * r });
    }
    // `az` y `half` (en radianes) acompañan a la huella: el recorte por sombras barre ese abanico completo
    return { polygon: pts, near: 0, far: r, maxRange: r, hfov: 360, vfov: 180, origin: p, az: 0, half: Math.PI, fisheye: true };
  }

  const halfV = fov.vfov / 2;
  const tUp = tilt + halfV;
  const tDn = tilt - halfV;
  const near = tUp > 0.5 ? clamp(h / Math.tan(rad(tUp)), 0.2, maxRange) : 0.2;
  // El alcance útil de COBERTURA no lo da el IR (visión nocturna) sino la distancia a la que
  // todavía se cumple el objetivo de vigilancia de la cámara (§15), limitada por IR y alcance máx.
  const objDist = maxDistanceFor(item, data.objective || 'OBSERVACION', focal);
  const far = tDn > 0.5 ? clamp(Math.min(h / Math.tan(rad(tDn)), objDist, ir), near + 0.2, maxRange)
                        : clamp(Math.min(objDist, ir), near + 0.2, maxRange);

  const half = fov.hfov / 2;
  const pts = [{ x: p.x, y: p.y }];
  const steps = Math.max(8, Math.round(fov.hfov / 4));
  for (let i = 0; i <= steps; i++) {
    const a = rad(az - half + (fov.hfov * i) / steps);
    pts.push({ x: p.x + Math.cos(a) * near, y: p.y + Math.sin(a) * near });
  }
  for (let i = steps; i >= 0; i--) {
    const a = rad(az - half + (fov.hfov * i) / steps);
    pts.push({ x: p.x + Math.cos(a) * far, y: p.y + Math.sin(a) * far });
  }
  return { polygon: pts, near, far, maxRange, hfov: fov.hfov, vfov: fov.vfov, origin: p, az: rad(az), half: rad(half) };
}
