/**
 * CCTV DESIGN PRO — Motor de red (CP CCTV §19, §23)
 * Topología lógica, estado de enlaces y dimensionado.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';
import { fiberBudget, hasSfpPort } from './fiber.js?v=b441e3fc';

export function buildTopology(prj, catalog) {
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const switches = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'switch');
  const nvrs = prj.entities.filter((e) => e.type === 'device' && (e.data.kind === 'nvr' || e.data.kind === 'dvr'));
  const routers = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'router');
  const pps = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'patchpanel');
  const upss = prj.entities.filter((e) => e.type === 'device' && e.data.kind === 'ups');

  const nodes = switches.map((s) => {
    const it = getItem(catalog, s.data.catalogId);
    return {
      id: s.id, kind: 'switch', label: s.data.label || s.id, model: it ? it.model : '?',
      ip: s.data.ip || '', pos: s.points[0],
      children: cams.filter((c) => c.data.switchId === s.id).map((c) => ({
        id: c.id, kind: 'camera', label: c.data.label || c.id, pos: c.points[0],
        model: (getItem(catalog, c.data.catalogId) || {}).model || '?',
      })),
      orphan: cams.filter((c) => c.data.switchId === s.id).length,
    };
  });

  const orphans = cams.filter((c) => !c.data.switchId).map((c) => ({ id: c.id, kind: 'camera', label: c.data.label || c.id }));

  // El switch con más cámaras actúa como núcleo si no se define otro.
  const core = nodes.slice().sort((a, b) => b.children.length - a.children.length)[0] || null;
  for (const n of nodes) if (core && n.id !== core.id) n.uplinkTo = core.id;

  return {
    nodes, core, orphans,
    nvrs: nvrs.map((n) => ({ id: n.id, label: n.data.label || n.id, model: (getItem(catalog, n.data.catalogId) || {}).model || '?', ip: n.data.ip || '', pos: n.points[0], uplinkTo: core ? core.id : null })),
    routers: routers.map((r) => ({ id: r.id, label: r.data.label || r.id, model: (getItem(catalog, r.data.catalogId) || {}).model || '?', ip: r.data.ip || '', pos: r.points[0], uplinkTo: core ? core.id : null })),
    patchPanels: pps.map((p) => ({ id: p.id, label: p.data.label || p.id, model: (getItem(catalog, p.data.catalogId) || {}).model || '?' })),
    ups: upss.map((u) => ({ id: u.id, label: u.data.label || u.id, model: (getItem(catalog, u.data.catalogId) || {}).model || '?' })),
    cameras: cams.length, switches: switches.length,
  };
}

/** Estado de cada enlace cámara→switch según la longitud calculada. */
export function linkReport(prj, rules, catalog) {
  const max = ruleNum(rules, 'MAX_UTP');
  const cat = catalog || prj.catalog || { items: [] };
  const byId = new Map(prj.entities.map((e) => [e.id, e]));
  return prj.entities.filter((e) => e.type === 'cable').map((c) => {
    const cam = byId.get(c.data.from);
    const sw = byId.get(c.data.to);
    const len = Number(c.data.net) || 0;
    const forced = c.data.media === 'fiber';
    const forcedUtp = c.data.media === 'utp';          // el proyectista fuerza cobre aunque pase del máximo
    const isFiber = forced || (!forcedUtp && len > max);
    const fiber = isFiber ? fiberBudget(len, rules, { catalog: cat, type: c.data.fiberType || undefined }) : null;
    return {
      id: c.id,
      camera: cam ? (cam.data.label || cam.id) : c.data.from,
      switch: sw ? (sw.data.label || sw.id) : c.data.to,
      geometric: Number(c.data.geometric) || 0,
      supply: Number(c.data.supply) || 0,
      net: len, max, pct: max ? (len / max) * 100 : 0,
      status: c.data.distanceStatus || 'NORMAL',
      advice: c.data.advice || [],
      media: isFiber ? 'fiber' : 'copper',
      mediaForced: forced,
      mediaChoice: forced ? 'fiber' : forcedUtp ? 'utp' : 'auto',
      medium: isFiber ? `${fiber.typeLabel} + SFP ${fiber.sfpModel}` : 'UTP Cat6',
      fiber, converters: isFiber ? ((hasSfpPort(sw, cat) && hasSfpPort(cam, cat)) ? 0 : 2) : 0,
      fiberStatus: fiber ? fiber.status : null,
    };
  });
}

/** Direccionamiento IP automático secuencial para los elementos que no lo tengan. */
export function autoAddress(prj, base = '192.168.10') {
  let n = 20;
  const assigned = [];
  const devices = prj.entities.filter((e) => e.type === 'device');
  for (const d of devices) {
    if (!d.data.ip) { d.data.ip = `${base}.${n++}`; assigned.push(d.data.label || d.id); }
    else n = Math.max(n, (parseInt(d.data.ip.split('.').pop(), 10) || 0) + 1);
  }
  const cams = prj.entities.filter((e) => e.type === 'camera');
  for (const c of cams) {
    if (!c.data.ip) { c.data.ip = `${base}.${n++}`; assigned.push(c.data.label || c.id); }
    else n = Math.max(n, (parseInt(c.data.ip.split('.').pop(), 10) || 0) + 1);
  }
  return assigned;
}
