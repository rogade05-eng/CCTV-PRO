/**
 * CCTV DESIGN PRO — Módulo de vídeo analógico: HD-TVI / AHD / HD-CVI y CVBS (§38)
 *
 * El vídeo analógico no comparte NADA con el IP salvo la óptica: no hay PoE, no hay switch, no hay
 * dirección IP. La señal viaja por cable coaxial (o par trenzado con balun) hasta un grabador
 * híbrido (DVR) que digitaliza cada canal, y cada cámara se alimenta a 12 V por un par de hilos
 * cuya caída de tensión crece con la longitud. Este módulo convierte esas tres realidades en datos
 * técnicos: distancia máxima por formato y cable, canales del grabador y alimentación verificada.
 *
 * Todo es aditivo y opcional (§38): una cámara sin `specs.analog` se comporta exactamente igual que
 * antes, y un proyecto sin cámaras analógicas no cambia ninguna cifra del resto del programa.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

/** Formatos analógicos del contrato §38: modulación, resolución y factor de alcance respecto a 1080p. */
export const ANALOG_FORMATS = {
  CVBS: { id: 'CVBS', label: 'CVBS 960H (analógico clásico)', mp: 0.4, resW: 976, resH: 494, factor: 1.3, bandwidthMbps: 6, note: 'Señal SD en CVBS; convive con cualquier grabador híbrido.' },
  TVI: { id: 'TVI', label: 'HD-TVI 1080p', mp: 2, resW: 1920, resH: 1080, factor: 1.0, bandwidthMbps: 60, note: 'Modulación de Hikvision; 1080p a 25/30 fps por coax.' },
  AHD: { id: 'AHD', label: 'AHD 1080p', mp: 2, resW: 1920, resH: 1080, factor: 1.0, bandwidthMbps: 60, note: 'Modulación abierta de Nextchip.' },
  CVI: { id: 'CVI', label: 'HD-CVI 1080p', mp: 2, resW: 1920, resH: 1080, factor: 1.0, bandwidthMbps: 60, note: 'Modulación de Dahua.' },
  TVI5: { id: 'TVI5', label: 'HD-TVI / AHD 5 MP', mp: 5, resW: 2560, resH: 1944, factor: 0.62, bandwidthMbps: 120, note: '5 MP exige coax corto y de buena calidad.' },
};

/** Medios de transmisión admitidos con su cable de catálogo y su balun cuando corresponde. */
export const ANALOG_CABLES = {
  RG59: { id: 'RG59', label: 'Coaxial RG-59', itemId: 'CBL-RG59', ruleKey: 'ANALOG_RG59_MAX', balun: false },
  RG6: { id: 'RG6', label: 'Coaxial RG-6', itemId: 'CBL-RG6', ruleKey: 'ANALOG_RG6_MAX', balun: false },
  UTP: { id: 'UTP', label: 'UTP Cat5e con balun', itemId: 'CBL-UTP6', ruleKey: 'ANALOG_UTP_MAX', balun: true },
};

/** ¿Es esta cámara analógica? (el catálogo lo declara en `specs.analog`, §38). */
export function isAnalog(cam, catalog) {
  if (!cam || !cam.data) return false;
  const it = getItem(catalog, cam.data.catalogId);
  return !!(it && it.specs && it.specs.analog);
}

/** Configuración analógica de una cámara: formato, medio de transmisión y consumo a 12 V. */
export function analogConfig(cam, catalog, rules) {
  const it = getItem(catalog, cam.data.catalogId);
  const s = (it && it.specs) || {};
  const d = cam.data || {};
  const fmt = ANALOG_FORMATS[d.analogFormat || s.analogFormat || 'TVI'] || ANALOG_FORMATS.TVI;
  const cable = ANALOG_CABLES[d.analogCable || s.analogCable || 'RG59'] || ANALOG_CABLES.RG59;
  const volts = Number(d.analogVolts || s.analogVolts || 12);
  const watts = Number(d.power === 'psu' ? 0 : (s.power || 0));
  return {
    cameraId: cam.id, label: d.label || cam.id, model: it ? it.model : '?',
    format: fmt, cable,
    dvm: fmt.mp >= 5 ? '5 MP / 8 MP' : fmt.mp >= 2 ? '1080p' : '960H',
    volts, watts, current: volts ? watts / volts : 0,
    section: Number(d.analogSection) || ruleNum(rules, 'ANALOG_SECCION') || 0.5,
    distance: Number(d.analogDistance) || 0,
    balun: !!cable.balun,
  };
}

/** Distancia máxima del enlace analógico: máximo del cable para 1080p escalado por el formato. */
export function analogLimit(cfg, rules) {
  const base = ruleNum(rules, cfg.cable.ruleKey) || (cfg.cable.id === 'UTP' ? 120 : 250);
  return base * cfg.format.factor;
}

/** Caída de tensión en la línea de alimentación de 12 V (dos hilos, cobre, ρ = 0,0172 Ω·mm²/m). */
export function powerDrop(distanceM, currentA, sectionMm2, rules) {
  const rho = 0.0172;
  const s = sectionMm2 || ruleNum(rules, 'ANALOG_SECCION') || 0.5;
  const drop = (2 * distanceM * currentA * rho) / s;
  const min = ruleNum(rules, 'ANALOG_TENSION_MIN') || 11;
  return { drop, section: s, volts: 12 - drop, min, ok: 12 - drop >= min };
}

/** Enlace analógico de una cámara: medio, distancia, margen y alimentación en la cámara. */
export function analogLink(cam, prj, catalog, rules) {
  const cfg = analogConfig(cam, catalog, rules);
  const cableEnt = prj.entities.find((e) => e.type === 'cable' && e.data.from === cam.id);
  const distance = cableEnt ? (Number(cableEnt.data.net) || 0) : cfg.distance;
  const limit = analogLimit(cfg, rules);
  const margin = limit - distance;
  const warnPct = ruleNum(rules, 'ANALOG_AVISO_PCT') || 85;
  const pct = limit ? (distance / limit) * 100 : 0;
  const status = pct > 100 ? 'EXCEDIDA' : pct >= warnPct ? 'PROXIMA' : 'NORMAL';
  const power = powerDrop(distance, cfg.current, cfg.section, rules);
  return {
    ...cfg, distance, limit, margin, pct, status, power,
    cableId: cfg.cable.itemId, waypoints: cableEnt ? cableEnt.points.length : 0,
  };
}

/** Grabador híbrido: canales totales, canales en alta definición y formatos admitidos. */
export function dvrInfo(dev, catalog) {
  const it = getItem(catalog, dev.data.catalogId);
  const s = (it && it.specs) || {};
  return {
    id: dev.id, label: dev.data.label || dev.id, model: it ? it.model : '?', catalogId: dev.data.catalogId,
    channels: Number(s.channels) || 0, hdChannels: Number(s.hdChannels) || Number(s.channels) || 0,
    formats: s.analogFormats || Object.keys(ANALOG_FORMATS), bays: Number(s.bays) || 0,
    maxMbps: Number(s.maxMbps) || 0, price: it ? it.price : 0,
  };
}

/**
 * Plan analógico del proyecto: enlaces, grabación y alimentación.
 * @returns {{rows:object[], count:number, links:object[], dvrs:object[], recording:object, power:object, status:string, ...}}
 */
export function analogPlan(prj, catalog, rules) {
  const cams = prj.entities.filter((e) => e.type === 'camera' && isAnalog(e, catalog));
  const devs = prj.entities.filter((e) => e.type === 'device');
  // Graba en analógico un DVR o un híbrido declarado como tal; un NVR puro es del módulo IP
  const dvrs = devs.filter((d) => d.data.kind === 'dvr' ||
    (d.data.kind === 'nvr' && !!(getItem(catalog, d.data.catalogId) || { specs: {} }).specs.hybrid));
  const links = cams.map((c) => analogLink(c, prj, catalog, rules));
  const rows = links.slice().sort((a, b) => b.pct - a.pct);

  const dvrList = dvrs.map((d) => dvrInfo(d, catalog));
  const channels = dvrList.reduce((a, d) => a + d.channels, 0);
  const hdChannels = dvrList.reduce((a, d) => a + d.hdChannels, 0);
  const needHd = links.filter((l) => l.format.mp >= 2).length;
  const channelsOk = channels >= links.length && (hdChannels >= needHd || needHd === 0);
  const bw = links.reduce((a, l) => a + l.format.bandwidthMbps, 0);
  const maxMbps = dvrList.reduce((a, d) => a + d.maxMbps, 0);
  const recording = {
    dvrs: dvrList, channels, hdChannels, needHd, cameras: links.length,
    channelsOk, bandwidth: bw, maxMbps, bandwidthOk: !maxMbps || bw <= maxMbps,
    ok: dvrList.length > 0 && channelsOk && (!maxMbps || bw <= maxMbps),
  };

  // Alimentación: consumo total y fuente necesaria con reserva de diseño
  const amps = links.reduce((a, l) => a + l.current, 0);
  const watts = links.reduce((a, l) => a + l.watts, 0);
  const reserve = ruleNum(rules, 'ANALOG_RESERVA_FUENTE') || 25;
  const psuList = devs.filter((d) => d.data.kind === 'psu' || (getItem(catalog, d.data.catalogId) || { specs: {} }).specs.power12);
  const psuAmps = psuList.reduce((a, d) => a + (Number((getItem(catalog, d.data.catalogId) || { specs: {} }).specs.amps) || 0), 0);
  const needAmps = amps * (1 + reserve / 100);
  const worstDrop = links.reduce((a, l) => Math.max(a, l.power.drop), 0);
  const voltsMin = links.length ? links.reduce((a, l) => Math.min(a, l.power.volts), 12) : 12;
  const power = {
    amps, watts, reserve, needAmps, psuAmps, psuCount: psuList.length,
    drop: worstDrop, voltsMin, voltsOk: links.every((l) => l.power.ok),
    ok: psuAmps >= needAmps - 1e-9 && links.every((l) => l.power.ok),
  };

  const status = !links.length ? 'SIN CÁMARAS'
    : links.some((l) => l.status === 'EXCEDIDA') ? 'EXCEDIDA'
      : links.some((l) => l.status === 'PROXIMA') ? 'PROXIMA' : 'NORMAL';
  return {
    rows, links, count: links.length, dvrs: dvrList, recording, power, status,
    formats: [...new Set(links.map((l) => l.format.id))],
    coaxMeters: links.filter((l) => !l.balun).reduce((a, l) => a + l.distance, 0),
    utpMeters: links.filter((l) => l.balun).reduce((a, l) => a + l.distance, 0),
    baluns: links.filter((l) => l.balun).length,
  };
}

/** Resumen del módulo para paneles y memoria. */
export function analogSummary(prj, catalog, rules) {
  const p = analogPlan(prj, catalog, rules);
  return {
    count: p.count, status: p.status, formats: p.formats,
    worst: p.rows[0] || null,
    channels: p.recording.channels, channelsOk: p.recording.channelsOk,
    amps: p.power.amps, watts: p.power.watts, psuAmps: p.power.psuAmps, voltsMin: p.power.voltsMin,
    dvrs: p.recording.dvrs, coaxMeters: p.coaxMeters, utpMeters: p.utpMeters, baluns: p.baluns,
    failed: p.rows.filter((l) => l.status !== 'NORMAL').length,
  };
}

/** Cuadro analógico del proyecto (CSV, PDF y paneles). */
export function analogSchedule(prj, catalog, rules) {
  const p = analogPlan(prj, catalog, rules);
  return p.rows.map((l) => ({
    camera: l.label, model: l.model, format: l.format.label, cable: l.cable.label,
    distance: Number(l.distance.toFixed(1)), limit: Number(l.limit.toFixed(1)), margin: Number(l.margin.toFixed(1)),
    pct: Number(l.pct.toFixed(0)), status: l.status, balun: l.balun, watts: l.watts,
    current: Number((l.current * 1000).toFixed(0)), drop: Number(l.power.drop.toFixed(2)),
    volts: Number(l.power.volts.toFixed(2)), channel: l.format.mp >= 2 ? 'HD' : 'SD',
  }));
}

/** Incidencias del módulo analógico (§30). */
export function validateAnalog(prj, catalog, rules) {
  const out = [];
  const p = analogPlan(prj, catalog, rules);
  if (!p.count) return out;
  for (const l of p.rows) {
    if (l.status === 'EXCEDIDA')
      out.push({ code: 'ANALOG_DISTANCIA', severity: 'error',
        text: `${l.label}: ${l.distance.toFixed(0)} m por ${l.cable.label} superan los ${l.limit.toFixed(0)} m de alcance del formato ${l.format.label}. Acorte el tramo, suba a coaxial RG-6 o intercale un repetidor/balun activo` });
    else if (l.status === 'PROXIMA')
      out.push({ code: 'ANALOG_DISTANCIA', severity: 'warn',
        text: `${l.label}: ${l.distance.toFixed(0)} m consumen el ${l.pct.toFixed(0)} % del alcance (${l.limit.toFixed(0)} m)` });
    if (l.balun && !l.format.mp)
      out.push({ code: 'ANALOG_SIN_BALUN', severity: 'warn', text: `${l.label}: transmisión por UTP sin balun declarado` });
    if (!l.power.ok)
      out.push({ code: 'ANALOG_TENSION', severity: l.power.volts < 10 ? 'error' : 'warn',
        text: `${l.label}: a ${l.distance.toFixed(0)} m con ${(l.current * 1000).toFixed(0)} mA llegan ${l.power.volts.toFixed(2)} V (mínimo ${l.power.min} V): use cable de mayor sección o alimentación local` });
  }
  if (!p.recording.dvrs.length && p.count)
    out.push({ code: 'ANALOG_CANALES', severity: 'error', text: `${p.count} cámara(s) analógicas sin grabador híbrido (DVR) en el proyecto` });
  else if (!p.recording.channelsOk)
    out.push({ code: 'ANALOG_CANALES', severity: 'error',
      text: `El grabador tiene ${p.recording.channels} canal(es) y el proyecto necesita ${p.recording.cameras} (${p.recording.needHd} en alta definición, ${p.recording.hdChannels} disponibles HD)` });
  if (p.recording.maxMbps && !p.recording.bandwidthOk)
    out.push({ code: 'ANALOG_CANALES', severity: 'warn',
      text: `Caudal de ${p.recording.bandwidth} Mbps sobre un grabador preparado para ${p.recording.maxMbps} Mbps` });
  for (const d of p.recording.dvrs) {
    const malos = p.links.filter((l) => !d.formats.includes(l.format.id));
    if (malos.length)
      out.push({ code: 'ANALOG_FORMATO', severity: 'error',
        text: `${d.label} no admite el formato de: ${malos.map((l) => l.label + ' (' + l.format.label + ')').join(', ')}` });
  }
  if (!p.power.ok && p.power.psuCount === 0 && p.count)
    out.push({ code: 'ANALOG_ALIMENTACION', severity: 'warn',
      text: `${p.count} cámara(s) a 12 V (${p.power.watts.toFixed(0)} W) sin fuente de alimentación en el proyecto: se necesitan al menos ${p.power.needAmps.toFixed(1)} A` });
  else if (!p.power.ok)
    out.push({ code: 'ANALOG_ALIMENTACION', severity: 'warn',
      text: `Fuente de ${p.power.psuAmps.toFixed(1)} A insuficiente para ${p.power.needAmps.toFixed(1)} A (consumo ${p.power.watts.toFixed(0)} W + reserva del ${p.power.reserve} %)` });
  return out;
}
