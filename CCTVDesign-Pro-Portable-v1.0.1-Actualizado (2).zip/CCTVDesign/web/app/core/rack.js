/**
 * CCTV DESIGN PRO — Motor de rack (CP CCTV §22)
 */
import { getItem } from './catalog.js?v=b441e3fc';

export const DEFAULT_ORDER = ['patchpanel', 'accessory', 'switch', 'switch_poe', 'nvr', 'router', 'ups'];

export function rackLayout(prj, catalog) {
  const rackItem = getItem(catalog, prj.rack.catalogId);
  const capacity = Number((rackItem && rackItem.specs && rackItem.specs.u) || 22);
  let used = 0, load = 0;
  const rows = (prj.rack.items || []).map((it) => {
    const item = getItem(catalog, it.itemId);
    const u = Number(it.u || (item && item.specs && item.specs.rackU) || 1) * (Number(it.qty) || 1);
    used += u;
    return {
      itemId: it.itemId, label: item ? `${item.manufacturer} ${item.model}` : it.itemId,
      name: item ? item.name : it.itemId, qty: Number(it.qty) || 1, uEach: Number(it.u || (item && item.specs && item.specs.rackU) || 1), u,
      category: item ? item.category : '?',
    };
  });
  const devices = prj.entities.filter((e) => e.type === 'device');
  for (const d of devices) {
    const item = getItem(catalog, d.data.catalogId);
    load += Number((item && item.specs && item.specs.power) || 0);
  }
  const warnings = [];
  if (used > capacity) warnings.push({ severity: 'error', text: `Ocupación ${used} U superior a la capacidad del rack (${capacity} U).` });
  else if (used > capacity * 0.8) warnings.push({ severity: 'warn', text: `Ocupación al ${Math.round((used / capacity) * 100)} %: reserve espacio para ventilación y ampliaciones.` });
  const maxLoad = Number((rackItem && rackItem.specs && rackItem.specs.maxLoad) || 0);
  if (maxLoad && load > maxLoad) warnings.push({ severity: 'error', text: `Carga estimada ${load} W superior a la máxima del rack (${maxLoad}).` });
  if (used === 0) warnings.push({ severity: 'info', text: 'Rack vacío: añada equipos o use la distribución automática.' });
  return { rackItem, label: prj.rack.label, capacity, used, free: capacity - used, fill: capacity ? (used / capacity) * 100 : 0, rows, load, warnings };
}

/** Distribución automática en orden técnico: paneles, organizadores, switches, NVR, router, UPS abajo. */
export function autoArrange(prj, catalog) {
  const items = [];
  const devices = prj.entities.filter((e) => e.type === 'device');
  const tally = new Map();
  for (const d of devices) {
    const key = d.data.catalogId;
    tally.set(key, (tally.get(key) || 0) + 1);
  }
  for (const [itemId, qty] of tally) {
    const item = getItem(catalog, itemId);
    if (!item) continue;
    if (item.category === 'rack') continue;
    items.push({ itemId, qty, u: Number((item.specs && item.specs.rackU) || 1) });
  }
  items.sort((a, b) => {
    const ia = getItem(catalog, a.itemId), ib = getItem(catalog, b.itemId);
    const oa = DEFAULT_ORDER.indexOf(ia ? ia.category : ''), ob = DEFAULT_ORDER.indexOf(ib ? ib.category : '');
    return (oa < 0 ? 99 : oa) - (ob < 0 ? 99 : ob);
  });
  // Un organizador entre grupos si hay más de 3 elementos.
  if (items.length > 3 && catalog.items.some((i) => i.id === 'ORG-1U')) {
    const out = [];
    items.forEach((it, i) => { out.push(it); if (i === 0 || i === Math.floor(items.length / 2)) out.push({ itemId: 'ORG-1U', qty: 1, u: 1 }); });
    prj.rack.items = out;
  } else {
    prj.rack.items = items;
  }
  return rackLayout(prj, catalog);
}
