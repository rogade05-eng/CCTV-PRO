/**
 * CCTV DESIGN PRO — Registro de módulos del sistema (CP CCTV §38)
 *
 * El contrato exige que el programa admita nuevas disciplinas sin reconstruirse.
 * Este registro es la lista de módulos previstos, su estado real y el componente
 * que los implementa. Un módulo no usado nunca altera los cálculos de los demás.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { cameraRules } from './analytics.js?v=b441e3fc';
import { isLpr, lprConfig } from './lpr.js?v=b441e3fc';
import { analogPlan } from './analog.js?v=b441e3fc';
import { PluginRegistry } from './plugins.js?v=b441e3fc';

export { PluginRegistry };

/** Módulos previstos por el §38, con el componente que los implementa hoy. */
export const MODULE_DEFS = [
  { id: 'ip', name: 'CCTV IP', ref: 'core/network.js · core/poe.js · core/storage.js' },
  { id: 'analog', name: 'CCTV analógico', ref: 'core/analog.js · core/routing.js (coaxial) · core/materials.js (12 V)' },
  { id: 'ptz', name: 'PTZ', ref: 'core/ptz.js · core/coverage.js' },
  { id: 'lpr', name: 'LPR (matrículas)', ref: 'core/lpr.js · cad.js (zona de captura)' },
  { id: 'analytics', name: 'Analítica de vídeo', ref: 'core/analytics.js · core/storage.js (metadatos)' },
  { id: 'fiber', name: 'Fibra óptica', ref: 'core/fiber.js · core/routing.js · core/materials.js' },
  { id: 'access', name: 'Control de acceso', ref: 'preparado (§38)' },
  { id: 'intrusion', name: 'Intrusión', ref: 'preparado (§38)' },
  { id: 'intercom', name: 'Intercomunicación', ref: 'preparado (§38)' },
  { id: 'pa', name: 'Megafonía', ref: 'preparado (§38)' },
];

/**
 * Estado real de cada módulo en el proyecto abierto.
 * - activo: el programa calcula con él.
 * - detectado: hay equipos de ese tipo en el catálogo o en el diseño, aunque su cálculo específico sea básico.
 * - preparado: el modelo de datos y la documentación lo contemplan, sin módulo de cálculo propio.
 */
export function detectedModules(prj, catalog) {
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const devices = prj.entities.filter((e) => e.type === 'device');
  const spec = (cam) => ((getItem(catalog, cam.data.catalogId) || { specs: {} }).specs) || {};
  const itemsWith = (fn) => (catalog.items || []).filter(fn).length;

  const ip = cams.filter((c) => !spec(c).analog);
  const analog = cams.filter((c) => spec(c).analog);
  const ptz = cams.filter((c) => spec(c).ptz);
  const lpr = cams.filter((c) => spec(c).lpr);
  const analytics = cams.filter((c) => spec(c).analytics);
  const analyticsRules = cams.reduce((a, c) => a + cameraRules(c).length, 0);
  const lprOn = cams.filter((c) => isLpr(c, catalog) && lprConfig(c, catalog, prj.rules).enabled);
  const fiberLinks = prj.entities.filter((e) => e.type === 'cable' && Number(e.data.net) > Number(prj.rules.MAX_UTP || 90));

  const state = (id) => MODULE_DEFS.find((m) => m.id === id);
  const row = (id, status, detail) => ({ ...state(id), status, detail });

  return [
    row('ip', 'activo', `${ip.length} cámara(s) IP · ${devices.filter((d) => d.data.kind === 'switch').length} switch(es) · PoE y ancho de banda calculados`),
    row('analog', 'activo',
      analog.length
        ? (() => {
          const pl = analogPlan(prj, catalog, prj.rules);
          return `${analog.length} cámara(s) analógica(s) · ${pl.status} · coaxial ${pl.coaxMeters.toFixed(0)} m · ${pl.recording.channels} canal(es) de grabación · ${pl.power.voltsMin.toFixed(1)} V`;
        })()
        : `sin cámaras analógicas en el diseño (catálogo con ${itemsWith((i) => i.specs && i.specs.analog)} artículo(s) analógico(s) disponible)`),
    row('ptz', ptz.length ? 'activo' : 'activo',
      ptz.length ? `${ptz.length} cámara(s) PTZ · ${ptz.reduce((a, c) => a + ((c.data.presets || []).length), 0)} preset(s) · cobertura por posición` : 'sin cámaras PTZ en el diseño (módulo disponible)'),
    row('lpr', lprOn.length ? 'activo' : lpr.length ? 'detectado' : 'preparado',
      lprOn.length ? `${lprOn.length} cámara(s) LPR calculadas: caracteres, ángulo, emborronamiento y carril`
        : lpr.length ? `${lpr.length} cámara(s) LPR con el módulo de lectura desactivado`
        : `${itemsWith((i) => i.specs && i.specs.lpr)} modelo(s) LPR en catálogo · colóquela y defina el carril`),
    row('analytics', analyticsRules ? 'activo' : analytics.length ? 'detectado' : 'preparado',
      analyticsRules ? `${analyticsRules} regla(s) de analítica sobre zonas de interés: cobertura, ppm, eventos y licencias`
        : analytics.length ? `${analytics.length} cámara(s) con analítica embarcada, sin reglas definidas`
        : 'sin reglas de analítica en el diseño'),
    row('fiber', fiberLinks.length ? 'activo' : 'activo',
      fiberLinks.length ? `${fiberLinks.length} enlace(s) de fibra calculado(s) por superar el máximo UTP` : `catálogo con ${itemsWith((i) => i.category === 'fiber')} artículo(s) de fibra, disponible para enlaces largos`),
    row('access', 'preparado', 'pendiente de módulo: reutilizará catálogo, rack y presupuesto'),
    row('intrusion', 'preparado', 'pendiente de módulo: reutilizará planos, zonas y cobertura'),
    row('intercom', 'preparado', 'pendiente de módulo: reutilizará red y PoE'),
    row('pa', 'preparado', 'pendiente de módulo: reutilizará canalizaciones y rack'),
  ];
}
