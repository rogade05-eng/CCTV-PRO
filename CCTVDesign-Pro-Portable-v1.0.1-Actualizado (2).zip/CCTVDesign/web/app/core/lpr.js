/**
 * CCTV DESIGN PRO — Módulo LPR: lectura de matrículas (CP CCTV §38, §13, §15)
 *
 * Un LPR no se diseña por «campo de visión» sino por **carácter legible**: la cámara debe
 * entregar el número suficiente de píxeles sobre la placa, con un ángulo de incidencia
 * pequeño y un tiempo de obturación que congele el movimiento del vehículo.
 *
 * Este módulo convierte la ubicación y la óptica de la cámara en esos tres criterios
 * (píxeles sobre matrícula, ángulo de lectura y emborronamiento) más la geometría de la
 * zona de captura y el carril que vigila.
 */
import { rad, clamp } from './geometry.js?v=b441e3fc';
import { fieldOfView, maxDistanceFor } from './dori.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

/** Funciones de lectura admitidas (el motor de placas es externo: aquí se diseña la escena). */
export const LPR_MODES = {
  ENTRADA: 'Entrada de vehículos',
  SALIDA: 'Salida de vehículos',
  BIDIRECCIONAL: 'Entrada y salida (doble sentido)',
  VIA: 'Vía de circulación / control de paso',
};

/** Cámara con capacidad LPR según el catálogo. */
export function isLpr(cam, catalog) {
  const it = getItem(catalog, cam && cam.data && cam.data.catalogId);
  return !!(it && it.specs && it.specs.lpr);
}

/** Parámetros LPR de una cámara, con los valores por defecto del proyecto. */
export function lprConfig(cam, catalog, rules) {
  const it = getItem(catalog, cam && cam.data && cam.data.catalogId);
  const s = (it && it.specs) || {};
  const d = (cam && cam.data) || {};
  const plate = Number(d.plateWidth) || Number(s.plateWidth) || 0.52;   // matrícula UE: 520 × 110 mm
  const plateH = Number(d.plateHeight) || Math.round(plate * 0.212 * 100) / 100;
  return {
    enabled: d.lprEnabled !== false,
    mode: d.lprMode || 'ENTRADA',
    lane: d.lprLane || '',
    plateWidth: plate,
    plateHeight: plateH,
    captureDistance: Number(d.lprDistance) || 8,
    mountingAngle: Number(d.lprAngle) || 0,        // ángulo horizontal cámara ↔ eje de circulación
    tilt: Number(d.lprTilt !== undefined ? d.lprTilt : (d.tilt === undefined ? 20 : d.tilt)),
    shutter: Number(d.lprShutter) || ruleNum(rules, 'LPR_OBTURADOR'),
    irIlluminator: d.lprIr !== false,
    speedLimit: Number(d.lprSpeed) || ruleNum(rules, 'LPR_VELOCIDAD_MAX'),
    objective: d.objective || 'MATRICULA',
    minPpm: ruleNum(rules, 'LPR_PPM'),
    minCharPx: ruleNum(rules, 'LPR_ALTURA_CARACTER'),
    maxAngle: ruleNum(rules, 'LPR_ANGULO_MAX'),
  };
}

/**
 * Cálculo óptico del LPR.
 * - píxeles por metro sobre la placa: ppm(d) = R·f / (sw·d)
 * - ancho de la matrícula en píxeles: platePx = ppm · ancho_placa
 * - altura de carácter: charPx = platePx · (altura_carácter / ancho_placa)
 * - distancia máxima de lectura: d_max = platePx_req · sw·d ... despejada de platePx(d)
 * - emborronamiento: blur_px = v · t_exposición / (ancho_campo / R)
 */
export function lprOptics(cam, catalog, rules, over = {}) {
  const cfg = Object.assign(lprConfig(cam, catalog, rules), over);
  const it = getItem(catalog, cam && cam.data ? cam.data.catalogId : null);
  const s = (it && it.specs) || {};
  const resW = Number(cam && cam.data && cam.data.focal ? undefined : undefined) || Number(s.resW) || 2560;
  const focal = Number(over.focal || (cam && cam.data && cam.data.focal) || s.lens) || 12;
  const sensorW = Number(s.sensorW) || 6.4;
  const d = Math.max(cfg.captureDistance, 0.5);
  const ppm = (resW * focal) / (sensorW * d);
  const platePx = ppm * cfg.plateWidth;
  // Altura real de carácter de una matrícula UE: 75 mm para una placa de 520 mm
  const charHeight = Number(cfg.charHeight) || cfg.plateWidth * (75 / 520);
  const charPx = ppm * charHeight;
  const fov = fieldOfView(it, focal);
  const widthAtDist = (sensorW * d) / focal;                 // ancho de campo real a esa distancia
  const pixelSize = widthAtDist / resW;                      // metros por píxel (= d / ppm)
  // Embronronamiento: el vehículo recorre v·t durante la exposición, comparado con el píxel
  const v = (cfg.speedLimit * 1000) / 3600;
  const exposure = 1 / Math.max(cfg.shutter, 1);
  const travel = v * exposure;                       // metros recorridos durante la exposición
  const blurPx = pixelSize ? travel / pixelSize : 0; // emborronamiento en píxeles
  // Criterio de lectura: el emborronamiento se mide sobre el propio carácter, no sobre el píxel
  const charWidth = Number(cfg.charWidth) || cfg.plateWidth * (47 / 520);
  const blurMm = travel * 1000;
  const blurPct = charWidth ? (travel / charWidth) * 100 : 0;
  const blurLimit = ruleNum(rules, 'LPR_EMBORRON_PCT') || 10;
  // Ventana de lectura: por lejos manda la altura mínima de carácter, por cerca el encuadre de la placa
  const charPxPerMeter = charHeight * ((resW * focal) / sensorW);
  const maxReadDistance = charPxPerMeter / Math.max(cfg.minCharPx, 1);
  const minReadDistance = Math.max(0.5, (focal * cfg.plateWidth) / (sensorW * 0.6));
  const angleFactor = Math.cos(rad(clamp(cfg.mountingAngle, 0, 89)));   // acortamiento horizontal
  const effectiveCharPx = charPx * angleFactor * Math.cos(rad(clamp(cfg.tilt, 0, 89)) * 0.35);
  const ok = effectiveCharPx >= cfg.minCharPx && ppm >= cfg.minPpm && cfg.mountingAngle <= cfg.maxAngle && blurPct <= blurLimit;
  return {
    ...cfg, resW, focal, sensorW, ppm, platePx, charPx: effectiveCharPx, charPxRaw: charPx, charHeight,
    hfov: fov.hfov, vfov: fov.vfov, widthAtDist, pixelSize, exposure, travel, blurPx, blurMm, blurPct, blurLimit, charWidth,
    maxReadDistance, minReadDistance, angleFactor, ok,
    distanceOk: d >= minReadDistance * 0.5 && d <= maxReadDistance,
    maxObjectiveDistance: maxDistanceFor(it, 'MATRICULA', focal),
  };
}

/** Zona de captura en planta: sector del carril donde la placa es legible. */
export function captureZone(cam, catalog, rules, opts = {}) {
  const o = lprOptics(cam, catalog, rules, opts);
  const p = cam.points[0] || { x: 0, y: 0 };
  const az = Number(cam.data.azimuth) || 0;
  const half = o.hfov / 2;
  const near = Math.max(o.minReadDistance, 1);
  const far = Math.min(o.maxReadDistance, o.maxObjectiveDistance, 60);
  const steps = Math.max(8, Math.round(o.hfov / 3));
  const pts = [{ x: p.x, y: p.y }];
  for (let i = 0; i <= steps; i++) {
    const a = rad(az - half + (o.hfov * i) / steps);
    pts.push({ x: p.x + Math.cos(a) * near, y: p.y + Math.sin(a) * near });
  }
  for (let i = steps; i >= 0; i--) {
    const a = rad(az - half + (o.hfov * i) / steps);
    pts.push({ x: p.x + Math.cos(a) * far, y: p.y + Math.sin(a) * far });
  }
  return { polygon: pts, origin: p, near, far, hfov: o.hfov, optics: o, azimuth: az };
}

/** Longitud de carril necesaria para que la lectura ocurra dentro de la zona útil. */

/** Velocidad máxima de circulación que admite el tiempo de obturación configurado. */
export function maxSpeedFor(cam, catalog, rules, blurPctLimit) {
  const o = lprOptics(cam, catalog, rules);
  const limit = (blurPctLimit || o.blurLimit) / 100;
  const allowedTravel = limit * o.charWidth;          // metros que puede recorrer el vehículo
  return (allowedTravel / o.exposure) * 3.6;          // m/s → km/h
}

/** Resumen LPR del proyecto (para panel, documentos y presupuesto). */
export function lprSummary(prj, catalog, rules) {
  const cams = prj.entities.filter((e) => e.type === 'camera' && isLpr(e, catalog) && lprConfig(e, catalog, rules).enabled);
  const lanes = new Map();
  const rows = cams.map((cam) => {
    const o = lprOptics(cam, catalog, rules);
    const zone = captureZone(cam, catalog, rules);
    const lane = o.lane || '— sin carril definido —';
    lanes.set(lane, (lanes.get(lane) || 0) + 1);
    return {
      id: cam.id, label: cam.data.label || cam.id, lane, mode: o.mode, model: (getItem(catalog, cam.data.catalogId) || {}).model || '?',
      distance: o.captureDistance, focal: o.focal, ppm: o.ppm, platePx: o.platePx, charPx: o.charPx, charMm: o.charWidth * 1000,
      angle: o.mountingAngle, speed: o.speedLimit, shutter: o.shutter, blur: o.blurPx, blurPct: o.blurPct, ir: o.irIlluminator,
      maxReadDistance: o.maxReadDistance, zoneArea: polyAreaOf(zone.polygon), ok: o.ok, zone,
      maxSpeed: maxSpeedFor(cam, catalog, rules),
    };
  });
  const status = !rows.length ? 'SIN CAMARAS' : (rows.every((r) => r.ok) ? (lanes.size === rows.length ? 'NORMAL' : 'PARCIAL') : 'REVISAR');
  return {
    count: rows.length, rows, lanes: [...lanes.keys()], laneCount: lanes.size, status,
    duplicateLanes: [...lanes.entries()].filter(([, n]) => n > 1).map(([l]) => l),
    plateWidth: rows.length ? lprOptics(cams[0], catalog, rules).plateWidth : 0,
  };
}

/** Área de un polígono (evita dependencia circular con geometry). */
function polyAreaOf(pts) {
  let a = 0;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) a += (pts[j].x + pts[i].x) * (pts[j].y - pts[i].y);
  return Math.abs(a / 2);
}

/** Cuadro LPR del proyecto (CSV, PDF y paneles). */
export function lprSchedule(prj, catalog, rules) {
  return lprSummary(prj, catalog, rules).rows.map((r) => ({
    camera: r.label, lane: r.lane, mode: LPR_MODES[r.mode] || r.mode,
    distance: r.distance, focal: r.focal, ppm: Math.round(r.ppm), charPx: Math.round(r.charPx * 10) / 10,
    angle: r.angle, speed: r.speed, shutter: r.shutter, blurPct: Math.round(r.blurPct * 10) / 10,
    maxSpeed: Math.round(r.maxSpeed), ir: r.ir, maxReadDistance: Math.round(r.maxReadDistance * 10) / 10,
    zoneArea: Math.round(r.zoneArea * 10) / 10, ok: r.ok,
  }));
}

/** Incidencias del módulo LPR (§30). */
export function validateLpr(prj, catalog, rules) {
  const out = [];
  const cams = prj.entities.filter((e) => e.type === 'camera' && isLpr(e, catalog));
  if (!cams.length) return out;
  const seen = new Map();
  for (const cam of cams) {
    const name = cam.data.label || cam.id;
    const o = lprOptics(cam, catalog, rules);
    if (!o.enabled) { out.push({ code: 'LPR_DESACTIVADO', severity: 'info', text: `${name}: cámara LPR con el módulo de lectura desactivado (se usa como cámara de vigilancia)` }); continue; }
    if (!o.lane) out.push({ code: 'LPR_SIN_CARRIL', severity: 'warn', text: `${name}: no se ha definido el carril que vigila la cámara` });
    if (o.mountingAngle > o.maxAngle)
      out.push({ code: 'LPR_ANGULO', severity: 'error', text: `${name}: ángulo de lectura ${o.mountingAngle}° mayor que el máximo de ${o.maxAngle}° (¿montaje perpendicular a la marcha?)` });
    if (o.charPx < o.minCharPx)
      out.push({ code: 'LPR_CARACTER', severity: 'error', text: `${name}: ${o.charPx.toFixed(1)} px de altura de carácter a ${o.captureDistance} m (mínimo ${o.minCharPx} px): acerque la cámara o aumente la focal` });
    if (o.ppm < o.minPpm)
      out.push({ code: 'LPR_PPM', severity: 'warn', text: `${name}: ${o.ppm.toFixed(0)} ppm a la distancia de captura (mínimo ${o.minPpm} ppm)` });
    if (!o.distanceOk)
      out.push({ code: 'LPR_DISTANCIA', severity: 'warn', text: `${name}: la distancia de captura ${o.captureDistance} m está fuera de la ventana de lectura ${o.minReadDistance.toFixed(1)}–${o.maxReadDistance.toFixed(1)} m` });
    if (o.blurPct > o.blurLimit)
      out.push({ code: 'LPR_EMBORRONAMIENTO', severity: 'warn',
        text: `${name}: el vehículo recorre ${o.blurMm.toFixed(1)} mm durante la exposición a ${o.speedLimit} km/h con 1/${o.shutter} s (${o.blurPct.toFixed(0)} % del ancho de carácter, máximo ${o.blurLimit} %): use 1/${Math.ceil(o.speedLimit / 3.6 / (o.blurLimit / 100 * o.charWidth))} s o menos` });
    if (!o.irIlluminator)
      out.push({ code: 'LPR_SIN_IR', severity: 'warn', text: `${name}: lectura nocturna sin iluminación IR dedicada` });
    const key = (o.lane || '').toLowerCase();
    if (key) { if (seen.has(key)) out.push({ code: 'LPR_CARRIL_DUPLICADO', severity: 'info', text: `${name} y ${seen.get(key)} vigilan el mismo carril «${o.lane}»` }); else seen.set(key, name); }
  }
  return out;
}
