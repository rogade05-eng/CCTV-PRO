/**
 * CCTV DESIGN PRO — Módulo de fibra óptica (CP CCTV §17, §18, §38)
 *
 * Decide qué enlaces van por fibra, elige el tipo de fibra y el transceptor (SFP) y
 * comprueba el **presupuesto de potencia óptica**: atenuación del cable, conectores,
 * empalmes, margen de diseño y capacidad del transceptor.
 *
 * Un enlace puede ir por fibra por dos motivos: superar el máximo de UTP o porque el
 * proyectista lo decide (tramos exteriores, aislamiento galvánico, ampliación futura).
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

/** Tipos de fibra y transceptores asociados (valores normalizados de referencia). */
export const FIBER_TYPES = {
  MM: { id: 'MM', label: 'Multimodo OM3', wavelength: 850, sfp: 'ACC-SFP', maxDist: 550, txBudget: 7.5, color: '#14b8a6' },
  SM: { id: 'SM', label: 'Monomodo OS2', wavelength: 1310, sfp: 'ACC-SFP-SM', maxDist: 10000, txBudget: 11.0, color: '#0ea5e9' },
  LH: { id: 'LH', label: 'Monomodo OS2 larga distancia', wavelength: 1550, sfp: 'ACC-SFP-LH', maxDist: 40000, txBudget: 20.0, color: '#8b5cf6' },
};

/** Escalones de fibra: se elige el más económico que cubre la distancia. */
export const FIBER_LADDER = ['MM', 'SM', 'LH'];

/** Atenuación por kilómetro según el tipo y la regla configurada. */
export function attenuationPerKm(type, rules) {
  const key = { MM: 'FIBRA_ATEN_MM', SM: 'FIBRA_ATEN_SM', LH: 'FIBRA_ATEN_SM' }[type] || 'FIBRA_ATEN_MM';
  return ruleNum(rules, key) || (type === 'MM' ? 3.5 : 0.35);
}

/** Tipo de fibra más económico que cubre la distancia (con la reserva de diseño). */
export function selectFiberType(distanceM, rules) {
  const reserve = 1 + (ruleNum(rules, 'FIBRA_RESERVA_DIST') || 0) / 100;
  const need = distanceM * reserve;
  for (const key of FIBER_LADDER) if (need <= FIBER_TYPES[key].maxDist) return FIBER_TYPES[key];
  return FIBER_TYPES.LH;
}

/**
 * Presupuesto de potencia de un enlace de fibra.
 * pérdidas = atenuación·km + conectores + empalmes ; margen = presupuesto SFP − pérdidas
 */
export function fiberBudget(distanceM, rules, opts = {}) {
  const typeKey = opts.type || selectFiberType(distanceM, rules).id;
  const type = FIBER_TYPES[typeKey] || FIBER_TYPES.MM;
  const km = Math.max(distanceM, 0) / 1000;
  const atten = attenuationPerKm(type.id, rules) * km;
  // Dos latiguillos por extremo (transceptor→ODF y ODF→cable) = 4 conectores; se añaden 2 más
  // si el enlace atraviesa un panel de parcheo intermedio (opts.patchPanels).
  const connectors = (4 + 2 * (opts.patchPanels || 0)) * (ruleNum(rules, 'FIBRA_CONECTOR') || 0.3);
  const spliceEvery = ruleNum(rules, 'FIBRA_TRAMO_EMPALME') || 2000;
  const splices = opts.splices === undefined ? Math.max(0, Math.floor((distanceM * 1.05) / spliceEvery)) : opts.splices;
  const spliceLoss = splices * (ruleNum(rules, 'FIBRA_EMPALME') || 0.1);
  const margin = ruleNum(rules, 'FIBRA_MARGEN') || 3;
  const totalLoss = atten + connectors + spliceLoss;
  const budget = type.txBudget;
  const remaining = budget - totalLoss - margin;
  const pct = budget ? ((totalLoss + margin) / budget) * 100 : 0;
  const warnPct = ruleNum(rules, 'FIBRA_AVISO_PCT') || 85;
  const status = distanceM > type.maxDist ? 'EXCESIVA' : pct > 100 ? 'EXCESIVA' : pct >= warnPct ? 'PROXIMA' : 'NORMAL';
  return {
    type: type.id, typeLabel: type.label, wavelength: type.wavelength, sfp: type.sfp, sfpModel: (getItem(opts.catalog || { items: [] }, type.sfp) || {}).model || type.sfp,
    distance: distanceM, km, atten, connectors, connectorCount: 4 + 2 * (opts.patchPanels || 0),
    splices, spliceLoss, margin, totalLoss, budget, remaining, pct, status,
    maxDist: type.maxDist, recommendation: status === 'EXCESIVA' ? suggestUpgrade(type.id) : null,
  };
}

const suggestUpgrade = (typeId) => {
  const i = FIBER_LADDER.indexOf(typeId);
  const next = FIBER_LADDER[i + 1];
  if (!next) return 'Divida el enlace con un switch intermedio o use un transceptor de mayor alcance.';
  return `Use fibra ${FIBER_TYPES[next].label} con transceptores ${FIBER_TYPES[next].sfp} (alcance ${FIBER_TYPES[next].maxDist / 1000} km).`;
};

/** ¿El equipo tiene puertos SFP libres para el transceptor? */
export function hasSfpPort(device, catalog) {
  const it = getItem(catalog, device && device.data && device.data.catalogId);
  return !!(it && it.specs && Number(it.specs.sfp) > 0);
}

/**
 * Analiza los enlaces del proyecto y devuelve el detalle de los que van por fibra.
 * @returns {{links:object[], fiberLinks:number, splices:number, byType:object, converters:number, cabling:object}}
 */
export function fiberSummary(prj, catalog, rules) {
  const maxUtp = ruleNum(rules, 'MAX_UTP');
  const byId = new Map(prj.entities.map((e) => [e.id, e]));
  const links = [];
  const byType = { MM: 0, SM: 0, LH: 0 };

  for (const c of prj.entities.filter((e) => e.type === 'cable')) {
    const cam = byId.get(c.data.from);
    const sw = byId.get(c.data.to);
    const distance = Number(c.data.net) || 0;
    const forced = c.data.media === 'fiber';
    const forcedUtp = c.data.media === 'utp';
    const overUtp = !forcedUtp && distance > maxUtp;
    if (!forced && !overUtp) continue;
    const b = fiberBudget(distance, rules, { catalog, type: c.data.fiberType || undefined });
    byType[b.type]++;
    const swSfp = hasSfpPort(sw, catalog);
    const camSfp = hasSfpPort(cam, catalog);
    links.push({
      id: c.id, camera: cam ? (cam.data.label || cam.id) : c.data.from, switch: sw ? (sw.data.label || sw.id) : c.data.to,
      distance, geometric: Number(c.data.geometric) || 0, supply: Number(c.data.supply) || 0,
      reason: forced && !overUtp ? 'Elección del proyectista' : 'Supera el máximo de UTP',
      forced, overUtp, ...b,
      converters: (swSfp && camSfp) ? 0 : 2,     // un conversor por extremo sin SFP
      switchSfp: swSfp, cameraSfp: camSfp,
      media: b.type === 'MM' ? 'Fibra multimodo' : 'Fibra monomodo',
    });
  }

  const splices = links.reduce((a, l) => a + l.splices, 0);
  const converters = links.reduce((a, l) => a + l.converters, 0);
  const status = links.length ? (links.some((l) => l.status === 'EXCESIVA') ? 'EXCESIVA'
    : links.some((l) => l.status === 'PROXIMA') ? 'PROXIMA' : 'NORMAL') : 'SIN ENLACES';
  return {
    links, fiberLinks: links.length, splices, converters, byType, status,
    meters: links.reduce((a, l) => a + l.supply, 0),
    totalLoss: links.reduce((a, l) => a + l.totalLoss, 0),
    // Cuadro de medios: fibra vs cobre (para la memoria y el presupuesto)
    mediaMix: (() => {
      const cables = prj.entities.filter((e) => e.type === 'cable');
      const fiber = cables.filter((c) => c.data.media === 'fiber' ||
        (c.data.media !== 'utp' && (Number(c.data.net) || 0) > maxUtp));
      return { total: cables.length, fiber: fiber.length, copper: cables.length - fiber.length };
    })(),
  };
}

/** Incidencias del módulo de fibra (§30). */
export function validateFiber(prj, catalog, rules) {
  const out = [];
  const s = fiberSummary(prj, catalog, rules);
  for (const l of s.links) {
    if (l.status === 'EXCESIVA')
      out.push({ code: 'FIBRA_PRESUPUESTO', severity: 'error',
        text: `${l.camera} → ${l.switch}: pérdidas ${l.totalLoss.toFixed(2)} dB + margen ${l.margin} dB sobre un presupuesto de ${l.budget} dB (${l.typeLabel}). ${l.recommendation}` });
    else if (l.status === 'PROXIMA')
      out.push({ code: 'FIBRA_MARGEN_JUSTO', severity: 'warn',
        text: `${l.camera} → ${l.switch}: margen óptico de solo ${l.remaining.toFixed(2)} dB (${l.pct.toFixed(0)} % del presupuesto)` });
    if (l.distance > l.maxDist)
      out.push({ code: 'FIBRA_ALCANCE', severity: 'error', text: `${l.camera} → ${l.switch}: ${Math.round(l.distance)} m superan el alcance del transceptor (${l.maxDist} m)` });
    if (l.converters > 0)
      out.push({ code: 'FIBRA_CONVERSOR', severity: 'info',
        text: `${l.camera} → ${l.switch}: se añaden ${l.converters} conversor(es) de medio porque los equipos no tienen puerto SFP` });
  }
  // Enlaces de cobre por encima del máximo: nunca deberían quedar sin convertir
  const maxUtp = ruleNum(rules, 'MAX_UTP');
  for (const c of prj.entities.filter((e) => e.type === 'cable')) {
    if ((c.data.media === 'utp') && (Number(c.data.net) || 0) > maxUtp)
      out.push({ code: 'FIBRA_SIN_CONVERTIR', severity: 'error', text: `Un enlace de ${Math.round(c.data.net)} m está forzado a UTP superando los ${maxUtp} m del estándar` });
  }
  return out;
}
