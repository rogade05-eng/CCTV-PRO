/**
 * CCTV DESIGN PRO — Modelo de proyecto (CP CCTV §6, §11, §12, §19, §37)
 * core/project.js — estructura de datos única del programa. Todo cálculo lee de aquí.
 */
import { defaultRules } from './rules.js?v=b441e3fc';
import { seedCatalog } from './catalog.js?v=b441e3fc';

export const PROJECT_VERSION = 1;

export const DEFAULT_LAYERS = [
  { id: 'ARQUITECTURA', name: 'Arquitectura', color: '#5b6b7c', visible: true, locked: false },
  { id: 'ZONAS', name: 'Zonas de interés', color: '#2f6f4f', visible: true, locked: false },
  { id: 'CAMARAS', name: 'Cámaras', color: '#e8443a', visible: true, locked: false },
  { id: 'COBERTURA', name: 'Cobertura', color: '#f2a33c', visible: true, locked: false },
  { id: 'CABLEADO', name: 'Cableado', color: '#3b82f6', visible: true, locked: false },
  { id: 'CANALIZACIONES', name: 'Canalizaciones', color: '#8b5cf6', visible: true, locked: false },
  { id: 'RED', name: 'Red', color: '#0ea5e9', visible: true, locked: false },
  { id: 'EQUIPOS', name: 'Equipos', color: '#14b8a6', visible: true, locked: false },
  { id: 'RACK', name: 'Rack', color: '#a3a3a3', visible: true, locked: false },
  { id: 'ALIMENTACION', name: 'Alimentación', color: '#eab308', visible: true, locked: false },
  { id: 'TEXTOS', name: 'Textos', color: '#d4d4d8', visible: true, locked: false },
  { id: 'COTAS', name: 'Cotas', color: '#94a3b8', visible: true, locked: false },
  { id: 'DIAGRAMAS', name: 'Diagramas', color: '#c084fc', visible: true, locked: false },
  { id: 'PRIVACIDAD', name: 'Privacidad', color: '#e11d48', visible: true, locked: false },
];

export const OBJECTIVES = {
  DETECCION: { label: 'Detección', ppm: 25, note: 'Saber que hay una persona en la escena.' },
  OBSERVACION: { label: 'Observación', ppm: 63, note: 'Rasgos generales, vestimenta, actividad.' },
  RECONOCIMIENTO: { label: 'Reconocimiento', ppm: 125, note: 'Identificar a alguien ya conocido.' },
  IDENTIFICACION: { label: 'Identificación', ppm: 250, note: 'Prueba forense de identidad.' },
  MATRICULA: { label: 'Lectura de matrícula', ppm: 130, note: 'LPR: altura de carácter legible.' },
  SEGUIMIENTO: { label: 'Seguimiento', ppm: 63, note: 'Seguir el movimiento de un objetivo.' },
};

let _seq = 0;
export const newId = (p = 'E') => `${p}${Date.now().toString(36)}${(_seq++).toString(36)}`;

export function newProject(name = 'Proyecto CCTV') {
  return {
    meta: {
      name, code: 'CCTV-001', client: '', address: '', author: '', company: '',
      units: 'm', scale: 1, created: new Date().toISOString(), modified: new Date().toISOString(),
      version: PROJECT_VERSION, notes: '',
    },
    rules: defaultRules(),
    layers: DEFAULT_LAYERS.map((l) => ({ ...l })),
    entities: [],
    catalog: seedCatalog(),
    rack: { catalogId: 'RACK-22', label: 'RACK-01', items: [] },
    settings: { gridVisible: true, gridStep: 1, snapEnabled: true, showCoverage: true, showRoutes: true, showLabels: true, showPresets: true, showLprZones: true, showPrivacy: true, privacidad: {} },
    results: {},
  };
}

export const layerOf = (prj, id) => prj.layers.find((l) => l.id === id);
export const byType = (prj, type) => prj.entities.filter((e) => e.type === type);
export const cameras = (prj) => byType(prj, 'camera');
export const devices = (prj) => byType(prj, 'device');
export const rooms = (prj) => byType(prj, 'room');
export const cableRuns = (prj) => byType(prj, 'cable');
export const getEntity = (prj, id) => prj.entities.find((e) => e.id === id) || null;

export function addEntity(prj, ent) {
  const e = Object.assign({ id: newId(ent.type === 'camera' ? 'CAM' : 'E'), layer: 'ARQUITECTURA', data: {} }, ent);
  prj.entities.push(e);
  return e;
}

export function removeEntity(prj, id) {
  const i = prj.entities.findIndex((e) => e.id === id);
  if (i >= 0) prj.entities.splice(i, 1);
  prj.entities.filter((e) => e.type === 'cable' && (e.data.from === id || e.data.to === id)).forEach((c) => removeEntity(prj, c.id));
}

export function makeCamera(catalogId, x, y, opts = {}) {
  return {
    type: 'camera', layer: 'CAMARAS',
    points: [{ x, y }],
    data: Object.assign({
      catalogId, label: '', height: 2.8, azimuth: 0, tilt: 15, objective: 'OBSERVACION',
      ip: '', notes: '', switchId: '', mount: 'wall', switchPoe: true,
    }, opts),
  };
}

export function makeDevice(catalogId, kind, x, y, opts = {}) {
  return {
    type: 'device', layer: kind === 'switch' ? 'RED' : 'EQUIPOS',
    points: [{ x, y }],
    data: Object.assign({ catalogId, kind, label: '', ip: '', notes: '' }, opts),
  };
}

/* ------------------------------------------------------------------ *
 *  Proyecto de demostración: planta de oficinas de 36 × 22 m
 *  Permite recorrer los 18 pasos del criterio de finalización (§41).
 * ------------------------------------------------------------------ */
export function demoProject() {
  const prj = newProject('Planta Oficina Demo');
  prj.meta.client = 'Cliente de demostración';
  prj.meta.address = 'Edificio Central, Planta 1';
  prj.meta.author = 'Dpto. Técnico';
  prj.meta.notes = 'Proyecto de ejemplo generado por CCTV DESIGN PRO para validar el flujo completo.';

  const wall = (pts, closed = false) =>
    addEntity(prj, { type: 'polyline', layer: 'ARQUITECTURA', points: pts, closed, data: { h: 2.8 } });

  // Perímetro con hueco de puerta en el acceso principal (0–11 m y 12,5–36 m):
  // el hueco es imprescindible para que las canalizaciones crucen del exterior al interior.
  wall([{ x: 0, y: 0 }, { x: 11, y: 0 }]);
  wall([{ x: 12.5, y: 0 }, { x: 36, y: 0 }, { x: 36, y: 22 }, { x: 0, y: 22 }, { x: 0, y: 0 }]);
  // Tabiquería con huecos de paso
  wall([{ x: 12, y: 0 }, { x: 12, y: 9 }]);
  wall([{ x: 12, y: 11 }, { x: 12, y: 22 }]);
  wall([{ x: 0, y: 6 }, { x: 4, y: 6 }]);
  wall([{ x: 5.5, y: 6 }, { x: 12, y: 6 }]);
  wall([{ x: 6, y: 6 }, { x: 6, y: 12.5 }]);
  wall([{ x: 12, y: 14 }, { x: 17, y: 14 }]);
  wall([{ x: 18.5, y: 14 }, { x: 36, y: 14 }]);
  wall([{ x: 24, y: 14 }, { x: 24, y: 19.5 }]);
  wall([{ x: 30, y: 14 }, { x: 30, y: 18.5 }]);
  wall([{ x: 30, y: 20 }, { x: 30, y: 22 }]);

  // Zonas de interés (polígonos cerrados con nombre y criticidad)
  const room = (name, a, b, critical = false) =>
    addEntity(prj, {
      type: 'room', layer: 'ZONAS',
      points: [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }],
      closed: true, data: { name, critical },
    });
  room('Recepción', { x: 0, y: 0 }, { x: 12, y: 6 }, true);
  room('Oficina 1', { x: 0, y: 6 }, { x: 6, y: 14 });
  room('Oficina 2', { x: 6, y: 6 }, { x: 12, y: 14 });
  room('Oficina abierta', { x: 12, y: 0 }, { x: 36, y: 14 }, true);
  room('Sala de reuniones', { x: 12, y: 14 }, { x: 24, y: 22 });
  room('Zona técnica / CPD', { x: 24, y: 14 }, { x: 30, y: 22 }, true);
  room('Almacén', { x: 30, y: 14 }, { x: 36, y: 22 });
  // Carril de acceso vehicular, delante del acceso principal (§38: módulo LPR)
  const laneZone = room('Acceso vehicular', { x: 3, y: -2.6 }, { x: 9.9, y: 0 }, true);

  // Bandeja portacables en el pasillo de la oficina abierta (abarata y ordena las rutas)
  addEntity(prj, {
    type: 'polyline', layer: 'CANALIZACIONES', closed: false,
    points: [{ x: 25, y: 13.6 }, { x: 13.5, y: 13.6 }, { x: 13.5, y: 2 }, { x: 34.5, y: 2 }],
    data: { kind: 'bandeja', width: 0.05 },
  });

  // Cámaras
  const cams = [
    ['CAM-2MP-BULLET', 11.3, 5.3, 225, 'Recepción'],
    ['CAM-4MP-DOME', 0.7, 13.3, 315, 'Oficina 1'],
    ['CAM-4MP-DOME', 11.3, 13.3, 225, 'Oficina 2'],
    ['CAM-4MP-DOME', 14.0, 12.9, 270, 'Oficina abierta A'],
    ['CAM-4MP-DOME', 24.0, 12.9, 270, 'Oficina abierta B'],
    ['CAM-4MP-DOME', 34.2, 12.9, 250, 'Oficina abierta C'],
    ['CAM-4MP-BULLET', 12.7, 0.9, 90, 'Acceso principal'],
    ['CAM-4MP-DOME', 12.8, 14.8, 45, 'Sala de reuniones'],
    ['CAM-2MP-BULLET', 29.3, 14.8, 90, 'Zona técnica'],
    ['CAM-2MP-BULLET', 35.3, 21.3, 225, 'Almacén'],
    ['CAM-PTZ-4MP', 35.2, 0.9, 150, 'PTZ perimetral'],
  ];
  cams.forEach(([id, x, y, az, label], i) => {
    addEntity(prj, makeCamera(id, x, y, {
      label: label || `CAM-${String(i + 1).padStart(2, '0')}`,
      azimuth: az, tilt: id === 'CAM-PTZ-4MP' ? 8 : 18,
      objective: label === 'Acceso principal' ? 'IDENTIFICACION' : label === 'Recepción' ? 'RECONOCIMIENTO' : 'OBSERVACION',
    }));
  });

  // Cámara LPR en el acceso vehicular (§38): lee matrículas a 5–16 m con 20° de ángulo
  addEntity(prj, makeCamera('CAM-LPR-4MP', 15.5, -1.3, {
    label: 'LPR-01', height: 3.2, azimuth: 180, tilt: 20, focal: 12, objective: 'MATRICULA',
    media: 'fiber', notes: 'Tramo exterior del carril: fibra por aislamiento galvánico y EMI',
    lprEnabled: true, lprMode: 'ENTRADA', lprLane: 'Acceso vehículos', lprDistance: 8, lprAngle: 20,
    lprSpeed: 30, lprShutter: 2000, lprIr: true,
  }));
  addEntity(prj, makeDevice('ACC-BARRIER', 'barrier', 11.6, -1.4, { label: 'BARR-01', notes: 'Barrera del control de acceso' }));

  // Reglas de analítica de vídeo (§38) sobre zonas de interés ya definidas
  const camByLabel = (l) => prj.entities.find((e) => e.type === 'camera' && e.data.label === l);
  const zoneByName = (n) => prj.entities.find((e) => e.type === 'room' && e.data.name === n);
  const anal = (label, rulesList) => {
    const c = camByLabel(label); if (!c) return;
    c.data.analytics = rulesList.map((r) => Object.assign({ type: 'intrusion', sensitivity: 5, actions: ['recording', 'alarm'] }, r));
  };
  anal('Oficina 2', [{ type: 'intrusion', zoneId: (zoneByName('Oficina 2') || {}).id, sensitivity: 6, actions: ['alarm', 'recording'], note: 'Intrusión fuera del horario laboral' }]);
  anal('Sala de reuniones', [{ type: 'count', zoneId: (zoneByName('Sala de reuniones') || {}).id, sensitivity: 4, actions: ['recording'], eventsPerDay: 25 }]);
  anal('Almacén', [{ type: 'loiter', zoneId: (zoneByName('Almacén') || {}).id, sensitivity: 5, actions: ['alarm'], note: 'Permanencia > 60 s' }]);
  anal('PTZ perimetral', [{ type: 'autotrack', sensitivity: 7, actions: ['zoom', 'recording'], note: 'Seguimiento automático del objetivo' }]);

  // Patrulla del PTZ perimetral (§38): tres posiciones memorizadas con distinto objetivo y zoom
  const ptz = prj.entities.filter((e) => e.type === 'camera' && e.data.catalogId === 'CAM-PTZ-4MP')[0];
  if (ptz) {
    ptz.data.presets = [
      { name: 'Oficina abierta', azimuth: 150, tilt: 8, focal: 6, objective: 'OBSERVACION', dwell: 30 },
      { name: 'Pasillo sur', azimuth: 188, tilt: 12, focal: 12, objective: 'RECONOCIMIENTO', dwell: 20 },
      { name: 'Fachada norte', azimuth: 95, tilt: 9, focal: 8, objective: 'OBSERVACION', dwell: 15 },
    ];
    ptz.data.ptzPatrol = true;
  }

  // Red
  addEntity(prj, makeDevice('SW-16P', 'switch', 24.9, 21.2, { label: 'SW-01', ip: '192.168.10.2' }));
  addEntity(prj, makeDevice('SW-8P', 'switch', 13.2, 13.2, { label: 'SW-02', ip: '192.168.10.3' }));
  addEntity(prj, makeDevice('NVR-16', 'nvr', 26.1, 21.2, { label: 'NVR-01', ip: '192.168.10.10', disks: [{ itemId: 'HDD-10TB', qty: 2 }] }));
  addEntity(prj, makeDevice('RT-GW', 'router', 27.3, 21.2, { label: 'RTR-01', ip: '192.168.10.1' }));
  addEntity(prj, makeDevice('PP-24', 'patchpanel', 28.5, 21.2, { label: 'PP-01' }));
  addEntity(prj, makeDevice('UPS-1500', 'ups', 29.4, 20.3, { label: 'UPS-01' }));

  // Rack inicial
  prj.rack = {
    catalogId: 'RACK-22', label: 'RACK-01',
    items: [
      { itemId: 'PP-24', qty: 1, u: 1 }, { itemId: 'ORG-1U', qty: 1, u: 1 },
      { itemId: 'SW-16P', qty: 1, u: 1 }, { itemId: 'SW-8P', qty: 1, u: 1 },
      { itemId: 'NVR-16', qty: 1, u: 1 }, { itemId: 'RT-GW', qty: 1, u: 1 },
      { itemId: 'UPS-1500', qty: 1, u: 2 },
    ],
  };

  // Textos de plano
  addEntity(prj, { type: 'text', layer: 'TEXTOS', points: [{ x: 18, y: 23.5 }], data: { text: 'PLANTA 1 — PLANO DE CÁMARAS', height: 0.9 } });
  return prj;
}

/* ------------------------- Persistencia (.cctv) ------------------------- */

export function serialize(prj) {
  prj.meta.modified = new Date().toISOString();
  return JSON.stringify({ magic: 'CCTV-DESIGN-PRO', version: PROJECT_VERSION, project: prj }, null, 1);
}

export function deserialize(text) {
  const doc = JSON.parse(text);
  if (!doc || doc.magic !== 'CCTV-DESIGN-PRO') throw new Error('El archivo no es un proyecto de CCTV DESIGN PRO');
  const prj = doc.project;
  prj.rules = Object.assign(defaultRules(), prj.rules || {});
  prj.catalog = prj.catalog && prj.catalog.items ? prj.catalog : seedCatalog();
  prj.layers = prj.layers && prj.layers.length ? prj.layers : DEFAULT_LAYERS.map((l) => ({ ...l }));
  prj.results = prj.results || {};
  prj.rack = prj.rack || { catalogId: 'RACK-22', label: 'RACK-01', items: [] };
  prj.settings = Object.assign({ gridVisible: true, gridStep: 1, snapEnabled: true, showCoverage: true, showRoutes: true, showLabels: true, showPresets: true, showLprZones: true, showPrivacy: true, privacidad: {} }, prj.settings || {});
  // La declaración de privacidad (responsable, finalidad, funciones sensibles) es del proyecto
  if (!prj.settings.privacidad) prj.settings.privacidad = {};
  return prj;
}

/** Detección de corrupción / integridad básica (§37). */
export function integrityCheck(text) {
  try {
    const doc = JSON.parse(text);
    if (!doc || doc.magic !== 'CCTV-DESIGN-PRO') return { ok: false, reason: 'Cabecera desconocida' };
    if (!doc.project || !Array.isArray(doc.project.entities)) return { ok: false, reason: 'Estructura incompleta' };
    return { ok: true, entities: doc.project.entities.length, version: doc.version };
  } catch (err) {
    return { ok: false, reason: 'JSON inválido: ' + err.message };
  }
}
