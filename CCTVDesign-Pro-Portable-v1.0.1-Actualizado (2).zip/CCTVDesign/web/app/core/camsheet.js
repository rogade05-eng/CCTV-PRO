/**
 * CCTV DESIGN PRO — Hoja de cámara (CP CCTV §28)
 * core/camsheet.js — datos puros de una hoja: óptica, DORI, cobertura, instalación y
 * privacidad de una cámara, más la geometría para dibujar su planta en el PDF.
 *
 * La hoja de cámara es el documento que se lleva a obra y el que firma el cliente: reúne en
 * una página lo que hay que montar, cómo hay que ajustarlo y qué se consigue con ello. Todo
 * sale del modelo, así que cambiar la focal o la altura cambia la hoja sin rehacer el escrito.
 */
import { bbox, bboxOf } from './geometry.js?v=b441e3fc';
import { maxDistanceFor, fieldOfView, pixelDensity } from './dori.js?v=b441e3fc';
import { footprintsOf, isPtz, cameraPresets, patrolCycle } from './ptz.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { segmentosOpacos, ALTURA_MURO } from './obstacles.js?v=b441e3fc';
import { OBJECTIVES } from './project.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';
import { mascarasPara } from './privacy.js?v=b441e3fc';

/** Etiqueta legible del soporte de fijación. */
export const SOPORTES = {
  wall: 'Pared', ceiling: 'Techo', pole: 'Poste/báculo', corner: 'Esquina',
  parapet: 'Pretil', soffit: 'Bajo forjado' };
export const etiquetaSoporte = (m) => SOPORTES[m] || SOPORTES.wall;

const num = (v, d = 2) => (Number.isFinite(Number(v)) ? Number(v).toFixed(d).replace('.', ',') : '—');

/**
 * Hoja de una cámara. `res` trae los cálculos ya hechos (cobertura, enlaces, PoE,
 * almacenamiento y privacidad); si faltan, la hoja sale con lo que se pueda deducir
 * directamente del modelo, para que se pueda imprimir en cualquier momento.
 */
export function hojaDeCamara(prj, catalog, rules, cam, res = {}) {
  const item = getItem(catalog, cam.data.catalogId) || {};
  const s = item.specs || {};
  const focal = Number(cam.data.focal) || Number(s.lens) || 4;
  const fov = fieldOfView(item, focal);
  const h = Number(cam.data.height) || ruleNum(rules, 'ALTO_FIJACION') || 2.8;
  const az = Number(cam.data.azimuth) || 0;
  const tilt = Number(cam.data.tilt) || 0;
  const objetivo = cam.data.objective || 'OBSERVACION';
  const esPtz = isPtz(cam, catalog);
  const presets = esPtz ? cameraPresets(cam) : [];
  const ciclo = esPtz && presets.length ? patrolCycle(cam, catalog, rules, presets) : null;

  // Alcance por objetivo de vigilancia (EN 62676-4): la distancia a la que se cumple cada ppm
  const dori = {
    DETECCION: maxDistanceFor(item, 'DETECCION', focal),
    OBSERVACION: maxDistanceFor(item, 'OBSERVACION', focal),
    RECONOCIMIENTO: maxDistanceFor(item, 'RECONOCIMIENTO', focal),
    IDENTIFICACION: maxDistanceFor(item, 'IDENTIFICACION', focal),
    MATRICULA: maxDistanceFor(item, 'MATRICULA', focal) };

  const cov = ((res.coverage && res.coverage.cameras) || []).find((c) => c.id === cam.id) || null;
  const enlace = ((res.links) || []).find((l) => l.id === cam.id || l.camera === (cam.data.label || cam.id)) || null;
  const poe = ((res.poe && res.poe.perCamera) || []).find((c) => c.id === cam.id || c.label === (cam.data.label || cam.id)) || null;
  const grab = ((res.storage && res.storage.perCamera) || []).find((c) => c.id === cam.id || c.label === (cam.data.label || cam.id)) || null;
  const priv = ((res.privacidad && res.privacidad.porCamara) || []).find((c) => c.id === cam.id) || null;

  const switchId = cam.data.switchId || (enlace && enlace.switchId) || '';
  const sw = switchId ? prj.entities.find((e) => e.id === switchId) : null;
  const huellas = footprintsOf(cam, catalog, rules).map((fp) => fp.polygon);

  // Planta de la hoja: la huella con margen y la arquitectura que la recorta, para que se
  // vea por qué la sombra del muro parte el campo de visión
  let caja = null;
  for (const p of huellas) caja = caja ? bboxOf(caja, bbox(p)) : bbox(p);
  if (!caja) caja = bbox([cam.points[0]]);
  const margen = Math.max(2, ((caja.maxX - caja.minX) + (caja.maxY - caja.minY)) * 0.12);
  caja = { minX: caja.minX - margen, minY: caja.minY - margen, maxX: caja.maxX + margen, maxY: caja.maxY + margen };
  const dentro = (p) => p.x >= caja.minX && p.x <= caja.maxX && p.y >= caja.minY && p.y <= caja.maxY;
  const muros = segmentosOpacos(prj, (prj.settings && prj.settings.alturaMuro) || ALTURA_MURO)
    .filter((sg) => dentro(sg.a) || dentro(sg.b))
    .map((sg) => ({ a: sg.a, b: sg.b }));

  return {
    id: cam.id,
    etiqueta: cam.data.label || cam.id,
    referencia: cam.data.catalogId || '—',
    fabricante: item.manufacturer || '—',
    modelo: item.model || '—',
    nombre: item.name || '',
    categoria: item.category || 'camera',

    optica: {
      resolucion: `${s.resW || '?'} × ${s.resH || '?'}`,
      mp: s.mp || null,
      focal, focales: (s.focalOptions || []).slice(),
      varifocal: !!s.varifocal,
      sensor: `${Number(s.sensorW || 6.4).toFixed(1)} × ${Number(s.sensorH || 3.6).toFixed(1)} mm`,
      hfov: fov.hfov, vfov: fov.vfov,
      ir: s.ir || 0,
      wdr: !!s.wdr,
      forma: s.form || '—',
      proteccion: [s.ip, s.ik].filter(Boolean).join(' / ') || '—',
      lpr: !!s.lpr },

    montaje: {
      altura: h, azimut: az, inclinacion: tilt,
      soporte: etiquetaSoporte(cam.data.mount || 'wall'),
      objetivo, objetivoLabel: OBJECTIVES[objetivo] ? OBJECTIVES[objetivo].label : objetivo,
      ppmExigidos: OBJECTIVES[objetivo] ? OBJECTIVES[objetivo].ppm : 0,
      notas: cam.data.notes || '' },

    dori,

    cobertura: {
      area: cov ? cov.area : null,
      areaHuella: cov ? cov.areaHuella : null,
      areaTeorica: cov ? cov.areaTeorica : null,
      sombraPct: cov ? cov.sombraPct : null,
      bloqueadas: cov ? cov.blockedCells : null,
      cumple: cov ? cov.meetsObjective : null,
      efectivaMax: cov ? cov.effectiveMax : null,
      teoricaMax: cov ? cov.theoreticalMax : null,
      ppmLejos: cov ? cov.ppmAtFar : null,
      lejos: cov ? cov.far : null,
      cerca: cov ? cov.near : null,
      ppmEn: (d) => pixelDensity(item, d, focal) },

    instalacion: {
      switchId,
      etiquetaSwitch: sw ? (sw.data.label || sw.id) : '—',
      ruta: enlace ? enlace.geometric : null,
      suministro: enlace ? enlace.supply : null,
      pctUtp: enlace ? enlace.pct : null,
      estadoEnlace: enlace ? enlace.status : '—',
      medio: enlace ? (enlace.media || 'UTP') : '—',
      poe: poe ? poe.poe : !!s.poe,
      consumo: poe ? poe.power : (s.power || 0),
      clasePoe: poe ? poe.poeClass : (s.poeClass || '—'),
      ip: cam.data.ip || '—' },

    grabacion: {
      kbps: grab ? grab.kbps : (s.bitrate || 0),
      fps: Number(cam.data.fps) || s.fps || 25,
      codec: s.codec || '—',
      gbDia: grab ? grab.gbPerDay : null,
      gbTotal: grab ? grab.gb : null,
      dias: ruleNum(rules, 'DIAS_GRABACION') },

    privacidad: {
      areaPublica: priv ? priv.areaPublica : 0,
      areaTerceros: priv ? priv.areaTerceros : 0,
      areaSensible: priv ? priv.areaSensible : 0,
      areaEnmascarada: priv ? priv.areaEnmascarada : 0,
      mascaras: mascarasPara(prj, cam.id).length },

    ptz: esPtz ? {
      esPtz: true,
      presets: presets.length,
      ciclo: ciclo ? ciclo.cycleSec : 0,
      posiciones: (ciclo ? ciclo.positions : presets).map((p) => ({
        nombre: p.name || '—', azimut: p.azimuth, inclinacion: p.tilt, focal: p.focal || focal,
        permanencia: p.dwell, tiempo: p.duty ? p.duty * 100 : null,
        objetivo: OBJECTIVES[p.objective] ? OBJECTIVES[p.objective].label : '—' })) } : { esPtz: false, presets: 0, ciclo: 0, posiciones: [] },

    planta: { caja, huellas, origen: cam.points[0], azimut: az, muros, etiqueta: cam.data.label || cam.id } };
}

/** Hojas de todas las cámaras del proyecto, en el orden del listado. */
export function hojasDeCamaras(prj, catalog, rules, res = {}) {
  const cams = (prj.entities || []).filter((e) => e.type === 'camera');
  const hojas = cams.map((c) => hojaDeCamara(prj, catalog, rules, c, res));
  const conCobertura = hojas.filter((h) => h.cobertura.area !== null);
  return {
    hojas,
    resumen: {
      camaras: hojas.length,
      areaCubierta: conCobertura.reduce((a, h) => a + (h.cobertura.area || 0), 0),
      cumplen: conCobertura.filter((h) => h.cobertura.cumple).length,
      conObjetivo: conCobertura.length,
      ptz: hojas.filter((h) => h.ptz.esPtz).length,
      consumo: hojas.reduce((a, h) => a + (h.instalacion.consumo || 0), 0),
      kbps: hojas.reduce((a, h) => a + (h.grabacion.kbps || 0), 0),
      conMascara: hojas.filter((h) => h.privacidad.mascaras > 0).length } };
}

/** Línea de la hoja lista para una tabla (para CSV, XLSX y pruebas). */
export function filaHoja(h) {
  return [
    h.etiqueta, h.modelo, h.optica.focal, h.montaje.altura, h.montaje.azimut, h.montaje.inclinacion,
    h.montaje.objetivoLabel, num(h.dori.OBSERVACION, 1), num(h.dori.RECONOCIMIENTO, 1), num(h.dori.IDENTIFICACION, 1),
    num(h.cobertura.area, 1), h.instalacion.etiquetaSwitch, num(h.instalacion.suministro, 1), h.instalacion.ip,
  ];
}
