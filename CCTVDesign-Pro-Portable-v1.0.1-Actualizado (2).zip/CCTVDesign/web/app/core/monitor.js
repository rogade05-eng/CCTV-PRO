/**
 * CCTV DESIGN PRO — Monitor de cámara: simulación de lo que ve una cámara (§8, §13, §15)
 *
 * Un plano dice dónde se coloca una cámara; un monitor dice lo que se va a ver en la pantalla del
 * grabador. Este módulo calcula **todo lo que hace falta para pintar esa pantalla** y nada más:
 * la vista (ojo, campos y resolución), el recorrido por el que circula alguien y el tamaño que
 * ocupa en píxeles a cada distancia. No toca el DOM: eso lo hace `app/monitor.js`, que además
 * reutiliza el pintor del 3D (`render3d.js`), de modo que lo que se ve en el monitor es la misma
 * escena que se calcula para la cobertura, no una maqueta aparte.
 *
 * Lo que se simula, y por qué:
 *   · el **campo real de la lente** (EN 62676-4): el monitor tiene la proporción del sensor, así que
 *     lo que cabe en la imagen es exactamente lo que cabrá en la cámara instalada;
 *   · el **paso de una persona y de un vehículo** por delante de la cámara, a su velocidad real,
 *     que es lo que permite juzgar si se les ve de verdad y con qué calidad;
 *   · la **densidad de píxeles** (px/m) a la distancia a la que están, que es el número que decide
 *     si sirve para detectar, observar, reconocer o identificar (§15).
 */
import { fieldOfView, footprint, pixelDensity, objectiveLabel } from './dori.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { camaraDesdeVigilancia, proyectar, baseDe, ojoDe, caraVisible } from './view3d.js?v=b441e3fc';
import { personaDe, cocheDe, ALTURA_PERSONA } from './obstacles.js?v=b441e3fc';
import { rad, centroid, pointInPoly, clamp } from './geometry.js?v=b441e3fc';
import { OBJECTIVES } from './project.js?v=b441e3fc';
import { mascarasPara } from './privacy.js?v=b441e3fc';

/** Ajustes del monitor. Se guardan en el estado de la interfaz, no en el proyecto (§8). */
export const OPCIONES_MONITOR = {
  camara: '',            // id de la cámara; vacío = la seleccionada, y si no hay, la primera
  fps: 15,               // fotogramas por segundo del monitor (no de la cámara)
  actores: 'ambos',      // ninguno · persona · vehiculo · ambos
  osd: true,             // rótulos sobre la imagen (nombre, reloj, REC, óptica, px/m)
  efecto: true,          // ruido, líneas de barrido y viñeteado: el «aire» de vídeo
  ir: false,             // visión nocturna por infrarrojos: imagen en blanco y negro
  distorsion: true,      // distorsión óptica de lente (barril en gran angular)
  vivo: true,            // en marcha o en pausa
  completo: false,       // pantalla completa
};

/** Velocidad con la que circula cada actor, en m/s (§15: 1,4 m/s un peatón, 30 km/h un coche). */
export const VELOCIDAD = { persona: 1.4, vehiculo: 8.3 };

/** Tamaño de cada actor, en metros: el de una persona y el de un turismo. */
export const MEDIDAS = {
  persona: { largo: 0.6, ancho: 0.6, alto: ALTURA_PERSONA },
  vehiculo: { largo: 4.5, ancho: 1.8, alto: 1.5 } };

/** Etiquetas del OSD. */
export const ETIQUETA_ACTOR = { persona: 'Persona a', vehiculo: 'Vehículo a' };

export function opcionesMonitor(o = {}) {
  return {
    camara: o.camara || '',
    fps: Number(o.fps) > 0 ? Math.min(30, Number(o.fps)) : OPCIONES_MONITOR.fps,
    actores: ['ninguno', 'persona', 'vehiculo', 'ambos'].includes(o.actores) ? o.actores : 'ambos',
    osd: o.osd !== false,
    efecto: o.efecto !== false,
    ir: !!o.ir,
    distorsion: o.distorsion !== false,
    mascaras: o.mascaras !== false,
    vivo: o.vivo !== false,
    completo: !!o.completo };
}

const n1 = (v, d = 1) => Number(v || 0).toFixed(d).replace('.', ',');

/**
 * Vista de una cámara: el ojo, los campos de su lente y la resolución con la que se pinta.
 *
 * La proporción del lienzo es la **del sensor** (no la de la ventana): el pintor usa el campo
 * vertical para los dos ejes, así que solo con esa proporción el campo horizontal de la imagen
 * coincide con el real de la lente. Si no, la imagen estaría estirada y engañaría.
 */
export function vistaDe(cam, catalog, rules = {}) {
  const data = (cam && cam.data) || {};
  const item = getItem(catalog, data.catalogId);
  const s = (item && item.specs) || {};
  const focal = Number(data.focal) || Number(s.lens) || 4;
  const fov = fieldOfView(item, focal);
  let fp = null;
  try { fp = footprint(cam, catalog, rules || {}, {}); } catch { fp = null; }
  const p = (cam.points && cam.points[0]) || { x: 0, y: 0 };
  return {
    id: cam.id,
    item,
    nombre: data.name || data.nombre || 'Cámara',
    etiqueta: data.label || data.etiqueta || (item && item.model) || 'CAM',
    modelo: (item && (item.model || item.name)) || '',
    marca: (item && item.manufacturer) || '',
    focal,
    resW: Number(s.resW) || 1920,
    resH: Number(s.resH) || 1080,
    streamFps: Number(data.fps) || Number(s.fps) || 25,
    hfov: fov.hfov,
    vfov: fov.vfov,
    aspecto: fov.sensorW > 0 && fov.sensorH > 0 ? fov.sensorW / fov.sensorH : 16 / 9,
    altura: Number(data.height) || 2.8,
    azimut: Number(data.azimuth) || 0,
    inclinacion: Number(data.tilt) || 0,
    objetivo: data.objective || 'OBSERVACION',
    cerca: fp ? fp.near : 0,
    lejos: fp ? fp.far : 0,
    huella: (fp && fp.polygon) || [],
    posicion: { x: p.x, y: p.y, z: Number(data.height) || 2.8 },
    // Distorsión óptica de barril calculada por la focal de la lente
    distorsion: focal <= 2.8 ? 0.085 : (focal <= 3.6 ? 0.055 : (focal <= 4.0 ? 0.035 : (focal <= 6.0 ? 0.015 : 0))),
    // Cámara orbital equivalente: el ojo en la cámara mirando con su azimut, su inclinación y el
    // campo vertical de su lente. Es la misma que usa la vista 3D «desde la cámara» (§8).
    cam3d: camaraDesdeVigilancia(cam, catalog, rules || {}, 12) };
}

/**
 * Recorrido por el que circulan los actores: una recta **de través a la mira** que pasa por el
 * centro de lo que la cámara ve y se recorta a la huella, así que quien pasa por ahí entra y sale
 * del encuadre como pasaría en la realidad.
 *
 * `huella` permite pasar la huella ya recortada por las sombras de los obstáculos (§13), que es la
 * que tiene el proyecto calculada: si la cámara no ve ese trozo, por ahí no circula nadie.
 */
export function recorridoDe(cam, catalog, rules = {}, huella = null) {
  const pol = (huella && huella.length >= 3) ? huella
    : ((vistaHuella(cam, catalog, rules) || []));
  if (!pol || pol.length < 3) return null;
  const c = centroid(pol);
  const az = Number(((cam && cam.data) || {}).azimuth) || 0;
  const adelante = { x: Math.cos(rad(az)), y: Math.sin(rad(az)) };
  const traves = { x: -adelante.y, y: adelante.x };
  let R = 0;
  for (const q of pol) R = Math.max(R, Math.hypot(q.x - c.x, q.y - c.y));
  R = Math.max(1, R) * 1.05;
  // Se barre la recta y se guarda el tramo que cae dentro de la huella: es más robusto que cortar
  // el polígono con la recta (que puede salir por un vértice y dejar un tramo de un solo punto)
  const paso = 0.2;
  let s0 = null, s1 = null;
  for (let s = -R; s <= R + 1e-9; s += paso) {
    const p = { x: c.x + traves.x * s, y: c.y + traves.y * s };
    if (pointInPoly(p, pol)) { if (s0 === null) s0 = s; s1 = s; }
  }
  if (s0 === null) return null;
  const margen = Math.min(0.4, Math.max(0, (s1 - s0) * 0.08));   // ni pegado al borde ni fuera
  s0 += margen; s1 -= margen;
  if (s1 - s0 < 0.6) { s0 = (s0 + s1) / 2 - 0.3; s1 = s0 + 0.6; }
  return {
    a: { x: c.x + traves.x * s0, y: c.y + traves.y * s0 },
    b: { x: c.x + traves.x * s1, y: c.y + traves.y * s1 },
    largo: s1 - s0, centro: c, traves, adelante, huella: pol };
}

function vistaHuella(cam, catalog, rules) {
  try { const fp = footprint(cam, catalog, rules || {}, {}); return (fp && fp.polygon) || []; }
  catch { return []; }
}

/**
 * Posición de un actor en el instante `t` (segundos). Va y vuelve por el recorrido a su velocidad,
 * y se orienta en el sentido en el que marcha, que es lo que hace que un coche se reconozca.
 */
export function actorEn(recorrido, tipo, t, opciones = {}) {
  if (!recorrido) return null;
  const v = VELOCIDAD[tipo] || VELOCIDAD.persona;
  const L = Math.max(0.5, recorrido.largo);
  const ciclo = (2 * L) / v;                       // ida y vuelta completas
  const desp = Number(opciones.desfase) || 0;      // desfase dentro del ciclo (0…1)
  let u = ((Number(t) || 0) / ciclo + desp) % 1;
  if (u < 0) u += 1;
  const sentido = u < 0.5 ? 1 : -1;
  const s = (u < 0.5 ? u * 2 : 2 - u * 2) * L;     // triángulo: 0 → L → 0
  // El carril separa al actor de la línea central, en la dirección de la mira. Si con ese
  // desplazamiento se sale de lo que ve la cámara, se pega a la línea: mejor verlo mal que no verlo.
  let carril = Number(opciones.carril) || 0;
  if (carril) {
    const prueba = (k) => {
      const p = { x: recorrido.a.x + recorrido.traves.x * s + recorrido.adelante.x * k,
        y: recorrido.a.y + recorrido.traves.y * s + recorrido.adelante.y * k };
      return pointInPoly(p, recorrido.huella);
    };
    if (!prueba(carril) && !prueba(carril / 2)) carril = 0;
    else if (!prueba(carril)) carril = carril / 2;
  }
  const x = recorrido.a.x + recorrido.traves.x * s + recorrido.adelante.x * carril;
  const y = recorrido.a.y + recorrido.traves.y * s + recorrido.adelante.y * carril;
  return {
    x, y, z: 0, tipo, velocidad: v, sentido, u,
    angulo: Math.atan2(recorrido.traves.y * sentido, recorrido.traves.x * sentido),
    recorrido: s };
}

/** Parejas de actores que circulan a la vez: una persona por el centro y un coche en su carril. */
export function repartoDe(modo = 'ambos') {
  const p = [];
  if (modo === 'persona' || modo === 'ambos') p.push({ tipo: 'persona', desfase: 0, carril: 0 });
  if (modo === 'vehiculo' || modo === 'ambos') p.push({ tipo: 'vehiculo', desfase: 0.35, carril: -2.4 });
  return p;
}

/**
 * Actores en el instante `t`, con sus volúmenes ya girados para pintarlos con la escena.
 * Cada uno trae su centro y su altura, que es lo que se usa para medir la densidad de píxeles.
 */
export function actoresEn(recorrido, t, opciones = {}) {
  if (!recorrido) return [];
  const modo = opciones.actores || 'ambos';
  if (modo === 'ninguno') return [];
  const out = [];
  for (const papel of repartoDe(modo)) {
    const actor = actorEn(recorrido, papel.tipo, t, papel);
    if (!actor) continue;
    const medidas = MEDIDAS[papel.tipo] || MEDIDAS.persona;
    const color = papel.tipo === 'vehiculo'
      ? (opciones.colorVehiculo || '#3f6ea8')
      : (opciones.colorPersona || '#5a6b7d');
    const volumenes = volumenesDeActor(actor, papel.tipo, color);
    out.push({ tipo: papel.tipo, actor, medidas, volumenes,
      alto: medidas.alto, centro: { x: actor.x, y: actor.y, z: medidas.alto / 2 } });
  }
  return out;
}

/** Volúmenes de un actor: una persona de 1,75 m o un turismo de 4,5 × 1,8 × 1,5 m. */
export function volumenesDeActor(actor, tipo, color = null) {
  if (tipo === 'vehiculo') {
    const m = MEDIDAS.vehiculo;
    const vol = cocheDe(actor.x - m.largo / 2, actor.y - m.ancho / 2,
      actor.x + m.largo / 2, actor.y + m.ancho / 2, 0.02, m.alto, color || '#3f6ea8', 1);
    // `cocheDe` construye el coche a lo largo de +X (el morro en un extremo), así que basta con
    // girarlo el ángulo de la marcha para que apunte hacia donde va.
    return girarVolumenes(vol, actor.angulo, actor);
  }
  const vol = personaDe(actor, ALTURA_PERSONA, 0, color || '#5a6b7d', 0.3);
  // En `personaDe` las piernas van separadas en X: la persona «mira» hacia ±Y. Se le suma un cuarto
  // de vuelta para que camine de frente, no de lado.
  return girarVolumenes(vol, actor.angulo + Math.PI / 2, actor);
}

/** Gira una lista de volúmenes alrededor del eje Z, sobre un centro dado. */
export function girarVolumenes(vols, angulo, centro) {
  if (!angulo) return vols || [];
  const c = Math.cos(angulo), s = Math.sin(angulo);
  const g = (p) => {
    const dx = p.x - centro.x, dy = p.y - centro.y;
    return { x: centro.x + dx * c - dy * s, y: centro.y + dx * s + dy * c, z: p.z };
  };
  return (vols || []).map((v) => ({
    ...v, caras: (v.caras || []).map((f) => ({ ...f, puntos: (f.puntos || []).map(g) })) }));
}

/**
 * Objetivo más exigente que se cumple con esa densidad, **para lo que se está mirando**: a una
 * persona se la detecta, observa, reconoce o identifica; la lectura de matrícula solo cuenta
 * cuando lo que pasa por delante es un vehículo (§15, EN 62676-4).
 */
export function objetivoDe(ppm, tipo = 'persona') {
  const orden = tipo === 'vehiculo'
    ? ['IDENTIFICACION', 'MATRICULA', 'RECONOCIMIENTO', 'OBSERVACION', 'DETECCION']
    : ['IDENTIFICACION', 'RECONOCIMIENTO', 'OBSERVACION', 'DETECCION'];
  for (const k of orden) if (ppm >= (OBJECTIVES[k] ? OBJECTIVES[k].ppm : Infinity)) return k;
  return null;
}

/**
 * Densidad de píxeles y objetivo alcanzado a una distancia (§15, EN 62676-4): cuántos píxeles
 * mide un metro a esa distancia y cuántos mide de alto quien pasa por delante.
 */
export function densidadDe(item, distancia, focal, alto = ALTURA_PERSONA, tipo = 'persona') {
  const d = Math.max(0.1, Number(distancia) || 0.1);
  const ppm = pixelDensity(item, d, focal);
  const clave = objetivoDe(ppm, tipo);
  const h = Number(alto) || ALTURA_PERSONA;
  return {
    ppm, altoPx: ppm * h, alto: h, distancia: d, tipo,
    objetivo: clave, etiqueta: objectiveLabel(clave) || '—' };
}

/** Distancia desde la cámara al actor, medida en el suelo (que es como se mide en obra). */
export function distanciaA(vista, punto) {
  return Math.hypot(punto.x - vista.posicion.x, punto.y - vista.posicion.y);
}

/** Reloj del OSD: `dd/mm/aaaa HH:MM:SS`, como el de un grabador. */
export function relojDe(fecha = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${p(fecha.getDate())}/${p(fecha.getMonth() + 1)}/${fecha.getFullYear()} `
    + `${p(fecha.getHours())}:${p(fecha.getMinutes())}:${p(fecha.getSeconds())}`;
}

/**
 * Rótulos que se pintan sobre la imagen. Los de abajo son los que valen para diseñar: la óptica
 * con la que se mira y la calidad con la que se ve a quien pasa por delante.
 */
export function osdDe(vista, estado = {}, fecha = new Date()) {
  const g = (n) => `${Math.round(Number(n) || 0)}°`;
  const izq = `${vista.resW}×${vista.resH} · ${Number(vista.streamFps) || 25} fps · ${n1(vista.focal)} mm`
    + ` · H ${g(vista.hfov)} V ${g(vista.vfov)}`;
  const der = estado.densidad
    ? `${ETIQUETA_ACTOR[estado.tipoActor] || 'Objetivo a'} ${n1(estado.distancia)} m`
      + ` · ${Math.round(estado.densidad.ppm)} px/m · ${estado.densidad.etiqueta}`
    : `Alcance ${n1(vista.cerca)}–${n1(vista.lejos)} m`;
  return {
    nombre: `${vista.etiqueta} · ${vista.nombre}`,
    reloj: relojDe(fecha),
    rec: !!estado.vivo,
    izq, der,
    // El punto de grabación parpadea dos veces por segundo, como en un grabador de verdad
    punto: (Math.floor((Number(estado.t) || 0) * 2) % 2) === 0 };
}

/**
 * Caja en pantalla de un actor: el rectángulo que ocupa su volumen proyectado. Es la «caja de
 * detección» que pintan las analíticas y, de paso, la forma más clara de ver cuánto ocupa.
 */
export function cajaEnPantalla(volumenes, cam3d, w, h) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, vistos = 0;
  for (const v of volumenes || []) {
    for (const cara of v.caras || []) {
      for (const p of cara.puntos || []) {
        const q = proyectar(p, cam3d, w, h);
        if (q.detras) continue;
        vistos++;
        if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x;
        if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
      }
    }
  }
  if (!vistos || !isFinite(x0)) return null;
  return { x0: clamp(x0, 0, w), y0: clamp(y0, 0, h), x1: clamp(x1, 0, w), y1: clamp(y1, 0, h) };
}

/**
 * Inventario de lo que hay en el proyecto y se ve —o no— desde la cámara: las personas y los
 * vehículos **dibujados en el plano**, con la distancia a la que están y, si no salen en la imagen,
 * por qué. Es la respuesta a la pregunta de siempre: «he puesto dos personas ahí y no las veo».
 */
export function inventarioDe(volumenes, vista, cam3d, w, h) {
  const grupos = new Map();
  for (const v of volumenes || []) {
    if (!v.id || (v.kind !== 'persona' && v.kind !== 'vehiculo')) continue;
    if (!grupos.has(v.id)) grupos.set(v.id, { id: v.id, tipo: v.kind, volumenes: [] });
    grupos.get(v.id).volumenes.push(v);
  }
  const out = [];
  for (const g of grupos.values()) {
    const caja = cajaEnPantalla(g.volumenes, cam3d, w, h);
    let cx = 0, cy = 0, n = 0;
    for (const v of g.volumenes) for (const c of v.caras) for (const p of c.puntos || []) { cx += p.x; cy += p.y; n++; }
    const centro = n ? { x: cx / n, y: cy / n } : { x: 0, y: 0 };
    const distancia = distanciaA(vista, centro);
    const visible = visibleEn(caja, w, h);
    // El motivo vale para saber qué hay que tocar: si está detrás, hay que girar la cámara; si se
    // sale por un lado, con girar un poco basta; y si está más allá de su alcance, por mucho que
    // se gire no se va a ver con la calidad que pide el objetivo. Se dicen las dos cosas si se
    // dan las dos, porque cada una lleva a una solución distinta.
    let motivo = 'a la vista';
    if (!visible) {
      if (!caja) motivo = 'detrás de la cámara';
      else {
        motivo = 'fuera del encuadre';
        if (distancia > (vista.lejos || 0) + 0.5) motivo += ` y más allá de su alcance (llega a ${n1(vista.lejos)} m)`;
      }
    }
    const densidad = densidadDe(vista.item, distancia, vista.focal,
      (MEDIDAS[g.tipo] && MEDIDAS[g.tipo].alto) || ALTURA_PERSONA, g.tipo);
    out.push({ id: g.id, tipo: g.tipo, distancia, centro, caja, visible, motivo, densidad });
  }
  return out.sort((a, b) => a.distancia - b.distancia);
}

/** Resumen del inventario: cuántos se ven y cuántos no, con el motivo. */
export function resumenDeInventario(lista) {
  const vistos = lista.filter((d) => d.visible);
  const fuera = lista.filter((d) => !d.visible);
  const personas = vistos.filter((d) => d.tipo === 'persona').length;
  const vehiculos = vistos.filter((d) => d.tipo === 'vehiculo').length;
  return {
    vistos, fuera, personas, vehiculos,
    texto: lista.length
      ? `${personas} persona(s) y ${vehiculos} vehículo(s) a la vista`
        + (fuera.length ? ` · ${fuera.length} fuera: ${fuera.map((d) => `${d.motivo} (${n1(d.distancia)} m)`).join(', ')}` : '')
      : 'ninguna persona ni vehículo dibujado en el proyecto' };
}

/** ¿Está el actor dentro del encuadre? Con que asome una parte, ya cuenta como detectado. */
export function visibleEn(caja, w, h, minimo = 4) {
  if (!caja) return false;
  const ancho = caja.x1 - caja.x0, alto = caja.y1 - caja.y0;
  if (ancho < 1 || alto < 1) return false;
  return caja.x1 > minimo && caja.x0 < w - minimo && caja.y1 > minimo && caja.y0 < h - minimo;
}

/* ---------------------------------------------------------------------------
 * Máscaras de privacidad sobre la imagen (§28)
 *
 * Una máscara se dibuja **en el plano**, como un recinto más, y se descuenta de
 * la cobertura. Para verla en el monitor hace falta dar el paso que da el propio
 * equipo: convertir ese recinto en un volumen —un prisma desde el suelo hasta la
 * altura que se quiera ocultar— y pintar de negro todo lo que quede dentro de su
 * silueta. Es lo que hace un instalador cuando configura una cámara y comprueba en
 * la pantalla que el recuadro tapa el portal del vecino.
 *
 * La silueta no es la proyección del polígono del suelo (eso solo taparía el suelo):
 * es la unión de las caras **delanteras** del prisma. Todo rayo que sale del ojo y
 * da con el prisma entra por una cara delantera, así que esa unión es exactamente
 * la mancha que la máscara deja en la imagen, sea el prisma convexo o no. Cada cara
 * se recorta primero con el plano cercano, para no proyectar puntos por detrás del
 * ojo, que es lo que hacía saltar la imagen a la otra esquina de la pantalla.
 * ------------------------------------------------------------------------- */

/** Alto del prisma de una máscara cuando no se dice otra cosa: la altura de la instalación. */
export const ALTO_MASCARA = 2.8;
/** Plano de recorte delante del ojo, en metros: por debajo de esto no se proyecta nada. */
export const PLANO_CERCANO = 0.1;

/** Polígono en sentido antihorario: del sentido del que depende que las normales miren hacia fuera. */
function antihorario(poligono) {
  let a = 0;
  for (let i = 0, n = poligono.length; i < n; i++) {
    const p = poligono[i], q = poligono[(i + 1) % n];
    a += p.x * q.y - q.x * p.y;
  }
  return a >= 0 ? poligono.slice() : poligono.slice().reverse();
}

/**
 * Prisma cerrado de una máscara: el recinto del plano llevado desde el suelo hasta `alto`.
 * Las caras salen orientadas hacia fuera, que es lo que permite quedarse solo con las
 * delanteras (`caraVisible`) para pintar la silueta.
 */
export function prismaDeMascara(poligono, alto = ALTO_MASCARA) {
  const base = antihorario(poligono);
  const h = Math.max(0.2, Number(alto) || ALTO_MASCARA);
  const caras = [{ puntos: base.map((p) => ({ x: p.x, y: p.y, z: h })) }];
  caras.push({ puntos: base.map((p) => ({ x: p.x, y: p.y, z: 0 })).reverse() });
  for (let i = 0, n = base.length; i < n; i++) {
    const a = base[i], b = base[(i + 1) % n];
    caras.push({
      puntos: [
        { x: a.x, y: a.y, z: 0 }, { x: b.x, y: b.y, z: 0 },
        { x: b.x, y: b.y, z: h }, { x: a.x, y: a.y, z: h },
      ] });
  }
  return { caras };
}

/** Recorta un polígono con el plano que pasa a `d` metros por delante del ojo (Sutherland–Hodgman). */
export function recortarPorDelante(puntos, ojo, f, d = PLANO_CERCANO) {
  const p0 = { x: ojo.x + f.x * d, y: ojo.y + f.y * d, z: ojo.z + f.z * d };
  const lado = (p) => (p.x - p0.x) * f.x + (p.y - p0.y) * f.y + (p.z - p0.z) * f.z;
  const out = [];
  for (let i = 0, n = puntos.length; i < n; i++) {
    const a = puntos[i], b = puntos[(i + 1) % n];
    const da = lado(a), db = lado(b);
    if (da >= 0) out.push(a);
    if ((da > 0 && db < 0) || (da < 0 && db > 0)) {
      const t = da / (da - db);
      out.push({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t });
    }
  }
  return out;
}

/**
 * Recorta un polígono de pantalla al rectángulo de la imagen (Sutherland–Hodgman).
 * Hace falta porque una máscara que queda muy de lado respecto a la óptica —al lado de la cámara,
 * como le pasa a una LPR de 17° con la calzada al costado— proyecta vértices a decenas de miles de
 * píxeles: el recuadro no pisa la imagen, pero las coordenadas se disparan y con ellas el área.
 */
export function recortarAlLienzo(poligono, w, h) {
  let p = poligono;
  const lados = [
    { dentro: (q) => q.x >= 0, corte: (a, b) => ({ x: 0, y: a.y + ((b.y - a.y) * (0 - a.x)) / (b.x - a.x) }) },
    { dentro: (q) => q.x <= w, corte: (a, b) => ({ x: w, y: a.y + ((b.y - a.y) * (w - a.x)) / (b.x - a.x) }) },
    { dentro: (q) => q.y >= 0, corte: (a, b) => ({ x: a.x + ((b.x - a.x) * (0 - a.y)) / (b.y - a.y), y: 0 }) },
    { dentro: (q) => q.y <= h, corte: (a, b) => ({ x: a.x + ((b.x - a.x) * (h - a.y)) / (b.y - a.y), y: h }) },
  ];
  for (const lado of lados) {
    if (!p.length) return [];
    const out = [];
    for (let i = 0, n = p.length; i < n; i++) {
      const a = p[i], b = p[(i + 1) % n];
      const da = lado.dentro(a), db = lado.dentro(b);
      if (da) out.push(a);
      if (da !== db) out.push(lado.corte(a, b));
    }
    p = out;
  }
  return p;
}

/** Mancha que el prisma deja en la imagen: la unión de sus caras delanteras, en píxeles. */
export function siluetaDeMascara(prisma, cam3d, w, h) {
  const b = baseDe(cam3d);
  const poligonos = [];
  for (const cara of prisma.caras || []) {
    if (!caraVisible(cara, b.ojo)) continue;
    const rec = recortarPorDelante(cara.puntos, b.ojo, b.f, PLANO_CERCANO);
    if (rec.length < 3) continue;
    const poli = recortarAlLienzo(rec.map((p) => {
      const q = proyectar(p, cam3d, w, h);
      return { x: q.x, y: q.y };
    }), w, h);
    if (poli.length >= 3) poligonos.push(poli);
  }
  return poligonos;
}

const areaPoligonoPx = (p) => {
  let s = 0;
  for (let i = 0, n = p.length; i < n; i++) {
    const a = p[i], b = p[(i + 1) % n];
    s += a.x * b.y - b.x * a.y;
  }
  return Math.abs(s) / 2;
};

/**
 * Máscaras que le tocan a una cámara, ya proyectadas sobre su imagen.
 * @param {object} prj proyecto
 * @param {string} camId cámara que se está mirando
 * @param {object} cam3d cámara virtual del monitor (`vista.cam3d`)
 * @param {number} w ancho del lienzo, en píxeles
 * @param {number} h alto del lienzo, en píxeles
 * @param {number} alto altura del prisma cuando la máscara no dice la suya
 * @returns {Array} una entrada por máscara, con su silueta en píxeles y su superficie
 */
export function mascarasEnPantalla(prj, camId, cam3d, w, h, alto = ALTO_MASCARA) {
  const mas = mascarasPara(prj, camId);
  if (!mas.length) return [];
  const ojo = ojoDe(cam3d);
  const out = [];
  for (const m of mas) {
    // Ojo con el nombre: `h` es el alto del lienzo en píxeles, así que el alto del prisma va aparte
    const altoMascara = Number(m.altura) > 0 ? Number(m.altura) : alto;
    const prisma = prismaDeMascara(m.poly, altoMascara);
    // Si la máscara envuelve a la propia cámara, la imagen entera queda oculta: es lo que
    // pasaría en obra si el recuadro se dibujara encima de donde está montado el equipo.
    const cubreTodo = !!m.poly && pointInPoly({ x: ojo.x, y: ojo.y }, m.poly) && ojo.z <= altoMascara;
    const poligonos = cubreTodo ? [] : siluetaDeMascara(prisma, cam3d, w, h);
    let areaPx = 0, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const p of poligonos) {
      areaPx += areaPoligonoPx(p);
      for (const q of p) {
        if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x;
        if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
      }
    }
    out.push({
      id: m.id, tipo: m.tipo || 'opaca', motivo: m.motivo || '', camara: m.camara || '',
      alto: altoMascara, cubreTodo, poligonos, areaPx,
      // Dentro del encuadre: que la silueta pise algo de imagen, no que quede fuera de plano
      enCuadre: cubreTodo || (areaPx > 4 && x1 > 0 && x0 < w && y1 > 0 && y0 < h),
      caja: isFinite(x0) ? { x0: clamp(x0, 0, w), y0: clamp(y0, 0, h), x1: clamp(x1, 0, w), y1: clamp(y1, 0, h) } : null });
  }
  return out;
}

/** ¿Este punto de la imagen queda dentro de alguna máscara? Devuelve la primera que lo tapa. */
export function puntoEnMascaras(mascaras, x, y) {
  for (const m of mascaras || []) {
    if (m.cubreTodo) return m;
    for (const p of m.poligonos || []) if (pointInPoly({ x, y }, p)) return m;
  }
  return null;
}
