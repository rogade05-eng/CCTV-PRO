/**
 * CCTV DESIGN PRO — Privacidad y cumplimiento normativo (RGPD, LOPDGDD, AI Act)
 * core/privacy.js — módulo puro: sin DOM, sin dependencias, ejecutable en Node.
 *
 * Por qué existe: un proyecto de videovigilancia no se cierra con el último cable. Captar imágenes
 * de personas es tratar datos personales, y en España eso obliga a acreditar proporcionalidad,
 * información (cartelería), un plazo de conservación y un registro de actividades; si además el
 * sistema lleva analítica con biometría, entra en juego el Reglamento de IA de la UE.
 *
 * Este módulo no da asesoramiento jurídico: **traduce el diseño a obligaciones comprobables**.
 * Lo que se puede medir sobre el plano (qué ve cada cámara y cuánto) se mide; lo que depende de
 * decisiones del responsable (finalidad, carteles, accesos) se deja declarado y se documenta.
 *
 * Referencias tenidas en cuenta (consultadas en 2026):
 *   · AEPD, «Guía sobre videovigilancia» (2025): deber de información con cartelería, conservación
 *     máxima de 30 días, registro de actividades y prohibición de captar la vía pública salvo la
 *     franja mínima imprescindible, preferiblemente con máscaras de privacidad.
 *   · LOPDGDD art. 22 y RGPD: base jurídica, proporcionalidad y minimización de datos.
 *   · Reglamento (UE) 2024/1689 (AI Act): prácticas prohibidas en vigor desde el 2 de febrero de
 *     2025 —reconocimiento de emociones en el trabajo y en centros educativos (art. 5.1.f) y
 *     creación de bases de datos de rostros mediante captación indiscriminada desde internet o
 *     desde cámaras (art. 5.1.e)—; obligaciones de transparencia del art. 50 desde el 2 de agosto
 *     de 2026 y sistemas de alto riesgo del anexo III desde el 2 de diciembre de 2027, según el
 *     calendario revisado por el Reglamento (UE) 2026/1744 («Digital Omnibus»).
 */
import { bbox, bboxOf, pointInPoly, polyArea } from './geometry.js?v=b441e3fc';
import { footprintsOf } from './ptz.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { segmentosOpacos, IndiceOpacos, ALTURA_MURO, ALTURA_OBJETIVO } from './obstacles.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

/* ---------------------------------------------------------------------------
 * Zonas y máscaras: geometría sobre el plano, no una nota al margen.
 *   · Zona de privacidad (`pzona`): recinto con un régimen jurídico distinto
 *     (vía pública, propiedad de un tercero, zona sensible…).
 *   · Máscara (`mascara`): recuadro que la cámara **no** registra. Se dibuja
 *     sobre el plano y se descuenta de la cobertura real (§13).
 * ------------------------------------------------------------------------- */

export const CLASES_ZONA = {
  PUBLICA: {
    id: 'PUBLICA', etiqueta: 'Vía pública', color: '#e11d48',
    nota: 'Solo se puede captar la franja mínima imprescindible del acceso.',
  },
  TERCEROS: {
    id: 'TERCEROS', etiqueta: 'Propiedad de terceros', color: '#f59e0b',
    nota: 'Portales, fincas vecinas o locales ajenos: exige máscara o reorientación.',
  },
  SENSIBLE: {
    id: 'SENSIBLE', etiqueta: 'Zona de intimidad', color: '#9333ea',
    nota: 'Vestuarios, baños, zonas de descanso o comedores: no se pueden captar.',
  },
  PROPIA: {
    id: 'PROPIA', etiqueta: 'Zona propia vigilada', color: '#0ea5e9',
    nota: 'Recinto de la instalación: es la finalidad legítima del sistema.',
  },
};

export const CLASES_LISTA = Object.values(CLASES_ZONA);
export const etiquetaClase = (c) => (CLASES_ZONA[c] ? CLASES_ZONA[c].etiqueta : c || '—');

/** Zonas de privacidad declaradas en el proyecto. */
export function zonasDe(prj) {
  return (prj.entities || [])
    .filter((e) => e.type === 'pzona' && e.points && e.points.length >= 3)
    .map((e) => ({
      id: e.id,
      nombre: (e.data && e.data.nombre) || 'Zona',
      clase: CLASES_ZONA[(e.data && e.data.clase)] ? e.data.clase : 'PROPIA',
      notas: (e.data && e.data.notas) || '',
      poly: e.points,
      area: Math.abs(polyArea(e.points)),
    }));
}

/** Máscaras de privacidad declaradas (las de `camara` vacía valen para todas). */
export function mascarasDe(prj) {
  return (prj.entities || [])
    .filter((e) => e.type === 'mascara' && e.points && e.points.length >= 3)
    .map((e) => ({
      id: e.id,
      camara: (e.data && e.data.camara) || '',
      motivo: (e.data && e.data.motivo) || '',
      tipo: (e.data && e.data.tipo) || 'opaca',
      // Alto del volumen que tapa. Si no se dice, se usa la altura de la instalación: es lo que
      // se ve en el monitor, donde la máscara se pinta como el recuadro negro del equipo.
      altura: Number(e.data && e.data.altura) > 0 ? Number(e.data.altura) : 0,
      poly: e.points,
      area: Math.abs(polyArea(e.points)),
    }));
}

/** Máscaras que afectan a una cámara concreta (las suyas y las generales). */
export const mascarasPara = (prj, camId) =>
  mascarasDe(prj).filter((m) => !m.camara || m.camara === camId);

/**
 * Enmascarador de una cámara: función rápida «¿este punto queda oculto?».
 * Compara primero la caja envolvente de cada máscara para no pagar el coste del
 * polígono en cada celda del raster de cobertura.
 */
export function enmascarador(prj, camId) {
  const mas = mascarasPara(prj, camId);
  if (!mas.length) return null;
  const cajas = mas.map((m) => ({ b: bbox(m.poly), p: m.poly }));
  return (x, y) => {
    for (const c of cajas) {
      if (x < c.b.minX || x > c.b.maxX || y < c.b.minY || y > c.b.maxY) continue;
      if (pointInPoly({ x, y }, c.p)) return true;
    }
    return false;
  };
}

/** Proveedor de enmascaradores para el análisis de cobertura: uno por cámara, bajo demanda. */
export function crearEnmascarador(prj) {
  if (!mascarasDe(prj).length) return () => null;
  const cache = new Map();
  return (camId) => {
    if (!cache.has(camId)) cache.set(camId, enmascarador(prj, camId));
    return cache.get(camId);
  };
}

/* ---------------------------------------------------------------------------
 * Análisis: cuánto ve cada cámara de cada zona, con obstáculos y máscaras.
 * ------------------------------------------------------------------------- */

const cajaComun = (a, b) => {
  if (!a || !b) return null;
  const c = {
    minX: Math.max(a.minX, b.minX), minY: Math.max(a.minY, b.minY),
    maxX: Math.min(a.maxX, b.maxX), maxY: Math.min(a.maxY, b.maxY),
  };
  return c.minX <= c.maxX && c.minY <= c.maxY ? c : null;
};

/**
 * Mide, por raster, el solape de las huellas de cada cámara con cada zona de privacidad.
 * Tiene en cuenta lo mismo que el análisis de cobertura: la oclusión de los obstáculos a la
 * altura del objetivo (§13) y las máscaras que el proyectista haya dibujado.
 */
export function analisisPrivacidad(prj, catalog, rules, res = {}) {
  const zonas = zonasDe(prj);
  const mascaras = mascarasDe(prj);
  const cams = (prj.entities || []).filter((e) => e.type === 'camera');
  const celda = Math.min(2, Math.max(0.1, ruleNum(rules, 'CELDA_PRIVACIDAD') || 0.5));
  const areaCelda = celda * celda;
  const vacio = { vacio: true, celda, zonas: [], porCamara: [], mascaras,
    resumen: { areaPublica: 0, areaTerceros: 0, areaSensible: 0, areaPropia: 0, areaEnmascarada: 0,
      areaVista: 0, camarasAfectadas: 0, zonasAfectadas: 0, mascaras: mascaras.length } };

  if (!zonas.length && !mascaras.length) return vacio;

  const alturaMuro = (prj.settings && prj.settings.alturaMuro) || ALTURA_MURO;
  const hObj = Math.max(0.05, ruleNum(rules, 'ALTURA_OBJETIVO') || ALTURA_OBJETIVO);
  const idx = new IndiceOpacos(segmentosOpacos(prj, alturaMuro), 4);

  const zonasCalc = zonas.map((z) => Object.assign({}, z, {
    areaVista: 0, areaEnmascarada: 0, areaTotalVista: 0, camaras: new Set(), pct: 0, pctMascarada: 0,
  }));
  const porCamara = [];

  for (const cam of cams) {
    const item = getItem(catalog, cam.data.catalogId);
    const fps = footprintsOf(cam, catalog, rules);
    const hCam = Number(cam.data.height) || alturaMuro;
    const oculto = enmascarador(prj, cam.id);

    let cajaCam = null;
    for (const fp of fps) cajaCam = cajaCam ? bboxOf(cajaCam, bbox(fp.polygon)) : bbox(fp.polygon);

    const filas = [];
    let areaEnmascarada = 0;

    // 1 · Cuánto ve la cámara de cada zona (y cuánto de eso queda tapado por una máscara)
    for (const z of zonasCalc) {
      const c = cajaComun(cajaCam, bbox(z.poly));
      if (!c) continue;
      let vistas = 0, tapadas = 0;
      const nx = Math.max(1, Math.ceil((c.maxX - c.minX) / celda));
      const ny = Math.max(1, Math.ceil((c.maxY - c.minY) / celda));
      for (let iy = 0; iy < ny; iy++) {
        const y = c.minY + (iy + 0.5) * celda;
        for (let ix = 0; ix < nx; ix++) {
          const x = c.minX + (ix + 0.5) * celda;
          const p = { x, y };
          if (!pointInPoly(p, z.poly)) continue;
          let hit = -1;
          for (let j = 0; j < fps.length; j++) if (pointInPoly(p, fps[j].polygon)) { hit = j; break; }
          if (hit < 0) continue;
          // Primero se comprueba si la cámara vería esa celda: una máscara sobre algo que la
          // cámara ya no ve no le resta nada a nadie y no debe inflar la cifra
          if (idx.tapado(fps[hit].origin, p, hCam, hObj)) continue;
          if (oculto && oculto(x, y)) { tapadas++; continue; }
          vistas++;
        }
      }
      const a = vistas * areaCelda, t = tapadas * areaCelda;
      z.areaVista += a; z.areaEnmascarada += t;
      if (a > 0) z.camaras.add(cam.id);
      if (a > 0 || t > 0) filas.push({ zona: z.nombre, clase: z.clase, area: a, areaEnmascarada: t });
    }

    // 2 · Cuánto le tapa la cámara a sí misma con sus máscaras (dentro o fuera de zona)
    for (const m of mascarasPara(prj, cam.id)) {
      const c = cajaComun(cajaCam, bbox(m.poly));
      if (!c) continue;
      let n = 0;
      const nx = Math.max(1, Math.ceil((c.maxX - c.minX) / celda));
      const ny = Math.max(1, Math.ceil((c.maxY - c.minY) / celda));
      for (let iy = 0; iy < ny; iy++) {
        const y = c.minY + (iy + 0.5) * celda;
        for (let ix = 0; ix < nx; ix++) {
          const x = c.minX + (ix + 0.5) * celda;
          const p = { x, y };
          if (!pointInPoly(p, m.poly)) continue;
          let hit = -1;
          for (let j = 0; j < fps.length; j++) if (pointInPoly(p, fps[j].polygon)) { hit = j; break; }
          if (hit < 0) continue;
          if (idx.tapado(fps[hit].origin, p, hCam, hObj)) continue;
          n++;
        }
      }
      areaEnmascarada += n * areaCelda;
    }

    const area = (clase) => filas.filter((f) => f.clase === clase).reduce((a, f) => a + f.area, 0);
    porCamara.push({
      id: cam.id,
      etiqueta: cam.data.label || cam.id,
      modelo: item ? item.model : '—',
      areaPublica: area('PUBLICA'),
      areaTerceros: area('TERCEROS'),
      areaSensible: area('SENSIBLE'),
      areaPropia: area('PROPIA'),
      areaEnmascarada,
      mascaras: mascarasPara(prj, cam.id).length,
      zonas: filas,
      // Una cámara «afectada» es la que ve algo que no debería verse sin más trámite
      afectada: filas.some((f) => (f.clase === 'PUBLICA' || f.clase === 'TERCEROS' || f.clase === 'SENSIBLE') && f.area > 0),
    });
  }

  for (const z of zonasCalc) {
    z.pct = z.area ? (z.areaVista / z.area) * 100 : 0;
    z.pctMascarada = z.areaVista + z.areaEnmascarada > 0
      ? (z.areaEnmascarada / (z.areaVista + z.areaEnmascarada)) * 100 : 0;
  }

  const suma = (clase) => zonasCalc.filter((z) => z.clase === clase)
    .reduce((a, z) => a + z.areaVista, 0);

  return {
    vacio: false, celda, mascaras,
    zonas: zonasCalc.map((z) => Object.assign({}, z, { camaras: [...z.camaras] })),
    porCamara,
    resumen: {
      areaPublica: suma('PUBLICA'),
      areaTerceros: suma('TERCEROS'),
      areaSensible: suma('SENSIBLE'),
      areaPropia: suma('PROPIA'),
      areaEnmascarada: porCamara.reduce((a, c) => a + c.areaEnmascarada, 0),
      areaVista: zonasCalc.reduce((a, z) => a + z.areaVista, 0),
      camarasAfectadas: porCamara.filter((c) => c.afectada).length,
      zonasAfectadas: zonasCalc.filter((z) => z.areaVista > 0 &&
        (z.clase === 'PUBLICA' || z.clase === 'TERCEROS' || z.clase === 'SENSIBLE')).length,
      mascaras: mascaras.length,
    },
  };
}

/* ---------------------------------------------------------------------------
 * Clasificación de la analítica según el Reglamento de IA de la UE
 * ------------------------------------------------------------------------- */

export const NIVELES_IA = {
  PROHIBIDO: { id: 'PROHIBIDO', etiqueta: 'Práctica prohibida', color: '#b91c1c', orden: 0 },
  ALTO: { id: 'ALTO', etiqueta: 'Alto riesgo', color: '#ea580c', orden: 1 },
  LIMITADO: { id: 'LIMITADO', etiqueta: 'Riesgo limitado (transparencia)', color: '#ca8a04', orden: 2 },
  MINIMO: { id: 'MINIMO', etiqueta: 'Riesgo mínimo', color: '#0d9488', orden: 3 },
  RGPD: { id: 'RGPD', etiqueta: 'Sin obligación específica de IA', color: '#475569', orden: 4 },
};

export const FUNCIONES_IA = [
  { id: 'emociones', etiqueta: 'Reconocimiento de emociones', ayuda: 'Inferir el estado de ánimo de empleados o alumnos.' },
  { id: 'scraping', etiqueta: 'Base de datos de rostros por captación indiscriminada', ayuda: 'Alimentar una base de caras a partir de las cámaras o de internet.' },
  { id: 'facial', etiqueta: 'Identificación biométrica (rostro)', ayuda: 'Reconocer a una persona concreta por su cara.' },
  { id: 'audio', etiqueta: 'Captación de sonido', ayuda: 'Micrófono en la cámara o en el grabador.' },
];

/** Declaración de funciones sensibles del proyecto (la que rellena el usuario en el panel). */
export function declaracionIA(prj) {
  const p = (prj.settings && prj.settings.privacidad) || {};
  return {
    emociones: !!p.emociones,
    scraping: !!p.scraping,
    facial: !!p.facial,
    facialTiempoReal: !!p.facialTiempoReal,
    facialEspacioPublico: !!p.facialEspacioPublico,
    audio: !!p.audio,
  };
}

/**
 * Clasifica lo que hace el sistema: por un lado las funciones declaradas por el responsable
 * (biometría, emociones, audio) y por otro las que se deducen del diseño (analítica, LPR).
 * Devuelve una fila por función con su nivel, su artículo, la fecha de exigibilidad y qué toca hacer.
 */
export function clasificacionIA(prj, catalog, rules) {
  const d = declaracionIA(prj);
  const filas = [];
  const add = (f) => filas.push(Object.assign({
    nivel: 'MINIMO', articulo: '—', desde: '—', obligaciones: [], detalle: '',
  }, f));

  if (d.emociones) {
    add({
      funcion: 'Reconocimiento de emociones en el trabajo o en centros educativos',
      nivel: 'PROHIBIDO', articulo: 'Art. 5.1.f', desde: 'En vigor desde el 2 de febrero de 2025',
      detalle: 'No puede ponerse en servicio ni utilizarse. No existe vía de conformidad.',
      obligaciones: ['Retirar la función del sistema antes de la puesta en marcha'],
    });
  }
  if (d.scraping) {
    add({
      funcion: 'Creación o ampliación de bases de datos de rostros por captación indiscriminada',
      nivel: 'PROHIBIDO', articulo: 'Art. 5.1.e', desde: 'En vigor desde el 2 de febrero de 2025',
      detalle: 'La captación sin dirigirse a nadie en concreto, desde internet o desde las cámaras, está prohibida.',
      obligaciones: ['No alimentar ninguna base de caras con las imágenes del sistema'],
    });
  }
  if (d.facial) {
    const prohibido = d.facialTiempoReal && d.facialEspacioPublico;
    add({
      funcion: 'Identificación biométrica a distancia' + (d.facialTiempoReal ? ' en tiempo real' : ' diferida'),
      nivel: prohibido ? 'PROHIBIDO' : 'ALTO',
      articulo: prohibido ? 'Art. 5.1.h' : 'Anexo III.1 · arts. 8–21',
      desde: prohibido ? 'En vigor desde el 2 de febrero de 2025'
        : 'Exigible desde el 2 de diciembre de 2027 (calendario revisado por el Reglamento (UE) 2026/1744)',
      detalle: prohibido
        ? 'Identificación biométrica en tiempo real en espacios públicos accesibles: solo cabe en los tres supuestos tasados (víctimas, amenaza inminente o delitos graves) y con autorización.'
        : 'Sistema de alto riesgo: registro, gestión de riesgos, gobernanza de datos, supervisión humana y evaluación de conformidad antes de su puesta en servicio.',
      obligaciones: prohibido
        ? ['Acreditar la autorización y la finalidad tasada', 'Documentar la proporcionalidad del despliegue']
        : ['Inscribir el sistema en la base de datos de la UE antes de usarlo',
          'Implantar gestión de riesgos y supervisión humana efectiva',
          'Conservar los registros automáticos y documentar la evaluación de impacto en derechos fundamentales'],
    });
  }
  if (d.audio) {
    add({
      funcion: 'Captación de sonido',
      nivel: 'RGPD', articulo: 'LOPDGDD art. 22 · RGPD arts. 5 y 6', desde: 'Permanente',
      detalle: 'La voz también es dato personal. Solo se admite cuando la finalidad no se puede lograr con la imagen y con garantías reforzadas.',
      obligaciones: ['Justificar por escrito que la imagen no basta',
        'Informar expresamente de la captación de sonido en los carteles',
        'Desactivar el micrófono donde no sea imprescindible'],
    });
  }

  const cams = (prj.entities || []).filter((e) => e.type === 'camera');
  let reglas = 0;
  const tipos = new Set();
  for (const c of cams) for (const r of ((c.data && c.data.analytics) || [])) { reglas++; tipos.add(r.type || 'intrusion'); }
  if (reglas) {
    add({
      funcion: `Analítica de vídeo automática (${reglas} regla(s): ${[...tipos].join(', ')})`,
      nivel: 'MINIMO', articulo: 'Fuera del anexo III', desde: 'Sin obligación específica del Reglamento de IA',
      detalle: 'La detección de intrusión, cruce de línea, merodeo o conteo no está catalogada como de alto riesgo, pero sigue tratando datos personales.',
      obligaciones: ['Revisar falsos positivos y ajustar la sensibilidad', 'Documentar la finalidad en el registro de actividades'],
    });
  }
  const lpr = cams.filter((c) => c.data && c.data.lprEnabled);
  if (lpr.length) {
    add({
      funcion: `Lectura de matrículas (${lpr.length} cámara(s))`,
      nivel: 'RGPD', articulo: 'RGPD art. 6 · LOPDGDD art. 22', desde: 'Permanente',
      detalle: 'La placa es un dato personal indirecto: identifica al titular del vehículo. No es biometría, así que no entra en el anexo III.',
      obligaciones: ['Limitar la lista de matrículas a la finalidad declarada (acceso, morosidad, seguridad)',
        'Fijar el plazo de borrado de las lecturas', 'No cruzar los datos con otras finalidades sin base jurídica'],
    });
  }
  if (!filas.length) {
    add({
      funcion: 'Sin funciones declaradas',
      nivel: 'MINIMO', articulo: '—', desde: '—',
      detalle: 'El sistema solo capta imágenes con finalidad de seguridad: ninguna función de IA catalogada.',
      obligaciones: [],
    });
  }
  filas.sort((a, b) => (NIVELES_IA[a.nivel].orden - NIVELES_IA[b.nivel].orden));
  return {
    filas,
    nivel: filas.reduce((peor, f) => (NIVELES_IA[f.nivel].orden < NIVELES_IA[peor].orden ? f.nivel : peor), 'MINIMO'),
    cuenta: { PROHIBIDO: 0, ALTO: 0, LIMITADO: 0, MINIMO: 0, RGPD: 0 },
    ...(() => { const c = { PROHIBIDO: 0, ALTO: 0, LIMITADO: 0, MINIMO: 0, RGPD: 0 }; for (const f of filas) c[f.nivel]++; return { cuenta: c }; })(),
  };
}

/* ---------------------------------------------------------------------------
 * Cumplimiento: la lista de comprobaciones que se pueden cerrar con el diseño
 * ------------------------------------------------------------------------- */

export const NIVELES_CUMPLIMIENTO = { ok: 'Correcto', warn: 'Revisar', error: 'Incumplimiento', info: 'Información' };

/**
 * Evalúa el proyecto contra las obligaciones comprobables de protección de datos.
 * Cada fila trae el estado, el detalle medido, lo que obliga la norma y la referencia.
 */
export function evaluarCumplimiento(prj, catalog, rules, res = {}) {
  const an = res.privacidad || analisisPrivacidad(prj, catalog, rules, res);
  const ia = clasificacionIA(prj, catalog, rules);
  const priv = (prj.settings && prj.settings.privacidad) || {};
  const umbral = ruleNum(rules, 'PRIV_UMBRAL_M2');
  const diasMax = ruleNum(rules, 'DIAS_MAXIMO_LEGAL');
  const items = [];
  const add = (o) => items.push(Object.assign({ id: '', titulo: '', estado: 'info', detalle: '', obligacion: '', base: '' }, o));

  const r = an.resumen;
  const terceros = r.areaPublica + r.areaTerceros;

  // 1 · Vía pública y propiedad de terceros
  const publicaMal = terceros > umbral;
  const publicaMask = r.areaEnmascarada > 0;
  add({
    id: 'VIA_PUBLICA',
    titulo: 'Captación de vía pública o de propiedad de terceros',
    estado: publicaMal ? 'error' : terceros > 0 ? 'warn' : 'ok',
    detalle: terceros > 0
      ? `${terceros.toFixed(1)} m² captados (${r.areaPublica.toFixed(1)} m² de vía pública y ${r.areaTerceros.toFixed(1)} m² de terceros) por ${r.camarasAfectadas} cámara(s)`
      : r.areaEnmascarada > 0
        ? `Sin captación ajena: ${r.areaEnmascarada.toFixed(1)} m² quedan ocultos con ${r.mascaras} máscara(s)`
        : 'Ninguna cámara capta vía pública ni propiedad de terceros',
    obligacion: 'Solo cabe captar la franja mínima imprescindible del acceso, preferiblemente con máscara de privacidad sobre el resto.',
    base: 'AEPD, Guía de videovigilancia · RGPD art. 5.1.c',
  });
  if (r.mascaras > 0) {
    add({
      id: 'MASCARA_PUBLICA',
      titulo: 'Máscaras de privacidad sobre lo captado',
      estado: publicaMal ? 'warn' : 'ok',
      detalle: `${r.mascaras} máscara(s) que ocultan ${r.areaEnmascarada.toFixed(1)} m² de lo que las cámaras verían`,
      obligacion: 'Comprobar que la máscara cubre todo lo ajeno y que no deja huecos por donde se vea la vía pública.',
      base: 'AEPD, Guía de videovigilancia · RGPD art. 25 (privacidad desde el diseño)',
    });
  }

  // 2 · Zonas de intimidad
  add({
    id: 'ZONAS_SENSIBLES',
    titulo: 'Captación de zonas de intimidad (vestuarios, baños, descanso)',
    estado: r.areaSensible > 0 ? 'error' : 'ok',
    detalle: r.areaSensible > 0
      ? `${r.areaSensible.toFixed(1)} m² de zonas sensibles dentro del campo de alguna cámara`
      : 'Ninguna cámara alcanza una zona declarada como sensible',
    obligacion: 'No se pueden instalar cámaras en vestuarios, baños, taquillas ni zonas de descanso, ni orientarlas hacia ellas.',
    base: 'AEPD, Guía de videovigilancia · LOPDGDD art. 22',
  });

  // 3 · Plazo de conservación
  const dias = ruleNum(rules, 'DIAS_GRABACION');
  add({
    id: 'CONSERVACION',
    titulo: 'Plazo de conservación de las imágenes',
    estado: dias > diasMax ? 'error' : dias === diasMax ? 'ok' : 'info',
    detalle: `Configurados ${dias} días; el límite general admitido es de ${diasMax} días`,
    obligacion: 'Las imágenes se borran al mes de su captación, salvo que deban conservarse para acreditar un incidente.',
    base: 'AEPD, Guía de videovigilancia · LOPDGDD art. 22.3',
  });

  // 4 · Deber de información y cartelería
  const cart = cartelesRequeridos(prj, an, rules);
  add({
    id: 'CARTELERIA',
    titulo: 'Carteles de zona videovigilada',
    estado: cart.length ? 'info' : 'ok',
    detalle: cart.length
      ? `${cart.length} cartel(es): ${cart.map((c) => c.donde).join(' · ')}`
      : 'No hay zonas que señalizar',
    obligacion: 'Colocar un cartel visible en cada acceso a zona vigilada, con responsable, finalidad y dónde ejercer derechos.',
    base: 'RGPD art. 13 · LOPDGDD art. 22.4 · AEPD',
  });

  // 5 · Registro de actividades
  const rat = registroActividades(prj, an, rules);
  const faltaResponsable = !String(rat.responsable || '').trim();
  add({
    id: 'RAT',
    titulo: 'Registro de actividades de tratamiento',
    estado: faltaResponsable ? 'warn' : 'ok',
    detalle: faltaResponsable
      ? 'Falta el responsable del tratamiento (dato del proyecto)'
      : `Responsable ${rat.responsable} · finalidad ${rat.finalidad} · plazo ${rat.plazo}`,
    obligacion: 'Inscribir el tratamiento en el registro de actividades del responsable, con finalidad, colectivos, plazos y medidas.',
    base: 'RGPD art. 30',
  });

  // 6 · Proporcionalidad y minimización
  add({
    id: 'MINIMIZACION',
    titulo: 'Proporcionalidad del sistema',
    estado: r.areaSensible > 0 || publicaMal ? 'warn' : 'info',
    detalle: `${(prj.entities || []).filter((e) => e.type === 'camera').length} cámara(s) sobre ${an.zonas.filter((z) => z.areaVista > 0 || z.areaEnmascarada > 0).length} zona(s) declarada(s)`,
    obligacion: 'Comprobar que no existe un medio menos invasivo y que el número de cámaras y su alcance se ajustan a la finalidad.',
    base: 'RGPD art. 5.1.c · AEPD, Guía de videovigilancia',
  });

  // 7 · Acceso a las grabaciones
  add({
    id: 'ACCESO',
    titulo: 'Acceso a las grabaciones y trazabilidad',
    estado: 'info',
    detalle: 'Acceso restringido al personal autorizado, con registro de quién visiona o exporta y cuándo',
    obligacion: 'Perfiles nominativos, contraseñas propias, registro de accesos y custodia del equipo de grabación en zona cerrada.',
    base: 'RGPD arts. 5.1.f y 32 · AEPD',
  });

  // 8 · Evaluación de impacto
  const dpiar = r.areaPublica > 0 || r.areaSensible > 0 || ia.nivel === 'ALTO' || ia.nivel === 'PROHIBIDO';
  add({
    id: 'DPIA',
    titulo: 'Evaluación de impacto en protección de datos',
    estado: dpiar ? 'warn' : 'info',
    detalle: dpiar
      ? 'Procede: el sistema vigila espacios públicos, zonas sensibles o incorpora biometría'
      : 'No es preceptiva: vigilancia interior de un recinto privado sin biometría',
    obligacion: 'Cuando hay vigilancia a gran escala de espacios públicos o tratamiento biométrico hay que evaluar el impacto antes de poner el sistema en marcha.',
    base: 'RGPD art. 35',
  });

  // 9 · Reglamento de IA
  if (ia.nivel !== 'MINIMO' || ia.cuenta.PROHIBIDO || ia.cuenta.ALTO) {
    add({
      id: 'AI_ACT',
      titulo: 'Reglamento de IA de la UE: clasificación de las funciones',
      estado: ia.cuenta.PROHIBIDO ? 'error' : ia.cuenta.ALTO ? 'warn' : 'info',
      detalle: ia.filas.map((f) => `${f.funcion}: ${NIVELES_IA[f.nivel].etiqueta}`).join(' · '),
      obligacion: 'Revisar cada función, su fecha de exigibilidad y las obligaciones asociadas antes de la puesta en marcha.',
      base: 'Reglamento (UE) 2024/1689 · calendario revisado por el Reglamento (UE) 2026/1744',
    });
  }

  const cuenta = { ok: 0, warn: 0, error: 0, info: 0 };
  for (const i of items) cuenta[i.estado]++;
  return {
    items, cuenta, carteles: cart, rat, ia,
    nivel: cuenta.error ? 'error' : cuenta.warn ? 'warn' : 'ok',
    resumen: `${cuenta.error} incumplimiento(s), ${cuenta.warn} por revisar, ${cuenta.ok} correcta(s)`,
    // Aviso que se repite en el panel y en el PDF: la herramienta mide, no asesora
    aviso: 'Comprobación documental sobre el diseño. No sustituye al asesoramiento jurídico del responsable.',
    avisadoPor: priv.avisoVisto === true,
  };
}

/**
 * Carteles que hay que colocar: uno por cada zona vigilada que se vea desde el exterior o
 * que linde con vía pública, más uno en el acceso principal del recinto.
 */
export function cartelesRequeridos(prj, an, rules) {
  const priv = (prj.settings && prj.settings.privacidad) || {};
  const out = [];
  const zonas = (an.zonas || []).filter((z) => z.areaVista > 0 ||
    (z.camaras && z.camaras.length));
  for (const z of zonas) {
    out.push({
      id: z.id,
      donde: z.nombre,
      motivo: z.clase === 'PUBLICA' || z.clase === 'TERCEROS'
        ? 'La zona linda con vía pública o con propiedad de terceros'
        : z.clase === 'SENSIBLE' ? 'Zona de intimidad: hay que acreditar que no se vigila' : 'Zona videovigilada',
      clase: z.clase,
    });
  }
  const cams = (prj.entities || []).filter((e) => e.type === 'camera');
  if (cams.length && !out.length) out.push({ id: 'acceso', donde: 'Acceso principal', motivo: 'Entrada al recinto videovigilado', clase: 'PROPIA' });
  const responsable = priv.responsable || prj.meta.client || '—';
  for (const c of out) c.texto = textoCartel(responsable, ruleNum(rules, 'DIAS_GRABACION'), priv);
  return out;
}

/** Texto normalizado del cartel informativo (art. 13 RGPD y criterio de la AEPD). */
export function textoCartel(responsable, dias, priv = {}) {
  return `ZONA VIDEOVIGILADA · Responsable: ${responsable || '—'} · Finalidad: ${priv.finalidad || 'seguridad de personas, bienes e instalaciones'} · ` +
    `Conservación: ${dias || 30} días · Derechos: acceso, rectificación, supresión, limitación y oposición · ` +
    `Ejercicio de derechos: ${priv.contactoDerechos || 'dirección del responsable'} · Más información en el punto de atención al ciudadano`;
}

/** Borrador del registro de actividades de tratamiento (art. 30 RGPD). */
export function registroActividades(prj, an = {}, rules = {}) {
  const priv = (prj.settings && prj.settings.privacidad) || {};
  const dias = ruleNum(rules, 'DIAS_GRABACION');
  return {
    responsable: priv.responsable || prj.meta.client || '',
    nif: priv.nif || '',
    domicilio: prj.meta.address || '',
    delegado: priv.dpd || '',
    finalidad: priv.finalidad || 'Seguridad de personas, bienes e instalaciones',
    baseJuridica: priv.baseJuridica || 'Art. 22 LOPDGDD e interés legítimo del responsable (art. 6.1.f RGPD)',
    categorias: 'Imágenes y, en su caso, sonido de las personas que acceden o permanecen en el recinto',
    colectivos: priv.colectivos || 'Empleados, visitantes, proveedores y personal de contratas',
    destinatarios: 'Fuerzas y Cuerpos de Seguridad y juzgados y tribunales, previo requerimiento; compañía aseguradora cuando proceda',
    transferencias: 'No se prevén transferencias internacionales de datos',
    plazo: `${dias} días desde la captación, salvo conservación como prueba de un incidente`,
    medidas: [
      'Acceso con usuario nominativo y contraseña propia, con registro de accesos y exportaciones',
      'Equipo de grabación en recinto de acceso restringido',
      'Cifrado de las comunicaciones y desactivación de servicios innecesarios',
      'Borrado automático al cumplir el plazo de conservación',
      'Máscaras de privacidad sobre vía pública y zonas de terceros',
    ],
    derechos: 'Acceso, rectificación, supresión, limitación del tratamiento y oposición',
  };
}

/** Resumen de una línea para el panel y para la portada del PDF. */
export function resumenPrivacidad(prj, catalog, rules, res = {}) {
  const an = res.privacidad || analisisPrivacidad(prj, catalog, rules, res);
  const cum = evaluarCumplimiento(prj, catalog, rules, Object.assign({}, res, { privacidad: an }));
  return { analisis: an, cumplimiento: cum };
}
