/**
 * CCTV DESIGN PRO — Módulo de analítica de vídeo (CP CCTV §38, §14, §21)
 *
 * Una regla de analítica no es un dibujo: es una **condición de disparo** sobre una zona
 * concreta. El módulo comprueba que esa zona esté realmente cubierta y con la densidad de
 * píxeles suficiente, calcula el caudal de eventos, el ancho de banda de metadatos, la
 * licencia necesaria cuando la cámara no trae analítica embarcada y las acciones asociadas.
 */
import { pointInPoly } from './geometry.js?v=b441e3fc';
import { pixelDensity } from './dori.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';

/** Tipos de regla del contrato y sus requisitos técnicos. */
export const ANALYTICS_TYPES = {
  linecross: { label: 'Cruce de línea', ppm: 63, note: 'Detecta el sentido de paso por una línea virtual.', needsLine: true },
  intrusion: { label: 'Intrusión en zona', ppm: 63, note: 'Entrada o permanencia no autorizada dentro de un área.' },
  loiter: { label: 'Merodeo / permanencia', ppm: 63, note: 'Presencia estacionaria por encima del tiempo configurado.' },
  abandoned: { label: 'Objeto abandonado', ppm: 125, note: 'Bulto que aparece y permanece sin dueño.' },
  removed: { label: 'Objeto retirado', ppm: 125, note: 'Desaparición de un objeto vigilado.' },
  count: { label: 'Conteo de personas', ppm: 63, note: 'Aforo y flujo de personas por zona o línea.' },
  crowd: { label: 'Aglomeración', ppm: 63, note: 'Densidad de personas por encima del umbral.' },
  autotrack: { label: 'Seguimiento automático (PTZ)', ppm: 63, note: 'El PTZ persigue al objetivo detectado.', onlyPtz: true },
  lpr: { label: 'Lectura de matrículas', ppm: 130, note: 'Reconoce placas en el carril configurado.', onlyLpr: true },
  heatmap: { label: 'Mapa de calor', ppm: 25, note: 'Estadística de ocupación, sin alarma.' },
};

export const ACTIONS = { alarm: 'Alarma', email: 'Correo', siren: 'Sirena', doorlock: 'Cierre de puerta', zoom: 'Zoom/preajuste PTZ', recording: 'Grabación reforzada' };

/** Reglas de analítica declaradas en una cámara (siempre un array normalizado). */
export function cameraRules(cam) {
  return ((cam && cam.data && cam.data.analytics) || []).map((r, i) => ({
    index: i,
    type: r.type || 'intrusion',
    zoneId: r.zoneId || '',
    sensitivity: r.sensitivity === undefined ? 5 : Number(r.sensitivity),
    minPpm: Number(r.minPpm) || (ANALYTICS_TYPES[r.type] || {}).ppm || 63,
    eventsPerDay: r.eventsPerDay === undefined ? null : Number(r.eventsPerDay),
    actions: Array.isArray(r.actions) ? r.actions.slice() : (r.actions ? [r.actions] : []),
    note: r.note || '',
  }));
}

/** ¿La cámara admite este tipo de regla integrada (analítica embarcada)? */
export function supportsType(cam, catalog, type) {
  const it = getItem(catalog, cam && cam.data && cam.data.catalogId);
  const list = (it && it.specs && it.specs.analytics) || [];
  return list.includes(type);
}

/**
 * Evalúa una regla: cobertura de la zona por esta cámara, ppm alcanzados, eventos y acciones.
 * `coverage` es el resultado de analyzeCoverage (con `_footprints` para el detalle de la cámara).
 */
export function evaluateRule(cam, rule, prj, catalog, rules, coverage) {
  const zone = prj.entities.find((e) => e.id === rule.zoneId);
  const zoneName = zone ? (zone.data.name || zone.id) : '(zona no definida)';
  const it = getItem(catalog, cam.data.catalogId);
  const s = (it && it.specs) || {};
  const fps = (coverage && coverage._footprints && coverage._footprints[cam.id]) || [];
  const def = ANALYTICS_TYPES[rule.type] || ANALYTICS_TYPES.intrusion;
  const stats = coverage && coverage.cameras ? coverage.cameras.find((c) => c.id === cam.id) : null;

  // Semilla de puntos de la zona para medir cobertura y densidad reales
  let inside = 0, covered = 0, bestPpm = 0, worstPpm = Infinity;
  const seed = zone ? samplePoints(zone.points, rule.sensitivity) : [];
  // La densidad exigida es la general del proyecto, elevada por el mínimo propio del tipo de
  // regla (identificar un objeto abandonado o una matrícula exige más densidad que detectar un paso)
  const targetPpm = Math.max(rule.minPpm || 0, ruleNum(rules, 'ANALITICA_PPM'), def.ppm || 0);
  const focal = cam.data.focal || s.lens || 4;
  for (const p of seed) {
    inside++;
    let hit = false;
    for (const poly of fps) if (pointInPoly(p, poly)) { hit = true; break; }
    if (!hit) continue;
    covered++;
    const d = Math.hypot(p.x - cam.points[0].x, p.y - cam.points[0].y);
    const ppm = pixelDensity(it, d, focal);
    bestPpm = Math.max(bestPpm, ppm);
    worstPpm = Math.min(worstPpm, ppm);
  }
  let coveragePct = inside ? (covered / inside) * 100 : 0;
  let worst = isFinite(worstPpm) ? worstPpm : 0;
  let best = bestPpm;
  // Reglas sin zona (seguimiento automático de un PTZ): se valoran sobre la cobertura real de la cámara
  if (!zone && stats) {
    coveragePct = stats.area > 0 ? 100 : 0;
    worst = stats.ppmAtFar || 0;
    best = worst;
  }
  const eventsPerDay = rule.eventsPerDay === null || rule.eventsPerDay === undefined
    ? ruleNum(rules, 'ANALITICA_EVENTOS_DIA') * (zone && zone.data.critical ? 1.5 : 1)
    : rule.eventsPerDay;
  const embedded = supportsType(cam, catalog, rule.type);
  const compatible = !(s.analog) && !(def.onlyPtz && !s.ptz) && !(def.onlyLpr && !s.lpr) && !(def.needsLine && !s.analytics);
  const coveredOk = zone ? covered > 0 : (stats ? stats.area > 0 : false);
  return {
    coveredOk,
    cameraId: cam.id, camera: cam.data.label || cam.id, model: it ? it.model : '?',
    type: rule.type, typeLabel: def.label, zoneId: rule.zoneId, zone: zoneName, critical: !!(zone && zone.data.critical),
    coveragePct, enough: coveredOk && worst >= targetPpm, bestPpm: best, worstPpm: worst, targetPpm,
    needsZone: !!zone,
    sensitivity: rule.sensitivity, eventsPerDay, actions: rule.actions, note: rule.note,
    embedded, needsLicense: !embedded, compatible, onlyPtz: !!def.onlyPtz, onlyLpr: !!def.onlyLpr,
    channelCamera: stats ? stats.label : (cam.data.label || cam.id),
    ok: compatible && coveredOk && worst >= targetPpm,
  };
}

/** Puntos de muestreo de una zona: rejilla adaptada a la sensibilidad de la regla. */
export function samplePoints(points, sensitivity = 5) {
  if (!points || points.length < 3) return [];
  const n = Math.max(2, Math.min(12, Math.round(4 + (10 - Math.min(sensitivity, 10)) * 0.8)));
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of points) { minX = Math.min(minX, p.x); minY = Math.min(minY, p.y); maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y); }
  const out = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const p = { x: minX + ((i + 0.5) / n) * (maxX - minX), y: minY + ((j + 0.5) / n) * (maxY - minY) };
      if (pointInPoly(p, points)) out.push(p);
    }
  }
  return out;
}

/** Resumen de analítica del proyecto: reglas, licencias, eventos y metadatos. */
export function analyticsSummary(prj, catalog, rules, coverage) {
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const rows = [];
  for (const cam of cams) {
    for (const r of cameraRules(cam)) rows.push(evaluateRule(cam, r, prj, catalog, rules, coverage));
  }
  const licenses = rows.filter((r) => r.needsLicense && r.compatible).length;
  const events = rows.reduce((a, r) => a + (r.eventsPerDay || 0), 0);
  const kbps = rows.length ? rows.filter((r) => r.coveragePct > 0).length * ruleNum(rules, 'ANALITICA_KBPS') : 0;
  const byType = {};
  for (const r of rows) byType[r.type] = (byType[r.type] || 0) + 1;
  return {
    rules: rows.length, rows, licenses, events, kbps, byType,
    cameras: new Set(rows.map((r) => r.cameraId)).size,
    failed: rows.filter((r) => !r.ok).length,
    status: !rows.length ? 'SIN REGLAS' : rows.some((r) => !r.compatible) ? 'INCOMPATIBLE' : rows.every((r) => r.ok) ? 'NORMAL' : 'REVISAR',
  };
}

/** Cuadro de reglas para documentación (§28). */
export function analyticsSchedule(prj, catalog, rules, coverage) {
  return analyticsSummary(prj, catalog, rules, coverage).rows.map((r) => ({
    camera: r.camera, type: r.typeLabel, zone: r.zone, sensitivity: r.sensitivity,
    coveragePct: r.coveragePct, ppm: r.worstPpm, events: r.eventsPerDay,
    actions: r.actions.map((a) => ACTIONS[a] || a).join(', ') || '—',
    license: r.needsLicense ? 'Sí' : 'Embarcada',
  }));
}

/** Incidencias del módulo de analítica (§30). */
export function validateAnalytics(prj, catalog, rules, coverage) {
  const out = [];
  const sum = analyticsSummary(prj, catalog, rules, coverage);
  if (!sum.rules) return out;
  for (const r of sum.rows) {
    const who = `${r.camera} · ${r.typeLabel}`;
    if (!r.compatible) {
      const why = r.onlyPtz ? 'requiere una cámara PTZ' : r.onlyLpr ? 'requiere una cámara LPR' : 'la cámara no admite analítica';
      out.push({ code: 'ANALITICA_INCOMPATIBLE', severity: 'error', text: `${who}: ${why}` });
      continue;
    }
    if (!r.needsZone) {
      // Sin zona: la regla depende de la cobertura de la propia cámara
      if (!r.coveredOk) out.push({ code: 'ANALITICA_SIN_COBERTURA', severity: 'error', text: `${who}: la cámara no cubre ninguna zona de interés` });
      else if (r.worstPpm > 0 && r.worstPpm < r.targetPpm) out.push({ code: 'ANALITICA_PPM', severity: 'warn', text: `${who}: ${r.worstPpm.toFixed(0)} ppm al final del alcance (se requieren ${r.targetPpm} ppm)` });
      if (r.needsLicense) out.push({ code: 'ANALITICA_LICENCIA', severity: 'info', text: `${who}: 1 licencia de canal añadida al presupuesto` });
      continue;
    }
    if (r.coveragePct <= 0)
      out.push({ code: 'ANALITICA_SIN_COBERTURA', severity: 'error', text: `${who}: la zona «${r.zone}» no está dentro del campo de visión de la cámara` });
    else if (r.coveragePct < 70)
      out.push({ code: 'ANALITICA_COBERTURA_BAJA', severity: 'warn', text: `${who}: solo el ${r.coveragePct.toFixed(0)} % de «${r.zone}» está cubierto` });
    if (r.worstPpm > 0 && r.worstPpm < r.targetPpm)
      out.push({ code: 'ANALITICA_PPM', severity: 'warn', text: `${who}: ${r.worstPpm.toFixed(0)} ppm en el punto más desfavorable de «${r.zone}» (se requieren ${r.targetPpm} ppm)` });
    if (r.needsLicense)
      out.push({ code: 'ANALITICA_LICENCIA', severity: 'info', text: `${who}: la cámara no trae analítica embarcada; se añade 1 licencia de canal al presupuesto` });
    if (!r.actions.length)
      out.push({ code: 'ANALITICA_SIN_ACCION', severity: 'info', text: `${who}: regla sin acciones asociadas (solo registro de eventos)` });
  }
  return out;
}
