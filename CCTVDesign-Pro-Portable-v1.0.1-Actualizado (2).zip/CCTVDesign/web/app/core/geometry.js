/**
 * CCTV DESIGN PRO — Motor geométrico
 * core/geometry.js  ·  Sin dependencias, sin DOM. Ejecutable en navegador y en Node.
 */

export const TAU = Math.PI * 2;
export const rad = (deg) => (deg * Math.PI) / 180;
export const deg = (r) => (r * 180) / Math.PI;
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export const v = (x, y) => ({ x, y });
export const add = (a, b) => ({ x: a.x + b.x, y: a.y + b.y });
export const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y });
export const len = (a) => Math.hypot(a.x, a.y);
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

export function polyLength(pts, closed = false) {
  let s = 0;
  for (let i = 1; i < pts.length; i++) s += dist(pts[i - 1], pts[i]);
  if (closed && pts.length > 2) s += dist(pts[pts.length - 1], pts[0]);
  return s;
}

export function bbox(pts) {
  if (!pts.length) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, minY, maxX, maxY };
}

export const bboxOf = (...bs) => {
  const o = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const b of bs) {
    o.minX = Math.min(o.minX, b.minX); o.minY = Math.min(o.minY, b.minY);
    o.maxX = Math.max(o.maxX, b.maxX); o.maxY = Math.max(o.maxY, b.maxY);
  }
  return o;
};

export const bboxIntersects = (a, b) =>
  a.minX <= b.maxX && b.minX <= a.maxX && a.minY <= b.maxY && b.minY <= a.maxY;

export function polyArea(pts) {
  let s = 0;
  for (let i = 0, n = pts.length; i < n; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    s += a.x * b.y - b.x * a.y;
  }
  return Math.abs(s) / 2;
}

export function centroid(pts) {
  let x = 0, y = 0;
  for (const p of pts) { x += p.x; y += p.y; }
  return { x: x / pts.length, y: y / pts.length };
}

/** Ray casting — punto dentro de polígono (borde considerado interior). */
export function pointInPoly(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.y > p.y) !== (b.y > p.y) && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) {
      inside = !inside;
    }
  }
  return inside;
}

export const distPointSeg = (p, a, b) => {
  const vx = b.x - a.x, vy = b.y - a.y;
  const wx = p.x - a.x, wy = p.y - a.y;
  const l2 = vx * vx + vy * vy;
  let t = l2 ? (wx * vx + wy * vy) / l2 : 0;
  t = clamp(t, 0, 1);
  return Math.hypot(p.x - (a.x + t * vx), p.y - (a.y + t * vy));
};


/* ---------------------------------------------------------------------------
 * Selección por ventana y por cruce (§8), como en AutoCAD:
 *   ventana · el rectángulo se traza de izquierda a derecha y solo coge lo que
 *            queda **completamente dentro**;
 *   cruce   · se traza de derecha a izquierda y coge **todo lo que toca**.
 * Es geometría pura para que se pueda comprobar sin navegador.
 * ------------------------------------------------------------------------- */

/** ¿El punto está dentro de la caja {minX,minY,maxX,maxY}? */
export const puntoEnCaja = (p, c) =>
  p.x >= c.minX && p.x <= c.maxX && p.y >= c.minY && p.y <= c.maxY;

/** Normaliza una caja desde dos esquinas cualesquiera. */
export const cajaDe2 = (a, b) => ({
  minX: Math.min(a.x, b.x), minY: Math.min(a.y, b.y),
  maxX: Math.max(a.x, b.x), maxY: Math.max(a.y, b.y),
});

/**
 * ¿El segmento a–b corta la caja (o entra en ella)? Recorte de Liang–Barsky.
 * Devuelve falso si el segmento es un punto (se trata aparte).
 */
export function segmentoCortaCaja(a, b, c) {
  let t0 = 0, t1 = 1;
  const dx = b.x - a.x, dy = b.y - a.y;
  const lados = [[-dx, a.x - c.minX], [dx, c.maxX - a.x], [-dy, a.y - c.minY], [dy, c.maxY - a.y]];
  for (const [p, q] of lados) {
    if (p === 0) { if (q < 0) return false; continue; }   // paralelo y fuera
    const t = q / p;
    if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
    else { if (t < t0) return false; if (t < t1) t1 = t; }
  }
  return t1 >= t0;
}

/** Radio de una entidad de punto: árboles, columnas, personas, círculos… */
export const radioDe = (e) =>
  Number(e?.radius ?? e?.data?.radio ?? e?.data?.radius ?? 0) || 0;

/**
 * Caja envolvente de una entidad: la de sus puntos, ensanchada con el radio si
 * lo tiene (círculos, árboles, personas de referencia).
 */
export function cajaDeEntidad(e) {
  const pts = (e && e.points) || [];
  if (!pts.length) return null;
  const r = radioDe(e);
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    if (p.x - r < minX) minX = p.x - r;
    if (p.y - r < minY) minY = p.y - r;
    if (p.x + r > maxX) maxX = p.x + r;
    if (p.y + r > maxY) maxY = p.y + r;
  }
  return { minX, minY, maxX, maxY };
}

/** ¿La entidad es un recorrido cerrado (estancia, rectángulo, círculo…)? */
export const esCerrada = (e) =>
  !!e && (e.type === 'room' || e.type === 'rect' || e.type === 'circle' ||
    e.type === 'pzona' || e.type === 'mascara' ||
    (e.type === 'polyline' && e.data && (e.data.closed === true || e.data.cerrada === true)));

/**
 * ¿La entidad entra en la selección?
 *   modo 'ventana' → todos sus puntos dentro de la caja;
 *   modo 'cruce'   → además, cualquier contacto con la caja (un lado que la
 *                    atraviesa, un vértice dentro, o una figura cerrada que
 *                    envuelve la caja).
 */
export function entidadEnCaja(e, c, modo = 'ventana') {
  const pts = (e && e.points) || [];
  if (!pts.length) return false;
  if (pts.every((p) => puntoEnCaja(p, c))) return true;
  if (modo !== 'cruce') return false;
  const r = radioDe(e);
  // Círculo o elemento de punto: cuenta como contacto si la caja se acerca a menos del radio
  if (r > 0 && (e.type === 'circle' || e.type === 'obstacle')) {
    const centro = pts[0];
    const qx = clamp(centro.x, c.minX, c.maxX), qy = clamp(centro.y, c.minY, c.maxY);
    if (Math.hypot(centro.x - qx, centro.y - qy) <= r) return true;
  }
  const b = cajaDeEntidad(e);
  if (b && !bboxIntersects(b, c)) return false;
  // Figura cerrada que envuelve la caja (por ejemplo una estancia grande)
  if (esCerrada(e) && pts.length >= 3) {
    if (pointInPoly({ x: (c.minX + c.maxX) / 2, y: (c.minY + c.maxY) / 2 }, pts)) return true;
  }
  // Algún lado de la entidad atraviesa la caja
  for (let i = 0; i + 1 < pts.length; i++) {
    if (segmentoCortaCaja(pts[i], pts[i + 1], c)) return true;
  }
  if (esCerrada(e) && pts.length >= 3 && segmentoCortaCaja(pts[pts.length - 1], pts[0], c)) return true;
  // O alguna esquina de la caja cae dentro de la figura cerrada
  if (esCerrada(e) && pts.length >= 3) {
    const esquinas = [{ x: c.minX, y: c.minY }, { x: c.maxX, y: c.minY },
      { x: c.maxX, y: c.maxY }, { x: c.minX, y: c.maxY }];
    if (esquinas.some((q) => pointInPoly(q, pts))) return true;
  }
  return false;
}

/** Identificadores de las entidades que entran en la caja, en el modo pedido. */
export function seleccionarEnCaja(entidades, c, modo = 'ventana') {
  const out = [];
  for (const e of entidades || []) if (entidadEnCaja(e, c, modo)) out.push(e.id);
  return out;
}

/**
 * Cierre convexo de una nube de puntos (cadena monótona de Andrew), en sentido antihorario.
 * Se usa para las sombras del 3D: la mancha que deja un volumen en el suelo es el cierre convexo
 * de su silueta proyectada, así se pinta de una sola vez y no se oscurece por solapes.
 */
export function cierreConvexo(pts) {
  const p = (pts || []).filter(Boolean).slice().sort((a, b) => (a.x - b.x) || (a.y - b.y));
  if (p.length < 3) return p;
  const cruz = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const mitad = (lista) => {
    const out = [];
    for (const q of lista) {
      while (out.length >= 2 && cruz(out[out.length - 2], out[out.length - 1], q) <= 0) out.pop();
      out.push(q);
    }
    out.pop();
    return out;
  };
  return mitad(p).concat(mitad(p.slice().reverse()));
}

/**
 * Área con signo del polígono (regla del trapecio). Con la **Y hacia arriba** (mundo), positiva
 * significa antihorario; con la **Y hacia abajo** (pantalla) positiva significa horario a la vista,
 * que es justo la regla del lazo de AutoCAD: antihorario → ventana, horario → cruce.
 */
export function areaConSigno(pts) {
  let s = 0;
  for (let i = 0, n = pts.length; i < n; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}

/**
 * ¿La entidad entra en un **lazo** (polígono libre, que puede autocortarse: la regla par-impar de
 * `pointInPoly` lo resuelve, como AutoCAD)?
 *   modo 'ventana' → la entidad entera cabe dentro del lazo;
 *   modo 'cruce'   → basta con que lo toque: un punto dentro o un lado que lo atraviesa.
 */
export function entidadEnPoligono(e, poli, modo = 'ventana') {
  if (!e || !e.points || !e.points.length || !poli || poli.length < 3) return false;
  const lados = [];
  for (let i = 0, n = poli.length; i < n; i++) lados.push([poli[i], poli[(i + 1) % n]]);
  const dentro = (p) => pointInPoly(p, poli);
  const todosDentro = e.points.every(dentro);
  if (todosDentro) {
    const r = radioDe(e);
    // Círculo, árbol o persona: además de tener el centro dentro, el borde no puede salirse
    if (r > 0) {
      for (const [a, b] of lados) if (distPointSeg(e.points[0], a, b) < r) return modo === 'cruce';
      return true;
    }
    // Polilínea: con todos los vértices dentro, cabe entera salvo que algún lado cruce el lazo
    if (modo === 'ventana') {
      for (const s of entitySegments(e)) {
        for (const [a, b] of lados) if (segIntersect(s.a, s.b, a, b)) return false;
      }
    }
    return true;
  }
  if (modo !== 'cruce') return false;
  if (e.points.some(dentro)) return true;
  const r = radioDe(e);
  if (r > 0) {
    for (const [a, b] of lados) if (distPointSeg(e.points[0], a, b) <= r) return true;
  }
  for (const s of entitySegments(e)) {
    for (const [a, b] of lados) if (segIntersect(s.a, s.b, a, b)) return true;
  }
  return false;
}

/** Identificadores de las entidades que entran en el lazo, en el modo pedido. */
export function seleccionarEnPoligono(entidades, poli, modo = 'ventana') {
  const out = [];
  for (const e of entidades || []) if (entidadEnPoligono(e, poli, modo)) out.push(e.id);
  return out;
}

/* ---------------------------------------------------------------------------
 * Recorte de polígonos (Sutherland–Hodgman)
 * Se usa para recortar el polígono de visibilidad con el sector del campo de
 * visión de la cámara: el **recorte** debe ser convexo (un sector circular de
 * ángulo ≤ 180° lo es, y un disco también), el sujeto puede ser cóncavo.
 * ------------------------------------------------------------------------- */

/** ¿El punto queda dentro (o sobre) la arista de recorte, a la izquierda de a→b? */
const dentroArista = (p, a, b) => (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x) >= -1e-12;

/** Punto donde el segmento p→q atraviesa la recta a→b. */
function cruceArista(p, q, a, b) {
  const dx = q.x - p.x, dy = q.y - p.y;
  const ex = b.x - a.x, ey = b.y - a.y;
  const den = dx * ey - dy * ex;
  if (Math.abs(den) < 1e-18) return { x: q.x, y: q.y };       // paralelos: se queda el extremo
  const t = ((a.x - p.x) * ey - (a.y - p.y) * ex) / den;
  return { x: p.x + dx * t, y: p.y + dy * t };
}

/**
 * Recorta el polígono `sujeto` con el polígono convexo `clip` (Sutherland–Hodgman).
 * Devuelve el polígono recortado (puede ser vacío si no hay solape). Con sujetos
 * cóncavos puede devolver aristas de unión degeneradas: por eso quien lo usa
 * comprueba el área y se queda con la original si el recorte la aumenta.
 */
export function recortarPoligono(sujeto, clip) {
  let salida = (sujeto || []).slice();
  // El recorte tiene que recorrerse en sentido antihorario: si viene al revés, se le da la vuelta
  let c = (clip || []).slice();
  if (c.length >= 3) {
    let firmada = 0;
    for (let i = 0; i < c.length; i++) { const u = c[i], v = c[(i + 1) % c.length]; firmada += u.x * v.y - v.x * u.y; }
    if (firmada < 0) c.reverse();
  }
  if (salida.length < 3 || c.length < 3) return [];
  for (let i = 0; i < c.length && salida.length; i++) {
    const a = c[i], b = c[(i + 1) % c.length];
    const entrada = salida;
    salida = [];
    for (let j = 0; j < entrada.length; j++) {
      const p = entrada[j], q = entrada[(j + 1) % entrada.length];
      const pd = dentroArista(p, a, b), qd = dentroArista(q, a, b);
      if (pd) salida.push(p);
      if (pd !== qd) salida.push(cruceArista(p, q, a, b));
    }
  }
  return salida;
}

/**
 * Polígono de un **sector circular** (el campo de visión de la cámara en planta):
 * vértice en `o`, desde el ángulo `a0` hasta `a1` y radio `r`. El arco se muestrea
 * con el paso que haga falta para que la cuerda no se separe del arco más de `tol`.
 * Con ángulo completo (a1 − a0 ≥ 360°) devuelve el disco sin vértice central.
 */
export function sectorPoligono(o, a0, a1, r, tol = 0.02) {
  if (!(r > 0)) return [];
  const ancho = a1 - a0;
  const completo = ancho >= TAU - 1e-9;
  const paso = Math.max(1e-3, 2 * Math.acos(Math.max(-1, Math.min(1, 1 - Math.min(0.25, tol / r)))));
  const n = Math.max(8, Math.ceil(ancho / paso));
  const pts = completo ? [] : [{ x: o.x, y: o.y }];
  for (let i = 0; i <= n; i++) {
    const a = a0 + (ancho * i) / n;
    pts.push({ x: o.x + Math.cos(a) * r, y: o.y + Math.sin(a) * r });
  }
  return pts;
}

/** Intersección propia entre dos segmentos (tolerante en los extremos). */
export function segIntersect(p1, p2, p3, p4, eps = 1e-9) {
  const d = (p2.x - p1.x) * (p4.y - p3.y) - (p2.y - p1.y) * (p4.x - p3.x);
  if (Math.abs(d) < eps) return null;
  const t = ((p3.x - p1.x) * (p4.y - p3.y) - (p3.y - p1.y) * (p4.x - p3.x)) / d;
  const u = ((p3.x - p1.x) * (p2.y - p1.y) - (p3.y - p1.y) * (p2.x - p1.x)) / d;
  if (t < -eps || t > 1 + eps || u < -eps || u > 1 + eps) return null;
  return { x: p1.x + t * (p2.x - p1.x), y: p1.y + t * (p2.y - p1.y), t };
}

/** Distancia punto→recta infinita definida por a,b. */
export function distPointLine(p, a, b) {
  const d = dist(a, b);
  if (d < 1e-9) return dist(p, a);
  return Math.abs((b.x - a.x) * (a.y - p.y) - (a.x - p.x) * (b.y - a.y)) / d;
}

/** Douglas–Peucker para simplificar polilíneas de ruta. */
export function simplify(pts, tol) {
  if (pts.length < 3 || tol <= 0) return pts.slice();
  const keep = new Uint8Array(pts.length);
  keep[0] = keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  while (stack.length) {
    const [i, j] = stack.pop();
    let maxD = -1, idx = -1;
    for (let k = i + 1; k < j; k++) {
      const d = distPointLine(pts[k], pts[i], pts[j]);
      if (d > maxD) { maxD = d; idx = k; }
    }
    if (maxD > tol && idx > 0) {
      keep[idx] = 1;
      stack.push([i, idx], [idx, j]);
    }
  }
  return pts.filter((_, i) => keep[i]);
}

/** Convierte una entidad del motor CAD a segmentos {a,b} para el motor de obstáculos. */
export function entitySegments(e) {
  const segs = [];
  const push = (p, q) => segs.push({ a: p, b: q });
  switch (e.type) {
    case 'line':
      if (e.points.length >= 2) push(e.points[0], e.points[1]);
      break;
    case 'polyline':
    case 'room': {
      for (let i = 1; i < e.points.length; i++) push(e.points[i - 1], e.points[i]);
      if (e.closed && e.points.length > 2) push(e.points[e.points.length - 1], e.points[0]);
      break;
    }
    case 'rect': {
      const [a, b] = e.points;
      const c = [v(a.x, a.y), v(b.x, a.y), v(b.x, b.y), v(a.x, b.y)];
      for (let i = 0; i < 4; i++) push(c[i], c[(i + 1) % 4]);
      break;
    }
    case 'circle': {
      const c = e.points[0], r = e.radius || 0, n = 24;
      for (let i = 0; i < n; i++) {
        const a1 = (i / n) * TAU, a2 = ((i + 1) / n) * TAU;
        push(
          v(c.x + Math.cos(a1) * r, c.y + Math.sin(a1) * r),
          v(c.x + Math.cos(a2) * r, c.y + Math.sin(a2) * r)
        );
      }
      break;
    }
    case 'arc': {
      const c = e.points[0], r = e.radius || 0, n = 16;
      const a0 = rad(e.startAngle || 0), a1 = rad(e.endAngle || 0);
      for (let i = 0; i < n; i++) {
        const t1 = a0 + ((a1 - a0) * i) / n, t2 = a0 + ((a1 - a0) * (i + 1)) / n;
        push(v(c.x + Math.cos(t1) * r, c.y + Math.sin(t1) * r), v(c.x + Math.cos(t2) * r, c.y + Math.sin(t2) * r));
      }
      break;
    }
  }
  return segs;
}

/**
 * Índice espacial uniforme de obstáculos: buckets cuadrados para consultas LOS rápidas.
 * Imprescindible para el objetivo de rendimiento de CP CCTV §36 (Celeron, 4 GB).
 */
export class SegmentIndex {
  constructor(segments, cell = 2) {
    this.cell = cell;
    this.map = new Map();
    this.segments = segments;
    for (const s of segments) this._insert(s);
  }
  _key(ix, iy) { return ix + ':' + iy; }
  _insert(s) {
    const c = this.cell;
    const x0 = Math.floor(Math.min(s.a.x, s.b.x) / c), x1 = Math.floor(Math.max(s.a.x, s.b.x) / c);
    const y0 = Math.floor(Math.min(s.a.y, s.b.y) / c), y1 = Math.floor(Math.max(s.a.y, s.b.y) / c);
    for (let ix = x0; ix <= x1; ix++)
      for (let iy = y0; iy <= y1; iy++) {
        const k = this._key(ix, iy);
        let arr = this.map.get(k);
        if (!arr) this.map.set(k, (arr = []));
        if (!arr.includes(s)) arr.push(s);
      }
  }
  query(a, b) {
    const c = this.cell;
    const x0 = Math.floor(Math.min(a.x, b.x) / c), x1 = Math.floor(Math.max(a.x, b.x) / c);
    const y0 = Math.floor(Math.min(a.y, b.y) / c), y1 = Math.floor(Math.max(a.y, b.y) / c);
    const out = [];
    for (let ix = x0; ix <= x1; ix++)
      for (let iy = y0; iy <= y1; iy++) {
        const arr = this.map.get(this._key(ix, iy));
        if (arr) for (const s of arr) if (!out.includes(s)) out.push(s);
      }
    return out;
  }
  /** true si el rayo a→b atraviesa algún obstáculo. */
  blocked(a, b) {
    for (const s of this.query(a, b)) if (segIntersect(a, b, s.a, s.b)) return true;
    return false;
  }
}
