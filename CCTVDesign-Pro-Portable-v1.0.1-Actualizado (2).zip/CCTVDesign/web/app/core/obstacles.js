/**
 * CCTV DESIGN PRO — Obstáculos, muros y elementos en altura (CP CCTV §9, §13, §14)
 *
 * Para decidir dónde va una cámara no basta con la planta: hay que saber **qué hay en alto**. Un
 * muro de 2,8 m tapa la visión de una cámara puesta a 2,5 m; una mesa de 0,8 m no; una ventana tapa
 * de 0,9 a 2,3 m y deja pasar lo que va por debajo o por encima; un árbol tapa con su copa pero deja
 * ver por debajo de ella. Este módulo es el catálogo de esos elementos y la aritmética que los hace
 * servir para dos cosas:
 *
 *   1. **Oclusión con altura** en el análisis de cobertura (§13, §14): un obstáculo corta el rayo de
 *      la cámara al punto que se comprueba solo si su rango de alturas [base, base + altura] corta
 *      la altura que lleva el rayo en ese punto.
 *   2. **Extrusión en la vista 3D** (§8): cada elemento se convierte en volúmenes (cajas, prismas y
 *      cilindros) que se proyectan y se pintan por profundidad.
 *
 * Además resuelve «definir dónde están los muros en el plano importado»: cualquier entidad —del plano
 * o dibujada aquí— se puede marcar como muro (`data.muro`) con su altura, sin duplicar geometría.
 *
 * Módulo puro: sin DOM, sin cad y sin catálogo, para poder probarlo bajo Node.
 */

/** Altura por defecto de un muro cuando no se sabe otra cosa (la de una planta de edificio). */
export const ALTURA_MURO = 2.8;

/** Altura de una persona: sirve de referencia para lo que se considera «visible» (§13). */
export const ALTURA_PERSONA = 1.75;

/** Altura a la que se comprueba la visión de una persona cuando se analiza el suelo (§13). */
export const ALTURA_OBJETIVO = 1.0;

/* ------------------------------------------------------------------ catálogo */

/**
 * Catálogo de elementos que se pueden dibujar o colocar.
 *
 * `dibujo` dice cómo se pide la geometría al usuario:
 *   · `punto`      un clic (se dibuja con su radio: árbol, persona, columna)
 *   · `segmento`   dos clics (puerta, ventana: van sobre un muro)
 *   · `cadena`     vértices sucesivos, Enter o doble clic para terminar (muro, cerca)
 *   · `rectangulo` dos clics en esquinas opuestas (mobiliario, vehículo, techo)
 *
 * `altura` es la altura del elemento y `base` la cota a la que empieza (una ventana empieza a 0,9 m;
 * un falso techo, a 2,8). `opaco` dice si corta la visión. `ancho` es el espesor al extruir una línea.
 */
export const OBSTACULOS = [
  { id: 'muro', etiqueta: 'Muro', icono: '🧱', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'cadena', altura: 2.8, base: 0, ancho: 0.2, radio: 0, opaco: true, color: '#8b95a6',
    descripcion: 'Cerramiento de fábrica: tapa la visión de lado a lado.' },
  { id: 'tabique', etiqueta: 'Tabique', icono: '▮', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'cadena', altura: 2.6, base: 0, ancho: 0.1, radio: 0, opaco: true, color: '#7f8a9c',
    descripcion: 'Tabiquería ligera (pladur, cristal): un poco más baja que un muro.' },
  { id: 'murete', etiqueta: 'Murete o pretil', icono: '▬', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'cadena', altura: 1.1, base: 0, ancho: 0.15, radio: 0, opaco: true, color: '#78849a',
    descripcion: 'Media altura (1,1 m): tapa lo que va pegado al suelo, no a una persona de pie.' },
  { id: 'cerca', etiqueta: 'Cerca perimetral', icono: '⛓', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'cadena', altura: 2.0, base: 0, ancho: 0.06, radio: 0, opaco: false, color: '#6f7d92',
    descripcion: 'Malla o verja: se ve a través (no se considera opaca al analizar la cobertura).' },
  { id: 'reja', etiqueta: 'Reja', icono: '▤', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'segmento', altura: 2.2, base: 0, ancho: 0.08, radio: 0, opaco: false, color: '#68758a',
    descripcion: 'Reja de puerta o ventana: estorba, pero se ve a través.' },
  { id: 'columna', etiqueta: 'Columna o pilar', icono: '▉', grupo: 'Cerramientos', capa: 'ARQUITECTURA',
    dibujo: 'punto', altura: 2.8, base: 0, ancho: 0, radio: 0.25, opaco: true, color: '#98a3b5',
    descripcion: 'Pilar aislado: tapa un haz estrecho, como una persona de pie.' },

  { id: 'puerta', etiqueta: 'Puerta (hueco)', icono: '🚪', grupo: 'Huecos', capa: 'ARQUITECTURA',
    dibujo: 'segmento', altura: 2.1, base: 0, ancho: 0.06, radio: 0, opaco: false, hueco: true, color: '#5eb0c9',
    descripcion: 'Hueco de paso: no tapa la visión (es un hueco en el muro, no un obstáculo).' },
  { id: 'ventana', etiqueta: 'Ventana', icono: '🪟', grupo: 'Huecos', capa: 'ARQUITECTURA',
    dibujo: 'segmento', altura: 1.4, base: 0.9, ancho: 0.08, radio: 0, opaco: true, color: '#7fc4d8',
    descripcion: 'Hueco acristalado entre 0,9 y 2,3 m: tapa lo que pasa por esa franja.' },

  { id: 'techo', etiqueta: 'Techo o falso techo', icono: '⬛', grupo: 'Cubierta', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 0.3, base: 2.8, ancho: 0, radio: 0, opaco: true, techo: true, color: '#5a6478',
    descripcion: 'Plano alto que limita la altura de montaje: por encima de él no se puede fijar nada.' },
  { id: 'cubierta', etiqueta: 'Cubierta exterior', icono: '🔺', grupo: 'Cubierta', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 0.5, base: 3.0, ancho: 0, radio: 0, opaco: true, techo: true, color: '#4f596c',
    descripcion: 'Cubierta del edificio: marca la cota máxima de la instalación.' },

  { id: 'arbol', etiqueta: 'Árbol', icono: '🌳', grupo: 'Exterior', capa: 'ARQUITECTURA',
    dibujo: 'punto', altura: 4.0, base: 0, ancho: 0, radio: 2.0, opaco: true, color: '#4f7a52',
    descripcion: 'Copa entre 1,2 y 4 m: tapa de lejos, pero deja ver por debajo de la copa.' },
  { id: 'arbusto', etiqueta: 'Arbusto o seto', icono: '🌿', grupo: 'Exterior', capa: 'ARQUITECTURA',
    dibujo: 'punto', altura: 1.6, base: 0, ancho: 0, radio: 0.9, opaco: true, color: '#4d6b4a',
    descripcion: 'Seto de 1,6 m: tapa solo lo que va muy pegado al suelo.' },
  { id: 'vehiculo', etiqueta: 'Vehículo', icono: '🚗', grupo: 'Exterior', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 1.5, base: 0, ancho: 0, radio: 0, opaco: true, color: '#6b7f96',
    descripcion: 'Coche aparcado: puede tapar una matrícula o un acceso.' },

  { id: 'persona', etiqueta: 'Persona (referencia)', icono: '🧍', grupo: 'Referencia', capa: 'ARQUITECTURA',
    dibujo: 'punto', altura: 1.75, base: 0, ancho: 0, radio: 0.3, opaco: true, referencia: true, color: '#c8b273',
    descripcion: 'Referencia de escala y de altura: sirve para juzgar si se ve a una persona.' },
  { id: 'mobiliario', etiqueta: 'Mobiliario bajo', icono: '🪑', grupo: 'Interior', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 0.8, base: 0, ancho: 0, radio: 0, opaco: true, color: '#7d8798',
    descripcion: 'Mesa, mostrador bajo o banco: no tapa a una persona de pie.' },
  { id: 'estanteria', etiqueta: 'Estantería o armario', icono: '🗄', grupo: 'Interior', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 2.0, base: 0, ancho: 0, radio: 0, opaco: true, color: '#6f7a8b',
    descripcion: 'Mueble alto (2 m): tapa la visión como un tabique corto.' },
  { id: 'maquinaria', etiqueta: 'Maquinaria o rack de planta', icono: '⚙', grupo: 'Interior', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 1.8, base: 0, ancho: 0, radio: 0, opaco: true, color: '#66717f',
    descripcion: 'Equipo industrial o armario técnico en planta.' },
  { id: 'escalera', etiqueta: 'Escalera', icono: '🪜', grupo: 'Interior', capa: 'ARQUITECTURA',
    dibujo: 'rectangulo', altura: 2.8, base: 0, ancho: 0, radio: 0, opaco: true, color: '#8892a0',
    descripcion: 'Escalera de comunicación vertical: peldaños, descansillo, zancas y barandilla.' },
];

const POR_ID = new Map(OBSTACULOS.map((o) => [o.id, o]));

export function obstaculoDe(id) {
  return POR_ID.get(String(id || '')) || null;
}

/** Catálogo agrupado, para la paleta de herramientas. */
export function gruposDeObstaculos() {
  const grupos = [];
  const visto = new Map();
  for (const o of OBSTACULOS) {
    let g = visto.get(o.grupo);
    if (!g) { g = { grupo: o.grupo, elementos: [] }; visto.set(o.grupo, g); grupos.push(g); }
    g.elementos.push(o);
  }
  return grupos;
}

/** Los que se ponen en la barra lateral (los más usados); el resto quedan en la paleta. */
export const OBSTACULOS_BARRA = ['muro', 'puerta', 'ventana', 'cerca', 'arbol', 'persona', 'mobiliario', 'techo'];

/* -------------------------------------------------------------- creación */

/**
 * Crea la entidad de obstáculo. El tipo de entidad es `obstacle` y el «qué es» va en `data.kind`,
 * de modo que el resto del programa (dibujo 2D, 3D, cobertura) lo reconoce sin saber el catálogo.
 */
export function crearObstaculo(kind, puntos, opts = {}) {
  const def = obstaculoDe(kind);
  if (!def) return null;
  const pts = (puntos || []).filter(Boolean).map((p) => ({ x: Number(p.x) || 0, y: Number(p.y) || 0 }));
  const cerrado = opts.closed !== undefined ? !!opts.closed
    : (def.dibujo === 'rectangulo' || (def.dibujo === 'cadena' && pts.length > 2 && !!opts.closed));
  return {
    type: 'obstacle',
    layer: opts.layer || def.capa || 'ARQUITECTURA',
    points: pts,
    closed: !!cerrado,
    radius: def.dibujo === 'punto' ? (opts.radio !== undefined ? opts.radio : def.radio) : (opts.radius || 0),
    data: {
      kind: def.id,
      altura: opts.altura !== undefined ? opts.altura : def.altura,
      base: opts.base !== undefined ? opts.base : def.base,
      ancho: opts.ancho !== undefined ? opts.ancho : def.ancho,
      opaco: opts.opaco !== undefined ? !!opts.opaco : def.opaco,
      color: def.color,
      etiqueta: opts.etiqueta || def.etiqueta,
    },
  };
}

/** Datos efectivos de una entidad: los suyos si es un obstáculo, si no los de la definición. */
export function datosDe(e) {
  const d = (e && e.data) || {};
  const def = obstaculoDe(d.kind);
  return {
    kind: d.kind || (d.muro ? 'muro' : null),
    altura: num(d.altura, d.h, def ? def.altura : ALTURA_MURO),
    base: num(d.base, def ? def.base : 0),
    ancho: num(d.ancho, def ? def.ancho : 0, 0),
    radio: num(d.radio, e && e.radius, def ? def.radio : 0, 0),
    opaco: d.opaco !== undefined ? !!d.opaco : (def ? def.opaco : true),
    color: d.color || (def ? def.color : '#8b95a6'),
    etiqueta: d.etiqueta || (def ? def.etiqueta : 'Elemento'),
    muro: !!d.muro || (def ? def.id === 'muro' || def.id === 'tabique' : false),
    techo: d.techo !== undefined ? !!d.techo : (def ? !!def.techo : false),
    referencia: def ? !!def.referencia : false,
    hueco: def ? !!def.hueco : false,
    forma: d.forma || (def ? def.forma : undefined),
    largo: d.largo !== undefined ? num(d.largo, def ? def.largo : 0, 0) : undefined,
    rotacion: d.rotacion !== undefined ? num(d.rotacion, 0, 0) : undefined,
    tipoEscalera: d.tipoEscalera || d.tipo || (def ? def.tipoEscalera || 'recta' : 'recta'),
    barandilla: d.barandilla !== undefined ? !!d.barandilla : true,
    numPeldanos: d.numPeldanos !== undefined ? num(d.numPeldanos, 0) : undefined,
  };
}

/**
 * Altura con la que se extruye una entidad (§9): la suya si el usuario la fijó al marcarla o al
 * dibujarla, y si no la **altura de muros del proyecto**, que es el ajuste que se cambia una vez y
 * vale para toda la arquitectura. Un `data.h` heredado (el de la demo o el de un plano) no gana al
 * ajuste del proyecto: si el usuario dice que sus muros miden 3,20 m, miden 3,20 m.
 */
export function alturaEfectiva(e, alturaMuro = ALTURA_MURO) {
  const d = (e && e.data) || {};
  const def = obstaculoDe(d.kind);
  if (def) return num(d.altura, def.altura);          // obstáculo dibujado: su altura
  if (d.muro) return num(d.altura, d.h, alturaMuro);  // muro marcado: la que se le dio, o la del proyecto
  return num(alturaMuro, d.altura, d.h, ALTURA_MURO); // arquitectura sin marcar: la del proyecto
}

function num(...vals) {
  for (const v of vals) if (v !== undefined && v !== null && isFinite(Number(v))) return Number(v);
  return 0;
}

/**
 * ¿Esta entidad participa en el análisis de alturas y en la vista 3D?
 * Ojo: un plano importado también usa `data.kind` (p. ej. `'hatch'` para los sombreados), así que
 * solo cuenta cuando el valor es uno de los del catálogo; si no, hay que marcarla como muro.
 */
export function esElemento3d(e) {
  if (!e) return false;
  if (e.type === 'obstacle') return true;
  if (e.type === 'text' || e.type === 'image' || e.type === 'camera' || e.type === 'device') return false;
  const d = (e.data || {});
  if (d.kind) return !!obstaculoDe(d.kind);
  return !!(d.muro || d.altura !== undefined || d.h !== undefined);
}

/**Cómo se pide la geometría al usuario, por tipo de dibujo (para los textos de ayuda). */
export const AYUDA_DIBUJO = {
  punto: 'Un clic lo coloca.',
  segmento: 'Haga clic en los dos extremos del tramo.',
  cadena: 'Clic en cada vértice; Enter o doble clic para terminar.',
  rectangulo: 'Dos clics en esquinas opuestas.',
};

/** Marca una entidad existente como muro (se usa sobre la geometría del plano importado). */
export function marcarMuro(e, altura, opaco = true) {
  if (!e || !e.data) return false;
  e.data.muro = true;
  e.data.altura = altura === undefined ? e.data.altura || ALTURA_MURO : altura;
  e.data.base = e.data.base === undefined ? 0 : e.data.base;
  e.data.opaco = opaco;
  e.data.color = e.data.color || '#8b95a6';
  return true;
}

export function desmarcarMuro(e) {
  if (!e || !e.data) return false;
  if (!e.data.muro) return false;
  delete e.data.muro;
  if (e.data.kind) delete e.data.altura; else { delete e.data.altura; delete e.data.base; delete e.data.opaco; }
  return true;
}

/* ------------------------------------------------- geometría para la visión */

/** Segmentos 2D de una entidad con su rango de alturas (para el análisis de cobertura). */
export function segmentosDe(e) {
  const d = datosDe(e);
  const pts = (e.points || []).filter(Boolean);
  const out = [];
  const push = (a, b) => out.push({ a, b, base: d.base, h: d.base + d.altura, opaco: d.opaco, kind: d.kind, id: e.id });
  if (!pts.length) return out;
  if (d.kind === 'columna' && pts.length === 1) {
    const c = pts[0];
    const forma = d.forma || 'redonda';
    const r = d.radio || 0.25;
    const w = d.ancho || (r * 2);
    const l = d.largo || (forma === 'cuadrada' ? w : r * 2);
    const ang = ((d.rotacion || 0) * Math.PI) / 180;
    const cos = Math.cos(ang), sin = Math.sin(ang);
    const rot = (dx, dy) => ({ x: c.x + dx * cos - dy * sin, y: c.y + dx * sin + dy * cos });
    if (forma === 'cuadrada' || forma === 'rectangular') {
      const hw = w / 2, hl = l / 2;
      const p1 = rot(-hw, -hl), p2 = rot(hw, -hl), p3 = rot(hw, hl), p4 = rot(-hw, hl);
      push(p1, p2); push(p2, p3); push(p3, p4); push(p4, p1);
      return out;
    }
    push({ x: c.x - r, y: c.y }, { x: c.x + r, y: c.y });
    push({ x: c.x, y: c.y - r }, { x: c.x, y: c.y + r });
    return out;
  }
  if (d.radio > 0 && (pts.length === 1 || d.kind === 'arbol' || d.kind === 'arbusto' || d.kind === 'persona' || d.kind === 'columna')) {
    // Un elemento de radio se aproxima por su diámetro: es lo que se ve en planta.
    const c = pts[0], r = d.radio;
    push({ x: c.x - r, y: c.y }, { x: c.x + r, y: c.y });
    push({ x: c.x, y: c.y - r }, { x: c.x, y: c.y + r });
    return out;
  }
  for (let i = 0; i < pts.length - 1; i++) push(pts[i], pts[i + 1]);
  if (e.closed && pts.length > 2) push(pts[pts.length - 1], pts[0]);
  return out;
}

/**
 * Todos los segmentos que pueden cortar la visión, con su altura.
 *
 * Cuentan los obstáculos dibujados, las entidades marcadas como muro y —para no perder el
 * comportamiento anterior— la geometría de la capa de arquitectura, que se considera muro a la
 * altura por defecto si no dice otra cosa.
 */
export function segmentosOpacos(prj, alturaMuro = ALTURA_MURO) {
  const out = [];
  for (const e of (prj && prj.entities) || []) {
    if (e.type === 'text' || e.type === 'image') continue;
    const d = (e.data || {});
    if (e.type === 'obstacle') {
      if (d.opaco === false) continue;
      for (const s of segmentosDe(e)) out.push(s);
      continue;
    }
    if (e.type === 'camera' || e.type === 'device') continue;
    const esMuro = !!d.muro;
    const tieneAltura = d.altura !== undefined || d.h !== undefined;
    // La arquitectura del proyecto (muros, tabiques) se extruye siempre; el resto, solo si está
    // marcado expresamente: así un plano importado no «tapa» hasta que se dice qué son sus líneas.
    if (e.layer === 'ARQUITECTURA' || esMuro || tieneAltura) {
      const h = alturaEfectiva(e, alturaMuro);
      const base = d.base || 0;
      const pts = (e.points || []).filter(Boolean);
      if (e.radius && pts.length === 1) {
        const r = e.radius, c = pts[0];
        out.push({ a: { x: c.x - r, y: c.y }, b: { x: c.x + r, y: c.y }, base, h: base + h, opaco: true, kind: d.kind || 'muro', id: e.id });
        out.push({ a: { x: c.x, y: c.y - r }, b: { x: c.x, y: c.y + r }, base, h: base + h, opaco: true, kind: d.kind || 'muro', id: e.id });
        continue;
      }
      for (let i = 0; i < pts.length - 1; i++) {
        out.push({ a: pts[i], b: pts[i + 1], base, h: base + h, opaco: d.opaco !== false, kind: d.kind || 'muro', id: e.id });
      }
      if (e.closed && pts.length > 2) {
        out.push({ a: pts[pts.length - 1], b: pts[0], base, h: base + h, opaco: d.opaco !== false, kind: d.kind || 'muro', id: e.id });
      }
    }
  }
  return out;
}

/**
 * ¿Un segmento corta el rayo que va de `h0` a `h1`?
 *
 * `t` es el parámetro del segmento recta-rayo en el que se cruzan (0 en el origen, 1 en el destino).
 * La altura del rayo en ese punto es `h0 + t·(h1 − h0)`; el obstáculo corta si esa altura cae dentro
 * de su rango `[base, h]`. Un murete de 1,1 m no corta un rayo que pasa a 1,5 m por él, y una mesa de
 * 0,8 m no corta el rayo que va a la cara de una persona.
 */
export function cortaRayo(seg, h0, h1, t) {
  if (seg.opaco === false) return false;
  if (!(t > 0) || !(t < 1)) return false;                 // el cruce tiene que ser entre los dos extremos
  const z = h0 + (h1 - h0) * t;
  return z >= seg.base - 1e-9 && z <= seg.h + 1e-9;
}

/** Parámetro en el que el rayo a→b cruza el segmento s (de 0 a 1), o −1 si no se cruzan. */
export function parametroCruce(a, b, s) {
  const r = { x: b.x - a.x, y: b.y - a.y };
  const q = { x: s.b.x - s.a.x, y: s.b.y - s.a.y };
  const den = r.x * q.y - r.y * q.x;
  if (Math.abs(den) < 1e-12) return -1;
  const d = { x: s.a.x - a.x, y: s.a.y - a.y };
  const t = (d.x * q.y - d.y * q.x) / den;
  const u = (d.x * r.y - d.y * r.x) / den;
  if (t <= 1e-9 || t >= 1 - 1e-9) return -1;
  if (u < 0 || u > 1) return -1;
  return t;
}

/** Índice espacial de segmentos con altura, para no recorrerlos todos en cada celda. */
export class IndiceOpacos {
  constructor(segmentos, celda = 4) {
    this.celda = Math.max(0.5, celda);
    this.segmentos = segmentos;
    this.map = new Map();
    for (const s of segmentos) this._insert(s);
  }
  _key(ix, iy) { return ix + ':' + iy; }
  _insert(s) {
    const c = this.celda;
    const x0 = Math.floor(Math.min(s.a.x, s.b.x) / c), x1 = Math.floor(Math.max(s.a.x, s.b.x) / c);
    const y0 = Math.floor(Math.min(s.a.y, s.b.y) / c), y1 = Math.floor(Math.max(s.a.y, s.b.y) / c);
    for (let ix = x0; ix <= x1; ix++)
      for (let iy = y0; iy <= y1; iy++) {
        const k = this._key(ix, iy);
        let arr = this.map.get(k);
        if (!arr) this.map.set(k, (arr = []));
        if (!arr.includes(s)) arr.push(s);
      }
  }
  candidatos(a, b) {
    const c = this.celda;
    const x0 = Math.floor(Math.min(a.x, b.x) / c), x1 = Math.floor(Math.max(a.x, b.x) / c);
    const y0 = Math.floor(Math.min(a.y, b.y) / c), y1 = Math.floor(Math.max(a.y, b.y) / c);
    const out = [];
    for (let ix = x0; ix <= x1; ix++)
      for (let iy = y0; iy <= y1; iy++) {
        const arr = this.map.get(this._key(ix, iy));
        if (arr) for (const s of arr) if (!out.includes(s)) out.push(s);
      }
    return out;
  }
  /**
   * ¿El rayo que va de `a` (a la altura `h0`) a `b` (a la altura `h1`) está tapado?
   * Devuelve `false` o el segmento que lo tapa (para poder informar de qué lo tapa).
   */
  tapado(a, b, h0, h1) {
    for (const s of this.candidatos(a, b)) {
      const t = parametroCruce(a, b, s);
      if (t < 0) continue;
      if (cortaRayo(s, h0, h1, t)) return s;
    }
    return false;
  }
}

/* ---------------------------------------------------- volúmenes para el 3D */

/** Prisma rectangular a partir de una caja en planta y un rango de cotas. */
export function prisma(minX, minY, maxX, maxY, z0, z1, color, opacidad = 1) {
  const c = [
    { x: minX, y: minY, z: z0 }, { x: maxX, y: minY, z: z0 }, { x: maxX, y: maxY, z: z0 }, { x: minX, y: maxY, z: z0 },
    { x: minX, y: minY, z: z1 }, { x: maxX, y: minY, z: z1 }, { x: maxX, y: maxY, z: z1 }, { x: minX, y: maxY, z: z1 },
  ];
  return {
    tipo: 'prisma', color, opacidad,
    caras: [
      { puntos: [c[4], c[5], c[6], c[7]] },   // superior
      { puntos: [c[0], c[1], c[5], c[4]] },   // sur
      { puntos: [c[1], c[2], c[6], c[5]] },   // este
      { puntos: [c[2], c[3], c[7], c[6]] },   // norte
      { puntos: [c[3], c[0], c[4], c[7]] },   // oeste
    ].map((f) => ({ puntos: f.puntos, color, opacidad })),
  };
}

/** Caja a partir de un segmento (un muro), engordada `ancho` metros a cada lado. */
export function cajaDeSegmento(a, b, ancho, z0, z1, color, opacidad = 1) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const L = Math.hypot(dx, dy) || 1;
  const nx = (-dy / L) * (ancho / 2), ny = (dx / L) * (ancho / 2);
  const p = [
    { x: a.x + nx, y: a.y + ny }, { x: b.x + nx, y: b.y + ny },
    { x: b.x - nx, y: b.y - ny }, { x: a.x - nx, y: a.y - ny },
  ];
  const base = [
    { x: p[0].x, y: p[0].y, z: z0 }, { x: p[1].x, y: p[1].y, z: z0 },
    { x: p[2].x, y: p[2].y, z: z0 }, { x: p[3].x, y: p[3].y, z: z0 },
  ];
  const topo = base.map((v) => ({ x: v.x, y: v.y, z: z1 }));
  // El orden de los vértices deja la normal de cada cara mirando hacia fuera (regla de Newell):
  // si se invierte, la cara «de delante» se descarta al pintar y el muro se ve hueco.
  return {
    tipo: 'caja', color, opacidad,
    caras: [
      { puntos: [topo[3], topo[2], topo[1], topo[0]], color, opacidad },
      { puntos: [base[0], base[1], topo[1], topo[0]].reverse(), color, opacidad },
      { puntos: [base[1], base[2], topo[2], topo[1]].reverse(), color, opacidad },
      { puntos: [base[2], base[3], topo[3], topo[2]].reverse(), color, opacidad },
      { puntos: [base[3], base[0], topo[0], topo[3]].reverse(), color, opacidad },
    ],
  };
}

/** Cilindro (o cono si los radios difieren) aproximado por `lados` caras: árboles, personas. */
/** Prisma rectangular orientado o alineado a los ejes. */
export function prismaRect(centro, ancho, largo, z0, z1, color, rotacionDeg = 0, opacidad = 1) {
  const hw = ancho / 2, hl = largo / 2;
  const ang = (rotacionDeg * Math.PI) / 180;
  const cos = Math.cos(ang), sin = Math.sin(ang);
  const rot = (dx, dy) => ({
    x: centro.x + dx * cos - dy * sin,
    y: centro.y + dx * sin + dy * cos,
  });
  const c0 = rot(-hw, -hl), c1 = rot(hw, -hl), c2 = rot(hw, hl), c3 = rot(-hw, hl);
  const abajo = [
    { x: c0.x, y: c0.y, z: z0 },
    { x: c1.x, y: c1.y, z: z0 },
    { x: c2.x, y: c2.y, z: z0 },
    { x: c3.x, y: c3.y, z: z0 },
  ];
  const arriba = [
    { x: c0.x, y: c0.y, z: z1 },
    { x: c1.x, y: c1.y, z: z1 },
    { x: c2.x, y: c2.y, z: z1 },
    { x: c3.x, y: c3.y, z: z1 },
  ];
  return {
    tipo: 'prisma', color, opacidad,
    caras: [
      { puntos: arriba, color, opacidad },
      { puntos: [abajo[0], abajo[1], arriba[1], arriba[0]], color, opacidad },
      { puntos: [abajo[1], abajo[2], arriba[2], arriba[1]], color, opacidad },
      { puntos: [abajo[2], abajo[3], arriba[3], arriba[2]], color, opacidad },
      { puntos: [abajo[3], abajo[0], arriba[0], arriba[3]], color, opacidad },
    ],
  };
}

export function cilindro(centro, radio, z0, z1, color, lados = 8, opacidad = 1) {
  const caras = [];
  const anillo = (z, r) => {
    const out = [];
    for (let i = 0; i < lados; i++) {
      const a = (i / lados) * Math.PI * 2;
      out.push({ x: centro.x + Math.cos(a) * r, y: centro.y + Math.sin(a) * r, z });
    }
    return out;
  };
  const abajo = anillo(z0, radio), arriba = anillo(z1, radio);
  caras.push({ puntos: arriba, color, opacidad });
  for (let i = 0; i < lados; i++) {
    const j = (i + 1) % lados;
    caras.push({ puntos: [abajo[i], abajo[j], arriba[j], arriba[i]], color, opacidad });
  }
  return { tipo: 'cilindro', color, opacidad, caras };
}

/**
 * Cilindro entre dos puntos `a` y `b`, con el eje **donde haga falta**: ruedas, brazos, carcasas
 * de cámara tumbadas (una bala mira de lado, no hacia arriba). `cilindro()` solo sirve para ejes
 * verticales; este es el caso general y devuelve lo mismo si se le da un eje vertical.
 *
 * Con `radio2` distinto de `radio` sale un **cono truncado**: es lo que hace falta para las cúpulas
 * de los domos, que no son un tambor sino una cazoleta que se cierra por abajo.
 *
 * Las caras se **orientan hacia fuera** con `orientarHaciaFuera()`: si la normal quedara mirando al
 * interior, el pintado la descartaría por ser una cara trasera y el tambor saldría hueco.
 */
export function tambor(a, b, radio, color, lados = 8, opacidad = 1, radio2 = radio) {
  const eje = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z };
  const largo = Math.hypot(eje.x, eje.y, eje.z) || 1;
  const u = { x: eje.x / largo, y: eje.y / largo, z: eje.z / largo };
  // Dos vectores perpendiculares al eje: con ellos se barre el círculo. El vector de referencia se
  // cambia si el eje es casi vertical, que es cuando el producto vectorial degenera.
  const ref = Math.abs(u.z) < 0.9 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
  let p = { x: u.y * ref.z - u.z * ref.y, y: u.z * ref.x - u.x * ref.z, z: u.x * ref.y - u.y * ref.x };
  const lp = Math.hypot(p.x, p.y, p.z) || 1;
  p = { x: p.x / lp, y: p.y / lp, z: p.z / lp };
  const q = { x: u.y * p.z - u.z * p.y, y: u.z * p.x - u.x * p.z, z: u.x * p.y - u.y * p.x };
  const anillo = (c, r) => {
    const out = [];
    for (let i = 0; i < lados; i++) {
      const ang = (i / lados) * Math.PI * 2;
      const cs = Math.cos(ang) * r, sn = Math.sin(ang) * r;
      out.push({ x: c.x + p.x * cs + q.x * sn, y: c.y + p.y * cs + q.y * sn, z: c.z + p.z * cs + q.z * sn });
    }
    return out;
  };
  const A = anillo(a, radio), B = anillo(b, radio2);
  const dentro = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 };
  const cara = (pts) => ({ puntos: orientarHaciaFuera(pts, dentro), color, opacidad });
  const caras = [cara(A.slice()), cara(B.slice())];
  for (let i = 0; i < lados; i++) {
    const j = (i + 1) % lados;
    caras.push(cara([A[i], A[j], B[j], B[i]]));
  }
  return { tipo: 'tambor', color, opacidad, caras };
}

/** Voltea el orden de los vértices si la normal de la cara apunta hacia `dentro` (hacia el sólido). */
export function orientarHaciaFuera(pts, dentro) {
  const n = normalDePoligono(pts);
  let cx = 0, cy = 0, cz = 0;
  for (const v of pts) { cx += v.x; cy += v.y; cz += v.z || 0; }
  const k = pts.length || 1;
  cx /= k; cy /= k; cz /= k;
  if (n.x * (cx - dentro.x) + n.y * (cy - dentro.y) + n.z * (cz - dentro.z) < 0) pts.reverse();
  return pts;
}

/** Normal de Newell de un polígono de vértices `{x,y,z}`. */
export function normalDePoligono(pts) {
  let nx = 0, ny = 0, nz = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    nx += (a.y - b.y) * (a.z + b.z);
    ny += (a.z - b.z) * (a.x + b.x);
    nz += (a.x - b.x) * (a.y + b.y);
  }
  return { x: nx, y: ny, z: nz };
}

/* -------------------------------------------------- formas reconocibles (§8) */

/**
 * Un coche: chasis bajo, cabina retrasada y más estrecha, parabrisas y luneta de cristal, faros,
 * pilotos y **cuatro ruedas**. Antes era una caja con otra caja encima —valía de lejos, pero no se
 * distinguía de una mesa— y ahora se lee como un vehículo aparcado.
 *
 * El coche se orienta solo: mira a lo largo del lado mayor del rectángulo (`t` = 0 es el morro).
 * Es detalle de la vista 3D: para la cobertura sigue contando el bulto completo (§13), que es lo
 * conservador, así que ocluye exactamente lo mismo que antes.
 */
export function cocheDe(minX, minY, maxX, maxY, z0, z1, color, opacidad = 1) {
  const L = maxX - minX, W = maxY - minY, alto = z1 - z0;
  if (!(L > 0.05) || !(W > 0.05) || !(alto > 0.05)) return [];
  const apaisado = L >= W;
  const ancho = Math.min(L, W);
  // `t` recorre el largo (0 = morro, 1 = trasera) y `s` el ancho (0 y 1, los dos lados)
  const lo = (t) => (apaisado ? minX + L * t : minY + W * t);
  const an = (s) => (apaisado ? minY + W * s : minX + L * s);
  // `prisma` quiere mínimo y máximo por separado, así que se le dan ya ordenados según la orientación
  const caja = (t0, t1, s0, s1, za, zb, col, op) => (apaisado
    ? prisma(lo(t0), an(s0), lo(t1), an(s1), za, zb, col, op)
    : prisma(an(s0), lo(t0), an(s1), lo(t1), za, zb, col, op));
  const punto = (t, s, z) => (apaisado ? { x: lo(t), y: an(s), z } : { x: an(s), y: lo(t), z });

  const rRueda = Math.max(0.10, Math.min(0.36, alto * 0.20, ancho * 0.28));
  const gordor = Math.max(0.08, Math.min(0.22, ancho * 0.22));
  const zEje = z0 + rRueda;
  const zBajo = z0 + rRueda * 0.55;          // bajos: el chasis no llega al suelo, las ruedas sí
  const zCintura = z0 + alto * 0.60;        // línea de cintura: de ahí para arriba van las lunas
  const zTecho = z0 + alto * 0.93;
  const zFaro = z0 + alto * 0.40;
  const goma = '#23272e', cristal = '#8fbcd4';

  const vol = [];
  vol.push(caja(0.01, 0.99, 0.02, 0.98, zBajo, zCintura, color, opacidad));           // chasis
  vol.push(caja(0.30, 0.40, 0.08, 0.92, zCintura, z0 + alto * 0.84, cristal, 0.55));  // parabrisas
  vol.push(caja(0.40, 0.84, 0.06, 0.94, zCintura, zTecho, '#5c6b7e', 0.96));          // cabina
  vol.push(caja(0.40, 0.84, 0.06, 0.94, zTecho, z1, '#6d7d90', 0.96));                 // techo
  vol.push(caja(0.84, 0.90, 0.10, 0.90, zCintura, z0 + alto * 0.84, cristal, 0.5));   // luneta
  // Faros delante y pilotos detrás: dos puntos de luz que dicen por dónde mira el coche
  vol.push(caja(0.00, 0.05, 0.08, 0.24, zFaro, zFaro + alto * 0.09, '#ffe9a3', 0.95));
  vol.push(caja(0.00, 0.05, 0.76, 0.92, zFaro, zFaro + alto * 0.09, '#ffe9a3', 0.95));
  vol.push(caja(0.95, 1.00, 0.08, 0.24, zFaro, zFaro + alto * 0.09, '#c0563a', 0.95));
  vol.push(caja(0.95, 1.00, 0.76, 0.92, zFaro, zFaro + alto * 0.09, '#c0563a', 0.95));
  // Cuatro ruedas: el eje va de través, así que el disco se ve de lado (rueda, no zapata). Se
  // meten justo lo justo para que no sobresalgan del rectángulo: el bulto del coche no cambia.
  const canto = Math.min(0.45, (gordor / 2 + Math.min(0.01, ancho * 0.01)) / ancho);
  for (const t of [0.24, 0.76]) {
    for (const s of [canto, 1 - canto]) {
      const c = punto(t, s, zEje);
      const m = gordor / 2;
      const a = apaisado ? { x: c.x, y: c.y - m, z: zEje } : { x: c.x - m, y: c.y, z: zEje };
      const b = apaisado ? { x: c.x, y: c.y + m, z: zEje } : { x: c.x + m, y: c.y, z: zEje };
      vol.push(tambor(a, b, rRueda, goma, 8, 1));
    }
  }
  return vol;
}

/**
 * Una persona: dos piernas, tronco, cabeza y dos brazos. Con dos tambores (piernas y cuerpo) se
 * leía como un poste; separando la cabeza —más estrecha y más clara— y sacando los brazos, la
 * silueta se reconoce al momento, que es justo lo que hace falta cuando se usa de referencia de
 * altura (§13) para juzgar si una cámara ve a una persona.
 */
export function personaDe(centro, alto, z0, color, radio = 0.3) {
  const r = radio > 0 ? radio : 0.3;
  const zCadera = z0 + alto * 0.47;
  const zHombro = z0 + alto * 0.80;
  const zCuello = z0 + alto * 0.83;
  const pierna = Math.max(0.04, r * 0.34);
  const brazo = Math.max(0.03, r * 0.19);
  return [
    cilindro({ x: centro.x - r * 0.40, y: centro.y }, pierna, z0, zCadera, color, 6, 1),
    cilindro({ x: centro.x + r * 0.40, y: centro.y }, pierna, z0, zCadera, color, 6, 1),
    cilindro(centro, r * 0.92, zCadera - alto * 0.06, zHombro, color, 8, 1),      // tronco
    cilindro(centro, r * 0.42, zCuello, z0 + alto, '#e3d3ab', 6, 1),              // cabeza
    cilindro({ x: centro.x - r * 0.95, y: centro.y }, brazo, z0 + alto * 0.44, zHombro, color, 5, 1),
    cilindro({ x: centro.x + r * 0.95, y: centro.y }, brazo, z0 + alto * 0.44, zHombro, color, 5, 1),
  ];
}

/**
 * Volúmenes de una entidad para la vista 3D.
 * @returns {Array} lista de `{tipo, caras, color, opacidad}` (cada cara: `{puntos:[{x,y,z}]}`)
 */
/**
 * Escalera detallada en 3D con variantes ('recta', 'en_l', 'caracol'):
 * Modela con alto nivel de realismo: peldaños volumétricos individuales (huella + contrahuella),
 * descansillo intermedio si es en L, zancas estructurales laterales inclinadas,
 * balaustres verticales y pasamanos continuo de protección.
 */

/**
 * Estantería / Armario industrial: montantes metálicos en las esquinas, estantes horizontales
 * repartidos uniformemente y cruceta trasera de arriostramiento en X.
 * Deja ver entre baldas y transmite realismo frente a una caja maciza.
 */
export function estanteriaDe(minX, minY, maxX, maxY, z0, z1, color, opacidad = 1) {
  const L = maxX - minX, W = maxY - minY, alto = z1 - z0;
  if (!(L > 0.05) || !(W > 0.05) || !(alto > 0.05)) return [];
  const apaisado = L >= W;
  const colMetal = '#4b5563';
  const colBalda = color || '#9ca3af';
  const rPata = Math.min(0.04, Math.min(L, W) * 0.12);
  const vol = [];

  // 1. Cuatro montantes verticales angulares
  const margenX = Math.min(0.04, L * 0.08);
  const margenY = Math.min(0.04, W * 0.08);
  const xCoords = [minX + margenX, maxX - margenX];
  const yCoords = [minY + margenY, maxY - margenY];
  for (const cx of xCoords) {
    for (const cy of yCoords) {
      vol.push(cilindro({ x: cx, y: cy }, rPata, z0, z1, colMetal, 6, 1));
    }
  }

  // 2. Baldas horizontales (entre 3 y 6 según altura)
  const nEstantes = Math.max(3, Math.min(6, Math.round(alto / 0.45)));
  const grosorBalda = Math.min(0.035, alto * 0.03);
  for (let i = 0; i < nEstantes; i++) {
    const f = (i + 1) / nEstantes;
    const bZ1 = z0 + f * (alto - grosorBalda);
    const bZ0 = bZ1 - grosorBalda;
    vol.push(prisma(minX, minY, maxX, maxY, Math.max(z0, bZ0), bZ1, colBalda, opacidad));
  }

  // 3. Arriostramiento trasero en cruz (cruceta de San Andrés)
  if (apaisado) {
    // Fachada posterior a lo largo del eje X (minY)
    const yAtr = minY + margenY;
    vol.push(tambor({ x: minX + margenX, y: yAtr, z: z0 }, { x: maxX - margenX, y: yAtr, z: z1 }, 0.012, colMetal, 4, 0.9));
    vol.push(tambor({ x: minX + margenX, y: yAtr, z: z1 }, { x: maxX - margenX, y: yAtr, z: z0 }, 0.012, colMetal, 4, 0.9));
  } else {
    // Fachada posterior a lo largo del eje Y (minX)
    const xAtr = minX + margenX;
    vol.push(tambor({ x: xAtr, y: minY + margenY, z: z0 }, { x: xAtr, y: maxY - margenY, z: z1 }, 0.012, colMetal, 4, 0.9));
    vol.push(tambor({ x: xAtr, y: minY + margenY, z: z1 }, { x: xAtr, y: maxY - margenY, z: z0 }, 0.012, colMetal, 4, 0.9));
  }

  return vol;
}

/**
 * Maquinaria industrial / Generador / Climatizador:
 * Bancada inferior amortiguada, cuerpo principal con rejillas de ventilación y chimenea / extractor superior.
 */
export function maquinariaDe(minX, minY, maxX, maxY, z0, z1, color, opacidad = 1) {
  const L = maxX - minX, W = maxY - minY, alto = z1 - z0;
  if (!(L > 0.05) || !(W > 0.05) || !(alto > 0.05)) return [];
  const vol = [];
  const colBancada = '#2d3748';
  const colCuerpo = color || '#718096';
  const colExtractor = '#4a5568';

  // 1. Bancada perimetral estructural (perfiles inferiores)
  const hBancada = Math.min(0.12, alto * 0.12);
  vol.push(prisma(minX, minY, maxX, maxY, z0, z0 + hBancada, colBancada, 1));

  // 2. Chasis o módulo principal
  const mx = Math.min(0.05, L * 0.06);
  const my = Math.min(0.05, W * 0.06);
  const zCuerpo1 = z1 - Math.min(0.2, alto * 0.2);
  vol.push(prisma(minX + mx, minY + my, maxX - mx, maxY - my, z0 + hBancada, zCuerpo1, colCuerpo, opacidad));

  // 3. Extractor cilíndrico o campana de ventilación superior
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2;
  const rExtractor = Math.min(0.35, Math.min(L, W) * 0.3);
  vol.push(cilindro({ x: cx, y: cy }, rExtractor, zCuerpo1, z1, colExtractor, 10, 1));
  vol.push(cilindro({ x: cx, y: cy }, rExtractor * 1.15, z1 - 0.03, z1, '#2d3748', 10, 1));

  return vol;
}

export function escaleraDe(minX, minY, maxX, maxY, z0, z1, color, opacidad = 1, tipo = 'recta', rotacion = 0, opciones = {}) {
  const L = maxX - minX, W = maxY - minY, alto = Math.max(0.1, z1 - z0);
  if (!(L > 0.05) || !(W > 0.05)) return [];
  const apaisado = L >= W;
  const largo = Math.max(L, W), ancho = Math.min(L, W);
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  const colPeldao = color || '#949eaf';
  const colEstructura = '#5d6778';
  const colBarandilla = '#3d444f';
  const colPasamanos = '#23272e';
  const hBar = Math.min(1.0, Math.max(0.75, alto * 0.35));
  const rBar = 0.02;
  const conBarandilla = opciones.barandilla !== false;
  const vol = [];

  const rotP = (px, py, angDeg, ox = cx, oy = cy) => {
    const rad = (angDeg * Math.PI) / 180;
    const cos = Math.cos(rad), sin = Math.sin(rad);
    const dx = px - ox, dy = py - oy;
    return { x: ox + dx * cos - dy * sin, y: oy + dx * sin + dy * cos };
  };

  const rotPrisma = (x0, y0, x1, y1, za, zb, col, rotDeg, ox = cx, oy = cy) => {
    const midX = (x0 + x1) / 2, midY = (y0 + y1) / 2;
    const rotMid = rotP(midX, midY, rotDeg, ox, oy);
    return prismaRect(rotMid, x1 - x0, y1 - y0, za, zb, col, rotDeg, opacidad);
  };

  if (tipo === 'caracol') {
    const radio = Math.min(L, W) / 2;
    const radioEje = Math.max(0.08, radio * 0.16);
    // 1. Columna central metálica
    vol.push(cilindro({ x: cx, y: cy }, radioEje, z0, z1 + (conBarandilla ? hBar : 0), colEstructura, 12, opacidad));

    // 2. Peldaños en abanico helicoidal
    const numPeldanos = opciones.numPeldanos || Math.max(8, Math.min(24, Math.round(alto / 0.18)));
    const pasoAng = (Math.PI * 1.6) / numPeldanos;
    const angBase = (rotacion * Math.PI) / 180;
    const dz = alto / numPeldanos;
    const espesorP = Math.max(0.035, dz * 0.28);
    const puntosBarandilla = [];

    for (let i = 0; i < numPeldanos; i++) {
      const a0 = angBase + i * pasoAng;
      const a1 = a0 + pasoAng * 1.15;
      const pz0 = z0 + i * dz;
      const pz1 = pz0 + espesorP;

      const p0 = { x: cx + Math.cos(a0) * radioEje, y: cy + Math.sin(a0) * radioEje };
      const p1 = { x: cx + Math.cos(a0) * radio, y: cy + Math.sin(a0) * radio };
      const p2 = { x: cx + Math.cos(a1) * radio, y: cy + Math.sin(a1) * radio };
      const p3 = { x: cx + Math.cos(a1) * radioEje, y: cy + Math.sin(a1) * radioEje };

      const cPel = [
        { x: p0.x, y: p0.y, z: pz0 }, { x: p1.x, y: p1.y, z: pz0 },
        { x: p2.x, y: p2.y, z: pz0 }, { x: p3.x, y: p3.y, z: pz0 },
        { x: p0.x, y: p0.y, z: pz1 }, { x: p1.x, y: p1.y, z: pz1 },
        { x: p2.x, y: p2.y, z: pz1 }, { x: p3.x, y: p3.y, z: pz1 },
      ];
      vol.push({
        tipo: 'prisma', color: colPeldao, opacidad,
        caras: [
          { puntos: [cPel[4], cPel[5], cPel[6], cPel[7]], color: colPeldao, opacidad },
          { puntos: [cPel[0], cPel[1], cPel[5], cPel[4]], color: colPeldao, opacidad },
          { puntos: [cPel[1], cPel[2], cPel[6], cPel[5]], color: colPeldao, opacidad },
          { puntos: [cPel[2], cPel[3], cPel[7], cPel[6]], color: colPeldao, opacidad },
          { puntos: [cPel[3], cPel[0], cPel[4], cPel[7]], color: colPeldao, opacidad },
        ]
      });

      if (conBarandilla) {
        const rExt = radio * 0.94;
        const bx = cx + Math.cos(a0 + pasoAng * 0.5) * rExt;
        const by = cy + Math.sin(a0 + pasoAng * 0.5) * rExt;
        const bz = pz1;
        vol.push(tambor({ x: bx, y: by, z: bz }, { x: bx, y: by, z: bz + hBar }, rBar, colBarandilla, 6, opacidad));
        puntosBarandilla.push({ x: bx, y: by, z: bz + hBar });
      }
    }

    if (conBarandilla && puntosBarandilla.length > 1) {
      for (let i = 0; i < puntosBarandilla.length - 1; i++) {
        vol.push(tambor(puntosBarandilla[i], puntosBarandilla[i + 1], rBar * 1.3, colPasamanos, 6, opacidad));
      }
    }
    return vol;
  }

  if (tipo === 'en_l') {
    const angRot = rotacion;
    const wTramo = Math.max(0.6, Math.min(largo * 0.45, ancho * 0.95));
    const mitadH = alto / 2;
    const nP1 = Math.max(3, Math.round(mitadH / 0.18));
    const nP2 = nP1;
    const lenT1 = largo - wTramo;
    const dz1 = mitadH / nP1;
    const dx1 = lenT1 / nP1;

    // Tramo 1 (longitudinal)
    for (let i = 0; i < nP1; i++) {
      const xA = -largo / 2 + i * dx1;
      const xB = xA + dx1;
      const yA = -ancho / 2;
      const yB = yA + wTramo;
      const zP = z0 + (i + 1) * dz1;
      vol.push(rotPrisma(cx + xA, cy + yA, cx + xB, cy + yB, z0, zP, colPeldao, angRot));
    }

    // Descansillo de giro
    const dxA = -largo / 2 + lenT1, dxB = largo / 2;
    const dyA = -ancho / 2, dyB = -ancho / 2 + wTramo;
    vol.push(rotPrisma(cx + dxA, cy + dyA, cx + dxB, cy + dyB, z0, z0 + mitadH, colPeldao, angRot));

    // Tramo 2 (sube en ángulo perpendicular)
    const lenT2 = ancho - wTramo;
    const dz2 = mitadH / nP2;
    const dy2 = lenT2 / nP2;
    for (let j = 0; j < nP2; j++) {
      const xA = largo / 2 - wTramo;
      const xB = largo / 2;
      const yA = -ancho / 2 + wTramo + j * dy2;
      const yB = yA + dy2;
      const zP = z0 + mitadH + (j + 1) * dz2;
      vol.push(rotPrisma(cx + xA, cy + yA, cx + xB, cy + yB, z0 + mitadH, zP, colPeldao, angRot));
    }

    // Barandilla exterior y pasamanos
    if (conBarandilla) {
      const p1_0 = rotP(cx - largo / 2, cy - ancho / 2, angRot);
      const p1_mid = rotP(cx + largo / 2, cy - ancho / 2, angRot);
      const p2_top = rotP(cx + largo / 2, cy + ancho / 2, angRot);
      vol.push(tambor({ x: p1_0.x, y: p1_0.y, z: z0 }, { x: p1_0.x, y: p1_0.y, z: z0 + hBar }, rBar, colBarandilla, 6, opacidad));
      vol.push(tambor({ x: p1_mid.x, y: p1_mid.y, z: z0 + mitadH }, { x: p1_mid.x, y: p1_mid.y, z: z0 + mitadH + hBar }, rBar, colBarandilla, 6, opacidad));
      vol.push(tambor({ x: p2_top.x, y: p2_top.y, z: z1 }, { x: p2_top.x, y: p2_top.y, z: z1 + hBar }, rBar, colBarandilla, 6, opacidad));

      vol.push(tambor({ x: p1_0.x, y: p1_0.y, z: z0 + hBar }, { x: p1_mid.x, y: p1_mid.y, z: z0 + mitadH + hBar }, rBar * 1.3, colPasamanos, 6, opacidad));
      vol.push(tambor({ x: p1_mid.x, y: p1_mid.y, z: z0 + mitadH + hBar }, { x: p2_top.x, y: p2_top.y, z: z1 + hBar }, rBar * 1.3, colPasamanos, 6, opacidad));
    }

    return vol;
  }

  // Escalera Recta (por defecto)
  const numPeldanos = opciones.numPeldanos || Math.max(4, Math.min(32, Math.round(alto / 0.175)));
  const rotDeg = apaisado ? rotacion : rotacion + 90;
  const dLen = largo / numPeldanos;
  const dAlt = alto / numPeldanos;
  const espPeldao = Math.max(0.04, dAlt * 0.25);

  // 1. Peldaños individuales con huella y contrahuella
  for (let i = 0; i < numPeldanos; i++) {
    const lx0 = -largo / 2 + i * dLen;
    const lx1 = lx0 + dLen * 1.05;
    const ly0 = -ancho / 2;
    const ly1 = ancho / 2;
    const pz0 = z0 + i * dAlt;
    const pz1 = pz0 + espPeldao;

    vol.push(rotPrisma(cx + lx0, cy + ly0, cx + lx1, cy + ly1, pz0, pz1, colPeldao, rotDeg));
    if (i > 0) {
      vol.push(rotPrisma(cx + lx0 - 0.02, cy + ly0, cx + lx0 + 0.02, cy + ly1, pz0 - dAlt, pz0, colEstructura, rotDeg));
    }
  }

  // 2. Zancas laterales inclinadas
  const espesorZanca = Math.min(0.06, ancho * 0.08);
  const zancaA_0 = rotP(cx - largo / 2, cy - ancho / 2 + espesorZanca / 2, rotDeg);
  const zancaA_1 = rotP(cx + largo / 2, cy - ancho / 2 + espesorZanca / 2, rotDeg);
  const zancaB_0 = rotP(cx - largo / 2, cy + ancho / 2 - espesorZanca / 2, rotDeg);
  const zancaB_1 = rotP(cx + largo / 2, cy + ancho / 2 - espesorZanca / 2, rotDeg);

  vol.push(tambor({ x: zancaA_0.x, y: zancaA_0.y, z: z0 }, { x: zancaA_1.x, y: zancaA_1.y, z: z1 }, espesorZanca, colEstructura, 6, opacidad));
  vol.push(tambor({ x: zancaB_0.x, y: zancaB_0.y, z: z0 }, { x: zancaB_1.x, y: zancaB_1.y, z: z1 }, espesorZanca, colEstructura, 6, opacidad));

  // 3. Barandillas laterales con balaustres verticales y pasamanos continuo
  if (conBarandilla) {
    const numBalaustres = Math.max(3, Math.min(8, Math.round(largo / 0.8)));
    for (const s of [-1, 1]) {
      const offset = s * (ancho / 2 - espesorZanca / 2);
      const puntosPasamanos = [];
      for (let k = 0; k <= numBalaustres; k++) {
        const frac = k / numBalaustres;
        const lx = -largo / 2 + frac * largo;
        const ptBase = rotP(cx + lx, cy + offset, rotDeg);
        const zBase = z0 + frac * alto;
        const zTop = zBase + hBar;
        vol.push(tambor({ x: ptBase.x, y: ptBase.y, z: zBase }, { x: ptBase.x, y: ptBase.y, z: zTop }, rBar, colBarandilla, 6, opacidad));
        puntosPasamanos.push({ x: ptBase.x, y: ptBase.y, z: zTop });
      }
      for (let k = 0; k < puntosPasamanos.length - 1; k++) {
        vol.push(tambor(puntosPasamanos[k], puntosPasamanos[k + 1], rBar * 1.35, colPasamanos, 6, opacidad));
      }
    }
  }

  return vol;
}

export function volumenesDe(e, alturaMuro = ALTURA_MURO) {
  const d = datosDe(e);
  const pts = (e.points || []).filter(Boolean);
  if (!pts.length) return [];
  const alto = alturaEfectiva(e, alturaMuro);
  const z0 = d.base, z1 = d.base + alto;
  const color = d.color;
  const opacidad = d.opaco ? 1 : 0.45;
  const out = [];
  const punto = d.kind === 'arbol' || d.kind === 'arbusto' || d.kind === 'persona' || d.kind === 'columna'
    || (d.radio > 0 && pts.length === 1);
  if (punto) {
    const r = d.radio || 0.3;
    if (d.kind === 'arbol') {
      // Un árbol: tronco fino y copa en **dos niveles**, más ancha abajo y más estrecha arriba, con
      // dos tonos. Un solo tambor se lee como una chimenea; dos, como una copa.
      const zTronco = z0 + Math.min(1.6, alto * 0.35);
      const zMedio = z0 + alto * 0.62;
      out.push(cilindro(pts[0], Math.max(0.12, r * 0.12), z0, zTronco, '#5b4a3a', 6, 1));
      out.push(cilindro(pts[0], r, z0 + alto * 0.3, zMedio, color, 10, 0.92));
      out.push(cilindro(pts[0], r * 0.68, zMedio - alto * 0.08, z1, '#5f8d63', 10, 0.92));
    } else if (d.kind === 'arbusto') {
      // Un seto no es un tambor: tres copas solapadas y desplazadas, más natural (y más barato)
      // que subir el número de lados.
      const paso = Math.max(0.25, r * 0.55);
      out.push(cilindro(pts[0], r, z0, z1, color, 7, 1));
      out.push(cilindro({ x: pts[0].x + paso * 0.7, y: pts[0].y + paso * 0.2 }, r * 0.68, z0, z0 + alto * 0.92, '#557a4f', 7, 1));
      out.push(cilindro({ x: pts[0].x - paso * 0.6, y: pts[0].y - paso * 0.35 }, r * 0.6, z0, z0 + alto * 0.84, '#47663f', 7, 1));
    } else if (d.kind === 'columna') {
      // Basa, fuste y capitel: tres piezas. Si es redonda son 3 cilindros/tambores;
      // si es cuadrada o rectangular son 3 prismas proporcionados.
      const remate = Math.min(0.18, alto * 0.06);
      const forma = d.forma || 'redonda';
      if (forma === 'cuadrada' || forma === 'rectangular') {
        const w = d.ancho || (r * 2);
        const l = d.largo || (forma === 'cuadrada' ? w : r * 2);
        const rot = d.rotacion || 0;
        out.push(prismaRect(pts[0], w * 1.18, l * 1.18, z0, z0 + remate, '#8f9aab', rot, 1));
        out.push(prismaRect(pts[0], w, l, z0 + remate, z1 - remate, color, rot, 1));
        out.push(prismaRect(pts[0], w * 1.18, l * 1.18, z1 - remate, z1, '#96a1b2', rot, 1));
      } else {
        out.push(cilindro(pts[0], r * 1.18, z0, z0 + remate, '#8f9aab', 8, 1));
        out.push(cilindro(pts[0], r, z0 + remate, z1 - remate, color, 8, 1));
        out.push(cilindro(pts[0], r * 1.18, z1 - remate, z1, '#96a1b2', 8, 1));
      }
    } else if (d.kind === 'persona') {
      return out.concat(personaDe(pts[0], alto, z0, color, r));
    } else {
      out.push(cilindro(pts[0], r, z0, z1, color, d.kind === 'columna' ? 8 : 8, opacidad));
    }
    return out;
  }
  if (d.techo || (e.closed && pts.length > 2 && (d.kind === 'techo' || d.kind === 'cubierta' || d.kind === 'mobiliario'
    || d.kind === 'estanteria' || d.kind === 'maquinaria' || d.kind === 'vehiculo' || d.kind === 'escalera'))) {
    // Superficies: se extruyen como una losa desde su base
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of pts) {
      minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
    }
    if (d.kind === 'vehiculo') {
      return out.concat(cocheDe(minX, minY, maxX, maxY, z0, z1, color, opacidad));
    }
    if (d.kind === 'escalera') {
      return out.concat(escaleraDe(minX, minY, maxX, maxY, z0, z1, color, opacidad, d.tipoEscalera, d.rotacion || 0, {
        barandilla: d.barandilla,
        numPeldanos: d.numPeldanos,
      }));
    }
    if (d.kind === 'estanteria') {
      return out.concat(estanteriaDe(minX, minY, maxX, maxY, z0, z1, color, opacidad));
    }
    if (d.kind === 'maquinaria') {
      return out.concat(maquinariaDe(minX, minY, maxX, maxY, z0, z1, color, opacidad));
    }
    if (d.kind === 'mobiliario') {
      // Una mesa: tablero y cuatro patas. Es lo que hace que se lea «mesa» y no «bloque gris», y es
      // además lo que de verdad ve la cámara: por debajo del tablero **se ve**, y eso importa.
      const grueso = Math.min(0.07, Math.max(0.03, (z1 - z0) * 0.09));
      const zTab = z1 - grueso;
      const lado = Math.min(0.08, Math.min(maxX - minX, maxY - minY) * 0.16);
      const dx = Math.min(0.12, (maxX - minX) * 0.12), dy = Math.min(0.12, (maxY - minY) * 0.12);
      const pata = (cx, cy) => prisma(cx - lado / 2, cy - lado / 2, cx + lado / 2, cy + lado / 2, z0, zTab, '#6a7382', 1);
      out.push(prisma(minX, minY, maxX, maxY, zTab, z1, color, opacidad));      // tablero
      out.push(pata(minX + dx, minY + dy), pata(maxX - dx, minY + dy),
        pata(minX + dx, maxY - dy), pata(maxX - dx, maxY - dy));
      return out;
    }
    out.push(prisma(minX, minY, maxX, maxY, z0, z1, color, opacidad));
    return out;
  }
  if (e.closed && pts.length > 2) {
    // Polígono cerrado: prisma con la silueta exacta. Se comprueba el sentido del contorno porque
    // lo mismo da dibujarlo en un sentido que en el otro, y de eso depende qué cara quede visible.
    const silueta = area2d(pts) < 0 ? pts.slice().reverse() : pts;
    const abajo = silueta.map((p) => ({ x: p.x, y: p.y, z: z0 }));
    const arriba = silueta.map((p) => ({ x: p.x, y: p.y, z: z1 }));
    const caras = [{ puntos: arriba.slice().reverse(), color, opacidad }];
    for (let i = 0; i < silueta.length; i++) {
      const j = (i + 1) % silueta.length;
      caras.push({ puntos: [abajo[i], abajo[j], arriba[j], arriba[i]], color, opacidad });
    }
    out.push({ tipo: 'prisma', color, opacidad, caras });
    return out;
  }
  // Líneas y cadenas: un muro por segmento
  const ancho = d.ancho || 0.1;
  for (let i = 0; i < pts.length - 1; i++) out.push(cajaDeSegmento(pts[i], pts[i + 1], ancho, z0, z1, color, opacidad));
  if (e.closed && pts.length > 2) out.push(cajaDeSegmento(pts[pts.length - 1], pts[0], ancho, z0, z1, color, opacidad));
  return out;
}

/** Área con signo de un polígono en planta: dice si el contorno va en un sentido o en el otro. */
export function area2d(pts) {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i], q = pts[(i + 1) % pts.length];
    a += p.x * q.y - q.x * p.y;
  }
  return a / 2;
}

/** Volúmenes de todo el proyecto: muros, obstáculos, techos… (todo menos cámaras y equipos). */
export function volumenesDelProyecto(prj, alturaMuro = ALTURA_MURO) {
  const out = [];
  for (const e of (prj && prj.entities) || []) {
    if (!esElemento3d(e)) continue;
    for (const v of volumenesDe(e, alturaMuro)) {
      v.id = e.id; v.kind = (e.data || {}).kind || 'muro'; v.etiqueta = datosDe(e).etiqueta;
      out.push(v);
    }
  }
  return out;
}

/** Cuántos muros (y de qué altura) hay marcados en el proyecto. */
export function resumenMuros(prj) {
  let muros = 0, obstaculos = 0, alturas = new Set();
  for (const e of (prj && prj.entities) || []) {
    if (e.type === 'obstacle') { obstaculos++; const d = datosDe(e); alturas.add(Math.round(d.altura * 100) / 100); }
    else if (e.data && e.data.muro) { muros++; const d = datosDe(e); alturas.add(Math.round(d.altura * 100) / 100); }
  }
  return { muros, obstaculos, alturas: [...alturas].sort((a, b) => a - b) };
}
