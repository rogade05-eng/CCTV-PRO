/**
 * CCTV DESIGN PRO — Motor de grabación y almacenamiento (CP CCTV §21)
 * Cálculo decimal (1 GB = 10^9 bytes), criterio habitual en videovigilancia.
 */
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';
import { cameraRules } from './analytics.js?v=b441e3fc';

const CODEC_FACTOR = { 'H.264': 1.6, 'H.264+': 1.15, 'H.265': 1.0, 'H.265+': 0.75, MJPEG: 4.0, '-': 0 };

export function cameraBitrate(camera, catalog, settings = {}) {
  const item = getItem(catalog, camera.data.catalogId);
  const s = (item && item.specs) || {};
  const base = Number(s.bitrate) || 0;
  if (!base) return { kbps: 0, note: 'Cámara sin bitrate (analógica o sin dato)' };
  const fpsRef = Number(s.fps) || 25;
  const fps = Number(camera.data.fps || s.fps || 25);
  const codecFactor = CODEC_FACTOR[s.codec] === undefined ? 1 : CODEC_FACTOR[s.codec];
  const cbr = camera.data.bitrateMode === 'cbr' && camera.data.bitrate ? Number(camera.data.bitrate) : 0;
  // Un PTZ en patrulla graba una escena en movimiento: se aplica el factor de patrulla (§38)
  const patrol = !!s.ptz && (camera.data.presets || []).length > 0 && camera.data.ptzPatrol !== false;
  const ptzFactor = patrol ? Number(settings.ptzFactor || 1) : 1;
  const kbps = cbr || base * (fps / fpsRef) * codecFactor * (settings.bitrateFactor || 1) * ptzFactor;
  const extra = patrol ? ` · patrulla ×${ptzFactor}` : '';
  return { kbps, note: `${Math.round(kbps)} kbps (${s.codec} · ${fps} fps · ${s.resW}×${s.resH}${extra})`, patrol };
}

/** GB por cámara para el periodo configurado. */
export function storageFor(kbps, days, hoursPerDay = 24, duty = 1) {
  const seconds = days * hoursPerDay * 3600 * duty;
  return (kbps * 1000 * seconds) / 8 / 1e9;
}

export function computeStorage(prj, catalog, rules) {
  const days = ruleNum(rules, 'DIAS_GRABACION');
  const hours = ruleNum(rules, 'HORAS_GRABACION');
  const reservePct = ruleNum(rules, 'RESERVA_DISCO');
  const settings = Object.assign({}, prj.settings || {}, { ptzFactor: ruleNum(rules, 'PTZ_FACTOR_BITRATE') });
  const duty = settings.recordMode === 'motion' ? (settings.motionDuty || 0.35) : 1;
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const perCamera = [];
  let totalKbps = 0, totalGb = 0;

  for (const cam of cams) {
    const { kbps, note, patrol } = cameraBitrate(cam, catalog, settings);
    const gb = storageFor(kbps, days, hours, duty);
    totalKbps += kbps; totalGb += gb;
    perCamera.push({
      id: cam.id, label: cam.data.label || cam.id, patrol: !!patrol,
      kbps: Math.round(kbps), gbPerDay: gb / Math.max(days, 1), gb, note,
      recording: settings.recordMode === 'motion' ? 'Detección de movimiento' : '24×7',
    });
  }

  // El módulo de analítica añade un flujo de metadatos por cámara con reglas activas (§38)
  const metaKbps = cams.filter((c) => cameraRules(c).length > 0).length * ruleNum(rules, 'ANALITICA_KBPS');
  const metaGb = storageFor(metaKbps, days, hours, 1);
  const totalWithMeta = totalGb + metaGb;
  const requiredGb = totalWithMeta * (1 + reservePct / 100);
  const requiredTb = requiredGb / 1000;
  const totalMbps = totalKbps / 1000;
  // Graban tanto el NVR (IP) como el DVR híbrido del módulo analógico (§38)
  const nvrs = prj.entities.filter((e) => e.type === 'device' && (e.data.kind === 'nvr' || e.data.kind === 'dvr'));
  let channels = 0, capacityMbps = 0, bays = 0;
  const nvrInfo = nvrs.map((n) => {
    const it = getItem(catalog, n.data.catalogId);
    const s = (it && it.specs) || {};
    channels += Number(s.channels) || 0;
    capacityMbps += Number(s.maxMbps) || 0;
    bays += Number(s.bays) || 0;
    const disks = (n.data.disks || []).map((d) => {
      const di = getItem(catalog, d.itemId);
      return { itemId: d.itemId, qty: d.qty, tb: ((di && di.specs && di.specs.tb) || 0) * d.qty, model: di ? di.model : d.itemId };
    });
    const installedTb = disks.reduce((a, d) => a + d.tb, 0);
    return { id: n.id, label: n.data.label || n.id, model: it ? it.model : '?', channels: Number(s.channels) || 0,
      maxMbps: Number(s.maxMbps) || 0, bays: Number(s.bays) || 0, disks, installedTb };
  });
  const installedTb = nvrInfo.reduce((a, n) => a + n.installedTb, 0);
  const retention = installedTb > 0 && totalWithMeta > 0 ? (installedTb * 1000) / (totalWithMeta / Math.max(days, 1) * (1 + reservePct / 100)) : 0;

  const rec = recommendDisks(requiredTb, bays, catalog);

  return {
    days, hours, duty, reservePct, perCamera, metaKbps, metaGb,
    videoGb: totalGb, totalKbps: totalKbps + metaKbps, totalMbps: (totalKbps + metaKbps) / 1000,
    totalGb: totalWithMeta, totalTb: totalWithMeta / 1000,
    requiredGb, requiredTb, installedTb, retentionDays: retention,
    capacityOk: capacityMbps === 0 ? null : totalMbps <= capacityMbps,
    channelsOk: channels === 0 ? null : cams.length <= channels,
    channels, capacityMbps, bays, nvrInfo, recommendation: rec,
    enough: installedTb >= requiredTb,
  };
}

/** Combinación de discos de menor coste que cubre la capacidad necesaria y cabe en las bahías. */
export function recommendDisks(requiredTb, bays, catalog) {
  const disks = catalog.items.filter((i) => i.category === 'disk' && i.specs && i.specs.tb);
  if (!disks.length || requiredTb <= 0) return null;
  const options = [];
  for (const d of disks) {
    const tb = Number(d.specs.tb);
    const qty = Math.ceil(requiredTb / tb);
    if (bays > 0 && qty > bays) continue;
    options.push({ itemId: d.id, model: d.model, tbEach: tb, qty, totalTb: qty * tb, cost: qty * (Number(d.price) || 0) });
  }
  if (!options.length) {
    const biggest = disks.slice().sort((a, b) => b.specs.tb - a.specs.tb)[0];
    return { itemId: biggest.id, model: biggest.model, tbEach: biggest.specs.tb, qty: Math.ceil(requiredTb / biggest.specs.tb),
      totalTb: Math.ceil(requiredTb / biggest.specs.tb) * biggest.specs.tb, cost: 0, infeasible: true,
      note: 'La capacidad requerida no cabe en las bahías disponibles: se necesita un NVR con más bahías o unidades externas.' };
  }
  return options.sort((a, b) => a.cost - b.cost || a.totalTb - b.totalTb)[0];
}

/** Recomendación de NVR según cámaras y ancho de banda. */
export function recommendNvr(prj, catalog, storage) {
  const cams = prj.entities.filter((e) => e.type === 'camera').length;
  const mbps = storage.totalMbps * 1.2;
  const cands = catalog.items.filter((i) => i.category === 'nvr' && !(i.specs && i.specs.hybrid))
    .filter((i) => i.specs.channels >= cams && Number(i.specs.maxMbps) >= mbps)
    .sort((a, b) => a.specs.channels - b.specs.channels || a.price - b.price);
  return cands[0] || null;
}
