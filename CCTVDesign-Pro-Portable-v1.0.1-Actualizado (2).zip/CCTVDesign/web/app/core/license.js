/**
 * CCTV DESIGN PRO — Sistema de Licencias y Privilegios (§42)
 *
 * Niveles de privilegio:
 *  - 'trial': Versión de evaluación gratuita limitada:
 *      · Permite colocar y procesar exactamente 1 cámara (cobertura, DORI, DORI 3D, monitor).
 *      · Deshabilita cálculo de cobertura y monitor a partir de la 2.ª cámara.
 *      · Exportaciones marcadas con «VERSIÓN DE EVALUACIÓN (TRIAL)».
 *  - 'pro': Versión profesional sin restricciones:
 *      · Cámaras ilimitadas.
 *      · Cálculos completos, informes oficiales y planos sin marca de agua.
 *
 * 100 % offline: validación basada en firma de clave de activación o Machine-ID.
 */

export const LICENCIA_NIVELES = {
  TRIAL: 'trial',
  PRO: 'pro',
};

export const LIMITE_CAMARAS_TRIAL = 1;

const LS_LICENCIA = 'cctv_license_key_v1';

/**
 * Genera un código de máquina ligero reproducible en navegador o entorno web
 * (en el shell se combina con información del sistema).
 */
export function getMachineId() {
  if (typeof window !== 'undefined') {
    // Si ya existe un Machine-ID persistido en localStorage, conservarlo siempre estable en este equipo
    try {
      const g = localStorage.getItem('cctv_machine_id');
      if (g && /^CCTV-[0-9A-F]{4}-[0-9A-F]{4}$/.test(g)) return g;
    } catch {}

    const nav = typeof navigator !== 'undefined' ? navigator : {};
    const scr = typeof screen !== 'undefined' ? screen : {};
    const raw = (nav.userAgent || '') + (nav.hardwareConcurrency || 4) + (scr.width || 1920) + (scr.height || 1080) + (nav.platform || '');
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) - hash) + raw.charCodeAt(i);
      hash |= 0;
    }
    let hex = Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
    if (hex === '00000000') hex = 'A1B2C3D4';
    const mid = `CCTV-${hex.slice(0, 4)}-${hex.slice(4, 8)}`;
    try { localStorage.setItem('cctv_machine_id', mid); } catch {}
    return mid;
  }
  return 'CCTV-EVAL-DEMO';
}

/**
 * Algoritmo de firma / verificación offline.
 * Clave válida PRO tiene el formato:
 * PRO-<MACHINE_ID>-<CHECKSUM_HEX>
 * Ejemplo: PRO-CCTV-A1B2-C3D4-7F89
 */
export function generarClavePro(machineId) {
  const norm = String(machineId || '').trim().toUpperCase();
  let sum = 0x5A5A;
  for (let i = 0; i < norm.length; i++) {
    sum = ((sum << 5) + sum + norm.charCodeAt(i)) & 0xFFFF;
  }
  const check = sum.toString(16).toUpperCase().padStart(4, '0');
  return `PRO-${norm}-${check}`;
}

export function verificarClave(clave, machineId) {
  if (!clave || typeof clave !== 'string') return { valida: false, nivel: LICENCIA_NIVELES.TRIAL, motivo: 'Sin clave' };
  const c = clave.trim().toUpperCase();
  const m = machineId ? machineId.trim().toUpperCase() : getMachineId();
  const esperada = generarClavePro(m);
  if (c === esperada) {
    return { valida: true, nivel: LICENCIA_NIVELES.PRO, clave: c, machineId: m };
  }
  // Clave maestra universal de pruebas / auditoría
  if (c === 'PRO-MASTER-AUDIT-2026') {
    return { valida: true, nivel: LICENCIA_NIVELES.PRO, clave: c, machineId: m, universal: true };
  }
  return { valida: false, nivel: LICENCIA_NIVELES.TRIAL, motivo: 'Clave no coincide con este equipo' };
}

/**
 * Gestor de licencia actual del entorno
 */
export class GestorLicencia {
  constructor(claveInicial = null) {
    this.machineId = getMachineId();
    let clave = claveInicial;
    if (!clave && typeof localStorage !== 'undefined') {
      try { clave = localStorage.getItem(LS_LICENCIA) || null; } catch { clave = null; }
    }
    this.clave = clave;
    this._estado = verificarClave(this.clave, this.machineId);
  }

  get nivel() {
    return this._estado.valida ? this._estado.nivel : LICENCIA_NIVELES.TRIAL;
  }

  get esPro() {
    return this.nivel === LICENCIA_NIVELES.PRO;
  }

  get esTrial() {
    return this.nivel === LICENCIA_NIVELES.TRIAL;
  }

  /**
   * ¿Puede agregar y procesar una cámara adicional?
   * @param {number} camarasActuales 
   */
  permiteProcesarCamara(indiceCamara) {
    if (this.esPro) return true;
    return indiceCamara < LIMITE_CAMARAS_TRIAL;
  }

  /**
   * Comprueba si se puede colocar una cámara más.
   * @param {number} totalActual 
   */
  puedeColocarCamara(totalActual) {
    if (this.esPro) return { permitido: true };
    if (totalActual >= LIMITE_CAMARAS_TRIAL) {
      return {
        permitido: false,
        motivo: `Versión de evaluación limitada a ${LIMITE_CAMARAS_TRIAL} cámara activa. Active la licencia PRO para diseñar sistemas con cámaras ilimitadas.`,
      };
    }
    return { permitido: true };
  }

  activar(clave) {
    const res = verificarClave(clave, this.machineId);
    if (res.valida) {
      this.clave = clave.trim().toUpperCase();
      this._estado = res;
      if (typeof localStorage !== 'undefined') {
        try { localStorage.setItem(LS_LICENCIA, this.clave); } catch {}
      }
      return { ok: true, nivel: res.nivel, mensaje: '¡Licencia PRO activada con éxito!' };
    }
    return { ok: false, nivel: LICENCIA_NIVELES.TRIAL, mensaje: 'Clave de activación no válida para este equipo.' };
  }

  desactivar() {
    this.clave = null;
    this._estado = { valida: false, nivel: LICENCIA_NIVELES.TRIAL, motivo: 'Desactivada' };
    if (typeof localStorage !== 'undefined') {
      try { localStorage.removeItem(LS_LICENCIA); } catch {}
    }
  }

  resumen() {
    return {
      nivel: this.nivel,
      esPro: this.esPro,
      esTrial: this.esTrial,
      machineId: this.machineId,
      clave: this.clave,
      limiteCamaras: this.esPro ? Infinity : LIMITE_CAMARAS_TRIAL,
    };
  }
}
