/**
 * CCTV DESIGN PRO — Motor de cableado y generador de rutas (CP CCTV §16, §17, §18)
 * A* sobre rejilla con obstáculos, bandejas portacables y waypoints.
 */
import { bbox, bboxOf, polyLength, simplify, entitySegments, distPointSeg } from './geometry.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';
import { isAnalog, analogConfig } from './analog.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';

/* ------------------------------ heap binario ------------------------------ */
class MinHeap {
  constructor() { this.a = []; }
  get size() { return this.a.length; }
  push(node) {
    const a = this.a; a.push(node);
    let i = a.length - 1;
    while (i > 0) { const p = (i - 1) >> 1; if (a[p].f <= a[i].f) break; [a[p], a[i]] = [a[i], a[p]]; i = p; }
  }
  pop() {
    const a = this.a, top = a[0], last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1; let m = i;
        if (l < a.length && a[l].f < a[m].f) m = l;
        if (r < a.length && a[r].f < a[m].f) m = r;
        if (m === i) break;
        [a[m], a[i]] = [a[i], a[m]]; i = m;
      }
    }
    return top;
  }
}

export class RouteGrid {
  constructor(prj, rules) {
    const cell = Math.max(0.1, ruleNum(rules, 'CELDA_RUTA'));
    this.cell = cell;
    let bb = null;
    for (const e of prj.entities) {
      if (!e.points || !e.points.length) continue;
      if (e.type === 'text' || e.type === 'image') continue;
      bb = bb ? bboxOf(bb, bbox(e.points)) : bbox(e.points);
    }
    if (!bb) bb = { minX: 0, minY: 0, maxX: 10, maxY: 10 };
    const pad = 1.5;
    this.bb = { minX: bb.minX - pad, minY: bb.minY - pad, maxX: bb.maxX + pad, maxY: bb.maxY + pad };
    this.cols = Math.max(2, Math.ceil((this.bb.maxX - this.bb.minX) / cell));
    this.rows = Math.max(2, Math.ceil((this.bb.maxY - this.bb.minY) / cell));
    this.blocked = new Uint8Array(this.cols * this.rows);
    this.tray = new Uint8Array(this.cols * this.rows);

    const mark = (x, y, arr, val = 1) => {
      const ix = Math.round((x - this.bb.minX) / cell), iy = Math.round((y - this.bb.minY) / cell);
      if (ix < 0 || iy < 0 || ix >= this.cols || iy >= this.rows) return;
      arr[iy * this.cols + ix] = val;
    };

    // Obstáculos: muros y tabiquería.
    for (const e of prj.entities) {
      if (e.layer !== 'ARQUITECTURA' || e.type === 'text' || e.type === 'image') continue;
      for (const s of entitySegments(e)) {
        const d = Math.hypot(s.b.x - s.a.x, s.b.y - s.a.y);
        const steps = Math.max(1, Math.ceil(d / (cell * 0.4)));
        for (let i = 0; i <= steps; i++) mark(s.a.x + ((s.b.x - s.a.x) * i) / steps, s.a.y + ((s.b.y - s.a.y) * i) / steps, this.blocked);
      }
    }
    // Inflado de una celda para separar el cable del muro.
    this.blockedInflated = new Uint8Array(this.blocked);
    for (let iy = 0; iy < this.rows; iy++)
      for (let ix = 0; ix < this.cols; ix++) {
        if (!this.blocked[iy * this.cols + ix]) continue;
        for (let dy = -1; dy <= 1; dy++)
          for (let dx = -1; dx <= 1; dx++) {
            const x = ix + dx, y = iy + dy;
            if (x >= 0 && y >= 0 && x < this.cols && y < this.rows) this.blockedInflated[y * this.cols + x] = 1;
          }
      }
    // Bandejas y canalizaciones: coste reducido.
    const trays = prj.entities.filter((e) => e.layer === 'CANALIZACIONES' && e.points.length > 1);
    if (trays.length) {
      const segs = [];
      for (const t of trays) for (const s of entitySegments(t)) segs.push(s);
      for (let iy = 0; iy < this.rows; iy++)
        for (let ix = 0; ix < this.cols; ix++) {
          const x = this.bb.minX + ix * cell, y = this.bb.minY + iy * cell;
          for (const s of segs) if (distPointSeg({ x, y }, s.a, s.b) < Math.max(0.35, cell)) { this.tray[iy * this.cols + ix] = 1; break; }
        }
    }
  }

  toCell(p) {
    return {
      ix: Math.min(this.cols - 1, Math.max(0, Math.round((p.x - this.bb.minX) / this.cell))),
      iy: Math.min(this.rows - 1, Math.max(0, Math.round((p.y - this.bb.minY) / this.cell))),
    };
  }
  toWorld(ix, iy) { return { x: this.bb.minX + ix * this.cell, y: this.bb.minY + iy * this.cell }; }
  key(ix, iy) { return iy * this.cols + ix; }
  isFree(ix, iy, map) { return ix >= 0 && iy >= 0 && ix < this.cols && iy < this.rows && !map[this.key(ix, iy)]; }

  /** A* 8-direcciones sin cortes de esquina. */
  astar(from, to, useInflated = true) {
    const map = useInflated ? this.blockedInflated : this.blocked;
    const s = this.toCell(from), g = this.toCell(to);
    // Permitir siempre origen y destino aunque caigan en celda bloqueada.
    const start = this.key(s.ix, s.iy), goal = this.key(g.ix, g.iy);
    const gScore = new Float64Array(this.cols * this.rows).fill(Infinity);
    const came = new Int32Array(this.cols * this.rows).fill(-1);
    const closed = new Uint8Array(this.cols * this.rows);
    gScore[start] = 0;
    const h = (ix, iy) => {
      const dx = Math.abs(ix - g.ix), dy = Math.abs(iy - g.iy);
      return (Math.max(dx, dy) + (Math.SQRT2 - 2) * Math.min(dx, dy)) * this.cell;
    };
    const heap = new MinHeap();
    heap.push({ i: start, f: h(s.ix, s.iy) });
    const DIRS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, Math.SQRT2], [1, -1, Math.SQRT2], [-1, 1, Math.SQRT2], [-1, -1, Math.SQRT2]];
    while (heap.size) {
      const cur = heap.pop();
      if (cur.i === goal) {
        const path = [];
        let k = goal;
        while (k !== -1) { path.push(this.toWorld(k % this.cols, Math.floor(k / this.cols))); if (k === start) break; k = came[k]; }
        return path.reverse();
      }
      if (closed[cur.i]) continue;
      closed[cur.i] = 1;
      const ix = cur.i % this.cols, iy = Math.floor(cur.i / this.cols);
      for (const [dx, dy, w] of DIRS) {
        const nx = ix + dx, ny = iy + dy;
        if (nx < 0 || ny < 0 || nx >= this.cols || ny >= this.rows) continue;
        const nk = this.key(nx, ny);
        if (closed[nk]) continue;
        if (nk !== goal && map[nk]) continue;
        if (w > 1 && (map[this.key(ix + dx, iy)] || map[this.key(ix, iy + dy)])) continue; // sin cortar esquinas
        const trayCost = this.tray[nk] ? 0.35 : 1;
        const tentative = gScore[cur.i] + w * this.cell * trayCost;
        if (tentative < gScore[nk]) {
          gScore[nk] = tentative; came[nk] = cur.i;
          heap.push({ i: nk, f: tentative + h(nx, ny) });
        }
      }
    }
    return null;
  }

  route(from, to, waypoints = []) {
    const pts = [from, ...waypoints, to];
    let out = [];
    for (let i = 1; i < pts.length; i++) {
      let leg = this.astar(pts[i - 1], pts[i], true) || this.astar(pts[i - 1], pts[i], false);
      if (!leg) return null;
      out = out.concat(i === 1 ? leg : leg.slice(1));
    }
    // Recorta extremos exactos y simplifica.
    if (out.length) { out[0] = { x: from.x, y: from.y }; out[out.length - 1] = { x: to.x, y: to.y }; }
    return simplify(out, this.cell * 0.7);
  }
}

/* ------------------------------ longitudes ------------------------------ */

export function cableLengths(routePts, camera, rules) {
  const geo = routePts ? polyLength(routePts) : 0;
  const drop = (Number(camera.data.height) || 2.8) + 0.6; // subida a cámara + holgura en rack
  const reservePct = ruleNum(rules, 'RESERVA_CABLE');
  const margin = ruleNum(rules, 'MARGEN_CABLE');
  const net = geo + drop;
  const reserve = (net * reservePct) / 100;
  return { geometric: geo, drop, net, reservePct, reserve, margin, supply: net + reserve + margin };
}

export const DISTANCE_OK = 'NORMAL', DISTANCE_WARN = 'PROXIMA', DISTANCE_OVER = 'EXCESIVA';

export function distanceStatus(length, rules) {
  const max = ruleNum(rules, 'MAX_UTP');
  const warn = ruleNum(rules, 'AVISO_UTP_PCT');
  if (length > max)
    return { status: DISTANCE_OVER, severity: 'error', pct: (length / max) * 100,
      advice: ['Agregar un switch intermedio o punto de concentración', 'Utilizar fibra óptica con conversores', 'Reubicar el switch más cerca de la cámara'] };
  if (length > (max * warn) / 100)
    return { status: DISTANCE_WARN, severity: 'warn', pct: (length / max) * 100,
      advice: ['Enlace próximo al límite: compruebe la categoría del cable', 'Evite empalmes y reduzca holguras', 'Considere un punto intermedio si se añaden tramos'] };
  return { status: DISTANCE_OK, severity: 'ok', pct: (length / max) * 100, advice: [] };
}

/** Genera/actualiza las entidades de cable de todas las cámaras hacia su switch. */
/** Genera/actualiza las entidades de cable de todas las cámaras hacia su switch. */
export function generateRoutes(prj, catalog, rules) {
  // Asegurar visibilidad de cables en el lienzo CAD
  if (prj.settings) prj.settings.showRoutes = true;

  // Helper para normalizar el punto central o de anclaje de una entidad
  const ptOf = (e) => {
    if (e.points && e.points.length > 0 && e.points[0] && typeof e.points[0].x === 'number') {
      return e.points[0];
    }
    if (typeof e.x === 'number' && typeof e.y === 'number') {
      e.points = [{ x: e.x, y: e.y }];
      return e.points[0];
    }
    if (e.points && e.points.length > 0) {
      const avgX = e.points.reduce((a, p) => a + (p.x || 0), 0) / e.points.length;
      const avgY = e.points.reduce((a, p) => a + (p.y || 0), 0) / e.points.length;
      return { x: avgX, y: avgY };
    }
    return { x: 0, y: 0 };
  };

  // Asegurar identificadores únicos
  let autoIdCount = 1;
  for (const e of prj.entities) {
    if (!e.id) {
      e.id = (e.type === 'camera' ? 'CAM-' : e.type === 'device' ? 'DEV-' : 'E-') + String(autoIdCount++);
    }
    if (!e.data) e.data = {};
  }

  const grid = new RouteGrid(prj, rules);
  const switches = prj.entities.filter((e) => e.type === 'device' && e.data && e.data.kind === 'switch');
  const recorders = prj.entities.filter((e) => e.type === 'device' && e.data && (e.data.kind === 'dvr' || e.data.kind === 'nvr'));
  const cams = prj.entities.filter((e) => e.type === 'camera');
  const byId = new Map(prj.entities.map((e) => [e.id, e]));
  const report = [];

  for (const cam of cams) {
    const camPt = ptOf(cam);

    // Una cámara analógica no llega a un switch: su enlace es un cable de vídeo hasta el DVR (§38)
    if (isAnalog(cam, catalog)) {
      const cfg = analogConfig(cam, catalog, rules);
      let dvr = byId.get(cam.data.switchId);
      if (!dvr || dvr.type !== 'device' || (dvr.data.kind !== 'dvr' && dvr.data.kind !== 'nvr')) {
        dvr = null;
        let bd = Infinity;
        // Prioridad: DVR o grabador híbrido (admite vídeo analógico); un NVR IP puro no lo acepta
        const acepta = (d) => {
          const info = (getItem(catalog, d.data.catalogId) || { specs: {} }).specs || {};
          if (!info.channels) return 0;
          if (d.data.kind === 'dvr' || info.hybrid) return 2;
          return info.analogFormats ? 1 : 0;
        };
        for (const d of recorders) {
          if (!acepta(d)) continue;
          const dPt = ptOf(d);
          const dist = Math.hypot(dPt.x - camPt.x, dPt.y - camPt.y) - acepta(d) * 100;
          if (dist < bd) { bd = dist; dvr = d; }
        }
      }
      let old = prj.entities.find((e) => e.type === 'cable' && e.data && e.data.from === cam.id);
      if (!dvr) {
        if (old) prj.entities.splice(prj.entities.indexOf(old), 1);
        report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: false, error: 'Sin grabador (DVR) asignado' });
        continue;
      }
      cam.data.switchId = dvr.id;
      const dvrPt = ptOf(dvr);
      const route = grid.route(camPt, dvrPt, cam.data.waypoints || []);
      if (!route) {
        report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: false, error: 'No se encontró ruta' });
        continue;
      }
      const L = cableLengths(route, cam, rules);
      const st = distanceStatus(L.net, rules);
      if (old) prj.entities.splice(prj.entities.indexOf(old), 1);
      prj.entities.push({
        id: 'CBL-' + cam.id, type: 'cable', layer: 'CABLEADO', closed: false, points: route,
        data: Object.assign({ from: cam.id, to: dvr.id, cableId: cfg.cable.itemId, conduitId: 'CAN-PVC20', analog: true },
          L, { distanceStatus: st.status, advice: st.advice, media: cfg.balun ? 'utp' : 'coax', analogCable: cfg.cable.id }),
      });
      report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: true, switch: dvr.data.label || dvr.id, length: L.supply, status: st.status, analog: true });
      continue;
    }

    let sw = byId.get(cam.data.switchId);
    if (!sw || sw.type !== 'device') {
      // Asignación por proximidad si aún no tiene switch
      let best = null, bd = Infinity;
      for (const s of switches) {
        const sPt = ptOf(s);
        const d = Math.hypot(sPt.x - camPt.x, sPt.y - camPt.y);
        if (d < bd) { bd = d; best = s; }
      }
      sw = best;
    }

    let old = prj.entities.find((e) => e.type === 'cable' && e.data && e.data.from === cam.id);
    if (!sw) {
      if (old) prj.entities.splice(prj.entities.indexOf(old), 1);
      report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: false, error: 'Sin switch asignado' });
      continue;
    }

    if (cam.data.switchId !== sw.id) cam.data.switchId = sw.id;
    const swPt = ptOf(sw);
    const route = grid.route(camPt, swPt, cam.data.waypoints || []);
    if (!route) {
      report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: false, error: 'No se encontró ruta' });
      continue;
    }
    const L = cableLengths(route, cam, rules);
    const st = distanceStatus(L.net, rules);
    if (old) prj.entities.splice(prj.entities.indexOf(old), 1);
    const media = (old && old.data && old.data.media) || cam.data.media || 'auto';
    const fiberType = (old && old.data && old.data.fiberType) || cam.data.fiberType;
    prj.entities.push({
      id: 'CBL-' + cam.id, type: 'cable', layer: 'CABLEADO', closed: false,
      points: route,
      data: Object.assign({ from: cam.id, to: sw.id, cableId: 'CBL-UTP6', conduitId: 'CAN-PVC20' }, L,
        { distanceStatus: st.status, advice: st.advice, media, fiberType }),
    });
    report.push({ camera: cam.id, label: cam.data.label || cam.id, ok: true, switch: sw.data.label || sw.id, length: L.supply, status: st.status });
  }
  return { grid, report };
}
