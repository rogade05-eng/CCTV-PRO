/**
 * CCTV DESIGN PRO — Vista del plano y menú contextual, al estilo de AutoCAD (§8)
 *
 * Módulo PURO: no toca el DOM ni el canvas, así que se prueba bajo Node.
 * El motor CAD (`app/cad.js`) delega aquí todo lo que pasa entre el ratón y la vista:
 *
 *   · Rueda ............. acerca y aleja manteniendo bajo el cursor el punto señalado.
 *   · Rueda pulsada ..... desplaza la vista; con doble pulsación, encuadra todo el dibujo.
 *   · Botón derecho ..... menú contextual (y, arrastrando, desplaza la vista) — como AutoCAD.
 *   · Zoom anterior ..... pila de vistas para volver de un salto donde se estaba.
 *
 * El menú contextual es una lista de datos (`menuContextual`), no DOM: el motor CAD la pinta.
 */

/** Parámetros de navegación (los mismos criterios que el paso de zoom de AutoCAD). */
export const ZOOM = {
  PASO: 1.1,        // 10 % por muesca de rueda
  MIN: 0.002,       // 1 píxel = 500 m (planos territoriales)
  MAX: 50000,       // 1 píxel = 0,02 mm (detalle de conector)
  MUESCAS_MAX: 3,   // una tirada de rueda no salta más de 3 muescas de golpe
  VISTAS: 32,       // profundidad de la pila de «Zoom anterior»
};

const limitar = (v, a, b) => (v < a ? a : v > b ? b : v);

/**
 * Factor de zoom de un giro de rueda.
 * `deltaMode` 0 = píxeles (Chrome/Edge), 1 = líneas (Firefox), 2 = páginas.
 * @returns {number} factor a multiplicar a la escala ( >1 acerca, <1 aleja )
 */
export function factorRueda(deltaY, deltaMode = 0) {
  let muescas;
  if (deltaMode === 1) muescas = deltaY / 3;
  else if (deltaMode === 2) muescas = deltaY * 3;
  else muescas = deltaY / 100;
  if (!isFinite(muescas)) muescas = 0;
  muescas = limitar(muescas, -ZOOM.MUESCAS_MAX, ZOOM.MUESCAS_MAX);
  // Giro hacia arriba (deltaY negativo) = acercar, como en AutoCAD
  return Math.pow(ZOOM.PASO, -muescas);
}

/* ------------------------------ cajas envolventes ------------------------------ */

/** Caja envolvente de una lista de puntos. */
export function cajaDePuntos(pts) {
  if (!pts || !pts.length) return null;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    if (!p || !isFinite(p.x) || !isFinite(p.y)) continue;
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
  }
  return isFinite(minX) ? { minX, minY, maxX, maxY } : null;
}

/**
 * Caja envolvente de una lista de entidades. Tiene en cuenta el radio de los círculos y
 * arcos (si no, un círculo sería un punto y el encuadre quedaría desproporcionado).
 * Las imágenes de fondo y lo que no tiene puntos se ignoran, como en el encuadre normal.
 */
export function cajaDeEntidades(entidades, filtro) {
  let caja = null;
  for (const e of entidades || []) {
    if (filtro && !filtro(e)) continue;
    if (!e || !e.points || !e.points.length || e.type === 'image') continue;
    let b = cajaDePuntos(e.points);
    if (!b) continue;
    if ((e.type === 'circle' || e.type === 'arc') && isFinite(e.radius) && e.radius > 0) {
      b = { minX: b.minX - e.radius, minY: b.minY - e.radius, maxX: b.maxX + e.radius, maxY: b.maxY + e.radius };
    }
    // Los símbolos (cámara, equipo, texto) son un punto en el encuadre: no se les añade margen
    // para no desviar el encuadre general de un proyecto ya dibujado.
    caja = unirCajas(caja, b);
  }
  return caja;
}

/** Caja que contiene a las dos. */
export function unirCajas(a, b) {
  if (!a) return b || null;
  if (!b) return a;
  return {
    minX: Math.min(a.minX, b.minX), minY: Math.min(a.minY, b.minY),
    maxX: Math.max(a.maxX, b.maxX), maxY: Math.max(a.maxY, b.maxY),
  };
}

export function cajaValida(c) {
  return !!(c && isFinite(c.minX) && isFinite(c.minY) && isFinite(c.maxX) && isFinite(c.maxY));
}

export function centroCaja(c) { return { x: (c.minX + c.maxX) / 2, y: (c.minY + c.maxY) / 2 }; }

export function tamanoCaja(c) { return { ancho: c.maxX - c.minX, alto: c.maxY - c.minY }; }

/** Distancia entre dos cajas (0 si se solapan). Sirve para saber si un plano quedó lejos. */
export function distanciaCajas(a, b) {
  if (!cajaValida(a) || !cajaValida(b)) return 0;
  const dx = Math.max(b.minX - a.maxX, a.minX - b.maxX, 0);
  const dy = Math.max(b.minY - a.maxY, a.minY - b.maxY, 0);
  return Math.hypot(dx, dy);
}

/**
 * ¿Está el plano importado lejos de la obra dibujada?
 * Se compara la distancia entre cajas con el tamaño del conjunto: si el hueco es mayor que
 * el propio plano, es que se dibujó en otra zona (típico de planos en coordenadas UTM).
 */
export function planoAlejado(cajaPlano, cajaObra, factor = 1) {
  if (!cajaValida(cajaPlano) || !cajaValida(cajaObra)) return false;
  const t = tamanoCaja(cajaPlano);
  const propio = Math.max(t.ancho, t.alto, 1);
  return distanciaCajas(cajaPlano, cajaObra) > propio * factor;
}

/* ---------------------------------- la vista ---------------------------------- */

/**
 * Estado de la vista (escala y centro) con la navegación de AutoCAD.
 * `scale` = píxeles por metro; `center` = punto del mundo que queda en el centro del lienzo.
 */
export class VistaNav {
  constructor(opts = {}) {
    this.scale = opts.scale || 20;
    this.center = { x: (opts.center && opts.center.x) || 0, y: (opts.center && opts.center.y) || 0 };
    this.w = opts.w || 800;
    this.h = opts.h || 600;
    this.pilas = [];
  }

  setViewport(w, h) { this.w = Math.max(1, w); this.h = Math.max(1, h); }

  /* conversiones de pantalla ↔ mundo (igual que las del motor CAD) */
  sx(wx) { return (wx - this.center.x) * this.scale + this.w / 2; }
  sy(wy) { return this.h / 2 - (wy - this.center.y) * this.scale; }
  wx(sx) { return (sx - this.w / 2) / this.scale + this.center.x; }
  wy(sy) { return (this.h / 2 - sy) / this.scale + this.center.y; }
  aMundo(p) { return { x: this.wx(p.x), y: this.wy(p.y) }; }

  /** Guarda la vista actual para poder volver con «Zoom anterior». */
  guardar() {
    const ult = this.pilas[this.pilas.length - 1];
    const vista = { scale: this.scale, x: this.center.x, y: this.center.y };
    if (ult && ult.scale === vista.scale && ult.x === vista.x && ult.y === vista.y) return;
    this.pilas.push(vista);
    if (this.pilas.length > ZOOM.VISTAS) this.pilas.shift();
  }

  /** ¿Hay alguna vista guardada a la que volver? */
  get hayVistas() { return this.pilas.length > 0; }

  /** Vuelve a la vista anterior. @returns {boolean} si había alguna */
  vistaAnterior() {
    const v = this.pilas.pop();
    if (!v) return false;
    this.scale = v.scale; this.center = { x: v.x, y: v.y };
    return true;
  }

  /** Encuadra una caja del mundo con un margen en píxeles. */
  encuadrar(caja, { pad = 40, guardar = true } = {}) {
    if (!cajaValida(caja)) return false;
    const t = tamanoCaja(caja);
    const pw = Math.max(this.w - pad * 2, 40);
    const ph = Math.max(this.h - pad * 2, 40);
    const escala = Math.min(pw / Math.max(t.ancho, 1e-6), ph / Math.max(t.alto, 1e-6));
    if (guardar) this.guardar();
    this.scale = limitar(escala, ZOOM.MIN, ZOOM.MAX);
    this.center = centroCaja(caja);
    return true;
  }

  /** Encuadra todo el dibujo. */
  encuadrarTodo(entidades, opts) { return this.encuadrar(cajaDeEntidades(entidades), opts); }

  /** Acerca o aleja manteniendo bajo el cursor el punto del mundo señalado. */
  zoomAt(factor, px, py) {
    const antes = { x: this.wx(px), y: this.wy(py) };
    const escala = limitar(this.scale * factor, ZOOM.MIN, ZOOM.MAX);
    if (escala === this.scale) return false;
    this.guardar();
    this.scale = escala;
    const ahora = { x: this.wx(px), y: this.wy(py) };
    this.center.x += antes.x - ahora.x;
    this.center.y += antes.y - ahora.y;
    return true;
  }

  /** Zoom ventana: dos esquinas en píxeles de pantalla. */
  zoomVentana(a, b, { guardar = true } = {}) {
    const caja = cajaDePuntos([
      { x: this.wx(a.x), y: this.wy(a.y) },
      { x: this.wx(b.x), y: this.wy(b.y) },
    ]);
    if (!caja) return false;
    // Una ventana diminuta no debe disparar la escala: se exige un mínimo de 8 px
    if (Math.abs(a.x - b.x) < 8 || Math.abs(a.y - b.y) < 8) return false;
    return this.encuadrar(caja, { pad: 6, guardar });
  }

  /** Escala real: 1 píxel = 1 metro (el «zoom 1:1» del dibujo en papel). */
  zoomReal(pxPorMetro = 1, { guardar = true } = {}) {
    if (guardar) this.guardar();
    this.scale = limitar(pxPorMetro, ZOOM.MIN, ZOOM.MAX);
    return true;
  }

  /** Desplaza la vista una cantidad en píxeles (arrastre). */
  paneo(dxPx, dyPx) {
    this.center.x -= dxPx / this.scale;
    this.center.y += dyPx / this.scale;
    return true;
  }

  /** Aplica un encuadre sin guardar vistas (para restaurar un estado guardado por la app). */
  fijar(scale, center) {
    this.scale = limitar(scale, ZOOM.MIN, ZOOM.MAX);
    this.center = { x: center.x, y: center.y };
  }

  /** Texto de la barra de estado: escala y situación. */
  resumen() {
    const uniones = { 1: '1 px = 1 m', 0.5: '1 px = 2 m', 2: '1 px = 0,5 m' };
    return {
      pxPorMetro: this.scale,
      texto: `Zoom ${this.scale.toFixed(2)} px/m${uniones[this.scale] ? ' (' + uniones[this.scale] + ')' : ''}`,
      centro: { x: this.center.x, y: this.center.y },
    };
  }
}

/* ------------------------------ menú contextual ------------------------------ */

/**
 * Contenido del menú del botón derecho, como el de AutoCAD: primero «repetir», después las
 * acciones de la selección, la vista, el plano importado y las ayudas de dibujo.
 * @param {object} e estado: {seleccion, ultimo, hayVistas, plano, rejilla, snap, herramienta}
 * @returns {Array<{sep?:boolean,label?:string,act?:string,key?:string,checked?:boolean,disabled?:boolean,danger?:boolean}>}
 */
export function menuContextual(e = {}) {
  const sel = e.seleccion || 0;
  const f = [];
  f.push(e.ultimo
    ? { label: `Repetir «${e.ultimo}»`, act: 'rep:ultimo', key: 'Intro' }
    : { label: 'Repetir último comando', act: 'rep:ultimo', disabled: true });
  f.push({ sep: true });

  if (sel) {
    // Edición, como en AutoCAD: lo primero que se necesita cuando se señala algo
    f.push({ label: 'Mover', act: 'cmd:mover', key: 'M' });
    f.push({ label: 'Copiar', act: 'edit:copiar', key: 'Ctrl+C' });
    f.push({ label: 'Cortar', act: 'edit:cortar', key: 'Ctrl+X' });
    f.push({ label: 'Girar', act: 'cmd:rotar', key: 'R' });
    f.push({ label: 'Escalar', act: 'cmd:escalar', key: 'S' });
    f.push({ label: 'Espejo (señalando el eje)', act: 'cmd:espejo', key: 'E' });
    f.push({ sep: true });
    f.push({ label: 'Insertar vértice', act: 'edit:vertice:mas' });
    f.push({ label: 'Quitar el último vértice', act: 'edit:vertice:menos' });
    f.push({ label: 'Cerrar o abrir la figura', act: 'edit:cerrar' });
    f.push({ sep: true });
    f.push({ label: sel === 1 ? 'Borrar objeto' : `Borrar ${sel} objetos`, act: 'sel:borrar', key: 'Supr', danger: true });
    f.push({ label: sel === 1 ? 'Duplicar objeto' : `Duplicar ${sel} objetos`, act: 'sel:duplicar', key: 'Ctrl+D' });
    f.push({ label: 'Propiedades…', act: 'sel:props' });
    f.push({ sep: true });
  } else if (e.portapapeles) {
    f.push({ label: 'Pegar aquí', act: 'edit:pegar', key: 'Ctrl+V' });
    f.push({ sep: true });
  }

  f.push({ label: 'Zoom extensión', act: 'zoom:ext', key: 'Z · doble clic rueda' });
  f.push({ label: 'Zoom anterior', act: 'zoom:prev', key: 'R', disabled: !e.hayVistas });
  f.push({ label: 'Zoom ventana', act: 'zoom:ventana', key: 'W' });
  f.push({ label: 'Zoom 100 % (1 px = 1 m)', act: 'zoom:real' });

  if (e.plano) {
    f.push({ sep: true });
    f.push({ label: `Encuadrar plano «${e.plano.nombre}»`, act: 'plano:encuadrar' });
    f.push({ label: 'Traer el plano a la zona del proyecto', act: 'plano:traer', disabled: !e.plano.lejos });
    f.push({ label: 'Seleccionar todo el plano importado', act: 'plano:seleccionar' });
    f.push({ label: 'Atenuar plano importado', act: 'plano:atenuar', checked: !!e.plano.atenuado });
    // Colores del plano: es lo que decide si el plano se ve o no sobre el fondo del lienzo (§9)
    f.push({ sep: false });
    f.push({ label: 'Colores del plano', act: 'plano:color:original', checked: (e.colorPlano || 'original') === 'original' });
    f.push({ label: 'Claro (recomendado)', act: 'plano:color:claro', checked: e.colorPlano === 'claro' });
    f.push({ label: 'Monocromo tenue', act: 'plano:color:monocromo', checked: e.colorPlano === 'monocromo' });
    f.push({ label: 'Ocultar / mostrar capas del plano', act: 'plano:capas' });
    f.push({ label: 'Quitar plano importado', act: 'plano:quitar', danger: true });
  }

  f.push({ sep: true });
  f.push({ label: 'Rejilla', act: 'plan:grid', key: 'F7', checked: e.rejilla !== false });
  f.push({ label: 'Forzado a rejilla (snap)', act: 'plan:snap', key: 'F9', checked: e.snap !== false });
  f.push({ label: 'Cobertura y rutas visibles', act: 'plan:capas', checked: e.capas !== false });
  f.push({ sep: true });
  f.push({ label: 'Desplazar vista', act: 'tool:pan', key: 'rueda pulsada' });
  f.push({ label: 'Medir / calibrar…', act: 'tool:measure' });
  f.push({ label: 'Capas…', act: 'panel:layers' });
  f.push({ label: 'Opciones de dibujo (puntero, colores, forzados)…', act: 'panel:options' });
  f.push({ label: 'Recorrido del proyecto…', act: 'panel:walkthrough' });
  return f;
}

/** Acciones que el propio motor CAD resuelve sin molestar a la aplicación. */
export const ACCIONES_VISTA = ['zoom:ext', 'zoom:prev', 'zoom:ventana', 'zoom:real'];
