/**
 * CCTV DESIGN PRO — Motor de cobertura (CP CCTV §13, §14)
 * Análisis raster con recorte por obstáculos y detección de zonas ciegas.
 */
import { bbox, bboxOf, pointInPoly, centroid } from './geometry.js?v=b441e3fc';
import { pixelDensity, maxDistanceFor, objectiveAt } from './dori.js?v=b441e3fc';
import { footprintsOf, isPtz, patrolCycle, cameraPresets } from './ptz.js?v=b441e3fc';
import { getItem } from './catalog.js?v=b441e3fc';
import { ruleNum } from './rules.js?v=b441e3fc';
import { OBJECTIVES } from './project.js?v=b441e3fc';
import { segmentosOpacos, IndiceOpacos, ALTURA_OBJETIVO, ALTURA_MURO } from './obstacles.js?v=b441e3fc';
import { recortarHuellas } from './shadows.js?v=b441e3fc';

/**
 * Segmentos que cortan la visión, **con su altura** (§13, §14).
 *
 * Antes todo lo que había en la capa de arquitectura tapaba por igual; ahora cada segmento lleva el
 * rango de alturas que ocupa y el análisis comprueba si el rayo de la cámara pasa por encima o por
 * debajo. Así una mesa de 0,8 m ya no «tapa» a una persona, y un murete de 1,1 m solo tapa lo que va
 * pegado al suelo (que es exactamente lo que un diseñador necesita saber).
 */
export function obstacleSegments(prj, alturaMuro = ALTURA_MURO) {
  return segmentosOpacos(prj, alturaMuro);
}

function zonePolygons(prj) {
  return prj.entities
    .filter((e) => e.type === 'room' && e.points.length >= 3)
    .map((e) => ({ id: e.id, name: (e.data && e.data.name) || 'Zona', critical: !!(e.data && e.data.critical), poly: e.points }));
}

/**
 * Análisis completo de cobertura.
 *
 * `opts.enmascarado` es opcional: una función `(camId) => (x, y) => booleano` que dice si un punto
 * queda bajo una **máscara de privacidad** de esa cámara. Lo que cae bajo una máscara no se
 * registra, así que no cuenta como cubierto: es la única forma honesta de medir la cobertura de
 * una instalación que está obligada a ocultar parte de la escena (§13, módulo de privacidad).
 *
 * @returns {object} raster + métricas globales, por zona, zonas ciegas y detalle por cámara.
 */
export function analyzeCoverage(prj, catalog, rules, opts = {}) {
  const darEnmascarado = opts.enmascarado || (() => null);
  const cell = Math.max(0.05, ruleNum(rules, 'CELDA_COBERTURA'));
  const zones = zonePolygons(prj);
  const cams = prj.entities.filter((e) => e.type === 'camera');

  let bb = null;
  if (zones.length) {
    for (const z of zones) bb = bb ? bboxOf(bb, bbox(z.poly)) : bbox(z.poly);
  } else {
    const arch = prj.entities.filter((e) => e.layer === 'ARQUITECTURA' && e.points.length);
    for (const e of arch) bb = bb ? bboxOf(bb, bbox(e.points)) : bbox(e.points);
  }
  if (!bb) return { empty: true, cell, zones: [], cameras: [], areaTotal: 0, areaCovered: 0, areaUncovered: 0, overlapPct: 0, blindZones: [], cells: null, _footprints: {}, _sombras: {} };

  const cols = Math.max(1, Math.ceil((bb.maxX - bb.minX) / cell));
  const rows = Math.max(1, Math.ceil((bb.maxY - bb.minY) / cell));
  const n = cols * rows;
  const inside = new Uint8Array(n);
  const count = new Uint8Array(n);

  for (let iy = 0; iy < rows; iy++) {
    const y = bb.minY + (iy + 0.5) * cell;
    for (let ix = 0; ix < cols; ix++) {
      const x = bb.minX + (ix + 0.5) * cell;
      const p = { x, y };
      for (const z of zones) if (pointInPoly(p, z.poly)) { inside[iy * cols + ix] = 1; break; }
      if (!zones.length) inside[iy * cols + ix] = 1;
    }
  }

  // Índice de obstáculos con altura: la oclusión se comprueba en tres dimensiones (§13)
  const alturaMuro = (prj.settings && prj.settings.alturaMuro) || ALTURA_MURO;
  const idx = new IndiceOpacos(obstacleSegments(prj, alturaMuro), Math.max(1, cell * 4));
  // Altura a la que se comprueba la visión: la de una persona (regla del sistema), no el suelo
  const hObjetivo = Math.max(0.05, ruleNum(rules, 'ALTURA_OBJETIVO') || ALTURA_OBJETIVO);
  const cellArea = cell * cell;
  const perCam = [];
  // Huellas **recortadas por las sombras** de los obstáculos (§13): lo que se dibuja ya no atraviesa
  // los muros. Se calcula una vez por análisis, no en cada repintado, para no penalizar el equipo.
  const sombras = {};

  for (const cam of cams) {
    const item = getItem(catalog, cam.data.catalogId);
    // Una cámara fija proyecta una huella; un PTZ, una por cada preset de su patrulla (§38).
    const fps = footprintsOf(cam, catalog, rules);
    const ptz = isPtz(cam, catalog);
    const list = ptz ? cameraPresets(cam) : [];
    const cyl = ptz && list.length ? patrolCycle(cam, catalog, rules, list) : null;
    const obj = cam.data.objective || 'OBSERVACION';
    const maxObj = maxDistanceFor(item, obj);
    const hCam = Number(cam.data && cam.data.height) || alturaMuro;
    const focalOf = (j) => (fps[j].preset && fps[j].preset.focal) || cam.data.focal || null;

    // Caja envolvente de la unión de todas las huellas
    let fpBox = null;
    for (const fp of fps) fpBox = fpBox ? bboxOf(fpBox, bbox(fp.polygon)) : bbox(fp.polygon);
    const ix0 = Math.max(0, Math.floor((fpBox.minX - bb.minX) / cell));
    const ix1 = Math.min(cols - 1, Math.floor((fpBox.maxX - bb.minX) / cell));
    const iy0 = Math.max(0, Math.floor((fpBox.minY - bb.minY) / cell));
    const iy1 = Math.min(rows - 1, Math.floor((fpBox.maxY - bb.minY) / cell));
    let covered = 0, losBlocked = 0, effectiveMax = 0;
    let ppmAtFar = 0, far = 0, near = Infinity;
    const perFootprint = fps.map(() => 0);
    const touched = new Set();          // la unión evita contar dos veces la misma celda en un PTZ
    // Máscaras de privacidad de esta cámara (§13): lo que ocultan deja de contar como cubierto
    const oculto = darEnmascarado(cam.id);
    let celdasEnmascaradas = 0;

    for (let iy = iy0; iy <= iy1; iy++) {
      for (let ix = ix0; ix <= ix1; ix++) {
        const k = iy * cols + ix;
        if (!inside[k]) continue;
        const p = { x: bb.minX + (ix + 0.5) * cell, y: bb.minY + (iy + 0.5) * cell };
        if (oculto && oculto(p.x, p.y)) { celdasEnmascaradas++; continue; }
        let hit = -1;
        for (let j = 0; j < fps.length; j++) if (pointInPoly(p, fps[j].polygon)) { hit = j; break; }
        if (hit < 0) continue;
        const origin = fps[hit].origin;
        const d = Math.hypot(p.x - origin.x, p.y - origin.y);
        // El rayo va de la altura de montaje de la cámara a la altura del objetivo: solo lo cortan
        // los obstáculos cuyo rango de alturas lo atraviesa (§13)
        const tapado = idx.tapado(origin, p, hCam, hObjetivo);
        if (tapado) { losBlocked++; continue; }
        perFootprint[hit]++;
        if (!touched.has(k)) { touched.add(k); count[k] = count[k] >= 250 ? 250 : count[k] + 1; covered++; }
        const at = objectiveAt(item, d, focalOf(hit));
        // Requisito de ppm: un objetivo más exigente (más ppm) también satisface al pedido
        const need = OBJECTIVES[fps[hit].objective || obj];
        const got = at.key ? OBJECTIVES[at.key] : null;
        if (need && got && got.ppm >= need.ppm && d > effectiveMax) effectiveMax = d;
      }
    }
    for (let j = 0; j < fps.length; j++) {
      far = Math.max(far, fps[j].far || 0);
      near = Math.min(near, fps[j].near === undefined ? 0 : fps[j].near);
      ppmAtFar = Math.max(ppmAtFar, pixelDensity(item, fps[j].far, focalOf(j)));
    }
    // Sombras: cada huella queda partida en los sectores que la cámara ve de verdad
    const recorte = recortarHuellas(fps, hCam, hObjetivo, idx);
    sombras[cam.id] = recorte.map((r) => r.sectores);
    perCam.push({
      id: cam.id, label: cam.data.label || cam.id, catalogId: cam.data.catalogId,
      model: item ? item.model : '?', area: covered * cellArea, blockedCells: losBlocked,
      areaEnmascarada: celdasEnmascaradas * cellArea,
      objective: obj, objectiveLabel: OBJECTIVES[obj] ? OBJECTIVES[obj].label : obj,
      requiredPpm: OBJECTIVES[obj] ? OBJECTIVES[obj].ppm : 0,
      theoreticalMax: maxObj, effectiveMax,
      meetsObjective: effectiveMax > 0,
      ppmAtFar, far, near: isFinite(near) ? near : 0, hfov: fps[0].hfov, vfov: fps[0].vfov,
      ptz, presets: list.length, cycleSec: cyl ? cyl.cycleSec : 0,
      presetAreas: perFootprint.map((n) => n * cellArea),
      presetPositions: cyl ? cyl.positions.map((q) => ({ name: q.name, azimuth: q.azimuth, tilt: q.tilt, focal: q.focal, dwell: q.dwell, duty: q.duty })) : [],
      // Área media vigilada: cada preset pesa el tiempo que la cámara permanece en él
      weightedArea: cyl ? cyl.positions.reduce((a, q, j) => a + q.duty * (perFootprint[j] * cellArea), 0) : covered * cellArea,
      // Cuánto de la huella teórica queda en sombra por los obstáculos (§13)
      sombraPct: recorte.length ? recorte[0].pct : 0,
      sectores: recorte.length ? recorte[0].sectores.length : 0,
      areaHuella: recorte.length ? recorte[0].area : 0,
      areaTeorica: recorte.length ? recorte[0].teoria : 0 });
  }

  let inCells = 0, covCells = 0, ovCells = 0;
  for (let i = 0; i < n; i++) {
    if (!inside[i]) continue;
    inCells++;
    if (count[i] > 0) covCells++;
    if (count[i] > 1) ovCells++;
  }

  const areaTotal = inCells * cellArea;
  const areaCovered = covCells * cellArea;
  const blindZones = findBlindZones(inside, count, cols, rows, cell, bb);

  const zoneStats = zones.map((z) => {
    const zb = bbox(z.poly);
    let tot = 0, cov = 0;
    const ix0 = Math.max(0, Math.floor((zb.minX - bb.minX) / cell));
    const ix1 = Math.min(cols - 1, Math.floor((zb.maxX - bb.minX) / cell));
    const iy0 = Math.max(0, Math.floor((zb.minY - bb.minY) / cell));
    const iy1 = Math.min(rows - 1, Math.floor((zb.maxY - bb.minY) / cell));
    for (let iy = iy0; iy <= iy1; iy++)
      for (let ix = ix0; ix <= ix1; ix++) {
        const k = iy * cols + ix;
        if (!inside[k]) continue;
        const p = { x: bb.minX + (ix + 0.5) * cell, y: bb.minY + (iy + 0.5) * cell };
        if (!pointInPoly(p, z.poly)) continue;
        tot++;
        if (count[k] > 0) cov++;
      }
    return {
      id: z.id, name: z.name, critical: z.critical,
      area: tot * cellArea, covered: cov * cellArea, uncovered: (tot - cov) * cellArea,
      pct: tot ? (cov / tot) * 100 : 0 };
  });

  // Huellas por cámara (una por preset en los PTZ): las consumen analítica, CAD y paneles
  const footprints = {};
  for (const cam of cams) footprints[cam.id] = footprintsOf(cam, catalog, rules).map((fp) => fp.polygon);

  return {
    empty: false, cell, cols, rows, bb, inside, count, _footprints: footprints, _sombras: sombras,
    areaTotal, areaCovered, areaUncovered: areaTotal - areaCovered,
    coveragePct: areaTotal ? (areaCovered / areaTotal) * 100 : 0,
    overlapPct: areaTotal ? (ovCells / areaTotal) * 100 : 0,
    blindZones, zones: zoneStats, cameras: perCam,
    criticalGaps: zoneStats.filter((z) => z.critical && z.pct < 100),
    ptzCameras: perCam.filter((c) => c.ptz).length,
    // Un PTZ solo puede estar en una posición a la vez: la unión es optimista, la media no.
    ptzWeightedArea: perCam.filter((c) => c.ptz).reduce((a, c) => a + (c.weightedArea || 0), 0),
    ptzPresets: perCam.filter((c) => c.ptz).reduce((a, c) => a + (c.presets || 0), 0) };
}

/** Agrupa celdas descubiertas en zonas ciegas con superficie y centroide. */
export function findBlindZones(inside, count, cols, rows, cell, bb, minArea = 0.25) {
  const seen = new Uint8Array(cols * rows);
  const out = [];
  const stack = [];
  for (let i = 0; i < inside.length; i++) {
    if (!inside[i] || count[i] > 0 || seen[i]) continue;
    seen[i] = 1;
    stack.length = 0;
    stack.push(i);
    let cells = 0, sx = 0, sy = 0;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    const list = [];
    while (stack.length) {
      const k = stack.pop();
      const ix = k % cols, iy = (k / cols) | 0;
      const x = bb.minX + (ix + 0.5) * cell, y = bb.minY + (iy + 0.5) * cell;
      cells++; sx += x; sy += y; list.push(k);
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      const nb = [k - 1, k + 1, k - cols, k + cols];
      const okIx = [ix > 0, ix < cols - 1, true, true];
      for (let j = 0; j < 4; j++) {
        const m = nb[j];
        if (!okIx[j] || m < 0 || m >= inside.length) continue;
        if (inside[m] && count[m] === 0 && !seen[m]) { seen[m] = 1; stack.push(m); }
      }
    }
    const area = cells * cell * cell;
    if (area < minArea) continue;
    out.push({
      area, cells: list, cols, rows, cell, bb,
      centroid: { x: sx / cells, y: sy / cells },
      bbox: { minX, minY, maxX, maxY } });
  }
  return out.sort((a, b) => b.area - a.area);
}
