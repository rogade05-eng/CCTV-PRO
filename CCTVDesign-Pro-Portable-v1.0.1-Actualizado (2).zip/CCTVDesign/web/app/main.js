import { GestorLicencia } from './core/license.js?v=b441e3fc';
/**
 * CCTV DESIGN PRO — Orquestación de la aplicación
 * Menús (§7), comandos, recálculo, autoguardado (§37) y exportación (§29).
 */
import { CadView } from './cad.js?v=b441e3fc';
import { renderPanel, PANEL_TITLES, esc, num, money } from './panels.js?v=b441e3fc';
import { Monitor } from './monitor.js?v=b441e3fc';
import { vistaDe as vistaMonitor } from './core/monitor.js?v=b441e3fc';
import { demoProject, newProject, serialize, deserialize, integrityCheck, addEntity, removeEntity, makeCamera, makeDevice, OBJECTIVES } from './core/project.js?v=b441e3fc';
import { analyzeCoverage } from './core/coverage.js?v=b441e3fc';
import { footprint } from './core/dori.js?v=b441e3fc';
import { generateRoutes } from './core/routing.js?v=b441e3fc';
import { computePoe, autoAssignSwitches } from './core/poe.js?v=b441e3fc';
import { computeStorage, recommendNvr } from './core/storage.js?v=b441e3fc';
import { buildTopology, linkReport, autoAddress } from './core/network.js?v=b441e3fc';
import { rackLayout, autoArrange } from './core/rack.js?v=b441e3fc';
import { buildBom, buildBudget } from './core/materials.js?v=b441e3fc';
import { validateProject } from './core/validation.js?v=b441e3fc';
import { analisisPrivacidad, evaluarCumplimiento, clasificacionIA, crearEnmascarador, zonasDe, mascarasDe,
  CLASES_ZONA, CLASES_LISTA, FUNCIONES_IA, NIVELES_IA, NIVELES_CUMPLIMIENTO, etiquetaClase } from './core/privacy.js?v=b441e3fc';
import { hojasEnPdf, anexoPrivacidad, colocarIndice, pieDePagina } from './docsheets.js?v=b441e3fc';
import { importCatalogCsv, importCatalogXlsx, getItem, cargarCatalogoDistribuidor } from './core/catalog.js?v=b441e3fc';
import { defaultRules, RULE_DEFS } from './core/rules.js?v=b441e3fc';
import { toDxf, importDxfAuto } from './io/dxf.js?v=b441e3fc';
import { toIfc } from './io/dwg.js?v=b441e3fc';
import { cajaDeEntidades, centroCaja, tamanoCaja, planoAlejado } from './core/view.js?v=b441e3fc';
import { aciAHex, hexDeVerdadero, ajustarParaFondo, colorDePlano, colorDePlanoPapel, resolverColor,
  ETIQUETA_MODO, MODOS_COLOR, CLARO_DEL_PLANO } from './io/aci.js?v=b441e3fc';
import { PREFS_POR_DEFECTO, PREF_DEFS, GRUPOS, defDe, normalizarPrefs, aplicarTema, temaDe, resumenPrefs,
  TECLAS, CONMUTABLES, LEYENDA_CONMUTABLE, valorValido, avisoContraste, ETIQUETA_FORZADO,
  tamanoCruzPx, TEMAS, siguienteTema, nombreTemaCorto } from './core/workspace.js?v=b441e3fc';
import { dwgInfo, dwgStrategy, bridgeStatus, CONVERTERS } from './io/dwg.js?v=b441e3fc';
import { INTEGRATION, integrationPackage, integrationToXml, importArqGen, applyArqGen } from './io/integration.js?v=b441e3fc';
import { isPtz, cameraPresets, ptzSchedule, ptzSummary, presetFromCurrent, spreadPresets } from './core/ptz.js?v=b441e3fc';
import { lprSchedule, lprSummary } from './core/lpr.js?v=b441e3fc';
import { cameraRules, analyticsSchedule, analyticsSummary, evaluateRule } from './core/analytics.js?v=b441e3fc';
import { fiberSummary, FIBER_TYPES } from './core/fiber.js?v=b441e3fc';
import { analogSchedule, analogPlan, ANALOG_FORMATS } from './core/analog.js?v=b441e3fc';
import { PdfDoc } from './io/pdf.js?v=b441e3fc';
import { toXlsx, fromXlsx } from './io/xlsx.js?v=b441e3fc';
import { toCsv, downloadText, downloadBytes, projectToXml } from './io/csv.js?v=b441e3fc';
import { layoutTopology, drawTopologyPdf } from './diagrams.js?v=b441e3fc';
import { drawPerspectivePdf } from './render3d-pdf.js?v=b441e3fc';
import { HELP } from './help.js?v=b441e3fc';
import * as DB from './db.js?v=b441e3fc';
import { UNIDADES, unidadPorId, unidadPropuesta, tamanoEnMetros, formatearLongitud, formatearEscala,
  escalarEntidades, factorEscala, escalarPorReferencia } from './core/units.js?v=b441e3fc';
import { OBSTACULOS, obstaculoDe, crearObstaculo, datosDe, marcarMuro, desmarcarMuro, resumenMuros,
  esElemento3d, ALTURA_MURO } from './core/obstacles.js?v=b441e3fc';
import { escribirCampo, ETIQUETA_TIPO } from './core/edit.js?v=b441e3fc';
import { PALETAS, buscarEnPaletas } from './core/palettes.js?v=b441e3fc';

const LS_AUTO = 'cctvdesign.autosave.v1';
const LS_BACKUP = 'cctvdesign.backups.v1';
// Las preferencias del espacio de trabajo (puntero, colores, forzados) son del usuario, no del
// proyecto: se guardan aparte y valen para todos los proyectos, como las Opciones de AutoCAD.
const LS_PREFS = 'cctvdesign.prefs.v1';
const LS_PALETA = 'cctvdesign.paleta.v1';   // qué paleta de herramientas queda abierta

const MENUS = [
  { title: 'Archivo', items: [
    { label: 'Nuevo proyecto…', act: 'file:new' }, { label: 'Abrir proyecto (.cctv)…', act: 'file:open' },
    { label: 'Guardar proyecto', act: 'file:save' }, { label: 'Guardar copia como…', act: 'file:saveas' },
    { sep: 1 }, { label: 'Importar plano DXF (texto o binario)…', act: 'file:dxf' }, { label: 'Importar DWG (asistente)…', act: 'file:dwg' },
    { label: 'Importar imagen de fondo…', act: 'file:image' },
    { label: 'Importar catálogo CSV…', act: 'cat:import' }, { sep: 1 },
    { label: 'Recuperar última sesión', act: 'file:recover' }, { label: 'Proyecto de demostración', act: 'file:demo' },
  ] },
  { title: 'Proyecto', items: [{ label: 'Datos del proyecto', panel: 'project' }, { label: 'Capas', panel: 'layers' },
    { label: 'Reglas del sistema', panel: 'rules' }, { sep: 1 },
    { label: 'Base de datos (SQLite) — estado', act: 'db:estado' },
    { label: 'Guardar catálogo y reglas en la base', act: 'db:guardar' },
    { label: 'Recargar catálogo y reglas desde la base', act: 'db:cargar' },
    { label: 'Guardar proyecto en la base', act: 'db:proyecto' },
    { label: 'Copias de seguridad y auditoría', act: 'db:historial' },
    { sep: 1 }, { label: 'Recorrido del proyecto (§41)', panel: 'walkthrough' }] },
  { title: 'Plano', items: [{ label: 'Importar DXF…', act: 'file:dxf' }, { label: 'Importar DWG (asistente)…', act: 'file:dwg' },
    { label: 'Convertir DWG e importar (conversor local)…', act: 'db:convertir' },
    { label: 'Importar estancias de ARQ GEN…', act: 'arq:import' },
    { label: 'Calibrar escala…', act: 'plan:calibrate' },
    { sep: 1 },
    { label: 'Encuadrar el plano importado', act: 'plan:planoEncuadrar' },
    { label: 'Traer el plano a la zona del proyecto', act: 'plan:planoTraer' },
    { label: 'Atenuar plano importado', act: 'plan:planoAtenuar' },
    { label: 'Colores del plano: los del fichero', act: 'plan:planoColores:original' },
    { label: 'Colores del plano: claro (recomendado)', act: 'plan:planoColores:claro' },
    { label: 'Colores del plano: monocromo tenue', act: 'plan:planoColores:monocromo' },
    { label: 'Quitar el plano importado', act: 'plan:planoQuitar' },
    { sep: 1 }, { label: 'Unidades y escala del plano…', act: 'panel:escala' },
    { label: 'Medir una distancia conocida para escalar…', act: 'escala:referencia' }] },
  { title: 'Ver', items: [
    { label: 'Zoom extensión (todo el dibujo)', act: 'plan:fit' },
    { label: 'Zoom anterior', act: 'plan:zoomPrev' },
    { label: 'Zoom ventana', act: 'plan:zoomVentana' },
    { label: 'Zoom 100 % (1 px = 1 m)', act: 'plan:zoomReal' },
    { sep: 1 },
    { label: 'Rueda: acercar y alejar · rueda pulsada: desplazar', act: 'plan:ayudaRaton' },
    { label: 'Referencia a objetos (F3)', act: 'pref:referenciaObjetos' },
    { label: 'Rejilla visible (F7)', act: 'pref:rejillaVisible' },
    { label: 'Forzar a la rejilla (F9)', act: 'pref:forzadoRejilla' },
    { label: 'Modo ortogonal (F8)', act: 'pref:orto' },
    { label: 'Rastreo polar (F10)', act: 'pref:polar' },
    { label: 'Opciones de dibujo…', act: 'pref:panel' },
    { sep: 1 },
    { label: 'Vista 3D', act: 'ver:3d' },
    { label: 'Opciones de la vista 3D…', act: 'panel:tresd' },
    { sep: 1 },
    { label: 'Cobertura visible', act: 'plan:coverage' }, { label: 'Rutas de cable visibles', act: 'plan:routes' }] },
  { title: 'Cámaras', items: [{ label: 'Colocar cámara (Asistente de marca, tipo y modelo)', act: 'tool:camera' }, { label: 'Colocar cámara ojo de pez (Fisheye 360°)', act: 'tool:camera:fisheye' }, { label: 'Propiedades', panel: 'props' },
    { label: 'Numeración automática', act: 'cam:renumber' }, { label: 'IP automáticas', act: 'net:address' },
    { label: 'Listado de cámaras', act: 'doc:cameras' }] },
  { title: 'PTZ', items: [{ label: 'Módulo PTZ', panel: 'ptz' }, { label: 'Añadir vista actual a la selección', act: 'ptz:add' },
    { label: 'Repartir barrido…', act: 'ptz:spread' }, { label: 'Ver posiciones en el plano', act: 'ptz:show' },
    { label: 'Cuadro de presets (CSV)', act: 'ptz:csv' }, { label: 'Cuadro de presets (PDF)', act: 'ptz:doc' }] },
  { title: 'LPR', items: [{ label: 'Panel LPR', panel: 'lpr' }, { label: 'Ver zonas de captura', act: 'lpr:zone' },
    { label: 'Cuadro LPR (CSV)', act: 'lpr:csv' }, { label: 'Cuadro LPR (PDF)', act: 'lpr:doc' }] },
  { title: 'Analítica', items: [{ label: 'Panel de analítica', panel: 'analytics' }, { label: 'Añadir regla a la cámara seleccionada', act: 'an:add' },
    { label: 'Cuadro de reglas (CSV)', act: 'an:csv' }, { label: 'Cuadro de reglas (PDF)', act: 'an:doc' }] },
  { title: 'Fibra', items: [{ label: 'Panel de fibra óptica', panel: 'fiber' }, { label: 'Cuadro de fibra (CSV)', act: 'fiber:csv' },
    { label: 'Cuadro de fibra (PDF)', act: 'fiber:doc' }] },
  { title: 'Analógico', items: [{ label: 'Panel de vídeo analógico', panel: 'analog' },
    { label: 'Cuadro analógico (CSV)', act: 'ana:csv' }, { label: 'Cuadro analógico (PDF)', act: 'ana:doc' }] },
  { title: 'Cobertura', items: [{ label: 'Analizar cobertura', act: 'cov:analyze' }, { label: 'Panel de cobertura', panel: 'coverage' },
    { label: 'Ver/sin ver zonas', act: 'plan:coverage' }, { label: 'Propuesta automática', act: 'cov:autocam' }] },
  { title: 'Cableado', items: [{ label: 'Generar rutas', act: 'cable:generate' }, { label: 'Panel de cableado', panel: 'cabling' },
    { label: 'Ver/ocultar rutas', act: 'plan:routes' }, { label: 'Cuadro de cableado', act: 'doc:cabling' }] },
  { title: 'Red', items: [{ label: 'Panel de red', panel: 'network' }, { label: 'Asignación automática', act: 'net:assign' },
    { label: 'Diagrama PDF', act: 'net:diagpdf' }] },
  { title: 'PoE', items: [{ label: 'Panel PoE', panel: 'poe' }, { label: 'Calcular PoE', act: 'calc:all' }] },
  { title: 'Grabación', items: [{ label: 'Panel de grabación', panel: 'recording' }, { label: 'Calcular almacenamiento', act: 'rec:calc' },
    { label: 'Recomendar NVR', act: 'rec:nvr' }] },
  { title: 'Equipos', items: [{ label: 'Colocar equipo', act: 'tool:device' }, { label: 'Catálogo', panel: 'catalog' },
    { label: 'Rack', panel: 'rack' }, { label: 'Distribución automática del rack', act: 'rack:auto' }] },
  { title: 'Materiales', items: [{ label: 'Panel de materiales', panel: 'materials' }, { label: 'Recalcular materiales', act: 'calc:all' }] },
  { title: 'Presupuesto', items: [{ label: 'Panel de presupuesto', panel: 'budget' }, { label: 'Presupuesto PDF', act: 'bud:pdf' }] },
  { title: 'Documentación', items: [{ label: 'Panel de documentación', panel: 'docs' }, { label: 'Dossier completo PDF', act: 'doc:complete' },
    { label: 'Hojas de cámara (una por equipo)', act: 'doc:sheets' },
    { label: 'Privacidad y cumplimiento (panel)', panel: 'privacy' },
    { label: 'Anexo de protección de datos PDF', act: 'doc:privacy' },
    { label: 'Plano PDF (A3 normalizado)…', act: 'plan:pdf:a3' }, { label: 'Plano de obra PDF (A1 gran formato)…', act: 'plan:pdf:a1' },
    { label: 'Lámina perspectiva 3D (A3)…', act: 'plan:pdf:3d' }, { label: 'Plano DXF', act: 'plan:dxf' }, { label: 'Plano PNG', act: 'plan:png' },
    { label: 'Plano DXF con bloques (para CAD externo)', act: 'plan:dxfblocks' },
    { label: 'Modelo BIM / IFC 2x3 (Revit / ArchiCAD)…', act: 'plan:ifc' }, { label: 'Cuadro de presets PTZ', act: 'ptz:doc' },
    { label: 'Cuadro LPR', act: 'lpr:doc' }, { label: 'Cuadro de reglas de analítica', act: 'an:doc' }, { label: 'Cuadro de enlaces de fibra', act: 'fiber:doc' }] },
  { title: 'Editar', items: [{ label: 'Propiedades del objeto…', act: 'edit:propiedades' },
    { label: 'Mover (M)', act: 'cmd:mover' }, { label: 'Copiar (Ctrl+C)', act: 'edit:copiar' },
    { label: 'Pegar (Ctrl+V)', act: 'edit:pegar' }, { label: 'Cortar (Ctrl+X)', act: 'edit:cortar' },
    { label: 'Girar (R)', act: 'cmd:rotar' }, { label: 'Escalar (S)', act: 'cmd:escalar' },
    { label: 'Espejo (E)', act: 'cmd:espejo' },
    { sep: 1 },
    { label: 'Espejo vertical (sin señalar eje)', act: 'edit:espejo:v' },
    { label: 'Espejo horizontal (sin señalar eje)', act: 'edit:espejo:h' },
    { sep: 1 },
    { label: 'Insertar vértice', act: 'edit:vertice:mas' }, { label: 'Quitar el último vértice', act: 'edit:vertice:menos' },
    { label: 'Cerrar o abrir la figura', act: 'edit:cerrar' },
    { label: 'Seleccionar todos los del mismo tipo', act: 'edit:seleccionar:tipo' },
    { sep: 1 },
    { label: 'Duplicar (Ctrl+D)', act: 'edit:duplicate' }, { label: 'Eliminar (Supr)', act: 'edit:delete' },
    { label: 'Deshacer (Ctrl+Z)', act: 'edit:undo' }, { label: 'Rehacer (Ctrl+Mayús+Z)', act: 'edit:redo' }] },
  { title: 'Herramientas', items: [{ label: 'Validar proyecto', act: 'val:run' }, { label: 'Calcular todo', act: 'calc:all' },
    { label: 'Medir distancia', act: 'tool:measure' }, { label: 'Deshacer (Ctrl+Z)', act: 'edit:undo' }, { label: 'Rehacer', act: 'edit:redo' }] },
  { title: 'Obstáculos', items: [{ label: 'Paleta de obstáculos y muros…', act: 'panel:obstaculos' },
    { sep: 1 },
    ...OBSTACULOS.filter((o) => o.grupo !== 'Referencia').map((o) => ({ label: `${o.icono} ${o.etiqueta} (${o.altura.toFixed(2).replace('.', ',')} m)`, act: `obs:${o.id}` })),
    { sep: 1 },
    { label: 'Marcar la selección como muro', act: 'muro:marcar' },
    { label: 'Quitar la marca de muro', act: 'muro:desmarcar' },
    { label: 'Detectar muros por capa', act: 'muro:detectar' },
    { label: 'Vista 3D…', act: 'panel:tresd' }] },
  { title: 'Configuración', items: [
    { label: 'Opciones de dibujo (puntero, colores, forzados)…', act: 'pref:panel' },
    { label: 'Tema del espacio: predeterminado', act: 'pref:tema:programa' },
    { label: 'Tema del espacio: AutoCAD (gris azulado)', act: 'pref:tema:autocad' },
    { label: 'Tema del espacio: AutoCAD clásico (negro)', act: 'pref:tema:negro' },
    { label: 'Tema del espacio: claro (papel)', act: 'pref:tema:claro' },
    { label: 'Restablecer el espacio de trabajo', act: 'pref:reset' },
    { sep: 1 },
    { label: 'Reglas del sistema', panel: 'rules' }, { label: 'Módulos del sistema (§38)', panel: 'modules' },
    { label: 'Importar DWG (asistente)…', act: 'file:dwg' },
    { label: 'Restaurar reglas', act: 'rules:reset' }] },
  { title: 'Ayuda', items: [{ label: 'Ayuda contextual', panel: 'help' }, { label: 'Atajos de teclado', act: 'help:keys' },
    { label: 'Acerca de', act: 'help:about' }] },
];

/** Nombre legible de los comandos que tiene sentido repetir desde el menú contextual (§8). */
export const ETIQUETA_ACT = {
  'tool:select': 'Seleccionar', 'tool:lasso': 'Lazo', 'tool:pan': 'Desplazar vista', 'tool:camera': 'Colocar cámara',
  'tool:device': 'Colocar equipo de red', 'tool:room': 'Zona de interés', 'tool:polyline': 'Polilínea',
  'tool:pzona': 'Zona de privacidad', 'tool:mascara': 'Máscara de privacidad',
  'tool:line': 'Línea', 'tool:rect': 'Rectángulo', 'tool:circle': 'Círculo', 'tool:text': 'Texto',
  'tool:measure': 'Medir / calibrar', 'plan:calibrate': 'Calibrar escala', 'plan:fit': 'Encuadrar todo',
  'muro:marcar': 'Marcar como muro', 'muro:detectar': 'Detectar muros', 'ver:3d': 'Vista 3D',
  'escala:referencia': 'Escalar por una distancia conocida',
  'plan:planoEncuadrar': 'Encuadrar plano importado', 'cov:analyze': 'Analizar cobertura',
  'cable:generate': 'Generar rutas de cable', 'net:assign': 'Asignación automática de red',
  'rack:auto': 'Distribuir rack', 'val:run': 'Validar el proyecto', 'calc:all': 'Calcular todo',
  'file:dxf': 'Importar DXF', 'db:convertir': 'Convertir DWG e importar' };

const App = {
  prj: null, cad: null, results: {}, panel: 'props', catalogFilter: { cat: '', q: '' }, camPickerFilter: { marca: '', tipo: '', q: '' }, planScale: 'fit',
  undoStack: [], redoStack: [], dirty: false,
  // Portapapeles del programa (§8): copiar, cortar y pegar como en cualquier editor, con su
  // punto base para que lo pegado caiga donde se señale.
  portapapeles: { entidades: [], base: null, cortar: false },
  licencia: new GestorLicencia('PRO-MASTER-AUDIT-2026'),

  /* ------------------------------ arranque ------------------------------ */
  init() {
    this.canvas = document.getElementById('cad');
    this.cad = new CadView(this.canvas, {
      on: {
        draw: (d) => this.commitDraw(d),
        place: (tool, w) => this.place(tool, w),
        placeText: (w) => this.placeText(w),
        select: (sel) => { this.showPanel(sel.length ? 'props' : this.panel === 'props' ? 'props' : this.panel); },
        delete: (ids) => { this.pushUndo(); ids.forEach((id) => removeEntity(this.prj, id)); this.afterChange(); },
        duplicate: (ids) => {
          if (this.licencia && this.licencia.esTrial) {
            const cams = (this.prj.entities || []).filter((e) => e.type === 'camera');
            const camsInIds = (ids || []).filter((id) => { const e = this.prj.entities.find((x) => x.id === id); return e && e.type === 'camera'; });
            if (cams.length + camsInIds.length > 1) {
              const chk = this.licencia.puedeColocarCamara(cams.length);
              this.hint(chk.motivo);
              this.showPanel('license');
              return;
            }
          }
          this.pushUndo(); this.cad.duplicate(ids); this.afterChange();
        },
        undo: (redo) => (redo ? this.redo() : this.undo()),
        change: () => this.afterChange(),
        // Edición de objetos (§9): el deshacer se guarda al empezar a arrastrar un tirador, para
        // que Ctrl+Z devuelva el objeto exactamente a como estaba.
        editStart: () => this.pushUndo(),
        editLive: () => { if (this.panel === 'props') this.refrescarPanelLigero(); },
        editar: (accion) => this.editar(accion),
        comandoEditar: (tipo) => this.comandoEdicion(tipo),
        // El motor puede pedir cambiar de herramienta (por ejemplo, al orientar una cámara ya colocada)
        setTool: (t) => this.setTool(t),
        // Comandos interactivos (MOVER, GIRAR…): la barra de estado muestra la fase y el valor
        comando: (c) => { this.estadoComando(c); this.refrescarBarra(); },
        comandoInfo: (t) => { const l = document.getElementById('cmdLabel'); if (l) l.textContent = t || 'Valor'; },
        // Esc la gasta primero quien tenga una ventana encima: el monitor a pantalla completa
        escOcupado: () => !!(this.monitor && this.monitor.op.completo),
        portapapeles: (accion) => this.accionPortapapeles(accion),
        hint: (t) => this.hint(t),
        menu: () => { if (this._aviso) { this._aviso.remove(); this._aviso = null; } },
        ctx: (act) => this.ctx(act),
        ctxEstado: () => this.ctxEstado(),
        pref: (clave) => this.conmutarPref(clave),
        prefs: () => this.prefs,
        cursor: (w, hover) => this.status(w, hover),
        coverageData: () => this.results.coverage,
        licencia: () => this.licencia } });
    this.cargarPrefs(true);
    try { this._paletaAbierta = localStorage.getItem(LS_PALETA) || null; } catch (e) { this._paletaAbierta = null; }
    this.construirBarraEstado();
    this.buildMenu();
    this.bindToolbar();
    this.conectarEscritorio();
    this.bindPanel();
    // Monitor de cámara (§8): se crea una sola vez; el bucle arranca cuando se abre su panel
    this.monitor = new Monitor(this);
    this.bindMonitor();
    document.getElementById('quickpanels').addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-panel]'); if (b) this.showPanel(b.dataset.panel);
    });
    document.querySelector('.topright').addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-act]'); if (b) this.act(b.dataset.act, b);
    });
    this.cad.on.measure = (d) => {
      if (!this._calibrating) return;
      this._calibrating = false;
      const real = parseFloat(prompt(`Distancia dibujada: ${d.toFixed(3)} unidades.\nIntroduzca la distancia real en metros (§10):`, d.toFixed(2)));
      if (!real || real <= 0) { this.hint('Calibración cancelada.'); return; }
      this.prj.meta.scale = real / d;
      this.alert(`Escala calibrada: 1 unidad de dibujo = ${(real / d).toFixed(4)} m.`);
    };
    this.loadOrNew();
    setInterval(() => this.autosave(), 30000);
    window.addEventListener('beforeunload', () => this.autosave(true));
    this.hint('Proyecto cargado. Use el panel Recorrido (§41) para seguir el flujo completo del contrato.');
  },

  loadOrNew() {
    let prj = null;
    try {
      const raw = localStorage.getItem(LS_AUTO);
      if (raw) { const chk = integrityCheck(raw); if (chk.ok) prj = deserialize(raw); }
    } catch (e) { console.warn('Autoguardado ilegible', e); }
    this.prj = prj || demoProject();
    // Asegurar catálogo del distribuidor cargado por defecto en la sesión de diseño
    if (this.prj && this.prj.catalog && this.prj.catalog.items && this.prj.catalog.items.length < 500) {
      cargarCatalogoDistribuidor(this.prj.catalog).catch(() => {});
    }
    this.cad.setProject(this.prj);
    this.pushUndo(true);
    this.recalc(false);
    this.showPanel('walkthrough');
    this.paintPanel();
  },

  /* ------------------------------ espacio de trabajo y puntero (§8) ------------------------------ */

  /**
   * Preferencias del usuario (puntero, colores del espacio, forzados y selección). Se guardan en el
   * navegador aparte del proyecto, como las Opciones de AutoCAD: valen para cualquier proyecto.
   */
  cargarPrefs(silencioso = false) {
    let guardadas = null;
    try { guardadas = JSON.parse(localStorage.getItem(LS_PREFS) || 'null'); }
    catch (e) { console.warn('Preferencias ilegibles, se usan las de fábrica', e); }
    this.prefs = normalizarPrefs(guardadas || PREFS_POR_DEFECTO);
    this.aplicarPrefs();
    if (!silencioso && guardadas) this.hint('Espacio de trabajo: ' + resumenPrefs(this.prefs));
    return this.prefs;
  },

  guardarPrefs() {
    try { localStorage.setItem(LS_PREFS, JSON.stringify(this.prefs)); } catch (e) { /* modo privado */ }
  },

  /** Lleva las preferencias al motor CAD y al proyecto (rejilla visible y paso viven en los dos). */
  aplicarPrefs() {
    const p = this.prefs;
    const fondoCambiado = this._fondoAplicado !== undefined && this._fondoAplicado !== p.fondo;
    if (this.cad) this.cad.setPrefs(p);
    if (this.prj) {
      this.prj.settings.gridVisible = p.rejillaVisible;
      this.prj.settings.gridStep = p.pasoRejilla;
      this.prj.settings.snapEnabled = p.forzadoRejilla;
    }
    this._fondoAplicado = p.fondo;
    // Si hay un plano importado, sus colores se recalculan para el fondo nuevo: así el plano se
    // sigue viendo aunque se cambie el fondo del espacio de trabajo (§8 + §9).
    if (fondoCambiado && this._plano && this.cad) this.recolorearPlano();
  },

  /** Vuelve a pintar las capas y los elementos del plano importado con el fondo actual. */
  recolorearPlano() {
    if (!this._plano) return 0;
    const modo = (this.prj.settings && this.prj.settings.colorPlano) || 'original';
    const fondo = this.prefs.fondo;
    let n = 0;
    for (const l of this.prj.layers) {
      if (!l.delPlano) continue;
      l.color = colorDePlano(l.colorOriginal || '#ffffff', modo, fondo);
      n++;
    }
    const ids = new Set(this._plano.ids);
    for (const e of this.prj.entities) {
      if (!ids.has(e.id) || !e.data) continue;
      e.data.color = colorDePlano(e.data.colorOriginal || CLARO_DEL_PLANO, modo, fondo);
    }
    if (this.cad) this.cad.draw();
    return n;
  },

  /** Cambia un ajuste del espacio de trabajo. `valor` admite valor directo o recibe el del control. */
  /**
   * Número escrito por el usuario, con coma o punto decimal. Un campo **vacío no es un cero**:
   * devuelve null y quien llama deja el valor como estaba, que es lo que se espera al borrar un
   * número para escribir otro.
   */
  numeroONada(v) {
    if (v === undefined || v === null) return null;
    const t = String(v).trim();
    if (!t) return null;
    const n = Number(t.replace(',', '.'));
    return isFinite(n) ? n : null;
  },

  setPref(clave, valor, vivo = false) {
    const d = defDe(clave);
    if (!d) { this.hint('Ajuste desconocido: ' + clave); return undefined; }
    if (valor === undefined) valor = !this.prefs[clave];   // conmutar (teclas de función)
    const v = valorValido(d, valor);
    // Un número a medias no es un error: mientras se borra para escribir otro, se deja como estaba
    if (v === undefined) {
      if (!vivo) this.hint(`${d.etiqueta}: valor «${valor}» no válido.`);
      return undefined;
    }
    this.prefs = normalizarPrefs(Object.assign({}, this.prefs, { [clave]: v }));
    if (!vivo) this.guardarPrefs();
    this.aplicarPrefs();
    this.cad.draw();
    this.actualizarBarraEstado();
    return this.prefs[clave];
  },

  /** Conmuta un ajuste (F3, F7, F8, F9, F10 y los botones de la barra de estado). */
  conmutarPref(clave) {
    const v = this.setPref(clave);
    if (v === undefined) return;
    const d = defDe(clave);
    const tecla = TECLAS[clave] ? ` (${TECLAS[clave]})` : '';
    const etiqueta = d.etiqueta.includes(tecla.trim()) ? d.etiqueta : d.etiqueta + tecla;
    this.hint(`${etiqueta}: ${typeof v === 'boolean' ? (v ? 'activado' : 'desactivado') : v}`);
    if (this.panel === 'options') this.refresh();
  },

  /** Aplica un tema completo de espacio de trabajo. */
  setTema(tema) {
    this.prefs = aplicarTema(this.prefs, tema);
    this.guardarPrefs();
    this.aplicarPrefs();
    this.cad.draw();
    this.actualizarBarraEstado();
    this.refresh();
    this.hint(`Tema del espacio de trabajo: ${tema === 'personalizado' ? 'personalizado' : tema}.`);
  },

  /** Vuelve a los valores de fábrica del espacio de trabajo. */
  resetPrefs() {
    this.prefs = normalizarPrefs(PREFS_POR_DEFECTO);
    this.guardarPrefs();
    this.aplicarPrefs();
    this.cad.draw();
    this.actualizarBarraEstado();
    this.refresh();
    this.hint('Espacio de trabajo restablecido: ' + resumenPrefs(this.prefs));
  },

  /** Barra de estado con los conmutadores de AutoCAD (REF, REJILLA, FORZ, ORTO, POLAR). */
  actualizarBarraEstado() {
    const el = document.getElementById('stToggles');
    if (!el || !this.prefs) return;
    el.innerHTML = CONMUTABLES.map((c) => {
      const activo = !!this.prefs[c];
      const d = defDe(c);
      return `<button class="stog ${activo ? 'on' : ''}" data-act="pref:${c}" title="${d.etiqueta}${TECLAS[c] ? ' · ' + TECLAS[c] : ''}">${LEYENDA_CONMUTABLE[c]}</button>`;
    }).join('');
    this.pintarBotonTema();
  },

  /**
   * Botón de tema de la barra de estado: rota entre **Papel** (hoja clara), **Oscuro**, **AutoCAD** y
   * **Negro**. Un clic cambia el fondo del espacio de trabajo y, con él, los colores del plano
   * importado y del puntero, que se recalculan para el nuevo fondo.
   */
  pintarBotonTema() {
    const caja = document.getElementById('stTema');
    if (!caja || !this.prefs) return;
    const tema = TEMAS[this.prefs.tema] ? this.prefs.tema : 'personalizado';
    const sig = nombreTemaCorto(siguienteTema(tema));
    caja.innerHTML = `<button class="stog tema" data-act="tema:siguiente" `
      + `title="Aspecto del espacio de trabajo: ${nombreTemaCorto(tema)}. Pulse para pasar a ${sig}. `
      + `También en Dibujo → Opciones de dibujo.">🎨 ${nombreTemaCorto(tema)}</button>`;
  },

  /* ------------------------------ menús ------------------------------ */
  buildMenu() {
    const bar = document.getElementById('menubar');
    bar.innerHTML = MENUS.map((m, i) =>
      `<div class="menu"><button data-menu="${i}">${m.title}</button><div class="drop" data-drop="${i}">${
        m.items.map((it) => (it.sep ? '<hr>' : `<button ${it.act ? `data-act="${it.act}"` : ''} ${it.panel ? `data-panel="${it.panel}"` : ''}>${it.label}</button>`)).join('')
      }</div></div>`).join('');
    bar.addEventListener('click', (ev) => {
      const mb = ev.target.closest('[data-menu]');
      if (mb) {
        const i = mb.dataset.menu;
        const open = bar.querySelector('.menu.open');
        bar.querySelectorAll('.menu').forEach((m) => m.classList.remove('open'));
        if (!open || open !== mb.parentElement) mb.parentElement.classList.add('open');
        return;
      }
      const item = ev.target.closest('.drop button');
      if (item) {
        bar.querySelectorAll('.menu').forEach((m) => m.classList.remove('open'));
        if (item.dataset.panel) this.showPanel(item.dataset.panel);
        else if (item.dataset.act) this.act(item.dataset.act, item);
      }
    });
    document.addEventListener('click', (ev) => { if (!ev.target.closest('.menu')) bar.querySelectorAll('.menu').forEach((m) => m.classList.remove('open')); });
  },

  /**
   * Barra lateral en **paletas** (§7, §8): los grupos de siempre en AutoCAD — Dibujo, Modificar,
   * Obstáculos, Vista y Proyecto — plegables (una abierta a la vez, como las cintas de opciones)
   * y con un buscador para encontrar una herramienta sin recorrerlas todas.
   */
  /**
   * Pinta la **cinta de herramientas**: una fila de pestañas (Dibujo, Modificar, Anotación,
   * Obstáculos, Vista y Proyecto) y, debajo, las herramientas de la pestaña activa agrupadas por
   * bloques, como en AutoCAD. Con texto en el buscador se sustituye todo por los resultados.
   */
  pintarPaletas() {
    const tb = document.getElementById('toolbar');
    if (!tb) return;
    const activaId = this._paletaAbierta || (PALETAS.find((p) => p.abierta) || PALETAS[0]).id;
    const q = (this._buscarPaletas || '').trim();
    const coincidencias = q ? buscarEnPaletas(q) : null;

    const boton = (it, paletaId) => {
      const activo = this._activoEnBarra(it);
      const cls = ['ribbtn', activo ? 'on' : '', it.danger ? 'danger' : ''].filter(Boolean).join(' ');
      return `<button class="${cls}" data-act="${esc(it.act)}" data-paleta="${esc(paletaId || '')}" title="${esc(it.title || it.etiqueta)}">`
        + `<span class="pico">${esc(it.icono)}</span><span class="petq">${esc(it.etiqueta)}</span></button>`;
    };

    // Pestañas y buscador
    let html = '<div class="ribtabs">';
    for (const p of PALETAS) {
      const on = p.id === activaId && !coincidencias;
      html += `<button class="ribtab${on ? ' on' : ''}" data-paleta-toggle="${esc(p.id)}" aria-selected="${on}" title="${esc(p.nota || p.titulo)}">`
        + `<span class="pico">${esc(p.icono)}</span>${esc(p.titulo)}</button>`;
    }
    html += `<span class="ribbusca"><input id="toolsearch" type="search" placeholder="Buscar herramienta…" `
      + `value="${esc(q)}" aria-label="Buscar herramienta"></span></div>`;

    // Cuerpo: resultados de la búsqueda o los grupos de la pestaña activa
    html += '<div class="ribcuerpo">';
    if (coincidencias) {
      html += `<div class="ribgrupo"><span class="ribgtit">Resultados (${coincidencias.length})</span><div class="ribbots">`
        + (coincidencias.map((it) => boton(it, it.paleta)).join('')
          || '<span class="muted small">Ninguna herramienta coincide. Pruebe con «muro», «girar» o «3d».</span>')
        + '</div></div>';
    } else {
      const paleta = PALETAS.find((p) => p.id === activaId) || PALETAS[0];
      const grupos = [];
      for (const it of paleta.items) {
        let g = grupos.find((x) => x.nombre === (it.grupo || ''));
        if (!g) { g = { nombre: it.grupo || '', items: [] }; grupos.push(g); }
        g.items.push(it);
      }
      for (const g of grupos) {
        html += `<div class="ribgrupo">${g.nombre ? `<span class="ribgtit">${esc(g.nombre)}</span>` : ''}`
          + `<div class="ribbots">${g.items.map((it) => boton(it, paleta.id)).join('')}</div></div>`;
      }
      html += `<span class="ribnota">${esc(paleta.nota || '')}</span>`;
    }
    html += '</div>';
    tb.innerHTML = html;

    const busca = document.getElementById('toolsearch');
    busca.addEventListener('input', () => {
      this._buscarPaletas = busca.value; this.pintarPaletas();
      const b = document.getElementById('toolsearch');
      if (b) { b.focus(); b.setSelectionRange(b.value.length, b.value.length); }
    });
    // Los atajos de una sola letra no deben dispararse mientras se escribe en el buscador
    busca.addEventListener('keydown', (ev) => ev.stopPropagation());
    tb.querySelectorAll('[data-paleta-toggle]').forEach((b) => b.addEventListener('click', () => {
      const id = b.dataset.paletaToggle;
      // Con pestañas siempre hay una activa: pulsar la activa no la cierra (no tiene sentido)
      this._paletaAbierta = id;
      try { localStorage.setItem(LS_PALETA, this._paletaAbierta); } catch (e) { /* sin memoria */ }
      this.pintarPaletas();
    }));
  },

  /** ¿Esta herramienta es la activa ahora mismo? (para resaltarla en la barra) */
  _activoEnBarra(it) {
    // Ojo: la barra se pinta antes de cargar el proyecto, así que `prj` puede no existir todavía
    if (!this.prj) return false;
    if (it.act.startsWith('tool:')) return this.cad.tool === it.act.slice(5);
    if (it.act.startsWith('obs:')) return this.cad.tool === 'obstacle' && this.cad.toolKind === it.act.slice(4);
    if (it.act === 'ver:3d') return !!this.cad.modo3d;
    if (it.act === 'plan:grid') return this.prj.settings.gridVisible !== false;
    if (it.act === 'plan:snap') return this.prj.settings.snapEnabled !== false;
    if (it.act.startsWith('cmd:')) return this.cad.comandoActivo() === it.act.slice(4);
    return false;
  },

  /** Vuelve a pintar la barra (se llama al cambiar de herramienta o de comando). */
  refrescarBarra() { this.pintarPaletas(); },

  bindToolbar() {
    const tb = document.getElementById('toolbar');
    this.pintarPaletas();
    tb.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-act]');
      if (b) this.act(b.dataset.act, b);
    });
  },

  bindPanel() {
    const p = document.getElementById('panel');
    p.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-act]');
      // Las casillas y los botones de opción ya los despacha el evento `change`. Si también los
      // cogiera el clic, cada acción se ejecutaría **dos veces** y un conmutador volvería a su
      // sitio: se pulsaba «Retícula del suelo» y no pasaba nada. Los deslizadores sí se dejan:
      // su acción fija un valor, no lo alterna, así que repetirla no cambia el resultado.
      const tipo = (b && b.type ? String(b.type) : '').toLowerCase();
      const esCasilla = b && b.tagName === 'INPUT' && (tipo === 'checkbox' || tipo === 'radio');
      if (b && !esCasilla) this.act(b.dataset.act, b);
    });
    p.addEventListener('input', (ev) => {
      const el = ev.target;
      if (el.dataset.act && el.dataset.act.startsWith('cat:search')) { this.catalogFilter.q = el.value; return; }
      if (el.dataset.act === 'cam:filter:q') {
        this.camPickerFilter.q = el.value;
        this.actualizarOpcionesCamara(el);
        return;
      }
      const act = el.dataset && el.dataset.act;
      // Los deslizadores se mueven «en vivo»: se repinta el plano, pero no el panel, porque si el
      // control se volviera a crear a media pulsación se cortaría el arrastre.
      if (act && act.endsWith(':slider')) {
        const clave = act.slice(0, -':slider'.length).replace(/^pref:/, '');
        this.setPref(clave, el.value, true);
        const gemelo = p.querySelector(`[data-act="${act.slice(0, -':slider'.length)}"]:not([type="range"])`);
        if (gemelo) gemelo.value = el.value;
        return;
      }
      // La ruleta de orientación de la cámara, igual: el cono sigue al deslizador.
      if (act === 'cam:giro' && el.type === 'range') {
        const c = this.cad.selected().find((x) => x.type === 'camera');
        if (!c) return;
        c.data.azimuth = ((Number(el.value) % 360) + 360) % 360;
        const num = p.querySelector('[data-act="cam:azimuth"]');
        if (num && document.activeElement !== num) num.value = Math.round(c.data.azimuth);
        this.cad.draw();
        this.scheduleSave();
      }
    });
    // Al entrar en un número se selecciona todo su contenido: así se sustituye escribiendo encima,
    // que es lo que se espera de un campo de medidas. Solo la primera vez que recibe el foco.
    p.addEventListener('focusin', (ev) => {
      const el = ev.target;
      if (!el || !el.classList || !el.classList.contains('num')) return;
      if (el.dataset && el.dataset.sel) return;
      el.dataset.sel = '1';
      try { el.select(); } catch (e) { /* sin soporte */ }
    });
    // Al salir de un control se hace el repintado que hubiera quedado pendiente mientras se escribía
    p.addEventListener('focusout', () => {
      if (!this._panelPendiente) return;
      setTimeout(() => { if (!this._editandoEnPanel() && this._panelPendiente) this.paintPanel(); }, 0);
    });
    p.addEventListener('change', (ev) => {
      const el = ev.target;
      let act = el.dataset && el.dataset.act;
      if (!act) return;
      // El deslizador de un ajuste numérico comparte acción con su campo: «pref:x:slider»
      if (act.endsWith(':slider')) act = act.slice(0, -':slider'.length);
      if (act === 'cat:search') { this.catalogFilter.q = el.value; this.refresh(); return; }
      if (act === 'cat:filter') { this.catalogFilter.cat = el.value; this.refresh(); return; }
      if (act === 'cam:filter:marca') {
        this.camPickerFilter.marca = el.value;
        this.actualizarOpcionesCamara(el);
        return;
      }
      if (act === 'cam:filter:tipo') {
        this.camPickerFilter.tipo = el.value;
        this.actualizarOpcionesCamara(el);
        return;
      }
      if (act.startsWith('edit:set:')) {
        const campo = act.slice('edit:set:'.length);
        this.editarCampo(campo, el.type === 'checkbox' ? el.checked : el.value);
        return;
      }
      if (act.startsWith('edit:vertice:')) {
        const partes = act.split(':');
        this.editarVertice(Number(partes[2]), partes[3], Number(el.value));
        return;
      }
      // Declaración de privacidad: responsable, finalidad y funciones sensibles del sistema.
      // Se atienden aquí porque cada campo tiene su propia acción y el texto llega en `el.value`.
      if (act.startsWith('priv:set:')) {
        const campo = act.slice('priv:set:'.length);
        this.declararPrivacidad(campo, el.type === 'checkbox' ? el.checked : el.value);
        return;
      }
      if (act.startsWith('priv:fn:')) {
        this.declararFuncionIA(act.slice('priv:fn:'.length), el.type === 'checkbox' ? el.checked : el.value !== 'false');
        return;
      }
      if (act.startsWith('rule:set:')) {
        const key = act.split(':')[2];
        const def = RULE_DEFS.find((d) => d.key === key);
        if (def && def.type === 'text') this.prj.rules[key] = el.value;
        else {
          const n = this.numeroONada(el.value);
          if (n === null) { this.hint('Número no válido: se deja el valor anterior.'); this.refresh(); return; }
          this.prj.rules[key] = n;
        }
        this.recalcLight(); this.refresh(); this.scheduleSave(); return;
      }
      this.act(act, el, el.value);
    });
  },

  /* ------------------------------ paneles ------------------------------ */
  showPanel(name) {
    if (name === 'help') { this.hint(HELP.contextual(this.prj, this.results)); return; }
    this.panel = name;
    document.getElementById('panelTitle').textContent = PANEL_TITLES[name] || name;
    this.paintPanel(true);          // cambio pedido por el usuario: se pinta aunque se esté escribiendo
    const hints = {
      coverage: 'Seleccione una cámara para modificar su orientación, altura, lente o campo de visión.',
      cabling: 'El generador evita muros y prioriza las bandejas dibujadas en la capa Canalizaciones.',
      network: 'La asignación automática reparte cámaras por proximidad respetando puertos y presupuesto PoE.',
      recording: 'El cálculo usa el bitrate real de cada equipo y el modo de grabación configurado.',
      validation: 'Revise los errores antes de exportar: el contrato exige validar antes de cerrar el proyecto.' };
    if (hints[name]) this.hint(hints[name]);
  },

  /**
   * Redibuja el panel. Se difiere un tick: sustituir el DOM de forma síncrona dentro
   * del despacho de un evento `change` del propio panel lanza excepción en Chromium
   * (el nodo enfocado deja de ser hijo durante el borrado).
   */
  refresh() {
    if (this._paintQueued) return;
    this._paintQueued = true;
    setTimeout(() => { this._paintQueued = false; this.paintPanel(); }, 0);
  },
  /**
   * ¿Se está escribiendo ahora mismo en un control del panel? Mientras sea así **el panel no se
   * repinta**: volver a crear el control a media tecla hace perder el cursor, la selección y lo que
   * se lleva escrito, que era exactamente el problema al corregir un número o un texto. El repintado
   * queda pendiente y se hace al salir del campo (blur/change).
   */
  _editandoEnPanel() {
    const p = document.getElementById('panel');
    const a = document.activeElement;
    return !!(p && a && p.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName || ''));
  },

  paintPanel(force = false) {
    const p = document.getElementById('panel');
    // Si el usuario está escribiendo, solo se repinta el plano: el panel espera. Con `force` (al
    // cambiar de panel a petición del usuario) se repinta igual, devolviendo el cursor a su sitio.
    if (this._editandoEnPanel() && !force) {
      this._panelPendiente = true;
      this.cad.draw();
      return;
    }
    this._panelPendiente = false;
    // Aun sin foco, se recuerda dónde estaba el cursor por si el repintado llega de un evento que
    // no quita el foco (por ejemplo, un clic en un botón del propio panel).
    const activo = document.activeElement;
    const recuerdo = activo && p.contains(activo) && activo.dataset && activo.dataset.act
      ? { act: activo.dataset.act, ini: activo.selectionStart, fin: activo.selectionEnd, tipo: activo.type }
      : null;
    p.innerHTML = renderPanel(this.panel, this);
    this.updateWalkBadge();
    this.cad.draw();
    if (this.panel === 'options') this.pintarPrevisualizacion();
    if (this.panel === 'monitor') this.asegurarMonitor();
    if (recuerdo) {
      const otro = p.querySelector(`[data-act="${recuerdo.act}"]`);
      if (otro && otro.focus) {
        otro.focus();
        // Los campos numéricos no dejan mover el cursor: solo los de texto
        if (otro.setSelectionRange && recuerdo.ini !== null) {
          try { otro.setSelectionRange(recuerdo.ini, recuerdo.fin); } catch (e) { /* sin soporte */ }
        }
      }
    }
  },

  /* ------------------------------ monitor ------------------------------ */

  /** Escuchadores del monitor: los botones de la pantalla completa viven fuera del panel. */
  bindMonitor() {
    const capa = document.getElementById('monfull');
    if (!capa) return;
    capa.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-act]');
      if (b) this.act(b.dataset.act, b);
    });
    // Esc cierra la pantalla completa, como cualquier visor
    window.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape' && this.monitor && this.monitor.op.completo) {
        this.monitor.fijar('completo', false);
        this.ajustarMonitor();
        this.refresh();
      }
    });
  },

  /**
   * Pone a punto el lienzo y arranca el bucle. Se llama cada vez que se pinta el panel porque el
   * lienzo se crea de nuevo con el HTML del panel, y hay que volver a dejarlo a su tamaño.
   */
  asegurarMonitor() {
    if (!this.monitor) return;
    this.ajustarMonitor();
    if (this._rafMonitor) return;
    const paso = (ts) => {
      this._rafMonitor = 0;
      if (!this.monitor || this.panel !== 'monitor') return;
      this.monitor.tick(ts || 0);
      this._rafMonitor = requestAnimationFrame(paso);
    };
    this._rafMonitor = requestAnimationFrame(paso);
  },

  /** Ajusta el lienzo: la proporción del sensor y el tamaño de la pantalla completa. */
  ajustarMonitor() {
    if (!this.monitor) return;
    const cam = this.monitor.camara();
    let aspecto = 16 / 9;
    if (cam) {
      try {
        const v = vistaMonitor(cam, this.prj.catalog, this.prj.rules || {});
        if (v && v.aspecto > 0.5 && v.aspecto < 4) aspecto = v.aspecto;
      } catch { aspecto = 16 / 9; }
    }
    const panel = document.getElementById('moncanvas');
    if (panel) { panel.width = 640; panel.height = Math.round(640 / aspecto); }
    const capa = document.getElementById('monfull');
    const grande = document.getElementById('monfullcanvas');
    if (capa) capa.hidden = !this.monitor.op.completo;
    if (grande) {
      // Se deja el alto de la ventana menos la barra de botones; el ancho sale de la proporción
      const alto = Math.max(320, Math.min(900, Math.round((window.innerHeight || 720) * 0.78)));
      const ancho = Math.min(1600, Math.round(alto * aspecto));
      grande.width = ancho;
      grande.height = Math.round(ancho / aspecto);
    }
    this.monitor._sucio = true;
  },

  /**
   * Dibuja la previsualización del puntero del panel de opciones: la misma cruz, mira, marca de
   * referencia y etiquetas que se verán en el lienzo, sobre el color de fondo elegido.
   */
  pintarPrevisualizacion() {
    const c = document.getElementById('prefcursor');
    if (!c) return;
    const ctx = c.getContext('2d');
    const q = this.prefs;
    const w = c.width, h = c.height;
    ctx.fillStyle = q.fondo;
    ctx.fillRect(0, 0, w, h);
    // Rejilla y ejes, con los colores elegidos
    ctx.strokeStyle = q.colorRejilla; ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x <= w; x += 30) { ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, h); }
    for (let y = 0; y <= h; y += 30) { ctx.moveTo(0, y + 0.5); ctx.lineTo(w, y + 0.5); }
    ctx.stroke();
    ctx.strokeStyle = q.colorEjes;
    ctx.beginPath(); ctx.moveTo(0, h / 2 + 0.5); ctx.lineTo(w, h / 2 + 0.5); ctx.stroke();
    // Puntero en el centro, con la misma geometría (y el mismo trazo nítido de medio píxel) que el
    // del lienzo, para que la muestra sea exactamente lo que se verá al dibujar.
    const x = Math.round(w / 2) + 0.5, y = Math.round(h / 2) + 0.5;
    const conMira = q.tipoPuntero !== 'flecha';
    // La cruz se dibuja en la misma proporción que en el lienzo (y con un mínimo para que un 1 % se
    // vea en la muestra): así el porcentaje que se elige aquí es el que se verá al dibujar.
    const real = this.cad ? { w: this.cad.w, h: this.cad.h } : { w, h };
    const arm = Math.max(9, tamanoCruzPx(q.tamanoCruz, real.w, real.h) * (w / Math.max(1, real.w)));
    const lado = conMira ? Math.max(3, q.tamanoMira) : 0;
    const hueco = conMira ? Math.max(3, lado / 2 + 1) : 0;
    if (q.tipoPuntero !== 'flecha') {
      ctx.strokeStyle = q.colorCruz; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x - arm, y); ctx.lineTo(x - hueco, y);
      ctx.moveTo(x + hueco, y); ctx.lineTo(x + arm, y);
      ctx.moveTo(x, y - arm); ctx.lineTo(x, y + hueco);
      ctx.moveTo(x, y + hueco); ctx.lineTo(x, y + arm);
      ctx.stroke();
      if (conMira) {
        ctx.strokeStyle = q.colorMira;
        ctx.strokeRect(x - lado / 2 + 0.5, y - lado / 2 + 0.5, lado - 1, lado - 1);
      }
    } else {
      ctx.fillStyle = q.colorCruz;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 14); ctx.lineTo(x + 4, y + 10); ctx.lineTo(x + 9, y + 10); ctx.closePath(); ctx.fill();
    }
    ctx.strokeStyle = q.colorReferencia; ctx.lineWidth = 1.6;
    ctx.strokeRect(x + 60 - 5.5, y - 30 - 5.5, 11, 11);
    if (q.marcasJuntoCursor) {
      ctx.font = '11px system-ui, sans-serif';
      ctx.fillStyle = 'rgba(8, 11, 16, 0.72)';
      ctx.fillRect(x + 14, y + 16, 132, 17);
      ctx.fillStyle = q.colorCruz;
      ctx.fillText('12,00 · -4,50 m  ·  Forzado', x + 19, y + 28);
    }
  },

  updateWalkBadge() {
    const w = this.walkthrough();
    const done = w.filter((s) => s.done).length;
    const el = document.getElementById('walkBadge');
    if (el) { el.textContent = `Recorrido ${done}/${w.length}`; el.className = done === w.length ? 'badge ok' : 'badge warn'; }
    const lb = document.getElementById('licBadge');
    if (lb) {
      const esPro = this.licencia && this.licencia.esPro;
      lb.textContent = esPro ? '🔒 LICENCIA PRO' : '⏳ TRIAL (1 cámara)';
      lb.className = esPro ? 'badge ok' : 'badge warn';
    }
  },

  /** Crea la barra de estado una sola vez, con los conmutadores de AutoCAD a la izquierda. */
  construirBarraEstado() {
    if (this._statusBuilt) return;
    document.getElementById('status').innerHTML =
      '<span id="stToggles"></span><span id="stX"></span><span id="stY"></span><span id="stZ"></span>' +
      '<span id="stS"></span><span id="stO"></span><span id="stM"></span>' +
      '<span id="stTema"></span><span class="right" id="hint"></span>';
    // Los botones de la barra de estado (forzados y tema) hasta ahora no hacían nada al pulsarlos:
    // se pintaban con su acción pero nadie la escuchaba. Un solo escuchador para todos.
    document.getElementById('status').addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-act]');
      if (b) this.act(b.dataset.act, b);
    });
    this._statusBuilt = true;
    // Caja del comando: mientras hay uno en curso se puede escribir el valor exacto
    const valor = document.getElementById('cmdValue');
    const aplicar = () => {
      const v = valor.value;
      if (!v.trim()) { this.hint('Escriba un valor o haga clic en el lienzo.'); return; }
      const ok = this.cad.aplicarDimensionDirecta ? this.cad.aplicarDimensionDirecta(v) : this.cad.valorComando(v);
      if (!ok) this.hint('Valor no válido para la operación en curso.');
      else {
        valor.value = '';
        if (!this.cad._comando && !this.cad._poly && !this.cad.draft) {
          document.getElementById('cmdbox').hidden = true;
        }
      }
    };
    valor.addEventListener('keydown', (ev) => {
      ev.stopPropagation();                      // que la «m», la «r»… no se coman la escritura
      if (ev.key === 'Enter') { ev.preventDefault(); aplicar(); }
      else if (ev.key === 'Escape') { ev.preventDefault(); this.cad.cancelarComando(); }
    });
    document.getElementById('cmdOk').addEventListener('click', aplicar);
    document.getElementById('cmdCancel').addEventListener('click', () => this.cad.cancelarComando());
    this.actualizarBarraEstado();
    if (this._hintText) document.getElementById('hint').textContent = this._hintText;
  },

  status(w, hover) {
    this.construirBarraEstado();
    const scale = this.prj.meta.scale || 1;
    document.getElementById('stX').textContent = `X ${w.x.toFixed(2)} m`;
    document.getElementById('stY').textContent = `Y ${w.y.toFixed(2)} m`;
    document.getElementById('stZ').textContent = `Zoom ${this.cad.scale.toFixed(1)} px/m`;
    document.getElementById('stS').textContent = `Escala 1:${(1 / scale).toFixed(0)}`;
    document.getElementById('stO').textContent = hover ? (hover.data.label || hover.data.name || hover.type) : '';
    // El nombre del ajuste que está forzando el cursor, como en la barra de AutoCAD
    const modo = document.getElementById('stM');
    if (modo && this.cad) modo.textContent = ETIQUETA_FORZADO[this.cad._modoForzado] || '';
    // Si el usuario está trazando un muro, obstáculo, línea o rectángulo, mostrar la caja de entrada rápida si no está visible
    const caja = document.getElementById('cmdbox');
    const lbl = document.getElementById('cmdLabel');
    if (caja && lbl && !this.cad._comando) {
      const enDibujo = (this.cad._poly && this.cad._poly.pts && this.cad._poly.pts.length > 0) || this.cad.draft;
      if (enDibujo) {
        caja.hidden = false;
        lbl.textContent = 'Longitud / Medida (m)';
      } else if (!this.cad._apunte) {
        if (caja.dataset.autoOpen) {
          caja.hidden = true;
          delete caja.dataset.autoOpen;
        }
      }
      if (enDibujo) caja.dataset.autoOpen = '1';
    }
  },

  hint(text) {
    this._hintText = text;
    // Historial corto de mensajes: útil para depurar y para comprobar en pruebas que un aviso
    // llegó a mostrarse aunque después otro mensaje lo sustituya en la barra de estado.
    this._hintLog = this._hintLog || [];
    this._hintLog.push(String(text || ''));
    if (this._hintLog.length > 40) this._hintLog.shift();
    const h = document.getElementById('hint');
    if (h) h.textContent = text;
  },
  hintLog(filtro) { return (this._hintLog || []).filter((m) => !filtro || new RegExp(filtro, 'i').test(m)); },

  /**
   * Arranque dentro del ejecutable de escritorio (§32, §35): si hay shell, la base SQLite manda.
   * Sin shell (navegador) no se hace nada y el programa usa su catálogo de serie, igual que antes.
   */
  async conectarEscritorio() {
    if (!DB.hayShell()) return;
    try {
      await DB.inicializar();
      const est = await DB.estado();
      this._shellInfo = est;
      if (est.baseDeDatos && est.baseDeDatos.articulos > 0) {
        const cat = await DB.cargarCatalogo();
        const reg = await DB.cargarReglas();
        if (cat && cat.items.length) this.prj.catalog = cat;
        if (reg && Object.keys(reg).length) this.prj.rules = { ...this.prj.rules, ...reg };
        this.recalc(true);
      }
      const conversores = (est.conversores || []).length;
      this.hint('Escritorio listo · SQLite ' + (est.baseDeDatos ? est.baseDeDatos.sqlite : '?') + ' · ' +
        (est.baseDeDatos ? est.baseDeDatos.articulos : 0) + ' artículos · ' +
        (conversores ? conversores + ' conversor(es) DWG' : 'conversor DWG no instalado'));
    } catch (e) {
      this.hint('Base de datos no disponible: ' + e.message + ' (el programa sigue funcionando).');
    }
  },

  /* ------------------------------ undo ------------------------------ */
  snapshot() { return JSON.stringify({ e: this.prj.entities, r: this.prj.rack, m: this.prj.meta, ru: this.prj.rules }); },
  pushUndo(clear = false) {
    if (clear) { this.undoStack = []; this.redoStack = []; }
    this.undoStack.push(this.snapshot());
    if (this.undoStack.length > 40) this.undoStack.shift();
    this.redoStack = [];
  },
  applyState(s) {
    const o = JSON.parse(s);
    this.prj.entities = o.e; this.prj.rack = o.r; this.prj.meta = o.m; this.prj.rules = o.ru;
    this.cad.selection.clear(); this.recalc(false); this.refresh();
  },
  undo() { if (!this.undoStack.length) return; this.redoStack.push(this.snapshot()); this.applyState(this.undoStack.pop()); this.hint('Deshacer'); },
  redo() { if (!this.redoStack.length) return; this.undoStack.push(this.snapshot()); this.applyState(this.redoStack.pop()); this.hint('Rehacer'); },

  /* ------------------------------ cambios ------------------------------ */
  /**
   * Después de cualquier cambio hay que **invalidar la escena 3D**: si no, al mover una cámara o
   * cambiarle el soporte se seguiría pintando la escena calculada antes, porque la caché solo se
   * fijaba en cuántas entidades hay (§8). El recálculo solo se paga si se está pintando en 3D.
   */
  afterChange() { this.cad._escena3dKey = ''; this.recalcLight(); this.refresh(); this.scheduleSave(); },
  scheduleSave() { clearTimeout(this._t); this._t = setTimeout(() => this.autosave(), 4000); },

  autosave(silent = false) {
    try {
      const raw = serialize(this.prj);
      localStorage.setItem(LS_AUTO, raw);
      const backups = JSON.parse(localStorage.getItem(LS_BACKUP) || '[]');
      backups.unshift({ at: new Date().toISOString(), size: raw.length, data: raw });
      localStorage.setItem(LS_BACKUP, JSON.stringify(backups.slice(0, 3)));
      if (!silent) this.hint('Autoguardado realizado · ' + new Date().toLocaleTimeString('es-ES'));
    } catch (e) { this.hint('No se pudo autoguardar: ' + e.message); }
  },

  /* ------------------------------ recálculo ------------------------------ */
  recalcLight() {
    const r = this.results;
    r.poe = computePoe(this.prj, this.prj.catalog, this.prj.rules);
    r.storage = computeStorage(this.prj, this.prj.catalog, this.prj.rules);
    r.rack = rackLayout(this.prj, this.prj.catalog);
    r.topology = buildTopology(this.prj, this.prj.catalog);
    r.links = linkReport(this.prj, this.prj.rules);
    r.bom = buildBom(this.prj, this.prj.catalog, this.prj.rules, r.storage);
    r.budget = buildBudget(r.bom, this.prj.rules);
    if (r.coverage) this.recalcCoverage();
  },

  recalcCoverage() {
    const t0 = performance.now();
    let prjCalc = this.prj;
    if (this.licencia && this.licencia.esTrial && this.prj.meta.name !== 'Planta Oficina Demo') {
      const allCams = (this.prj.entities || []).filter((e) => e.type === 'camera');
      if (allCams.length > 1) {
        // En versión Trial solo procesa la 1.ª cámara activa (excepto demo de fábrica)
        const primeraCamId = allCams[0].id;
        prjCalc = {
          ...this.prj,
          entities: this.prj.entities.filter((e) => e.type !== 'camera' || e.id === primeraCamId),
        };
      }
    }
    // Las máscaras de privacidad ocultan parte de la escena: lo que cae debajo no se registra y
    // por tanto no cuenta como cubierto. El enmascarador se construye una vez por recálculo.
    const cov = analyzeCoverage(prjCalc, this.prj.catalog, this.prj.rules,
      { enmascarado: crearEnmascarador(this.prj) });
    if (!cov.empty) {
      cov._key = this.prj.entities.filter((e) => e.type === 'camera').map((c) =>
        c.id + c.data.azimuth + c.data.tilt + c.data.height + c.data.catalogId + (c.data.presets || []).map((q) => `${q.azimuth}/${q.tilt}/${q.focal}`).join(',')).join('|') + '|' + this.prj.rules.CELDA_COBERTURA;
    }
    cov._ms = performance.now() - t0;
    this.results.coverage = cov;
    return cov;
  },

  recalc(withCoverage = true) {
    if (withCoverage) this.recalcCoverage();
    this.recalcLight();
    // Privacidad y cumplimiento: se miden sobre el diseño y alimentan la validación (§28)
    this.results.privacidad = analisisPrivacidad(this.prj, this.prj.catalog, this.prj.rules, this.results);
    this.results.cumplimiento = evaluarCumplimiento(this.prj, this.prj.catalog, this.prj.rules, this.results);
    this.results.validation = validateProject(this.prj, this.prj.catalog, this.prj.rules, this.results);
  },

  iniciarAsistenteCamara(esFisheye = false) {
    const cams = this.prj.entities.filter((x) => x.type === 'camera');
    const numCams = cams.length;
    if (this.licencia && this.licencia.esTrial && numCams >= 1 && this.prj.meta.name !== 'Planta Oficina Demo') {
      const chk = this.licencia.puedeColocarCamara(numCams);
      this.avisoCad({
        texto: `<b>Límite de Evaluación (Trial) alcanzado.</b><br>${chk.motivo}`,
        tipo: 'aviso',
        duracion: 8000,
        acciones: [{ label: 'Ver Licencia / Activar', act: 'panel:license' }],
      });
      this.hint(chk.motivo);
      this.showPanel('license');
      return;
    }
    this._nextCamFisheye = esFisheye;
    this.abrirAsistenteCamara(null);
  },

  abrirAsistenteCamara(punto = null) {
    this._asistenteCamaraAbierto = true;
    const targetParent = document.body;
    const previo = document.getElementById('dlg-camara-asistente');
    if (previo) previo.remove();

    if (!this.camPickerFilter) this.camPickerFilter = { marca: '', tipo: '', q: '' };
    const allCams = (this.prj && this.prj.catalog && this.prj.catalog.items ? this.prj.catalog.items : []).filter((i) => i.category === 'camera');
    const marcas = Array.from(new Set(allCams.map((i) => i.manufacturer).filter(Boolean))).sort();
    const tipos = Array.from(new Set(allCams.map((i) => (i.specs && (i.specs.tipo || i.specs.form)) || '').filter(Boolean))).sort();

    // Valores iniciales
    let marcaSel = this.camPickerFilter.marca || '';
    let tipoSel = this.camPickerFilter.tipo || '';
    if (this._nextCamFisheye) {
      tipoSel = tipos.find((t) => t.toLowerCase().includes('pez') || t.toLowerCase().includes('fisheye')) || tipoSel;
    }
    let queryBusq = '';
    const numCams = this.prj.entities.filter((x) => x.type === 'camera').length;
    const labelSugerida = `CAM-${String(numCams + 1).padStart(2, '0')}`;
    const hDef = (this.prj.rules && this.prj.rules.ALTO_FIJACION) || 2.8;

    const overlay = document.createElement('div');
    overlay.id = 'dlg-camara-asistente';
    overlay.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.65); z-index:99999; display:flex; align-items:center; justify-content:center; backdrop-filter:blur(3px); font-family:system-ui,-apple-system,sans-serif;';

    const card = document.createElement('div');
    card.style.cssText = 'background:#181c24; border:1px solid #3b82f6; border-radius:8px; box-shadow:0 12px 36px rgba(0,0,0,0.7); width:560px; max-width:94vw; max-height:90vh; overflow-y:auto; color:#f1f5f9; padding:20px;';

    const renderContenido = () => {
      const q = queryBusq.trim().toLowerCase();
      const filtradas = allCams.filter((i) => {
        if (marcaSel && i.manufacturer !== marcaSel) return false;
        const t = (i.specs && (i.specs.tipo || i.specs.form)) || '';
        if (tipoSel && t !== tipoSel) return false;
        if (q) {
          const txt = `${i.manufacturer} ${i.model} ${i.name || ''} ${t}`.toLowerCase();
          if (!txt.includes(q)) return false;
        }
        return true;
      });

      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid #2d3748; padding-bottom:10px;">
          <div style="display:flex; align-items:center; gap:8px;">
            <span style="font-size:20px;">🎥</span>
            <span style="font-weight:700; font-size:16px;">Asistente de Configuración de Cámara</span>
          </div>
          <button id="btn-asist-close" style="background:transparent; border:none; color:#94a3b8; font-size:20px; cursor:pointer; line-height:1;">&times;</button>
        </div>

        <div style="background:#0f1217; border:1px solid #232a36; border-radius:6px; padding:12px; margin-bottom:14px;">
          <div style="font-size:11px; text-transform:uppercase; letter-spacing:0.5px; color:#60a5fa; font-weight:700; margin-bottom:8px;">1. Filtro del Catálogo</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:8px;">
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Fabricante / Marca</label>
              <select id="asist-marca" style="width:100%; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
                <option value="">Todas las marcas (${marcas.length})</option>
                ${marcas.map((m) => `<option value="${m}" ${marcaSel === m ? 'selected' : ''}>${m}</option>`).join('')}
              </select>
            </div>
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Tipo / Factor de forma</label>
              <select id="asist-tipo" style="width:100%; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
                <option value="">Todos los tipos (${tipos.length})</option>
                ${tipos.map((t) => `<option value="${t}" ${tipoSel === t ? 'selected' : ''}>${t}</option>`).join('')}
              </select>
            </div>
          </div>
          <div style="display:flex; gap:8px; align-items:center; margin-bottom:8px;">
            <input type="text" id="asist-q" placeholder="Buscar por modelo, resolución, focal o serie…" value="${queryBusq}" style="flex:1; padding:6px 10px; font-size:12px; background:#14171f; color:#eee; border:1px solid #374151; border-radius:4px;">
            <span style="font-size:11px; color:#94a3b8; white-space:nowrap;"><b>${filtradas.length}</b> disponible(s)</span>
          </div>
          <div>
            <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Modelo de cámara</label>
            <select id="asist-modelo" size="4" style="width:100%; padding:4px 6px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #3b82f6; border-radius:4px; height:88px;">
              ${filtradas.length ? filtradas.map((cam, idx) => {
                const tBadge = (cam.specs && cam.specs.tipo) ? ` [${cam.specs.tipo}]` : '';
                const mp = (cam.specs && cam.specs.mp) ? `${cam.specs.mp} MP · ` : '';
                const lens = (cam.specs && cam.specs.lens) ? `${cam.specs.lens} mm · ` : '';
                return `<option value="${cam.id}" ${idx === 0 ? 'selected' : ''}>${cam.manufacturer} ${cam.model} — ${mp}${lens}${cam.name}${tBadge}</option>`;
              }).join('') : '<option value="" disabled>(Sin modelos con este filtro)</option>'}
            </select>
          </div>
        </div>

        <div style="background:#0f1217; border:1px solid #232a36; border-radius:6px; padding:12px; margin-bottom:16px;">
          <div style="font-size:11px; text-transform:uppercase; letter-spacing:0.5px; color:#60a5fa; font-weight:700; margin-bottom:8px;">2. Parámetros de Instalación y Montaje</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:10px;">
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Etiqueta / ID</label>
              <input type="text" id="asist-label" value="${labelSugerida}" style="width:100%; box-sizing:border-box; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
            </div>
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Altura de instalación (m)</label>
              <input type="number" step="0.1" min="1" max="25" id="asist-height" value="${hDef}" style="width:100%; box-sizing:border-box; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px;">
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Orientación / Azimut (°)</label>
              <input type="number" step="5" min="0" max="360" id="asist-azimuth" value="0" style="width:100%; box-sizing:border-box; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
            </div>
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Inclinación / Tilt (°)</label>
              <input type="number" step="1" min="0" max="89" id="asist-tilt" value="15" style="width:100%; box-sizing:border-box; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
            </div>
            <div>
              <label style="display:block; font-size:11px; color:#94a3b8; margin-bottom:4px;">Tipo de Soporte</label>
              <select id="asist-mount" style="width:100%; padding:6px 8px; font-size:12px; background:#1b222d; color:#eee; border:1px solid #374151; border-radius:4px;">
                <option value="wall">Pared (Wall)</option>
                <option value="ceiling">Techo (Ceiling)</option>
                <option value="pole">Mástil / Columna</option>
                <option value="corner">Esquina exterior</option>
              </select>
            </div>
          </div>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:10px; align-items:center;">
          <button id="btn-asist-cancel" style="padding:7px 14px; font-size:12px; background:#262f3d; color:#cbd5e1; border:1px solid #475569; border-radius:4px; cursor:pointer;">Cancelar (Esc)</button>
          <button id="btn-asist-confirm" style="padding:7px 18px; font-size:12px; background:#2563eb; color:#fff; font-weight:600; border:none; border-radius:4px; cursor:pointer; box-shadow:0 2px 8px rgba(37,99,235,0.4);">✓ Colocar Cámara en el Plano</button>
        </div>
      `;

      // Eventos internos
      card.querySelector('#btn-asist-close').onclick = () => cerrar();
      card.querySelector('#btn-asist-cancel').onclick = () => cerrar();

      const selMarcaEl = card.querySelector('#asist-marca');
      selMarcaEl.onchange = () => {
        marcaSel = selMarcaEl.value;
        this.camPickerFilter.marca = marcaSel;
        renderContenido();
      };

      const selTipoEl = card.querySelector('#asist-tipo');
      selTipoEl.onchange = () => {
        tipoSel = selTipoEl.value;
        this.camPickerFilter.tipo = tipoSel;
        renderContenido();
      };

      const inpQEl = card.querySelector('#asist-q');
      inpQEl.oninput = () => {
        queryBusq = inpQEl.value;
        const selModeloEl = card.querySelector('#asist-modelo');
        if (selModeloEl) {
          const qLoc = queryBusq.trim().toLowerCase();
          const filLoc = allCams.filter((i) => {
            if (marcaSel && i.manufacturer !== marcaSel) return false;
            const t = (i.specs && (i.specs.tipo || i.specs.form)) || '';
            if (tipoSel && t !== tipoSel) return false;
            if (qLoc) {
              const txt = `${i.manufacturer} ${i.model} ${i.name || ''} ${t}`.toLowerCase();
              if (!txt.includes(qLoc)) return false;
            }
            return true;
          });
          selModeloEl.innerHTML = filLoc.length ? filLoc.map((c, idx) => {
            const tBadge = (c.specs && c.specs.tipo) ? ` [${c.specs.tipo}]` : '';
            const mp = (c.specs && c.specs.mp) ? `${c.specs.mp} MP · ` : '';
            const lens = (c.specs && c.specs.lens) ? `${c.specs.lens} mm · ` : '';
            return `<option value="${c.id}" ${idx === 0 ? 'selected' : ''}>${c.manufacturer} ${c.model} — ${mp}${lens}${c.name}${tBadge}</option>`;
          }).join('') : '<option value="" disabled>(Sin modelos con este filtro)</option>';
        }
      };

      const selModelo = card.querySelector('#asist-modelo');
      selModelo.ondblclick = () => card.querySelector('#btn-asist-confirm').click();

      card.querySelector('#btn-asist-confirm').onclick = () => {
        const catId = selModelo.value;
        if (!catId) { alert('Por favor, seleccione un modelo de cámara.'); return; }
        const label = card.querySelector('#asist-label').value.trim() || labelSugerida;
        const height = parseFloat(card.querySelector('#asist-height').value) || hDef;
        const azimuth = parseFloat(card.querySelector('#asist-azimuth').value) || 0;
        const tilt = parseFloat(card.querySelector('#asist-tilt').value) || 0;
        const mount = card.querySelector('#asist-mount').value || 'wall';
        cerrar();
        if (punto) {
          this.colocarCamaraDefinida(punto, { catId, label, height, azimuth, tilt, mount });
        } else {
          // Si se abrió antes de pulsar en el plano:
          this._camaraPendienteColocacion = { catId, label, height, azimuth, tilt, mount };
          this.cad.tool = 'camera';
          this.cad.toolKind = null;
          this.refrescarBarra();
          this.hint(`Cámara configurada (${label}). Haga clic en el plano para situarla.`);
        }
      };
    };

    const cerrar = () => {
      this._asistenteCamaraAbierto = false;
      this._nextCamFisheye = false;
      overlay.remove();
    };

    const onKey = (ev) => {
      if (ev.key === 'Escape') {
        ev.stopPropagation();
        window.removeEventListener('keydown', onKey);
        cerrar();
      }
    };
    window.addEventListener('keydown', onKey);

    overlay.appendChild(card);
    targetParent.appendChild(overlay);
    renderContenido();
  },

  colocarCamaraDefinida(punto, opts) {
    this.pushUndo();
    const item = getItem(this.prj.catalog, opts.catId);
    const s = (item && item.specs) || {};
    const esFisheye = !!(s.fisheye || (s.tipo && s.tipo.toLowerCase().includes('pez')));
    const e = addEntity(this.prj, makeCamera(opts.catId, punto.x, punto.y, {
      label: opts.label,
      height: opts.height,
      azimuth: opts.azimuth,
      tilt: esFisheye ? 0 : opts.tilt,
      mount: esFisheye ? 'ceiling' : opts.mount,
      objective: 'OBSERVACION',
      focal: s.lens || 2.8,
    }));
    this.recalcCoverage();
    this.cad.selection = new Set([e.id]);
    if (!esFisheye && typeof this.cad._empezarApunte === 'function') {
      this.cad._empezarApunte(e);
    }
    this.afterChange();
    this.showPanel('props');
    this.hint(`Cámara ${e.data.label || e.id} (${(item && item.model) || opts.catId}) colocada.`);
  },

  actualizarOpcionesCamara(triggerEl) {
    const cardEl = triggerEl.closest('.card') || triggerEl.closest('.panel');
    const selEl = cardEl ? cardEl.querySelector('select[data-act="cam:catalog"]') : document.querySelector('select[data-act="cam:catalog"]');
    if (!selEl) { this.renderProps(); return; }
    const f = this.camPickerFilter || { marca: '', tipo: '', q: '' };
    const q = (f.q || '').trim().toLowerCase();
    const items = (this.prj.catalog.items || []).filter((i) => i.category === 'camera');
    const valActual = selEl.value;
    const filtrados = items.filter((i) => {
      if (f.marca && i.manufacturer !== f.marca) return false;
      const t = (i.specs && (i.specs.tipo || i.specs.form)) || '';
      if (f.tipo && t !== f.tipo) return false;
      if (q) {
        const txt = `${i.manufacturer} ${i.model} ${i.name || ''} ${t}`.toLowerCase();
        if (!txt.includes(q)) return false;
      }
      return true;
    });
    let html = '';
    // Si el valor seleccionado no está en la lista filtrada, lo incluimos primero para no perder la selección
    if (valActual && !filtrados.some((i) => i.id === valActual)) {
      const cur = items.find((i) => i.id === valActual);
      if (cur) {
        html += `<option value="${cur.id}" selected>${cur.manufacturer} ${cur.model} (actual)</option>`;
      }
    }
    if (!filtrados.length) {
      html += '<option value="" disabled>(Sin modelos con este filtro)</option>';
    } else {
      for (const i of filtrados) {
        const sel = i.id === valActual ? 'selected' : '';
        const tipoBadge = (i.specs && i.specs.tipo) ? ` [${i.specs.tipo}]` : '';
        html += `<option value="${i.id}" ${sel}>${i.manufacturer} ${i.model}${tipoBadge}</option>`;
      }
    }
    selEl.innerHTML = html;
    const contador = cardEl ? cardEl.querySelector('.campicker-count') : null;
    if (contador) contador.textContent = `${filtrados.length} modelo(s)`;
  },

  footprintOf(cam) { return footprint(cam, this.prj.catalog, this.prj.rules); },

  /* ------------------------------ comandos ------------------------------ */
  act(name, el, value) {
    const A = this;
    // El menú contextual del botón derecho ofrece repetir el último comando, como AutoCAD (§8)
    if (ETIQUETA_ACT[name]) this._ultimoComando = { act: name, label: ETIQUETA_ACT[name] };
    const cmd = {
      'file:new': () => A.confirm('¿Crear un proyecto nuevo? Se perderán los cambios no guardados.', () => { A.prj = newProject(); A.cad.setProject(A.prj); A.results = {}; A.pushUndo(true); A.recalc(false); A.refresh(); }),
      'file:demo': () => { A.prj = demoProject(); A.cad.setProject(A.prj); A.results = {}; A.pushUndo(true); A.recalc(true); A.refresh(); A.hint('Proyecto de demostración cargado.'); },
      'file:open': () => A.pickFile('.cctv', (text) => {
        const chk = integrityCheck(text);
        if (!chk.ok) { A.alert('Archivo no válido: ' + chk.reason); return; }
        A.prj = deserialize(text); A.cad.setProject(A.prj); A.results = {}; A.pushUndo(true); A.recalc(true); A.refresh();
        A.hint(`Proyecto abierto: ${chk.entities} entidades.`);
      }),
      'file:save': () => A.saveProject(A.prj.meta.name),
      'file:saveas': () => A.saveProject(prompt('Nombre del proyecto', A.prj.meta.name) || A.prj.meta.name),
      'file:recover': () => {
        const backups = JSON.parse(localStorage.getItem(LS_BACKUP) || '[]');
        if (!backups.length) { A.alert('No hay copias de recuperación.'); return; }
        A.alert(`Copias disponibles: ${backups.map((b) => new Date(b.at).toLocaleString('es-ES')).join(' · ')}\nSe restaurará la más reciente.`);
        A.prj = deserialize(backups[0].data); A.cad.setProject(A.prj); A.results = {}; A.recalc(true); A.refresh();
      },
      'file:dxf': () => A.pickFileBinary('.dxf', (bytes, f) => {
        // El mismo selector sirve para DXF ASCII y para DXF binario (lo que generan los conversores de DWG)
        const r = importDxfAuto(bytes);
        const rep = r.report || {};
        const avisos = [];
        const bloques = rep.blocks ? `${rep.blocks} bloque(s) expandidos (${rep.expanded} inserción/es, profundidad ${rep.depth})` : '';
        const inc = (rep.missing && rep.missing.length) ? `bloques no encontrados: ${rep.missing.join(', ')}` : '';
        if (rep.xrefMissing) avisos.push(`${rep.xrefMissing} referencia(s) externa(s) sin resolver (${rep.xrefs.filter((x) => !x.resolved).map((x) => x.name + ' → ' + x.path).join(', ')}): importe también ese DXF para incorporarlas`);
        if (rep.xrefResolved) avisos.push(`${rep.xrefResolved} referencia(s) externa(s) incorporada(s) al plano`);
        if (rep.unsupported && Object.keys(rep.unsupported).length) avisos.push(`tipos no soportados: ${Object.entries(rep.unsupported).map(([k, v]) => k + '×' + v).join(', ')}`);
        if (rep.encodingFixed) avisos.push(`texto reinterpretado como ${rep.encoding} (se corrigieron ${rep.encodingFixed} caracteres)`);
        if (inc) avisos.push(inc);
        A.aplicarPlanoImportado(r, {
          nombre: (f && f.name) || 'plano.dxf',
          titulo: `DXF ${r.binary ? 'binario' : 'ASCII'} importado`,
          detalle: bloques,
          avisos });
      }),

      /* ---------- DWG: identificación y estrategia de conversión (§9) ---------- */
      'file:dwg': () => A.pickFileBinary('.dwg', (bytes, f) => {
        const info = dwgInfo(bytes);
        const st = dwgStrategy(info, CONVERTERS);
        const bridge = bridgeStatus({ canSpawn: !!(A.prj.settings && A.prj.settings.dwgConverter) });
        A._dwgInfo = { info, strategy: st, file: f && f.name };
        const cmd = st.recommended && st.recommended.command ? st.recommended.command(`<${(f && f.name) || 'plano'}.dwg>`, `<${(f && f.name) || 'plano'}.dxf>`) : '';
        A.alert([
          st.title,
          '',
          ...st.steps.map((x, i) => `${i + 1}. ${x}`),
          '',
          `Conversor recomendado: ${st.recommended ? st.recommended.name + ' (' + st.recommended.license + ')' : '—'}`,
          cmd ? `Comando: ${cmd}` : '',
          st.recommended && st.recommended.note ? `Nota: ${st.recommended.note}` : '',
          '',
          bridge.hint,
          st.warning ? `\nAviso: ${st.warning}` : '',
        ].filter(Boolean).join('\n'));
        A.hint(`DWG detectado: ${info.versionName} · ${(info.size / 1024).toFixed(0)} KB · ${st.recommended ? st.recommended.name : 'sin conversor'}`);
        if (!A.prj.settings) A.prj.settings = {};
        A.prj.settings.lastDwg = info.versionName;
      }),
      'file:image': () => {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = 'image/*,.png,.jpg,.jpeg,.bmp';
        inp.onchange = () => {
          const f = inp.files[0]; if (!f) return;
          const img = new Image();
          img.onload = () => {
            A.cad._images = A.cad._images || {};
            const id = 'IMG' + Math.random().toString(36).slice(2, 7);
            A.cad._images[id] = img;
            A.pushUndo();
            addEntity(A.prj, { id, type: 'image', layer: 'ARQUITECTURA', points: [{ x: 0, y: 0 }], data: { width: 30, heightM: 30 * (img.height / img.width), opacity: 0.45 } });
            A.afterChange();
            A.hint('Imagen insertada. Use Medir para calibrar su escala (§10).');
          };
          img.src = URL.createObjectURL(f);
        };
        inp.click();
      },
      'plan:fit': () => { A.cad.fit(); A.hint('Zoom extensión: todo el dibujo en pantalla.'); },
      'plan:zoomPrev': () => { if (!A.cad.zoomAnterior()) A.hint('No hay una vista anterior guardada todavía.'); else A.hint('Vista anterior.'); },
      'plan:zoomVentana': () => A.cad.zoomVentana(),
      'plan:zoomReal': () => { A.cad.zoomReal(); A.hint('Zoom 100 %: 1 píxel = 1 metro.'); },
      'plan:ayudaRaton': () => A.alert(['Ratón y teclado, como en AutoCAD (§8)', '',
        '· Rueda: acerca y aleja sobre el punto que señala el cursor.',
        '· Rueda pulsada y arrastrar: desplaza la vista (encuadre).',
        '· Doble pulsación de la rueda: zoom extensión (todo el dibujo).',
        '· Botón derecho: menú contextual. Si se arrastra, desplaza la vista.',
        '· Rueda lateral: desplaza en horizontal.',
        '· Ctrl o Mayús + rueda: zoom fino (1 % por muesca).',
        '· Teclas: Z = zoom extensión · R = vista anterior · W = zoom ventana · F3 referencia · F7 rejilla · F8 ortogonal · F9 forzado · F10 polar · Esc cancela y vuelve a Selección.',
        '', 'Al importar un plano, la vista se coloca sola sobre él: no hay que buscarlo.']),
      'pref:panel:abrir': () => A.showPanel('options'),
      'panel:license': () => A.showPanel('license'),
      'lic:activate': () => {
        const inp = document.getElementById('licenseKeyInput');
        const k = inp ? inp.value : '';
        const res = A.licencia.activar(k);
        if (res.ok) {
          A.hint(res.mensaje);
          A.alert(res.mensaje);
        } else {
          A.hint(res.mensaje);
          A.alert(res.mensaje);
        }
        A.recalc(true);
        A.refresh();
      },
      'lic:deactivate': () => {
        A.licencia.desactivar();
        A.hint('Licencia desactivada. Modo Evaluación activo.');
        A.recalc(true);
        A.refresh();
      },
      'plan:planoColores:modo': () => A.planoColores(value || (A.prj.settings && A.prj.settings.colorPlano) || 'original'),
      'plan:planoColores:original': () => A.planoColores('original'),
      'plan:planoColores:claro': () => A.planoColores('claro'),
      'plan:planoColores:monocromo': () => A.planoColores('monocromo'),
      'plan:planoColores': () => {
        // Ciclo de color del plano: colores del plano → claro → monocromo (y vuelta)
        const actual = (A.prj.settings.colorPlano) || 'original';
        const i = MODOS_COLOR.indexOf(actual);
        A.planoColores(MODOS_COLOR[(i + 1) % MODOS_COLOR.length]);
      },
      'plan:planoEncuadrar': () => A.planoEncuadrar(),
      'plan:planoTraer': () => A.planoTraerAlProyecto(),
      'plan:planoAtenuar': () => A.planoAtenuar(),
      'plan:planoQuitar': () => A.planoQuitar(),
      'plan:planoSeleccionar': () => A.planoSeleccionar(),
      // Rejilla y forzado viven en las preferencias del espacio de trabajo (§8); el proyecto se
      // mantiene sincronizado por `aplicarPrefs`, de modo que las dos vías dicen lo mismo.
      'plan:grid': () => A.conmutarPref('rejillaVisible'),
      'plan:snap': () => A.conmutarPref('forzadoRejilla'),
      'pref:panel': () => { A.showPanel('options'); },
      'pref:reset': () => A.resetPrefs(),
      'plan:coverage': () => { A.prj.settings.showCoverage = !A.prj.settings.showCoverage; A.cad.draw(); },
      'plan:routes': () => { A.prj.settings.showRoutes = !A.prj.settings.showRoutes; A.cad.draw(); },
      'plan:calibrate': () => {
        A.setTool('measure');
        A._calibrating = true;
        A.hint('Haga clic en los dos extremos de una distancia conocida del plano e indique su longitud real.');
      },
      'tool:select': () => A.setTool('select'), 'tool:lasso': () => A.setTool('lasso'),
      'tool:line': () => A.setTool('line'), 'tool:polyline': () => A.setTool('polyline'),
      'tool:rect': () => A.setTool('rect'), 'tool:circle': () => A.setTool('circle'), 'tool:text': () => A.setTool('text'),
      'tool:room': () => A.setTool('room'), 'tool:camera': () => A.iniciarAsistenteCamara(false), 'tool:camera:fisheye': () => A.iniciarAsistenteCamara(true), 'tool:device': () => A.setTool('device'),
      'tool:measure': () => A.setTool('measure'), 'tool:pan': () => A.setTool('pan'),

      'cov:analyze': () => { const c = A.recalcCoverage(); A.recalcLight(); A.showPanel('coverage'); A.hint(`Cobertura ${c.coveragePct.toFixed(1)} % · ${c._ms.toFixed(0)} ms`); },
      'cov:autocam': () => A.autoCameras(),

      'cable:generate': () => {
        A.pushUndo();
        const cams = (A.prj.entities || []).filter((e) => e.type === 'camera');
        const switches = (A.prj.entities || []).filter((e) => e.type === 'device' && e.data && e.data.kind === 'switch');
        if (switches.length > 0 && cams.some((c) => !c.data || !c.data.switchId)) {
          autoAssignSwitches(A.prj, A.prj.catalog, A.prj.rules);
        }
        if (A.prj.settings) A.prj.settings.showRoutes = true;
        const r = generateRoutes(A.prj, A.prj.catalog, A.prj.rules);
        A.recalcLight(); A.refresh(); A.showPanel('cabling');
        const bad = r.report.filter((x) => !x.ok);
        A.hint(bad.length ? `Rutas generadas. ${bad.length} sin resolver: ${bad.map((b) => b.label).join(', ')}` : `${r.report.length} rutas de cable calculadas y trazadas en el plano.`);
      },
      'cable:clear': () => { A.pushUndo(); A.prj.entities = A.prj.entities.filter((e) => e.type !== 'cable'); A.afterChange(); },

      'net:assign': () => { A.pushUndo(); const r = autoAssignSwitches(A.prj, A.prj.catalog); A.recalcLight(); A.refresh(); A.hint(`${r.changes.length} asignación(es). Sin switch: ${r.unassigned}`); },
      'net:address': () => { const a = autoAddress(A.prj); A.refresh(); A.hint(`${a.length} dirección(es) IP asignada(s).`); },
      'net:diagpdf': () => A.exportDiagramPdf(),

      'rec:calc': () => { A.results.storage = computeStorage(A.prj, A.prj.catalog, A.prj.rules); A.showPanel('recording'); A.hint(`Necesario ${A.results.storage.requiredTb.toFixed(2)} TB para ${A.prj.rules.DIAS_GRABACION} días.`); },
      'rec:mode': () => { A.prj.settings.recordMode = value; A.recalcLight(); A.refresh(); },
      'rec:duty': () => { A.prj.settings.motionDuty = Number(value) / 100; A.recalcLight(); A.refresh(); },
      'rec:apply': () => {
        const s = A.results.storage, rec = s.recommendation;
        if (!rec) return;
        A.pushUndo();
        const nvr = A.prj.entities.find((e) => e.type === 'device' && e.data.kind === 'nvr');
        if (!nvr) { A.alert('Añada primero un NVR al proyecto.'); return; }
        nvr.data.disks = [{ itemId: rec.itemId, qty: rec.qty }];
        A.recalcLight(); A.refresh(); A.hint(`Discos aplicados: ${rec.qty} × ${rec.model}`);
      },
      'rec:nvr': () => {
        const rec = recommendNvr(A.prj, A.prj.catalog, A.results.storage || computeStorage(A.prj, A.prj.catalog, A.prj.rules));
        if (!rec) { A.alert('Ningún NVR del catálogo satisface las cámaras y el ancho de banda actuales.'); return; }
        if (!confirm(`Recomendado: ${rec.manufacturer} ${rec.model} — ${rec.name}\n¿Sustituir el NVR actual?`)) return;
        A.pushUndo();
        const old = A.prj.entities.find((e) => e.type === 'device' && e.data.kind === 'nvr');
        if (old) { old.data.catalogId = rec.id; }
        else addEntity(A.prj, makeDevice(rec.id, 'nvr', 0, 0, { label: 'NVR-01' }));
        A.recalcLight(); A.refresh(); A.hint('NVR actualizado: ' + rec.model);
      },

      'rack:auto': () => { A.pushUndo(); const r = autoArrange(A.prj, A.prj.catalog); A.refresh(); A.hint(`Rack distribuido: ${r.used}/${r.capacity} U`); },
      'rack:clear': () => { A.pushUndo(); A.prj.rack.items = []; A.afterChange(); },
      'rack:change': () => { A.prj.rack.catalogId = value; A.recalcLight(); A.refresh(); },

      'cat:import': () => {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = '.csv,.txt,.xlsx';
        inp.onchange = () => {
          const f = inp.files[0]; if (!f) return;
          const rd = new FileReader();
          rd.onload = () => {
            const r = /\.xlsx$/i.test(f.name)
              ? importCatalogXlsx(A.prj.catalog, new Uint8Array(rd.result), fromXlsx)
              : importCatalogCsv(A.prj.catalog, rd.result);
            A.recalcLight(); A.refresh();
            A.alert(`Catálogo importado: ${r.added} nuevo(s), ${r.updated || 0} actualizado(s).` +
              (r.errors && r.errors.length ? '\n\n' + r.errors.slice(0, 10).join('\n') : ''));
          };
          if (/\.xlsx$/i.test(f.name)) rd.readAsArrayBuffer(f); else rd.readAsText(f);
        };
        inp.click();
      },
      // Catálogo del distribuidor: el que publica con sus cámaras y su equipamiento (§24)
      'cat:distribuidor': async () => {
        try {
          const r = await cargarCatalogoDistribuidor(A.prj.catalog);
          A.recalcLight(); A.refresh();
          A.alert(`Catálogo del distribuidor cargado: ${r.anadidos} artículo(s) nuevo(s) y ${r.actualizados} actualizado(s) de ${r.total} (revisión ${r.fecha}).\n\nLos precios son de referencia en USD y se pueden editar en la tabla.`);
        } catch (e) {
          A.alert('No se pudo cargar el catálogo del distribuidor: ' + (e && e.message ? e.message : e));
        }
      },
      'cat:template': () => downloadText('plantilla-catalogo.csv',
        toCsv([['id', 'categoria', 'fabricante', 'modelo', 'nombre', 'precio', 'unidad', 'specs'],
          ['MI-CAM-4MP', 'camera', 'MiMarca', 'MC-420', 'Cámara 4 MP', '120', 'ud', '{"mp":4,"resW":2560,"resH":1440,"sensorW":6.4,"sensorH":3.6,"lens":4,"fps":25,"codec":"H.265","bitrate":4096,"poe":true,"power":8,"poeClass":"3","ip":"IP67","ik":"IK10","ir":50,"wdr":true,"form":"bullet"}']], ';'), 'text/csv', true),
      'cat:export': () => downloadText('catalogo.csv', toCsv([
        ['id', 'categoria', 'fabricante', 'modelo', 'nombre', 'precio', 'unidad'],
        ...A.prj.catalog.items.map((i) => [i.id, i.category, i.manufacturer, i.model, i.name, i.price, i.unit])], ';'), 'text/csv', true),
      'cat:price': () => { const it = getItem(A.prj.catalog, el.dataset.id); if (it) { it.price = Number(value) || 0; A.recalcLight(); } },

      'edit:delete': () => { A.pushUndo(); A.cad.selected().forEach((e) => removeEntity(A.prj, e.id)); A.cad.selection.clear(); A.afterChange(); },
      'edit:duplicate': () => { A.pushUndo(); A.cad.duplicate([...A.cad.selection]); A.afterChange(); },
      'edit:rotate': () => A.editar('rotar'),
      'edit:undo': () => A.undo(), 'edit:redo': () => A.redo(),
      'edit:mover': () => A.editar('mover'),
      'edit:escalar': () => A.editar('escalar'),
      'edit:espejo:h': () => A.editar('espejo', 'h'),
      'edit:espejo:v': () => A.editar('espejo', 'v'),
      'edit:vertice:mas': () => A.editar('vertice:mas'),
      'edit:vertice:menos': () => A.editar('vertice:menos'),
      'edit:cerrar': () => A.editar('cerrar'),
      'edit:propiedades': () => A.showPanel('props'),
      'edit:copiar': () => A.accionPortapapeles('copiar'),
      'edit:cortar': () => A.accionPortapapeles('cortar'),
      'edit:pegar': () => A.accionPortapapeles('pegar'),
      'cmd:mover': () => A.comandoEdicion('mover'),
      'cmd:copiar': () => A.comandoEdicion('copiar'),
      'cmd:rotar': () => A.comandoEdicion('rotar'),
      'cmd:escalar': () => A.comandoEdicion('escalar'),
      'cmd:espejo': () => A.comandoEdicion('espejo'),
      'cmd:cancelar': () => A.cad.cancelarComando(),
      'edit:seleccionar:tipo': () => A.editar('seleccionar:tipo'),

      'cam:renumber': () => { A.pushUndo(); A.prj.entities.filter((e) => e.type === 'camera')
        .forEach((c, i) => { c.data.label = `CAM-${String(i + 1).padStart(2, '0')}`; }); A.afterChange(); },
      'cam:align': () => { A.pushUndo(); const sel = A.cad.selected().filter((e) => e.type === 'camera'); if (sel.length < 2) return;
        const y = sel[0].points[0].y; sel.forEach((c) => { c.points[0].y = y; }); A.afterChange(); },
      /* ---------- módulo PTZ (§38) ---------- */
      'ptz:add': () => {
        const c = A.selectedCamera(); if (!c) return;
        if (!isPtz(c, A.prj.catalog)) { A.alert('El equipo seleccionado no es PTZ. Elija una cámara PTZ del catálogo.'); return; }
        A.pushUndo();
        c.data.presets = cameraPresets(c).map((p) => ({ name: p.name, azimuth: p.azimuth, tilt: p.tilt, focal: p.focal, objective: p.objective, dwell: p.dwell }));
        c.data.presets.push(presetFromCurrent(c, `Vista ${c.data.presets.length + 1}`, A.prj.rules.PTZ_DWELL_MIN));
        A.recalcCoverage(); A.recalcLight(); A.refresh();
        A.hint(`Preset añadido: ${c.data.presets[c.data.presets.length - 1].name}. Ajuste azimut, inclinación y zoom en la tabla.`);
      },
      'ptz:spread': () => {
        const c = A.selectedCamera();
        const target = c && isPtz(c, A.prj.catalog) ? c : A.prj.entities.filter((e) => e.type === 'camera' && isPtz(e, A.prj.catalog))[0];
        if (!target) { A.alert('No hay ninguna cámara PTZ en el proyecto.'); return; }
        const n = parseInt(prompt('Número de posiciones del barrido (§38):', '4'), 10);
        if (!n || n < 1) return;
        A.pushUndo();
        target.data.presets = spreadPresets(target, A.prj.catalog, n, { base: 'Barrido', dwell: A.prj.rules.PTZ_DWELL_MIN });
        target.data.ptzPatrol = true;
        A.recalcCoverage(); A.recalcLight(); A.refresh();
        A.hint(`Barrido de ${n} posiciones generado para ${target.data.label || target.id}.`);
      },
      'ptz:set': () => {
        const c = A.selectedCamera(); if (!c) return;
        const i = Number(el.dataset.i), k = el.dataset.k;
        const presets = cameraPresets(c);
        if (!presets[i]) return;
        presets[i][k] = ['azimuth', 'tilt', 'focal', 'dwell'].includes(k)
          ? (el.value === '' ? null : Number(el.value))
          : el.value;
        if (k === 'dwell' && !(presets[i][k] > 0)) presets[i][k] = Number(A.prj.rules.PTZ_DWELL_MIN) || 10;
        c.data.presets = presets.map((p) => ({ name: p.name, azimuth: p.azimuth, tilt: p.tilt, focal: p.focal, objective: p.objective, dwell: p.dwell }));
        A.recalcCoverage(); A.recalcLight();
      },
      'ptz:del': () => {
        const c = A.selectedCamera(); if (!c) return;
        const i = Number(el.dataset.i);
        A.pushUndo();
        c.data.presets = cameraPresets(c).filter((p, j) => j !== i).map((p) => ({ name: p.name, azimuth: p.azimuth, tilt: p.tilt, focal: p.focal, objective: p.objective, dwell: p.dwell }));
        A.recalcCoverage(); A.recalcLight(); A.refresh();
      },
      'ptz:goto': () => {
        const c = A.selectedCamera(); if (!c) return;
        const p = cameraPresets(c)[Number(el.dataset.i)];
        if (!p) return;
        A.pushUndo();
        c.data.azimuth = p.azimuth; c.data.tilt = p.tilt;
        if (p.focal) c.data.focal = p.focal;
        if (p.objective) c.data.objective = p.objective;
        A.recalcCoverage(); A.recalcLight(); A.refresh();
        A.hint(`${c.data.label || c.id} orientada a «${p.name}» (${p.azimuth}°).`);
      },
      'ptz:patrol': () => {
        const c = A.selectedCamera(); if (!c) return;
        A.pushUndo();
        c.data.ptzPatrol = el.checked;
        A.recalcLight(); A.refresh();
        A.hint(el.checked ? 'Patrulla activada: el bitrate de grabación incluye el factor de movimiento.' : 'Patrulla detenida: la cámara queda en su vista principal.');
      },
      'ptz:show': () => {
        A.prj.settings.showPresets = !A.prj.settings.showPresets;
        A.cad.draw();
        A.hint('Posiciones PTZ ' + (A.prj.settings.showPresets === false ? 'ocultas' : 'visibles') + ' en el plano.');
      },
      'ptz:csv': () => {
        const rows = ptzSchedule(A.prj, A.prj.catalog, A.prj.rules);
        if (!rows.length) { A.alert('No hay presets PTZ que exportar.'); return; }
        downloadText(A.fname('presets-ptz.csv'), toCsv([
          ['Camara', 'Posicion', 'Azimut', 'Inclinacion', 'Zoom', 'Objetivo', 'Permanencia s', 'Tiempo %', 'Ciclo s'],
          ...rows.map((r) => [r.camera, r.preset, r.azimuth, r.tilt, r.focal, OBJECTIVES[r.objective] ? OBJECTIVES[r.objective].label : r.objective, r.dwell, r.duty, r.cycle]),
        ], ';'), 'text/csv');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Cuadro de ${rows.length} posición(es) PTZ exportado.`);
      },
      'ptz:doc': () => A.exportDocPdf('ptz'),

      /* ---------- módulo LPR (§38) ---------- */
      'lpr:enable': () => A.setLpr('lprEnabled', el.checked),
      'lpr:mode': () => A.setLpr('lprMode', value), 'lpr:lane': () => A.setLpr('lprLane', value),
      'lpr:distance': () => A.setLpr('lprDistance', Number(value)), 'lpr:angle': () => A.setLpr('lprAngle', Number(value)),
      'lpr:speed': () => A.setLpr('lprSpeed', Number(value)), 'lpr:shutter': () => A.setLpr('lprShutter', Number(value)),
      'lpr:ir': () => A.setLpr('lprIr', el.checked),
      'lpr:zone': () => {
        A.prj.settings.showLprZones = A.prj.settings.showLprZones === false;
        A.cad.draw();
        A.hint('Zonas de captura LPR ' + (A.prj.settings.showLprZones === false ? 'ocultas' : 'visibles') + ' en el plano.');
      },
      'lpr:panel': () => A.showPanel('lpr'),
      'lpr:csv': () => {
        const rows = lprSchedule(A.prj, A.prj.catalog, A.prj.rules);
        if (!rows.length) { A.alert('No hay cámaras LPR que exportar.'); return; }
        downloadText(A.fname('cuadro-lpr.csv'), toCsv([
          ['Camara', 'Carril', 'Funcion', 'Distancia m', 'Focal mm', 'ppm', 'px caracter', 'Angulo', 'Emborronamiento %', 'Velocidad max km/h', 'IR', 'Alcance lectura m', 'Estado'],
          ...rows.map((r) => [r.camera, r.lane, r.mode, r.distance, r.focal, r.ppm, r.charPx, r.angle, r.blurPct, r.maxSpeed, r.ir ? 'Si' : 'No', r.maxReadDistance, r.ok ? 'Correcto' : 'Revisar']),
        ], ';'), 'text/csv');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Cuadro LPR de ${rows.length} cámara(s) exportado.`);
      },
      'lpr:doc': () => A.exportDocPdf('lpr'),

      /* ---------- analítica de vídeo (§38) ---------- */
      'an:add': () => {
        const c = A.selectedCamera();
        if (!c) { A.alert('Seleccione una cámara para añadirle una regla de analítica.'); return; }
        A.pushUndo();
        const zone = A.prj.entities.find((e) => e.type === 'room');
        const list = cameraRules(c);
        list.push({ type: 'intrusion', zoneId: zone ? zone.id : '', sensitivity: 5, minPpm: 0, eventsPerDay: null, actions: ['recording', 'alarm'], note: '' });
        c.data.analytics = list.map((r) => ({ type: r.type, zoneId: r.zoneId, sensitivity: r.sensitivity, eventsPerDay: r.eventsPerDay, actions: r.actions, note: r.note }));
        A.recalcLight(); A.refresh();
        A.hint('Regla añadida. Ajuste tipo, zona, sensibilidad y acciones en la tabla.');
      },
      'an:type': () => A.setRule(Number(el.dataset.i), 'type', value),
      'an:zone': () => A.setRule(Number(el.dataset.i), 'zoneId', value),
      'an:sens': () => A.setRule(Number(el.dataset.i), 'sensitivity', Number(value)),
      'an:events': () => A.setRule(Number(el.dataset.i), 'eventsPerDay', value === '' ? null : Number(value)),
      'an:actions': () => A.setRule(Number(el.dataset.i), 'actions', String(value).split('+').map((x) => x.trim()).filter(Boolean)),
      'an:del': () => {
        const c = A.selectedCamera(); if (!c) return;
        const i = Number(el.dataset.i);
        A.pushUndo();
        c.data.analytics = cameraRules(c).filter((r, j) => j !== i)
          .map((r) => ({ type: r.type, zoneId: r.zoneId, sensitivity: r.sensitivity, eventsPerDay: r.eventsPerDay, actions: r.actions, note: r.note }));
        A.recalcLight(); A.refresh();
      },
      'an:panel': () => A.showPanel('analytics'),
      'an:csv': () => {
        const rows = analyticsSchedule(A.prj, A.prj.catalog, A.prj.rules, A.results.coverage || {});
        if (!rows.length) { A.alert('No hay reglas de analítica que exportar.'); return; }
        downloadText(A.fname('reglas-analitica.csv'), toCsv([
          ['Camara', 'Regla', 'Zona', 'Sensibilidad', 'Cobertura zona %', 'Peor ppm', 'Eventos dia', 'Acciones', 'Analitica'],
          ...rows.map((r) => [r.camera, r.type, r.zone, r.sensitivity, r.coveragePct.toFixed(1), r.ppm.toFixed(0), r.events, r.actions, r.license]),
        ], ';'), 'text/csv');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Cuadro de ${rows.length} regla(s) de analítica exportado.`);
      },
      'an:doc': () => A.exportDocPdf('analytics'),

      /* ---------- fibra óptica (§38) ---------- */
      'fiber:csv': () => {
        const f = fiberSummary(A.prj, A.prj.catalog, A.prj.rules);
        if (!f.fiberLinks) { A.alert('No hay enlaces de fibra en el proyecto.'); return; }
        downloadText(A.fname('fibra.csv'), toCsv([
          ['Camara', 'Switch', 'Distancia m', 'Fibra', 'Transceptor', 'Atenuacion dB', 'Conectores', 'Empalmes', 'Perdidas dB', 'Margen dB', 'Resto dB', 'Uso %', 'Estado'],
          ...f.links.map((l) => [l.camera, l.switch, l.distance.toFixed(1), l.typeLabel, l.sfpModel, l.atten.toFixed(2), l.connectors, l.splices,
            l.totalLoss.toFixed(2), l.margin, l.remaining.toFixed(2), l.pct.toFixed(0), l.status]),
        ], ';'), 'text/csv');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Cuadro de ${f.links.length} enlace(s) de fibra exportado.`);
      },
      'fiber:doc': () => A.exportDocPdf('fiber'),

      /* ---------- vídeo analógico (§38) ---------- */
      'ana:panel': () => A.showPanel('analog'),
      'ana:format': () => A.setAnalog('analogFormat', value),
      'ana:cable': () => A.setAnalog('analogCable', value),
      'ana:distance': () => A.setAnalog('analogDistance', Number(value)),
      'ana:section': () => A.setAnalog('analogSection', Number(value)),
      'ana:csv': () => {
        const rows = analogSchedule(A.prj, A.prj.catalog, A.prj.rules);
        if (!rows.length) { A.alert('No hay cámaras analógicas que exportar.'); return; }
        downloadText(A.fname('cuadro-analogico.csv'), toCsv([
          ['Camara', 'Modelo', 'Formato', 'Medio', 'Distancia m', 'Alcance m', 'Margen m', 'Uso %', 'Canal', 'Consumo W', 'Intensidad mA', 'Caida V', 'Tension V', 'Estado'],
          ...rows.map((r) => [r.camera, r.model, r.format, r.cable, r.distance, r.limit, r.margin, r.pct, r.channel, r.watts, r.current, r.drop, r.volts, r.status]),
        ], ';'), 'text/csv');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Cuadro analógico de ${rows.length} cámara(s) exportado.`);
      },
      'ana:doc': () => A.exportDocPdf('analog'),

      /* ---------- integración con ARQ GEN (§4, §39): módulo eliminable ---------- */
      'arq:json': () => {
        const pkg = integrationPackage(A.prj, A.results);
        downloadText(A.fname('integracion-arqgen.json'), JSON.stringify(pkg, null, 1), 'application/json');
        A._exported = true; A.updateWalkBadge();
        A.hint(`Paquete de integración ${INTEGRATION.id} ${INTEGRATION.version}: ${pkg.zones.length} zona(s), ${pkg.cameras.length} cámara(s), ${pkg.links.length} enlace(s).`);
      },
      'arq:xml': () => {
        const xml = integrationToXml(integrationPackage(A.prj, A.results));
        downloadText(A.fname('contrato-integracion.xml'), xml, 'application/xml');
        A.hint('Contrato de integración exportado en XML (mismo contenido que el paquete JSON).');
      },
      /* ---------- base de datos propia y conversor local (shell de escritorio, §9, §32, §35) ---------- */
      'db:estado': async () => {
        const est = await DB.estado();
        A._shellInfo = est;
        if (!est.disponible) {
          A.alert(['Base de datos SQLite: no disponible.', '', 'Esta ventana está ejecutándose en un navegador. El ejecutable de escritorio (CCTVDesign.exe) abre la misma aplicación con la base de datos propia en database/cctv.sqlite y con el conversor DWG de tools/converter.', '', 'Todo el cálculo, la documentación y la exportación funcionan igual sin la base: el programa nunca depende de ella.']);
          return;
        }
        const bd = est.baseDeDatos || {};
        const conv = est.conversores || [];
        A.alert(['Base de datos propia (SQLite ' + bd.sqlite + ')', '', `Carpeta del programa: ${est.raiz}`, `Base de datos: ${bd.ruta}`, `Catálogo: ${bd.articulos} artículos · Reglas: ${bd.reglas}`, '', conv.length ? 'Conversor DWG local: ' + conv.map((c) => c.nombre + ' (' + c.version + ')').join(' · ') : 'Conversor DWG local: no instalado (el programa sigue funcionando con DXF; ver tools/fetch-converter.mjs).', '', 'Programa ' + est.version + ' · ' + est.plataforma + '/' + est.arquitectura]);
        A.hint('Base de datos: ' + (bd.articulos || 0) + ' artículos y ' + (bd.reglas || 0) + ' reglas en SQLite.');
      },
      'db:guardar': async () => {
        if (!DB.hayShell()) { A.alert(['Sin shell de escritorio: el catálogo vive en la sesión del navegador.', '', 'Abra CCTVDesign.exe para guardarlo en la base SQLite.'].join('\n')); return; }
        const n = await DB.guardarCatalogo(A.prj.catalog);
        const r = await DB.guardarReglas(RULE_DEFS, A.prj.rules);
        A.hint(`Base de datos actualizada: ${n} artículos y ${r} reglas.`);
      },
      'db:cargar': async () => {
        const cat = await DB.cargarCatalogo();
        const reg = await DB.cargarReglas();
        if (!cat && !reg) { A.hint('No hay base de datos con contenido (abra CCTVDesign.exe).'); return; }
        A.pushUndo();
        if (cat) A.prj.catalog = cat;
        if (reg) A.prj.rules = { ...A.prj.rules, ...reg };
        A.recalc(true);
        A.hint(`Catálogo y reglas cargados de la base: ${(cat ? cat.items.length : 0)} artículos.`);
      },
      'db:proyecto': async () => {
        if (!DB.hayShell()) { A.hint('Sin shell: use Archivo → Guardar proyecto (.cctv).'); return; }
        const r = await DB.guardarProyecto(A.prj.meta.name || 'Proyecto sin nombre', serialize(A.prj));
        A.hint(r ? `Proyecto guardado en la base (versión ${(r.filas !== undefined ? r.filas : 1)}).` : 'No se pudo guardar en la base.');
      },
      'db:historial': async () => {
        const ps = await DB.listarProyectos();
        const au = await DB.auditoria(12);
        if (!ps.length && !au.length) { A.alert('La base de datos todavía no tiene proyectos ni movimientos registrados.'); return; }
        A.alert(['Copias de seguridad y auditoría (SQLite)', '',
          ...(ps.length ? ['Proyectos guardados:'] : ['Sin proyectos guardados.']),
          ...ps.map((p) => `  · ${p.nombre} — v${p.version} · ${p.modificado}`),
          '', 'Últimos movimientos:',
          ...au.map((a) => `  · ${a.fecha} ${a.accion}: ${a.detalle}`),
        ]);
      },
      /* ---------- convertir e importar en un paso, con el conversor local (§9, §32) ---------- */
      'db:convertir': () => {
        if (!DB.hayShell()) {
          A.alert(['La conversión automática necesita el ejecutable de escritorio (§9).', '',
            'Esta ventana es el programa abierto en un navegador y no puede ejecutar programas locales.', '',
            '· Con el ejecutable: Menú Plano ▸ «Convertir DWG e importar (conversor local)».',
            '· En el navegador: «Importar DWG (asistente)» explica los pasos y el comando exacto,',
            '  y luego «Importar DXF» carga el resultado.']);
          return;
        }
        A.pickFileBinary('.dwg', async (bytes, f) => {
          const nombre = (f && f.name) || 'plano.dwg';
          const limpio = nombre.replace(/\.dwg$/i, '');
          const info = dwgInfo(bytes);
          A.pushUndo();
          A.hint(`Convirtiendo ${nombre} (${info.versionName}, ${(bytes.length / 1024).toFixed(0)} KB) con el conversor local…`);
          A.avisoCad({ texto: `Convirtiendo <b>${nombre}</b> (${info.versionName}) con el conversor local… puede tardar unos segundos.`, tipo: 'info', duracion: 0, acciones: [] });
          let res = null, error = '';
          try {
            res = await DB.convertirDwgBytes(nombre, bytes);
          } catch (e) { error = e && e.message ? e.message : String(e); }
          if (!res || !res.ok || !res.dxfBase64) {
            const detalle = error || (res && res.erroresEstandar ? String(res.erroresEstandar).split('\n').slice(0, 8).join('\n') : '');
            const sinConversor = /no hay conversor/i.test(error || detalle);
            A.avisoCad({
              texto: `<b>No se ha podido convertir ${nombre}.</b><br>` +
                (sinConversor
                  ? 'El programa no encuentra el conversor DWG en <span class="mono">tools/converter/</span>.'
                  : 'El conversor no ha producido un DXF legible. Detalle: ' + (detalle ? `<span class="mono">${detalle.split('\n')[0]}</span>` : '(sin detalle)') + '.'),
              tipo: 'error', duracion: 0,
              acciones: [{ label: 'Ver el asistente DWG', act: 'file:dwg' }, { label: 'Importar un DXF ya convertido', act: 'file:dxf' }] });
            A.alert([`Conversión de ${nombre}: no se ha producido un DXF.`, '',
              sinConversor
                ? 'No hay conversor instalado en tools/converter/. Ejecute «node tools/fetch-converter.mjs» en el equipo con Internet, o copie la carpeta tools/converter/ junto al programa.'
                : 'Detalle del conversor:',
              sinConversor ? '' : detalle,
              '', 'El DWG no bloquea el trabajo: puede seguir con un DXF convertido en otro equipo (§9).'].filter(Boolean).join('\n'));
            return;
          }
          // El DXF llega en Base64: se reconstruye byte a byte y lo lee nuestro lector propio (§9)
          const dxfBytes = DB.base64ABytes(res.dxfBase64);
          const r = importDxfAuto(dxfBytes);
          const avisos = [];
          if (res.versionesNoSoportadas && res.versionesNoSoportadas.length) avisos.push(`tipos no soportados por el conversor: ${res.versionesNoSoportadas.join(', ')}`);
          if (!(r.entities || []).length) {
            A.avisoCad({ texto: `<b>${nombre} se ha convertido, pero el DXF no tiene geometría que dibujar.</b><br>El conversor local no extrae entidades de esta versión de DWG. Use un conversor de escritorio (ODA File Converter) o guarde como DXF desde su programa de CAD.`, tipo: 'aviso', duracion: 0, acciones: [{ label: 'Ver el asistente DWG', act: 'file:dwg' }] });
            A.alert(`El conversor local (${res.conversor}) produjo un DXF válido de ${(res.dxfBytes / 1024).toFixed(1)} KB, pero sin entidades que podamos leer: no es un fallo del programa ni del fichero DWG, es una limitación conocida del conversor con esta versión (§9).`);
            return;
          }
          const out = A.aplicarPlanoImportado(r, {
            nombre: limpio,
            titulo: `DWG convertido e importado`,
            detalle: `Conversor: ${res.conversor} ${res.versionConversor || ''} · DXF de ${(res.dxfBytes / 1024).toFixed(1)} KB generado junto al programa`,
            avisos });
          if (out.entidades) {
            A.alert([`${nombre} convertido e importado con ${res.conversor} ${res.versionConversor || ''}`, '',
              `DWG de entrada: ${(res.entradaBytes / 1024).toFixed(0)} KB · DXF generado: ${(res.dxfBytes / 1024).toFixed(1)} KB`,
              `Entidades: ${out.entidades} · Capas del plano: ${(r.layers || []).length} · Bloques expandidos: ${(r.report && r.report.blocks) || 0}`,
              '', 'Nada ha salido del equipo: el conversor es local (§3, §9).'].join('\n'));
          }
        });
      },
      'arq:import': () => A.pickFile('.json', (text) => {
        let pack;
        try { pack = importArqGen(text); } catch (e) { A.alert('El archivo no es un paquete de ARQ GEN legible: ' + e.message); return; }
        if (!pack.ok) { A.alert('El paquete no contiene estancias con polígono válido.'); return; }
        A.pushUndo();
        const added = applyArqGen(A.prj, pack);
        A.cad.fit(); A.afterChange();
        A.alert(`ARQ GEN: ${pack.summary}${pack.project ? '\nProyecto de origen: ' + pack.project : ''}${pack.scale ? `\nEscala heredada: 1 unidad = ${pack.scale} m` : ''}\nSe han añadido ${added.rooms} zona(s) a la capa ZONAS. Los cálculos de CCTV se rehacen con el motor propio (§42).`);
        A.hint(`Zonas importadas de ARQ GEN: ${added.rooms}.`);
      }),
      'cable:media': () => {
        const c = A.prj.entities.find((e) => e.type === 'cable' && e.id === el.dataset.id);
        if (!c) return;
        A.pushUndo();
        c.data.media = value;
        const cam = A.prj.entities.find((e) => e.id === c.data.from);
        if (cam) cam.data.media = value;      // se recuerda para las próximas regeneraciones de ruta
        A.recalcLight(); A.refresh();
        A.hint(`Medio del enlace ${c.data.from}: ${value === 'fiber' ? 'fibra óptica' : value === 'utp' ? 'cobre (forzado)' : 'automático por distancia'}.`);
      },
      'cam:rotate90': () => A.girarCamara(90),
      // Girar la cámara como un bloque de AutoCAD: se le suma el ángulo al azimut y se recalcula
      // la cobertura, de modo que el cono y el haz quedan coherentes al instante (§13).
      'cam:giro:-15': () => A.girarCamara(-15),
      'cam:giro:+15': () => A.girarCamara(15),
      'cam:giro': () => A.setCam('azimuth', Number(value)),
      // Apuntar: el programa se queda esperando un punto del plano, como el comando GIRAR por
      // referencia de AutoCAD, y el cono sigue al ratón mientras se mueve (§9).
      'cam:apuntar': () => {
        const c = A.cad.selected().find((x) => x.type === 'camera');
        if (!c) { A.hint('Seleccione primero la cámara que quiere orientar.'); return; }
        if (A.cad.apuntarCamara(c.id)) A.hint('Haga clic en el plano hacia donde debe mirar la cámara (Esc lo cancela).');
      },
      'cam:aim': () => {
        const c = A.cad.selected()[0]; if (!c) return;
        A.pushUndo();
        const rooms = A.prj.entities.filter((e) => e.type === 'room');
        let target = null, bd = Infinity;
        for (const r of rooms) {
          const cx = r.points.reduce((a, p) => a + p.x, 0) / r.points.length, cy = r.points.reduce((a, p) => a + p.y, 0) / r.points.length;
          const d = Math.hypot(cx - c.points[0].x, cy - c.points[0].y);
          if (d < bd) { bd = d; target = { x: cx, y: cy }; }
        }
        if (target) c.data.azimuth = (Math.atan2(target.y - c.points[0].y, target.x - c.points[0].x) * 180) / Math.PI;
        A.afterChange(); A.hint('Cámara orientada al centro de la zona más próxima.');
      },

      'val:run': () => { A.recalc(true); A.showPanel('validation'); A.hint('Validación: ' + A.results.validation.summary); },
      'calc:all': () => { const t = performance.now(); A.recalc(true); A.refresh(); A.hint(`Recalculado en ${(performance.now() - t).toFixed(0)} ms.`); },
      'rules:reset': () => { A.prj.rules = defaultRules(); A.recalcLight(); A.refresh(); A.hint('Reglas restauradas.'); },
      'rules:export': () => downloadText('reglas.json', JSON.stringify(A.prj.rules, null, 2), 'application/json'),

      'layer:add': () => { const n = prompt('Nombre de la capa'); if (!n) return; const id = n.toUpperCase().replace(/\s+/g, '_'); A.prj.layers.push({ id, name: n, color: '#8899aa', visible: true }); A.refresh(); },
      'layer:visible': () => { const l = A.prj.layers.find((x) => x.id === el.dataset.id); if (l) { l.visible = el.checked; A.cad.draw(); } },
      'layer:color': () => { const l = A.prj.layers.find((x) => x.id === el.dataset.id); if (l) { l.color = el.value; A.cad.draw(); } },
      'layer:current': () => { A.cad.layer = el.value; A.hint('Capa activa: ' + el.value); },
      'layer:isolate': () => { A.prj.layers.forEach((l) => { l.visible = l.id === A.cad.layer; }); A.cad.draw(); },
      'layer:all': () => { A.prj.layers.forEach((l) => { l.visible = true; }); A.cad.draw(); },

      'meta:name': () => { A.prj.meta.name = value; }, 'meta:code': () => { A.prj.meta.code = value; },
      'meta:client': () => { A.prj.meta.client = value; }, 'meta:address': () => { A.prj.meta.address = value; },
      'meta:author': () => { A.prj.meta.author = value; }, 'meta:company': () => { A.prj.meta.company = value; },
      'meta:notes': () => { A.prj.meta.notes = value; },

      // Los números se pasan **como se han escrito** (con coma o con punto): los interpreta `setCam`,
      // que además ignora un campo vacío en lugar de dejar la medida a cero.
      'cam:label': () => A.setCam('label', value), 'cam:height': () => A.setCam('height', value),
      'cam:azimuth': () => A.setCam('azimuth', value), 'cam:tilt': () => A.setCam('tilt', value),
      'cam:focal': () => A.setCam('focal', value), 'cam:objective': () => A.setCam('objective', value),
      'cam:fps': () => A.setCam('fps', value), 'cam:bitrate': () => A.setCam('bitrate', value),
      'cam:ip': () => A.setCam('ip', value), 'cam:switch': () => A.setCam('switchId', value),
      // El accesorio con el que se sujeta: se dibuja en la vista 3D y entra en el pedido (§24)
      'cam:mount': () => A.setCam('mount', value),
      'cam:catalog': () => {
        const c = A.cad.selected()[0]; if (!c) return;
        A.pushUndo(); c.data.catalogId = value;
        const it = getItem(A.prj.catalog, value);
        // Al cambiar de modelo se resincroniza la óptica: la focal anterior pertenecía a
        // otro objetivo y daría un campo de visión falso (§13, §15).
        if (it && it.specs && it.specs.lens) c.data.focal = it.specs.lens;
        A.recalcCoverage(); A.recalcLight(); A.refresh();
      },
      'dev:label': () => A.setDev('label', value), 'dev:kind': () => A.setDev('kind', value), 'dev:ip': () => A.setDev('ip', value),
      'dev:catalog': () => A.setDev('catalogId', value),
      'room:name': () => A.setRoom('name', value), 'room:critical': () => A.setRoom('critical', el.checked),

      'plan:scale': () => { A.planScale = value; },
      'plan:pdf': () => A.exportPlanPdf('A3'), 'plan:pdf:a3': () => A.exportPlanPdf('A3'), 'plan:pdf:a1': () => A.exportPlanPdf('A1'),
      'plan:pdf:3d': () => A.exportPerspectivePdf('A3'),
      'plan:png': () => A.exportPlanPng(), 'plan:dxf': () => A.exportPlanDxf(),
      'plan:dxfblocks': () => A.exportPlanDxf({ blocks: true }),
      'plan:ifc': () => A.exportPlanIfc(),
      'doc:memory': () => A.exportDocPdf('memory'), 'doc:technical': () => A.exportDocPdf('technical'),
      'doc:cameras': () => A.exportDocPdf('cameras'), 'doc:equipment': () => A.exportDocPdf('equipment'),
      'doc:cabling': () => A.exportDocPdf('cabling'), 'doc:poe': () => A.exportDocPdf('poe'),
      'doc:storage': () => A.exportDocPdf('storage'),
      'doc:lpr': () => A.exportDocPdf('lpr'), 'doc:analytics': () => A.exportDocPdf('analytics'), 'doc:fiber': () => A.exportDocPdf('fiber'),
      'doc:analog': () => A.exportDocPdf('analog'),
      'doc:complete': () => A.exportDocPdf('complete'),
      'doc:sheets': () => A.exportDocPdf('sheets'),
      'doc:privacy': () => A.exportDocPdf('privacy'),
      'doc:perspective': () => A.exportPerspectivePdf('A3'),

      /* ---- privacidad y cumplimiento ---- */
      'tool:pzona': () => A.setTool('pzona'), 'tool:mascara': () => A.setTool('mascara'),
      'priv:zona': () => A.marcarZonaPrivacidad(),
      'priv:mascara': () => A.marcarMascara(),
      'priv:quitar': () => A.quitarPrivacidad(),
      'priv:clase': () => { A._privClase = value; A.aplicarClaseAZonas(value); },
      'priv:nombre': () => A.setZonaPrivacidad('nombre', value),
      'priv:notas': () => A.setZonaPrivacidad('notas', value),
      'priv:mascara:cam': () => A.setMascara('camara', value),
      'priv:mascara:motivo': () => A.setMascara('motivo', value),
      'priv:mascara:tipo': () => A.setMascara('tipo', value),
      'priv:mascara:altura': () => {
        const n = A.numeroONada(value);
        A.setMascara('altura', n === null || n <= 0 ? 0 : Math.min(30, n));
        A.hint(n === null || n <= 0
          ? 'La máscara tapa hasta la altura de la instalación.'
          : `La máscara tapa hasta ${n} m: así se ve en el monitor.`);
      },
      'priv:pdf': () => A.exportDocPdf('privacy'),
      'priv:hojas': () => A.exportDocPdf('sheets'),
      'mat:csv': () => A.exportBomCsv(), 'mat:xlsx': () => A.exportXlsx(),
      'bud:pdf': () => A.exportDocPdf('budget'), 'bud:xlsx': () => A.exportXlsx(), 'bud:csv': () => A.exportBudgetCsv(),
      'exp:json': () => downloadText(A.fname('json'), serialize(A.prj), 'application/json'),
      'exp:xml': () => downloadText(A.fname('xml'), projectToXml(A.prj, { cameras: A.results.coverage ? A.results.coverage.cameras : [], links: A.results.links || [] }), 'application/xml'),
      'exp:csv': () => downloadText(A.fname('csv'), toCsv([
        ['ID', 'Etiqueta', 'Equipo', 'X', 'Y', 'Altura', 'Azimut', 'Inclinación', 'Objetivo', 'IP', 'Switch'],
        ...A.prj.entities.filter((e) => e.type === 'camera').map((c) => [c.id, c.data.label, (getItem(A.prj.catalog, c.data.catalogId) || {}).model || '',
          num(c.points[0].x), num(c.points[0].y), c.data.height, c.data.azimuth, c.data.tilt,
          OBJECTIVES[c.data.objective] ? OBJECTIVES[c.data.objective].label : '', c.data.ip,
          (A.prj.entities.find((e) => e.id === c.data.switchId) || { data: {} }).data.label || ''])], ';'), 'text/csv', true),
      'exp:xlsx': () => A.exportXlsx(),

      /* ---- unidades y escala del plano (§9, §10) ---- */
      'panel:escala': () => A.showPanel('escala'),
      'panel:obstaculos': () => A.showPanel('obstaculos'),
      'panel:tresd': () => A.showPanel('tresd'),
      'escala:unidad': () => { A._unidadElegida = value; A.refresh(); },
      'escala:factor': () => { A._factorManual = Number(value) || 1; },
      'escala:aplicar': () => {
        const elegida = A._unidadElegida || (A._unidades ? A._unidades.id : 'm');
        const f = A.factorAEscalar();
        if (Math.abs(f - 1) < 1e-12) {
          A.hint(A._unidadAplicada === null
            ? 'La geometría ya está en metros y no se sabe de qué unidad venía: use «Deshacer la última escala» para reinterpretarla, o mida una distancia conocida.'
            : 'Nada que aplicar: la unidad elegida es la que ya está puesta.');
          return;
        }
        A.aplicarEscala(f, { unidad: elegida, origen: 'unidad' });
      },
      'escala:aplicarFactor': () => A.aplicarEscala(A._factorManual || 1, { origen: 'factor' }),
      'escala:deshacer': () => A.deshacerEscala(),
      'escala:referencia': () => A.escalarPorReferencia(),
      'escala:elegir': () => { A.showPanel('escala'); A.hint('Elija la unidad en la que está dibujado el plano y aplíquela.'); },

      /* ---- obstáculos, muros y alturas (§9, §13) ---- */
      'muro:marcar': () => {
        const sel = [...A.cad.selection];
        if (!sel.length) { A.hint('Seleccione las líneas que son muros (o use «Detectar muros por capa»).'); return; }
        A.marcarMuros(sel, A.prj.settings.alturaMuro || ALTURA_MURO);
      },
      'muro:desmarcar': () => {
        const sel = [...A.cad.selection];
        A.quitarMuros(sel.length ? sel : A.prj.entities.map((e) => e.id));
      },
      'muro:detectar': () => A.detectarMuros(),
      'muro:altura': () => {
        const h = Math.max(0.2, Math.min(12, Number(value) || ALTURA_MURO));
        A.prj.settings.alturaMuro = h;
        // La altura por defecto se aplica también a lo que ya esté marcado como muro
        let n = 0;
        for (const e of A.prj.entities) if (e.data && e.data.muro && !e.data.kind && e.data.altura !== h) { e.data.altura = h; n++; }
        A.cad._escena3dKey = '';
        A.afterChange();
        A.hint(`Altura de los muros: ${h.toFixed(2)} m${n ? ` (${n} muro(s) actualizados)` : ''}.`);
        A.refresh();
      },
      'obs:altura': () => {
        const h = Math.max(0.05, Math.min(30, Number(value) || 0));
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.altura = h; n++;
        }
        if (n) { A.pushUndo(); A.cad._escena3dKey = ''; A.afterChange(); A.hint(`Altura: ${h.toFixed(2)} m en ${n} elemento(s).`); }
        A.refresh();
      },
      'obs:base': () => {
        const b = Math.max(0, Math.min(30, Number(value) || 0));
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.base = b; n++;
        }
        if (n) { A.pushUndo(); A.cad._escena3dKey = ''; A.afterChange(); A.hint(`Base: ${b.toFixed(2)} m en ${n} elemento(s).`); }
        A.refresh();
      },
      'obs:opaco': () => {
        const v = !!(value === true || value === 'true' || (value === undefined && !(A.cad.selection.size && A.prj.entities.find((x) => x.id === [...A.cad.selection][0]).data.opaco)));
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.opaco = v; n++;
        }
        if (n) { A.pushUndo(); A.afterChange(); A.hint(`${n} elemento(s): ${v ? 'tapan' : 'no tapan'} la visión.`); }
        A.refresh();
      },
      'obs:tipoEscalera': () => {
        const val = String(value || 'recta');
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.tipoEscalera = val; n++;
        }
        if (n) { A.pushUndo(); A.cad._escena3dKey = ''; A.afterChange(); A.hint(`Tipo de escalera cambiado a ${val}.`); }
        A.refresh();
      },
      'obs:barandilla': () => {
        const v = !!(value === true || value === 'true' || (value === undefined && !(A.cad.selection.size && A.prj.entities.find((x) => x.id === [...A.cad.selection][0]).data.barandilla !== false)));
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.barandilla = v; n++;
        }
        if (n) { A.pushUndo(); A.cad._escena3dKey = ''; A.afterChange(); A.hint(`Barandilla ${v ? 'activada' : 'desactivada'}.`); }
        A.refresh();
      },
      'obs:numPeldanos': () => {
        const nPel = Math.max(0, Math.min(64, Math.round(Number(value) || 0)));
        let n = 0;
        for (const id of A.cad.selection) {
          const e = A.prj.entities.find((x) => x.id === id);
          if (!e || !esElemento3d(e)) continue;
          if (!e.data) e.data = {};
          e.data.numPeldanos = nPel; n++;
        }
        if (n) { A.pushUndo(); A.cad._escena3dKey = ''; A.afterChange(); A.hint(`Peldaños fijados: ${nPel || 'automático'}.`); }
        A.refresh();
      },

      /* ---- vista 3D (§8) ---- */
      'ver:3d': () => A.alternar3d(),
      '3d:encuadrar': () => { A.cad.encuadrar3d(); A.hint('Vista 3D encuadrada en el proyecto.'); },
      '3d:rejilla': () => A.cad.setOpciones3d({ rejilla: !A.cad.opciones3d.rejilla }),
      '3d:haces': () => A.cad.setOpciones3d({ mostrarHaz: !A.cad.opciones3d.mostrarHaz }),
      'edit:setcolorcapa': () => {
        A.pushUndo();
        for (const e of A.prj.entities) if (A.cad.selection.has(e.id)) delete e.data.color;
        A.afterChange(); A.hint('Color propio quitado: el objeto toma el de su capa.');
      },
      'tema:siguiente': () => A.setTema(siguienteTema(TEMAS[A.prefs.tema] ? A.prefs.tema : 'claro')),
      '3d:persona': () => A.cad.setOpciones3d({ mostrarPersona: !A.cad.opciones3d.mostrarPersona }),
      '3d:sombras': () => A.cad.setOpciones3d({ sombras: !A.cad.opciones3d.sombras }),
      '3d:niebla': () => A.cad.setOpciones3d({ niebla: !A.cad.opciones3d.niebla }),
      '3d:techos': () => A.cad.setOpciones3d({ ocultarTechos: !A.cad.opciones3d.ocultarTechos }),
      '3d:rotulos': () => A.cad.setOpciones3d({ rotulosSuelo: !A.cad.opciones3d.rotulosSuelo }),
      '3d:contacto': () => A.cad.setOpciones3d({ contactos: !A.cad.opciones3d.contactos }),
      '3d:aristas': () => A.cad.setOpciones3d({ aristas: !A.cad.opciones3d.aristas }),
      '3d:desdecamara': () => {
        // Se mira desde la primera cámara seleccionada; si no hay ninguna, desde la primera del proyecto
        const sel = A.cad.selected().find((e) => e.type === 'camera');
        const cam = sel || A.prj.entities.find((e) => e.type === 'camera');
        if (!cam) { A.hint('No hay cámaras en el proyecto.'); return; }
        A.cad.verDesdeCamara(cam.id);
        A.refresh();
      },
      '3d:orbital': () => { A.cad.verDesdeCamara(null); A.refresh(); },
      '3d:suelo': () => A.cad.setOpciones3d({ suelo: !A.cad.opciones3d.suelo }),
      '3d:degradado': () => A.cad.setOpciones3d({ degradado: !A.cad.opciones3d.degradado }),
      '3d:materiales': () => A.cad.setOpciones3d({ materiales: !A.cad.opciones3d.materiales }),
      '3d:penumbra': () => A.cad.setOpciones3d({ penumbra: !A.cad.opciones3d.penumbra }),
      '3d:rotuloscam': () => A.cad.setOpciones3d({ rotulosCamaras: !A.cad.opciones3d.rotulosCamaras }),
      '3d:norte': () => A.cad.setOpciones3d({ norte: !A.cad.opciones3d.norte }),
      '3d:cielo': () => A.cad.setOpciones3d({ cielo: !A.cad.opciones3d.cielo }),
      '3d:juntas': () => A.cad.setOpciones3d({ juntas: !A.cad.opciones3d.juntas }),
      '3d:escala': () => A.cad.setOpciones3d({ escalaGrafica: !A.cad.opciones3d.escalaGrafica }),
      '3d:estancias': () => A.cad.setOpciones3d({ nombresEstancias: !A.cad.opciones3d.nombresEstancias }),
      '3d:atenuarhaz': () => A.cad.setOpciones3d({ atenuarHaz: !A.cad.opciones3d.atenuarHaz }),
      '3d:soporte': () => A.cad.setOpciones3d({ soporteCamara: !A.cad.opciones3d.soporteCamara }),
      '3d:zocalo': () => A.cad.setOpciones3d({ zocalo: !A.cad.opciones3d.zocalo }),
      '3d:formascamara': () => A.cad.setOpciones3d({ formasCamara: !A.cad.opciones3d.formasCamara }),
      '3d:degradadohaz': () => A.cad.setOpciones3d({ degradadoHaz: !A.cad.opciones3d.degradadoHaz }),
      '3d:sombrahaz': () => A.cad.setOpciones3d({ sombraHaz: !A.cad.opciones3d.sombraHaz }),
      '3d:regla': () => A.cad.setOpciones3d({ referenciaAltura: !A.cad.opciones3d.referenciaAltura }),
      /* ---------- monitor de cámara: lo que ve una cámara, en vivo (§8, §13, §15) ---------- */
      'mon:cam': () => { A.monitor.fijar('camara', value || ''); A.monitor._sucio = true; A.refresh(); },
      // Desde la vista 3D (o desde cualquier sitio): abre el monitor con la cámara que se esté mirando
      'mon:ver': () => {
        const c = A.cad.selected().find((e) => e.type === 'camera')
          || (A.prj.entities || []).find((e) => e.type === 'camera');
        if (!c) { A.hint('No hay ninguna cámara en el proyecto.'); return; }
        A.monitor.fijar('camara', c.id);
        A.monitor.fijar('vivo', true);
        A.showPanel('monitor');
        A.hint(`Monitor: ${(c.data && (c.data.name || c.data.nombre)) || c.id}.`);
      },
      'mon:play': () => { const vivo = A.monitor.alternar('vivo'); A.hint(vivo ? 'Monitor en marcha.' : 'Monitor en pausa.'); A.refresh(); },
      'mon:fps': () => { A.monitor.fijar('fps', Number(value) || 15); A.refresh(); },
      'mon:actores': () => { A.monitor.fijar('actores', value || 'ambos'); A.refresh(); },
      'mon:osd': () => { A.monitor.alternar('osd'); A.refresh(); },
      'mon:efecto': () => { A.monitor.alternar('efecto'); A.refresh(); },
      'mon:distorsion': () => {
        const d = A.monitor.alternar('distorsion');
        A.hint(d ? 'Distorsión óptica de lente activada.' : 'Distorsión óptica desactivada (proyección rectilínea).');
        A.monitor._sucio = true;
        A.refresh();
      },
      'mon:ir': () => { const ir = A.monitor.alternar('ir'); A.hint(ir ? 'Visión nocturna por infrarrojos.' : 'Visión diurna.'); A.refresh(); },
      'mon:mascaras': () => {
        const m = A.monitor.alternar('mascaras');
        A.hint(m ? 'Las máscaras de privacidad se pintan sobre la imagen, como las graba el equipo.'
          : 'Las máscaras se dejan de pintar: la imagen sale sin recuadros.');
        A.refresh();
      },
      'mon:full': () => { A.monitor.alternar('completo'); A.ajustarMonitor(); A.refresh(); },
      'mon:captura': () => { const f = A.monitor.capturar(); A.hint(f ? `Captura guardada: ${f}` : 'No se pudo guardar la captura.'); },

      'help:keys': () => A.alert('Atajos: Esc cancelar y volver a Selección · Supr eliminar · Ctrl+Z deshacer · Ctrl+Mayús+Z rehacer · Ctrl+D duplicar · Ctrl+A seleccionar todo · Enter/doble clic terminar polilínea · rueda zoom · botón central desplazar.\nEdición de objetos: M mover · R girar · S escalar · E espejo · arrastrar los tiradores (cuadrados, rombos y círculos) para deformar, insertar vértices o cambiar el radio.\nForzados (como AutoCAD): F3 referencia a objetos · F7 rejilla · F8 ortogonal · F9 forzado · F10 rastreo polar.'),
      'help:about': () => A.alert('CCTV DESIGN PRO — prototipo funcional\nSoftware independiente de diseño y cálculo de sistemas CCTV.\n100 % offline. Sin dependencia de ARQ GEN, AutoCAD ni servicios externos (CP CCTV §3, §42).') };
    const fn = cmd[name];
    if (fn) { fn(); return; }
    // Ajustes del espacio de trabajo desde el panel y la barra de estado (§8):
    //   pref:<clave>            conmuta
    //   pref:<clave>:<valor>    fija el valor que trae el control
    //   pref:tema:<tema>        aplica un tema completo
    if (name.startsWith('pref:')) {
      const partes = name.split(':');
      const clave = partes[1];
      if (clave === 'tema') { A.setTema(partes[2] || 'programa'); return; }
      if (defDe(clave)) {
        const conmutar = partes.length < 3 && typeof A.prefs[clave] === 'boolean';
        A.setPref(clave, conmutar ? undefined : (partes.length > 2 ? partes.slice(2).join(':') : value));
        if (A.panel === 'options') A.refresh();
        return;
      }
    }
    // Quitar un vértice concreto desde la tabla del panel de propiedades
    if (name.startsWith('edit:vertice:borrar:')) {
      const i = Number(name.split(':')[3]);
      A.pushUndo();
      const k = A.cad.vertices([...A.cad.selection], 'borrar', i);
      if (!k) A.undo(); else { A.afterChange(); A.hint('Vértice eliminado.'); }
      return;
    }
    // Herramientas de obstáculos: obs:<tipo> activa el dibujo de ese elemento (§9)
    if (name.startsWith('obs:')) {
      const kind = name.slice(4);
      const def = A.cad.setObstacleTool(kind);
      if (def && A.panel === 'obstaculos') A.refresh();
      return;
    }
    // Marcar (o desmarcar) como muro la geometría de una capa del plano importado (§9)
    if (name.startsWith('muro:capa:')) {
      const capa = name.slice('muro:capa:'.length);
      const ids = A.prj.entities.filter((e) => e.layer === capa && (e.points || []).length
        && e.type !== 'text' && e.type !== 'image').map((e) => e.id);
      const yaMarcados = ids.filter((id) => (A.prj.entities.find((x) => x.id === id).data || {}).muro);
      if (yaMarcados.length >= ids.length && ids.length) A.quitarMuros(ids);
      else A.marcarMuros(ids, A.prj.settings.alturaMuro || ALTURA_MURO);
      return;
    }
    // Cámara y opciones de la vista 3D: el estado lo guarda el motor del lienzo (§8)
    if (name.startsWith('3d:')) {
      const partes = name.split(':');
      if (partes[1] === 'vista') { A.cad.setVista3d(partes[2]); A.refresh(); return; }
      const mapa = { azimut: 'azimut', elevacion: 'elevacion', distancia: 'distancia' };
      if (mapa[partes[1]]) {
        const v = Number(value !== undefined ? value : partes[2]);
        if (isFinite(v)) { A.cad.cam3d[mapa[partes[1]]] = v; A.cad.draw(); if (A.panel === 'tresd') A.refresh(); }
        return;
      }
      if (partes[1] === 'opacidad') { A.cad.setOpciones3d({ opacidadMuros: Math.max(0.15, Math.min(1, (Number(value) || 100) / 100)) }); A.refresh(); return; }
      return;
    }
    // Las acciones del plano importado (encuadrar, traer, atenuar, capas, quitar…) viven en la ruta
    // del menú contextual; desde un panel o un botón se llega aquí, así que se reenvían a esa ruta.
    if (name.startsWith('plano:')) { this.ctx(name); return; }
    if (name.startsWith('walk:')) { this.walkAction(name); return; }
    console.warn('Acción no implementada:', name);
  },

  walkAction(name) {
    const map = { 'walk:import': 'file:dxf', 'walk:calibrate': 'plan:calibrate', 'walk:place': 'tool:camera',
      'walk:coverage': 'cov:analyze', 'walk:lpr': 'lpr:panel', 'walk:analytics': 'an:panel', 'walk:fiber': 'fiber:panel',
      'walk:routes': 'cable:generate', 'walk:network': 'net:assign',
      'walk:storage': 'rec:calc', 'walk:rack': 'rack:auto', 'walk:materials': 'calc:all',
      'walk:plan': 'plan:pdf', 'walk:docs': 'doc:complete', 'walk:validate': 'val:run', 'walk:export': 'exp:xlsx' };
    if (map[name]) this.act(map[name]);
  },

  selectedCamera() { return this.cad.selected().find((e) => e.type === 'camera') || null; },

  /** Escribe un campo del módulo LPR en la cámara seleccionada y recalcula. */
  setLpr(key, value) {
    const c = this.selectedCamera(); if (!c) return;
    this.pushUndo();
    c.data[key] = value;
    this.recalcCoverage(); this.recalcLight(); this.refresh();
  },
  /** Cambio de un atributo del enlace analógico (§38): recalcula rutas y validación. */
  setAnalog(key, value) {
    const c = this.selectedCamera(); if (!c) return;
    this.pushUndo();
    c.data[key] = value;
    generateRoutes(this.prj, this.prj.catalog, this.prj.rules);
    this.recalc(true); this.refresh();
    this.hint(`Enlace analógico actualizado (${key} = ${value}). Rutas regeneradas con el nuevo medio.`);
  },

  /** Edita una regla de analítica concreta de la cámara seleccionada. */
  setRule(i, key, value) {
    const c = this.selectedCamera(); if (!c) return;
    const list = cameraRules(c);
    if (!list[i]) return;
    this.pushUndo();
    list[i][key] = value;
    c.data.analytics = list.map((r) => ({ type: r.type, zoneId: r.zoneId, sensitivity: r.sensitivity, eventsPerDay: r.eventsPerDay, actions: r.actions, note: r.note }));
    this.recalcLight(); this.refresh();
  },

  /** Evaluación de una regla de analítica para los paneles. */
  ruleEval(cam, rule) {
    try { return evaluateRule(cam, rule, this.prj, this.prj.catalog, this.prj.rules, this.results.coverage || {}); }
    catch (e) { return null; }
  },

  setCam(key, value) {
    const c = this.cad.selected().find((e) => e.type === 'camera');
    if (!c) return;
    const numerico = ['height', 'azimuth', 'tilt', 'focal', 'fps', 'bitrate'].includes(key);
    let v = value;
    if (numerico) {
      v = this.numeroONada(value);
      if (v === null) { this.hint('Número no válido: se deja el valor anterior.'); this.refresh(); return; }
      if (key === 'azimuth') v = ((v % 360) + 360) % 360;
      if (key === 'height' && v <= 0) v = 0.1;
    }
    this.pushUndo();
    c.data[key] = v;
    this.recalcCoverage(); this.recalcLight(); this.refresh();
  },
  /**
   * Gira una cámara un ángulo dado, como se gira un bloque en AutoCAD: se le suma al azimut, se
   * recalcula la cobertura y el panel se refresca. Sirve tanto para los botones del panel como
   * para cualquier atajo que quiera reutilizarlo (§13).
   */
  girarCamara(grados) {
    const c = this.cad.selected().find((e) => e.type === 'camera');
    if (!c) { this.hint('Seleccione primero la cámara que quiere girar.'); return false; }
    this.pushUndo();
    c.data.azimuth = ((c.data.azimuth + grados) % 360 + 360) % 360;
    this.recalcCoverage(); this.recalcLight(); this.refresh();
    this.hint(`${c.data.label || 'Cámara'} girada ${grados > 0 ? '+' : ''}${grados}° → ${Number(c.data.azimuth).toFixed(1).replace('.', ',')}°.`);
    return true;
  },

  setDev(key, value) {
    const d = this.cad.selected().find((e) => e.type === 'device');
    if (!d) return;
    this.pushUndo(); d.data[key] = value; this.recalcLight(); this.refresh();
  },
  setRoom(key, value) {
    const r = this.cad.selected().find((e) => e.type === 'room');
    if (!r) return;
    this.pushUndo(); r.data[key] = value; this.recalcCoverage(); this.recalcLight(); this.refresh();
  },

  /* ------------------ privacidad: zonas, máscaras y declaración ------------------ */

  /**
   * Recintos que sirven como zona de privacidad: una estancia, un rectángulo o una polilínea
   * cerrada. Convertir una zona de interés en zona de privacidad la saca del cómputo de
   * cobertura: la vía pública no es superficie a cubrir, es superficie que no se debe ver.
   */
  recintosSeleccionados() {
    return [...this.cad.selection]
      .map((id) => this.prj.entities.find((e) => e.id === id))
      .filter((e) => e && e.points && e.points.length >= 3 &&
        (e.type === 'room' || e.type === 'rect' || e.type === 'pzona' || e.type === 'mascara' ||
          (e.type === 'polyline' && (e.closed || (e.data && e.data.cerrada)))));
  },

  marcarZonaPrivacidad() {
    const sel = this.recintosSeleccionados();
    if (!sel.length) {
      this.hint('Dibuje un recinto (herramienta Zona, rectángulo o polilínea cerrada) y selecciónelo.');
      this.showPanel('privacy');
      return;
    }
    const clase = this._privClase || 'PUBLICA';
    this.pushUndo();
    let n = 0;
    for (const e of sel) {
      if (e.type === 'pzona') { e.data.clase = clase; n++; continue; }
      e.type = 'pzona'; e.layer = 'PRIVACIDAD'; e.closed = true;
      e.data.nombre = e.data.nombre || e.data.name || ('Zona ' + (zonasDe(this.prj).length + 1));
      e.data.clase = e.data.clase || clase;
      n++;
    }
    this.afterChange(); this.recalc(true); this.refresh();
    this.hint(`${n} recinto(s) marcado(s) como «${etiquetaClase(clase)}»: se miden aparte y dejan de contar como superficie a cubrir.`);
  },

  marcarMascara() {
    const sel = this.recintosSeleccionados();
    if (!sel.length) {
      this.hint('Dibuje el recuadro que hay que ocultar y selecciónelo.');
      this.showPanel('privacy');
      return;
    }
    const camara = this._privCamara === undefined
      ? (() => { const c = this.cad.selected().find((e) => e.type === 'camera'); return c ? c.id : ''; })()
      : this._privCamara;
    this.pushUndo();
    let n = 0;
    for (const e of sel) {
      if (e.type === 'mascara') { e.data.camara = camara; n++; continue; }
      e.type = 'mascara'; e.layer = 'PRIVACIDAD'; e.closed = true;
      e.data.camara = camara; e.data.tipo = e.data.tipo || 'opaca';
      e.data.motivo = e.data.motivo || '';
      n++;
    }
    this.afterChange(); this.recalc(true); this.refresh();
    this.hint(`${n} máscara(s) de privacidad${camara ? ' para ' + (this.prj.entities.find((e) => e.id === camara) || { data: {} }).data.label : ' para todas las cámaras'}: lo que tapen deja de contar como cubierto.`);
  },

  quitarPrivacidad() {
    const sel = [...this.cad.selection]
      .map((id) => this.prj.entities.find((e) => e.id === id))
      .filter((e) => e && (e.type === 'pzona' || e.type === 'mascara'));
    if (!sel.length) { this.hint('Seleccione la zona o la máscara que quiere quitar.'); return; }
    this.pushUndo();
    let zonas = 0, mascaras = 0;
    for (const e of sel) {
      if (e.type === 'pzona') { e.type = 'room'; e.layer = 'ZONAS'; e.data.name = e.data.name || e.data.nombre; zonas++; }
      else { removeEntity(this.prj, e.id); mascaras++; }
    }
    this.cad.selection.clear();
    this.afterChange(); this.recalc(true); this.refresh();
    this.hint(`${zonas} zona(s) devuelta(s) a zonas de interés · ${mascaras} máscara(s) eliminada(s).`);
  },

  aplicarClaseAZonas(clase) {
    const sel = [...this.cad.selection]
      .map((id) => this.prj.entities.find((e) => e.id === id))
      .filter((e) => e && e.type === 'pzona');
    if (!sel.length) { this.refresh(); return; }
    this.pushUndo();
    for (const e of sel) e.data.clase = clase;
    this.afterChange(); this.recalc(true); this.refresh();
    this.hint(`${sel.length} zona(s) como «${etiquetaClase(clase)}».`);
  },

  setZonaPrivacidad(key, value) {
    const z = this.cad.selected().find((e) => e.type === 'pzona');
    if (!z) return;
    this.pushUndo(); z.data[key] = value; this.afterChange(); this.recalcLight(); this.refresh();
  },

  setMascara(key, value) {
    const m = this.cad.selected().find((e) => e.type === 'mascara');
    if (!m) return;
    this.pushUndo(); m.data[key] = value; this.afterChange(); this.recalc(true); this.refresh();
  },

  /** Datos del responsable y de la finalidad: alimentan los carteles y el registro de actividades. */
  declararPrivacidad(campo, valor) {
    if (!this.prj.settings.privacidad) this.prj.settings.privacidad = {};
    this.prj.settings.privacidad[campo] = valor;
    this.recalcularCumplimiento();
    this.refresh();
  },

  declararFuncionIA(id, activa) {
    if (!this.prj.settings.privacidad) this.prj.settings.privacidad = {};
    this.prj.settings.privacidad[id] = !!activa;
    this.recalcularCumplimiento();
    this.refresh();
    const f = FUNCIONES_IA.find((x) => x.id === id);
    if (f && activa) this.hint(`${f.etiqueta}: ${f.ayuda}`);
  },

  /** Recálculo ligero: sólo lo que depende de la declaración, sin rehacer la cobertura. */
  recalcularCumplimiento() {
    this.results.cumplimiento = evaluarCumplimiento(this.prj, this.prj.catalog, this.prj.rules, this.results);
    this.results.validation = validateProject(this.prj, this.prj.catalog, this.prj.rules, this.results);
    this.scheduleSave();
  },

  setTool(t) {
    if (t === 'camera' && !this._camaraPendienteColocacion && !this._asistenteCamaraAbierto) {
      this.iniciarAsistenteCamara(false);
      return;
    }
    // Dibujar en 3D no tiene sentido: si se pide una herramienta de dibujo estando en 3D, se vuelve
    // a la planta sin que el usuario tenga que hacer nada más.
    if (this.cad.modo3d && t !== 'select' && t !== 'pan' && t !== 'measure') this.cad.setModo3d(false);
    this.cad.tool = t;
    if (t !== 'obstacle') this.cad.toolKind = null;
    this.refrescarBarra();
    const hints = {
      select: 'Seleccione una cámara para modificar su orientación, altura, lente o campo de visión. Esc vuelve a esta herramienta desde cualquier otra.',
      camera: this._camaraPendienteColocacion ? `Cámara ${this._camaraPendienteColocacion.label} lista: haga clic en el plano para situarla.` : 'Haga clic en el plano para colocar una cámara.',
      device: 'Haga clic para colocar un switch, NVR, router, patch panel o UPS.',
      room: 'Dibuje el contorno de la zona y pulse Enter o doble clic para cerrarla.',
      pzona: 'Dibuje el recinto que tiene otro régimen (vía pública, finca vecina, vestuario) y ciérrelo.',
      mascara: 'Dibuje el recuadro que la cámara no debe grabar y ciérrelo: después asígnelo a una cámara.',
      polyline: 'Clic para cada vértice; Enter o doble clic para terminar.',
      measure: 'Haga clic en dos puntos para medir. Úselo para calibrar la escala (§10).' };
    this.hint(hints[t] || '');
  },

  commitDraw(d) {
    this.pushUndo();
    // Los obstáculos no son una geometría más: llevan su tipo, su altura y si tapan la visión (§9)
    if (d.type === 'obstacle') {
      const def = obstaculoDe(d.kind);
      if (!def) { this.hint('Obstáculo desconocido.'); return; }
      const e = crearObstaculo(def.id, d.points, { closed: d.closed, layer: this.cad.layer });
      if (!e) return;
      addEntity(this.prj, e);
      this.afterChange();
      this.cad.selection = new Set([e.id]);
      this.hint(`${def.etiqueta} colocado a ${e.data.altura.toFixed(2)} m de altura · ` +
        (e.data.opaco ? 'tapa la visión' : 'no tapa la visión') + ' · cámbielo en el panel Obstáculos.');
      if (this.panel === 'obstaculos') this.refresh();
      return;
    }
    // Las zonas de privacidad y las máscaras son geometría con régimen propio: van a su capa
    // y nacen ya clasificadas para que el análisis de privacidad las encuentre (§28).
    if (d.type === 'pzona' || d.type === 'mascara') {
      const e2 = addEntity(this.prj, {
        type: d.type, layer: 'PRIVACIDAD', points: d.points, closed: true,
        data: d.type === 'pzona'
          ? { nombre: 'Zona ' + (zonasDe(this.prj).length + 1), clase: this._privClase || 'PUBLICA' }
          : { camara: this._privCamara === undefined ? '' : this._privCamara, tipo: 'opaca', motivo: '' } });
      this.afterChange();
      this.cad.selection = new Set([e2.id]);
      this.recalc(true);
      this.showPanel('privacy');
      this.hint(d.type === 'pzona'
        ? `Zona de privacidad creada como «${etiquetaClase(e2.data.clase)}»: cámbiela en el panel.`
        : 'Máscara creada. Asígnela a una cámara o déjela para todas.');
      this.refresh();
      return;
    }
    const layer = d.type === 'room' ? 'ZONAS' : this.cad.layer;
    const e = addEntity(this.prj, {
      type: d.type, layer, points: d.points, closed: d.closed || false, radius: d.radius || 0,
      // El arco guarda sus ángulos, igual que un DXF: centro, radio, inicio y fin (§9)
      startAngle: d.startAngle, endAngle: d.endAngle,
      data: {} });
    if (d.type === 'arc') { delete e.startAngle; delete e.endAngle; e.startAngle = d.startAngle || 0; e.endAngle = d.endAngle || 0; }
    if (d.type === 'room') { e.data.name = prompt('Nombre de la zona', 'Zona ' + (this.prj.entities.filter((x) => x.type === 'room').length)) || 'Zona'; }
    this.afterChange();
    this.cad.selection = new Set([e.id]);
  },

  /* ------------------ unidades y escala del plano importado (§9, §10) ------------------ */

  /**
   * A qué se aplica una escala: a la selección si la hay, si no al plano importado y si no a todo.
   * Es la regla de sentido común: lo que el usuario tiene delante es lo que quiere escalar.
   */
  /**
   * Factor que hay que aplicar para dejar la geometría en metros, sabiendo que ya se pudo haber
   * convertido antes desde otra unidad (§10). `null` en `_unidadAplicada` significa «la geometría ya
   * está en metros y no se sabe de qué unidad venía»: en ese caso no se puede reinterpretar.
   */
  factorAEscalar() {
    const elegida = this._unidadElegida || (this._unidades ? this._unidades.id : 'm');
    const aplicada = this._unidadAplicada === undefined ? 'm' : this._unidadAplicada;
    if (!aplicada) return 1;
    return factorEscala(elegida, aplicada);
  },

  objetivoEscala() {
    const sel = this.cad.selection;
    if (sel && sel.size) return { ids: [...sel], nombre: `la selección (${sel.size})`, cuantos: sel.size };
    if (this._plano && this._plano.ids.length) {
      return { ids: this._plano.ids, nombre: `el plano «${this._plano.nombre}»`, cuantos: this._plano.ids.length };
    }
    const ids = this.prj.entities.map((e) => e.id);
    return { ids, nombre: 'todo el dibujo', cuantos: ids.length };
  },

  /**
   * Aplica un factor de escala a la geometría (§10): la deja en metros, que es la unidad interna.
   * El plano no se mueve de sitio: se escala sobre el centro de su extensión.
   */
  aplicarEscala(factor, opts = {}) {
    const f = Number(factor);
    if (!isFinite(f) || f <= 0 || Math.abs(f - 1) < 1e-12) { this.hint('Nada que escalar: el factor es 1.'); return 0; }
    const objetivo = this.objetivoEscala();
    const ids = new Set(objetivo.ids);
    const entidades = this.prj.entities.filter((e) => ids.has(e.id));
    if (!entidades.length) return 0;
    const caja = cajaDeEntidades(entidades);
    const centro = caja ? centroCaja(caja) : { x: 0, y: 0 };
    this.pushUndo();
    const n = escalarEntidades(entidades, f, centro);
    // Se recuerda el factor inverso por si el usuario se ha equivocado
    this._escalaAnterior = {
      factor: f, inversa: 1 / f, centro, ids: objetivo.ids,
      unidad: opts.unidad || '', unidadAnterior: this._unidadAplicada === undefined ? 'm' : this._unidadAplicada };
    const previo = (this.prj.meta.escalaPlano && this.prj.meta.escalaPlano.acumulado) || 1;
    this.prj.meta.escalaPlano = {
      factor: f, acumulado: previo * f, unidad: opts.unidad || (this._unidadElegida || ''),
      origen: opts.origen || 'manual', cuando: new Date().toISOString() };
    this.prj.settings.unidadPlano = 'm';
    this._unidadAplicada = opts.unidad || null;   // la geometría queda en metros; se recuerda de dónde
    // La geometría ya está en metros: la calibración antigua deja de tener sentido (§10)
    if (this.prj.meta.scale && Math.abs(this.prj.meta.scale - 1) > 1e-9) {
      this.prj.meta.scale = 1;
      this.prj.meta.calibracionHeredada = false;
    }
    if (this._plano && this._plano.ids.every((id) => ids.has(id))) {
      this._plano.caja = cajaDeEntidades(this.prj.entities, (x) => ids.has(x.id));
      this.cad.encuadrarCaja(this._plano.caja, 60);
    }
    this.afterChange();
    const tam = tamanoEnMetros(this._plano ? this._plano.caja : caja, 'm');
    this.hint(`Escala aplicada (${formatearEscala(f)} · ${n} puntos): ${objetivo.nombre} queda en ` +
      `${formatearLongitud(tam.ancho, 'm', 1)} × ${formatearLongitud(tam.alto, 'm', 1)}. Se puede deshacer con Ctrl+Z.`);
    if (this.panel === 'escala') this.refresh();
    return n;
  },

  /** Deshace la última escala aplicada (sin pasar por la pila de deshacer). */
  deshacerEscala() {
    const a = this._escalaAnterior;
    if (!a) { this.hint('No hay ninguna escala que deshacer.'); return 0; }
    const ids = new Set(a.ids);
    const entidades = this.prj.entities.filter((e) => ids.has(e.id));
    const n = escalarEntidades(entidades, a.inversa, a.centro);
    if (this._plano && this._plano.ids.every((id) => ids.has(id))) {
      this._plano.caja = cajaDeEntidades(this.prj.entities, (x) => ids.has(x.id));
    }
    this.prj.settings.unidadPlano = a.unidad || 'm';
    this._unidadAplicada = a.unidadAnterior;
    const previo = (this.prj.meta.escalaPlano && this.prj.meta.escalaPlano.acumulado) || 1;
    this.prj.meta.escalaPlano = { factor: a.inversa, acumulado: previo * a.inversa, unidad: a.unidad, origen: 'deshacer', cuando: new Date().toISOString() };
    this._escalaAnterior = null;
    this.afterChange();
    this.hint(`Escala deshecha (${n} puntos devueltos a su tamaño anterior).`);
    if (this.panel === 'escala') this.refresh();
    return n;
  },

  /**
   * Mide una distancia sobre el plano y la compara con la real: es la forma de escalar un plano
   * del que no se sabe la unidad (un escaneo, un PDF, un DWG sin $INSUNITS).
   */
  escalarPorReferencia() {
    this.setTool('measure');
    this._calibrating = false;
    this._escalandoReferencia = true;
    this.hint('Haga clic en los dos extremos de una distancia que conozca (un vano, una puerta, un lado del edificio).');
  },

  /**
   * Pregunta por la unidad del plano recién importado (§9, §10).
   *
   * Si el fichero la declara ($INSUNITS) se propone esa; si no, se deduce del tamaño del plano. Y como
   * acertar no es seguro, no se escala nada por las buenas: se avisa en el lienzo con la propuesta y
   * se ofrece aplicarla, elegir otra unidad o medir una distancia conocida. Es la respuesta a «quiero
   * determinar la unidad de medida en la que se importará el plano».
   */
  proponerUnidades(r, opts = {}) {
    const rep = (r && r.report) || {};
    const prop = unidadPropuesta(rep);
    this._unidades = prop;
    this._unidadElegida = prop.id;
    this._unidadAplicada = 'm';                 // nada convertido todavía: la geometría está como llegó
    this.prj.settings.unidadPlano = this.prj.settings.unidadPlano || prop.id;
    const u = prop.unidad;
    if (!u || !u.metros || Math.abs(u.metros - 1) < 1e-9) return null;   // ya está en metros: nada que preguntar
    const caja = this._plano ? this._plano.caja : rep.extents;
    const tam = tamanoEnMetros(caja, prop.id);
    const antes = tamanoEnMetros(caja, 'm');
    this.hint(`El plano parece dibujado en ${u.etiqueta.toLowerCase()} (${prop.origen === 'declarada' ? 'lo declara el fichero' : 'deducido del tamaño'}): ` +
      `confirme la unidad en el aviso del lienzo o en «Plano ▸ Unidades y escala…».`);
    // El aviso lo arma `aplicarPlanoImportado`, que es quien ya avisa de la importación: así el
    // usuario recibe una sola noticia con todo, en vez de dos que se pisan.
    return {
      prop,
      texto: `<br><b>¿En qué unidad está dibujado el plano?</b> ` +
        `${prop.origen === 'declarada' ? 'El fichero lo declara' : 'No lo declara, se deduce del tamaño'}: ` +
        `<b>${esc(u.etiqueta.toLowerCase())}</b> (${esc(prop.motivo)}).<br>` +
        `Si es así, el plano mide <b>${esc(formatearLongitud(tam.ancho, 'm', 1))} × ${esc(formatearLongitud(tam.alto, 'm', 1))}</b> ` +
        `(ahora mismo se está leyendo como ${esc(formatearLongitud(antes.ancho, 'm', 1))} × ${esc(formatearLongitud(antes.alto, 'm', 1))}). ` +
        `<span class="muted small">Mientras no se corrija, las distancias, la cobertura y los cálculos saldrán mal.</span>`,
      acciones: [
        { label: `Sí: está en ${u.etiqueta.toLowerCase()} → escalar a metros (${formatearEscala(u.metros)})`, act: 'escala:aplicar' },
        { label: 'Elegir otra unidad…', act: 'escala:elegir' },
        { label: 'Medir una distancia conocida…', act: 'escala:referencia' },
      ] };
  },

  /* --------------------- muros del plano importado (§9, §13) --------------------- */

  /* ---------------------- edición de objetos (§8, §9) ---------------------- */

  /**
   * Comandos interactivos (MOVER, COPIAR, GIRAR, ESCALAR, ESPEJO), al estilo de AutoCAD: se
   * lanzan, se señala el punto base en el lienzo y luego el destino, con vista previa y con la
   * posibilidad de escribir el valor exacto en la barra de estado.
   */
  comandoEdicion(tipo, extra = {}) {
    if (tipo === 'pegar') {
      if (!this.portapapeles.entidades.length) { this.hint('No hay nada copiado en el portapapeles.'); return false; }
      extra = { entidades: this.portapapeles.entidades };
    }
    const ok = this.cad.iniciarComando(tipo, extra);
    if (!ok) this.hint(tipo === 'pegar' ? 'No hay nada que pegar.' : 'Seleccione primero los objetos que quiere modificar.');
    return ok;
  },

  /** Muestra u oculta la caja de valor de la barra de estado según la fase del comando. */
  estadoComando(c) {
    const caja = document.getElementById('cmdbox');
    if (!caja) return;
    const valor = document.getElementById('cmdValue');
    const etiqueta = document.getElementById('cmdLabel');
    if (!c) {
      caja.hidden = true;
      if (valor) valor.value = '';
      return;
    }
    caja.hidden = false;
    if (etiqueta) etiqueta.textContent = { mover: 'Desplazamiento «dx,dy»', copiar: 'Desplazamiento «dx,dy»', pegar: 'Desplazamiento «dx,dy»', rotar: 'Ángulo (°)', escalar: 'Factor', espejo: 'Ángulo del eje (°)' }[c.tipo] || 'Valor';
    if (valor && document.activeElement !== valor) valor.value = '';
    this.hint(this.cad._textoComando());
  },

  /** Cortar, copiar y pegar (Ctrl+X, Ctrl+C, Ctrl+V). */
  accionPortapapeles(accion) {
    const sel = this.cad.selected();
    if (accion === 'copiar' || accion === 'cortar') {
      if (!sel.length) { this.hint('No hay nada seleccionado que copiar.'); return false; }
      this.portapapeles = {
        entidades: sel.map((e) => JSON.parse(JSON.stringify(e))),
        base: this.cad.centroSeleccion(),
        cortar: accion === 'cortar' };
      if (accion === 'cortar') {
        this.pushUndo();
        sel.forEach((e) => removeEntity(this.prj, e.id));
        this.cad.selection.clear();
        this.afterChange();
        this.hint(`${this.portapapeles.entidades.length} objeto(s) cortado(s): haga clic donde pegarlos (Ctrl+V).`);
      } else {
        this.hint(`${this.portapapeles.entidades.length} objeto(s) copiado(s): haga clic donde pegarlos (Ctrl+V).`);
      }
      return true;
    }
    if (accion === 'pegar') {
      if (!this.portapapeles.entidades.length) { this.hint('El portapapeles está vacío.'); return false; }
      return this.comandoEdicion('pegar');
    }
    return false;
  },

  /** Refresco suave del panel: se usa mientras se arrastra un tirador, para no recalcular todo. */
  refrescarPanelLigero() {
    if (this._refrescoPendiente) return;
    this._refrescoPendiente = setTimeout(() => {
      this._refrescoPendiente = null;
      if (this.panel) this.showPanel(this.panel);
    }, 300);
  },

  /**
   * Comandos de edición de objetos: **M** mover, **R** rotar, **S** escalar, **E** espejo,
   * insertar o borrar vértices y abrir o cerrar una figura. Trabajan sobre la selección completa
   * y, como el resto de comandos numéricos del programa, piden los valores por teclado.
   */
  editar(accion, extra) {
    const ids = [...this.cad.selection];
    if (!ids.length) { this.hint('Seleccione primero los objetos que quiere modificar (herramienta Seleccionar).'); return false; }
    const n = ids.length;
    const pedir = (t, d) => prompt(t, d);
    const numero = (t, d) => { const v = parseFloat(String(pedir(t, d)).replace(',', '.')); return isFinite(v) ? v : null; };
    switch (accion) {
      case 'mover': {
        const d = pedir('Desplazamiento en metros «dx,dy» (por ejemplo 1,-0,5):', '0,0');
        if (d === null) return false;
        const [dx, dy] = String(d).split(/[,;\s]+/).map((v) => parseFloat(String(v).replace(',', '.')));
        if (!isFinite(dx) || !isFinite(dy)) { this.hint('Desplazamiento no válido.'); return false; }
        this.pushUndo(); this.cad.mover(ids, dx, dy); this.afterChange();
        this.hint(`${n} objeto(s) desplazado(s): ${dx} m en X y ${dy} m en Y.`); return true;
      }
      case 'rotar': {
        const a = numero('Ángulo de giro en grados (positivo, en sentido antihorario):', '90');
        if (a === null) return false;
        this.pushUndo(); this.cad.rotate(ids, a, this.cad.centroSeleccion()); this.afterChange();
        this.hint(`${n} objeto(s) girado(s) ${a}° sobre su centro.`); return true;
      }
      case 'escalar': {
        const f = numero('Factor de escala (2 = el doble de grande, 0,5 = la mitad):', '2');
        if (!f) { this.hint('Factor no válido.'); return false; }
        this.pushUndo(); this.cad.escalar(ids, f, this.cad.centroSeleccion()); this.afterChange();
        this.hint(`${n} objeto(s) escalado(s) ×${f}.`); return true;
      }
      case 'espejo': {
        this.pushUndo(); this.cad.espejar(ids, extra === 'h' ? 'h' : 'v', this.cad.centroSeleccion()); this.afterChange();
        this.hint(`${n} objeto(s) en espejo ${extra === 'h' ? 'horizontal' : 'vertical'}.`); return true;
      }
      case 'vertice:mas': {
        this.pushUndo();
        const k = this.cad.vertices(ids, 'insertar');
        this.afterChange();
        this.hint(k ? `Vértice insertado en ${k} objeto(s): arrástrelo para darle forma.` : 'Ese objeto no admite vértices nuevos.');
        return k > 0;
      }
      case 'vertice:menos': {
        this.pushUndo();
        const k = this.cad.vertices(ids, 'borrar');
        this.afterChange();
        this.hint(k ? `Último vértice eliminado en ${k} objeto(s).` : 'No se puede quitar ningún vértice más sin romper la figura.');
        return k > 0;
      }
      case 'cerrar': {
        this.pushUndo();
        const k = this.cad.vertices(ids, 'cerrar');
        this.afterChange();
        this.hint(k ? `Figura abierta o cerrada en ${k} objeto(s).` : 'Aquí no hay nada que abrir o cerrar.');
        return k > 0;
      }
      case 'seleccionar:tipo': {
        // Muy útil con planos importados: selecciona de golpe todo lo del mismo tipo
        const tipos = new Set(this.prj.entities.filter((e) => ids.includes(e.id)).map((e) => e.type));
        this.cad.selection = new Set(this.prj.entities.filter((e) => tipos.has(e.type)).map((e) => e.id));
        this.cad.draw(); this.showPanel('props');
        this.hint(`Seleccionados todos los objetos de tipo ${[...tipos].map((t) => ETIQUETA_TIPO[t] || t).join(', ')}.`);
        return true;
      }
      default: return false;
    }
  },

  /** Escribe un campo en todos los objetos seleccionados (desde el panel de propiedades). */
  editarCampo(campo, valor) {
    const ids = [...this.cad.selection];
    if (!ids.length) return false;
    this.pushUndo();
    let n = 0;
    for (const e of this.prj.entities) {
      if (!ids.includes(e.id)) continue;
      if (escribirCampo(e, campo, valor)) n++;
    }
    if (!n) {
      this.undo();
      this.hint('Ese cambio no se puede aplicar al objeto seleccionado.');
      return false;
    }
    this.afterChange();
    return true;
  },

  /** Mueve un vértice escribiendo su coordenada X o Y (panel de propiedades). */
  editarVertice(indice, eje, valor) {
    const ids = [...this.cad.selection];
    if (!ids.length || !isFinite(valor)) return false;
    this.pushUndo();
    let n = 0;
    for (const e of this.prj.entities) {
      if (!ids.includes(e.id)) continue;
      const p = e.points && e.points[indice];
      if (!p) continue;
      p[eje === 'y' ? 'y' : 'x'] = valor;
      n++;
    }
    if (!n) { this.undo(); return false; }
    this.afterChange();
    return true;
  },

  /** Marca como muro la geometría seleccionada (o la de una capa) sin duplicarla. */
  marcarMuros(ids, altura) {
    const set = new Set(ids);
    let n = 0;
    for (const e of this.prj.entities) {
      if (!set.has(e.id)) continue;
      if (e.type === 'text' || e.type === 'image') continue;
      if (!(e.points || []).length) continue;
      marcarMuro(e, altura);
      n++;
    }
    if (n) {
      this.pushUndo();
      this.afterChange();
      this.hint(`${n} elemento(s) marcados como muro a ${altura.toFixed(2)} m: ya se extruyen en la vista 3D y tapan la visión.`);
    } else {
      this.hint('Nada que marcar: seleccione líneas, polilíneas o arcos.');
    }
    if (this.panel === 'obstaculos') this.refresh();
    return n;
  },

  quitarMuros(ids) {
    const set = new Set(ids);
    let n = 0;
    for (const e of this.prj.entities) if (set.has(e.id) && e.data && e.data.muro && desmarcarMuro(e)) n++;
    if (n) { this.pushUndo(); this.afterChange(); this.hint(`${n} elemento(s) dejan de ser muro.`); }
    else this.hint('La selección no tiene elementos marcados como muro.');
    if (this.panel === 'obstaculos') this.refresh();
    return n;
  },

  /**
   * Detección automática de muros: las capas cuyo nombre los delata (MUROS, WALL, TABIQUES…).
   * Es lo que hace falta al importar un plano de arquitectura: decir «estas líneas son muros»
   * sin tener que seleccionarlas una a una.
   */
  detectarMuros() {
    const re = /muro|murs|wall|tabi|pared|parti|cloison|awall|alzado|cerramiento/i;
    const ids = [], capas = new Set();
    for (const e of this.prj.entities) {
      if (e.type === 'text' || e.type === 'image' || e.type === 'camera' || e.type === 'device') continue;
      if (!(e.points || []).length) continue;
      if (!re.test(e.layer || '')) continue;
      if (e.data && e.data.muro) continue;
      ids.push(e.id);
      capas.add(e.layer);
    }
    if (!ids.length) {
      this.hint('No se encuentran capas con nombre de muro (MUROS, WALL, TABIQUES…): márquelas a mano o por selección.');
      return 0;
    }
    const altura = this.prj.settings.alturaMuro || ALTURA_MURO;
    const n = this.marcarMuros(ids, altura);
    if (n) this.hint(`${n} elemento(s) marcados como muro en ${capas.size} capa(s): ${[...capas].join(', ')} · altura ${altura.toFixed(2)} m.`);
    return n;
  },

  /* --------------------------------- vista 3D (§8) --------------------------------- */

  /** Entra o sale de la vista 3D, y deja el panel a juego. */
  alternar3d(on) {
    const activo = on === undefined ? !this.cad.modo3d : !!on;
    this.cad.setModo3d(activo);
    if (activo) {
      this.showPanel('tresd');
      this.hint('Vista 3D: arrastre para girar, rueda para acercar, clic para seleccionar. Los muros se extruyen con su altura real.');
    } else {
      this.hint('Vista en planta (2D).');
      if (this.panel === 'tresd') this.showPanel('obstaculos');
    }
    this.refresh();
    return activo;
  },

  place(tool, w) {
    if (tool === 'camera') {
      const cams = this.prj.entities.filter((x) => x.type === 'camera');
      const numCams = cams.length;
      if (this.licencia && this.licencia.esTrial && numCams >= 1 && this.prj.meta.name !== 'Planta Oficina Demo') {
        const chk = this.licencia.puedeColocarCamara(numCams);
        this.avisoCad({
          texto: `<b>Límite de Evaluación (Trial) alcanzado.</b><br>${chk.motivo}`,
          tipo: 'aviso',
          duracion: 8000,
          acciones: [{ label: 'Ver Licencia / Activar', act: 'panel:license' }],
        });
        this.hint(chk.motivo);
        this.showPanel('license');
        return;
      }
      if (this._camaraPendienteColocacion) {
        const cfg = this._camaraPendienteColocacion;
        this.colocarCamaraDefinida(w, cfg);
        this._camaraPendienteColocacion = null;
        this.cad.tool = 'select';
        this.refrescarBarra();
        return;
      }
      if (this._asistenteCamaraAbierto) return;
      this.abrirAsistenteCamara(w);
      return;
    }
    this.pushUndo();
    let e = addEntity(this.prj, makeDevice('SW-16P', 'switch', w.x, w.y, {
      label: 'SW-' + String(this.prj.entities.filter((x) => x.type === 'device' && x.data.kind === 'switch').length + 1).padStart(2, '0') }));
    this.cad.selection = new Set([e.id]);
    this.afterChange();
    this.showPanel('props');
  },

  placeText(w) {
    const t = prompt('Texto:', 'NOTA');
    if (t === null) return;
    this.pushUndo();
    addEntity(this.prj, { type: 'text', layer: 'TEXTOS', points: [w], data: { text: t, height: 0.4 } });
    this.afterChange();
  },

  /**
   * Propuesta automática de cámaras a partir de la edificación, muros y espacio generado.
   * Analiza:
   * 1. Zonas/estancias del proyecto con baja cobertura (< 90%).
   * 2. Zonas ciegas detectadas por obstáculos/muros generados.
   * 3. Accesos y puertas (puntos de paso de la edificación).
   * 4. Envolvente perimetral de la edificación cuando no hay recintos definidos.
   */
  autoCameras() {
    this.recalcCoverage();
    const cov = this.results.coverage || {};
    const rooms = this.prj.entities.filter((e) => e.type === 'room');
    const def = (this.prj.catalog && this.prj.catalog.items.find((i) => i.id === 'CAM-4MP-DOME'))
      || (this.prj.catalog && this.prj.catalog.items.find((i) => i.category === 'camera'))
      || { id: 'CAM-4MP-DOME', specs: { lens: 2.8 } };

    let added = 0;
    this.pushUndo();

    const puedePoner = () => {
      const num = this.prj.entities.filter((x) => x.type === 'camera').length;
      return !(this.licencia && !this.licencia.puedeColocarCamara(num).permitido);
    };

    // 1. Cobertura por recintos / zonas de interés
    if (rooms.length > 0) {
      for (const r of rooms) {
        if (!puedePoner()) break;
        const st = (cov.zones || []).find((z) => z.id === r.id);
        if (st && st.pct > 90) continue;
        const cx = r.points.reduce((a, p) => a + p.x, 0) / r.points.length;
        const cy = r.points.reduce((a, p) => a + p.y, 0) / r.points.length;
        const minx = Math.min(...r.points.map((p) => p.x)), maxx = Math.max(...r.points.map((p) => p.x));
        const miny = Math.min(...r.points.map((p) => p.y)), maxy = Math.max(...r.points.map((p) => p.y));

        // Buscar la esquina más favorable orientada hacia el centroide de la estancia
        const esquinas = [
          { x: minx + 0.6, y: maxy - 0.6 },
          { x: maxx - 0.6, y: maxy - 0.6 },
          { x: minx + 0.6, y: miny + 0.6 },
          { x: maxx - 0.6, y: miny + 0.6 },
        ];
        // Elegir la esquina más alejada del centro para maximizar el cono de visión
        esquinas.sort((a, b) => Math.hypot(b.x - cx, b.y - cy) - Math.hypot(a.x - cx, a.y - cy));
        const pos = esquinas[0];

        const az = ((Math.atan2(cy - pos.y, cx - pos.x) * 180) / Math.PI + 360) % 360;
        addEntity(this.prj, makeCamera(def.id, pos.x, pos.y, {
          label: `CAM-${String(this.prj.entities.filter((x) => x.type === 'camera').length + 1).padStart(2, '0')}`,
          height: this.prj.rules.ALTO_FIJACION || 2.8, tilt: 22,
          azimuth: Math.round(az * 10) / 10,
          objective: r.data && r.data.critical ? 'RECONOCIMIENTO' : 'OBSERVACION',
          focal: (def.specs && def.specs.lens) || 2.8,
        }));
        added++;
      }
    }

    // 2. Cobertura de accesos / puertas detectadas en la edificación
    const puertas = this.prj.entities.filter((e) => e.type === 'obstacle' && e.data && (e.data.kind === 'puerta' || e.data.hueco));
    for (const p of puertas) {
      if (!puedePoner()) break;
      const pts = p.points || [];
      if (!pts.length) continue;
      const mx = pts.reduce((a, q) => a + q.x, 0) / pts.length;
      const my = pts.reduce((a, q) => a + q.y, 0) / pts.length;
      // Comprobar si ya hay cámara cerca de la puerta (menos de 6 m)
      const camsCerca = this.prj.entities.filter((e) => e.type === 'camera' && Math.hypot(e.points[0].x - mx, e.points[0].y - my) < 6);
      if (camsCerca.length === 0) {
        // Colocar cámara enfrentada al acceso a 4 m
        const dx = pts.length > 1 ? -(pts[1].y - pts[0].y) : 0;
        const dy = pts.length > 1 ? (pts[1].x - pts[0].x) : 1;
        const norm = Math.hypot(dx, dy) || 1;
        const camX = mx + (dx / norm) * 4;
        const camY = my + (dy / norm) * 4;
        const az = ((Math.atan2(my - camY, mx - camX) * 180) / Math.PI + 360) % 360;
        addEntity(this.prj, makeCamera(def.id, camX, camY, {
          label: `CAM-${String(this.prj.entities.filter((x) => x.type === 'camera').length + 1).padStart(2, '0')}`,
          height: this.prj.rules.ALTO_FIJACION || 2.8, tilt: 18,
          azimuth: Math.round(az * 10) / 10,
          objective: 'IDENTIFICACION',
          focal: (def.specs && def.specs.lens) || 2.8,
        }));
        added++;
      }
    }

    // 3. Si no hay estancias pero hay muros o zonas ciegas grandes (> 12 m²):
    if (added === 0 && cov.blindZones && cov.blindZones.length > 0) {
      for (const b of cov.blindZones) {
        if (!puedePoner()) break;
        if (b.area < 10) continue;
        const c = b.centroid;
        const bb = b.bbox;
        const camX = bb.minX + 0.5, camY = bb.maxY - 0.5;
        const az = ((Math.atan2(c.y - camY, c.x - camX) * 180) / Math.PI + 360) % 360;
        addEntity(this.prj, makeCamera(def.id, camX, camY, {
          label: `CAM-${String(this.prj.entities.filter((x) => x.type === 'camera').length + 1).padStart(2, '0')}`,
          height: this.prj.rules.ALTO_FIJACION || 2.8, tilt: 20,
          azimuth: Math.round(az * 10) / 10,
          objective: 'OBSERVACION',
          focal: (def.specs && def.specs.lens) || 2.8,
        }));
        added++;
      }
    }

    // 4. Si es una edificación sin estancias ni cámaras previas (muros en ARQUITECTURA o contorno)
    const totalCams = this.prj.entities.filter((x) => x.type === 'camera').length;
    if (added === 0 && totalCams === 0) {
      const muros = this.prj.entities.filter((e) => e.layer === 'ARQUITECTURA' || (e.data && e.data.muro));
      if (muros.length > 0 && puedePoner()) {
        const pts = muros.flatMap((m) => m.points || []);
        if (pts.length) {
          const minx = Math.min(...pts.map((p) => p.x)), maxx = Math.max(...pts.map((p) => p.x));
          const miny = Math.min(...pts.map((p) => p.y)), maxy = Math.max(...pts.map((p) => p.y));
          const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2;
          const pos = { x: minx + 1, y: maxy - 1 };
          const az = ((Math.atan2(cy - pos.y, cx - pos.x) * 180) / Math.PI + 360) % 360;
          addEntity(this.prj, makeCamera(def.id, pos.x, pos.y, {
            label: `CAM-01`,
            height: this.prj.rules.ALTO_FIJACION || 2.8, tilt: 22,
            azimuth: Math.round(az * 10) / 10,
            objective: 'OBSERVACION',
            focal: (def.specs && def.specs.lens) || 2.8,
          }));
          added++;
        }
      }
    }

    this.recalc(true);
    this.refresh();
    this.hint(added
      ? `${added} cámara(s) propuesta(s) de forma inteligente según la edificación y zonas críticas. Revise orientación y objetivos.`
      : 'La distribución actual ya cubre adecuadamente el espacio y las zonas de la edificación.');
  },

  /* ------------------------------ utilidades UI ------------------------------ */
  /** Selector de archivo en bytes: necesario para el DXF binario y para leer la firma de un DWG. */
  pickFileBinary(ext, cb) {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = ext;
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => cb(new Uint8Array(rd.result), f);
      rd.readAsArrayBuffer(f);
    };
    inp.click();
  },
  pickFile(ext, cb) {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = ext;
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => cb(rd.result, f.name);
      rd.readAsText(f);
    };
    inp.click();
  },
  alert(msg) { window.alert(msg); },
  confirm(msg, fn) { if (window.confirm(msg)) fn(); },
  saveProject(name) {
    this.prj.meta.name = name || this.prj.meta.name;
    downloadText(this.fname('cctv'), serialize(this.prj), 'application/json');
    this.hint('Proyecto guardado como ' + this.fname('cctv'));
  },
  fname(ext) { return `${(this.prj.meta.name || 'proyecto').replace(/[^\w\-]+/g, '_')}.${ext}`; },

  /* ------------------------------ plano importado y avisos en pantalla (§9) ------------------------------ */

  /** Aviso flotante sobre el lienzo, con acciones. `duracion: 0` lo deja hasta que se cierre. */
  avisoCad({ texto, tipo = 'info', duracion = 9000, acciones = [] }) {
    const vp = document.getElementById('viewport');
    if (!vp) return null;
    if (this._aviso) { this._aviso.remove(); this._aviso = null; }
    const d = document.createElement('div');
    d.className = 'avisocad' + (tipo === 'error' ? ' err' : tipo === 'aviso' ? ' warn' : '');
    const cuerpo = document.createElement('div');
    cuerpo.innerHTML = texto;
    d.appendChild(cuerpo);
    if (acciones.length) {
      const fila = document.createElement('div');
      fila.className = 'btnrow';
      for (const a of acciones) {
        const b = document.createElement('button');
        b.className = 'btn'; b.dataset.act = a.act; b.textContent = a.label;
        fila.appendChild(b);
      }
      fila.addEventListener('click', (ev) => {
        const b = ev.target.closest('[data-act]');
        if (!b) return;
        d.remove(); if (this._aviso === d) this._aviso = null;
        this.act(b.dataset.act);
      });
      d.appendChild(fila);
    }
    vp.appendChild(d);
    this._aviso = d;
    if (duracion) setTimeout(() => { if (this._aviso === d) { d.remove(); this._aviso = null; } }, duracion);
    return d;
  },

  /**
   * Incorpora al proyecto un plano recién importado (DXF suelto o DWG ya convertido), lo deja
   * encuadrado en pantalla y avisa de dónde ha quedado.
   *
   * Es la pieza que faltaba: antes el plano entraba en su sitio (a veces en coordenadas UTM,
   * a kilómetros de lo dibujado) y la vista se quedaba donde estaba, así que «no se encontraba».
   * Ahora las dos puertas de entrada (Importar DXF y Convertir DWG) hacen lo mismo.
   */
  aplicarPlanoImportado(r, opts = {}) {
    const A = this;
    const entidades = r.entities || [];
    const nombre = opts.nombre || 'plano';
    if (!entidades.length) {
      A.hint(`Plano «${nombre}»: no contiene geometría que se pueda dibujar.`);
      A.avisoCad({
        texto: `<b>El plano «${nombre}» no tiene geometría que se pueda dibujar.</b><br>` +
          'Se ha leído el fichero, pero no trae entidades que el programa sepa representar (LINE, LWPOLYLINE, ARC, CIRCLE, TEXT…).' +
          (opts.detalle ? '<br><span class="muted small">' + opts.detalle + '</span>' : ''),
        tipo: 'aviso', duracion: 0,
        acciones: [{ label: 'Ver el asistente DWG', act: 'file:dwg' }] });
      return { entidades: 0, caja: null };
    }
    A.pushUndo();
    const modo = (A.prj.settings && A.prj.settings.colorPlano) || 'original';
    const info = r.layerInfo || {};
    // 1. Capas del plano: nombre, color y estado tal como vienen del fichero (§9, §11).
    //    Antes se creaban todas del mismo gris y con el nombre en mayúsculas, de modo que la
    //    geometría de una capa «Muros» no llegaba a pintarse nunca (el fallo de «no se ve el plano»).
    const creadas = [], ajustadas = [], ocultas = [], reutilizadas = [];
    const capasPlano = new Map();
    for (const idl of r.layers || []) {
      const id = String(idl || '').toUpperCase();
      if (!id) continue;
      const meta = info[id] || { id, name: id, aci: 7, visible: true };
      const original = meta.colorVerdadero !== undefined && meta.colorVerdadero !== null
        ? hexDeVerdadero(meta.colorVerdadero)
        : (aciAHex(meta.aci) || meta.color || '#ffffff');
      const existente = A.prj.layers.find((l) => l.id === id);
      if (existente) {
        // Capa que ya existía (p. ej. ARQUITECTURA del proyecto): se respeta la del proyecto,
        // pero se recuerda que el plano la usa para poder repintarla.
        existente.delPlano = true;
        existente.colorOriginal = existente.colorOriginal || original;
        if (existente.aci === undefined) existente.aci = meta.aci;
        capasPlano.set(id, existente);
        reutilizadas.push(existente.name);
        continue;
      }
      const ajuste = ajustarParaFondo(original, this.prefs.fondo);
      const capa = {
        id, name: meta.name || id, color: colorDePlano(original, modo, this.prefs.fondo), colorOriginal: original,
        aci: meta.aci, colorVerdadero: meta.colorVerdadero, visible: meta.visible !== false,
        locked: false, delPlano: true };
      A.prj.layers.push(capa);
      capasPlano.set(id, capa);
      creadas.push(capa.name);
      if (meta.visible === false) ocultas.push(capa.name);
      if (ajuste.cambiado) ajustadas.push({ name: capa.name, de: original, a: capa.color, tinta: !!ajuste.tinta });
    }
    // 2. Entidades con identificador propio, color resuelto y marcadas como parte de este plano.
    //    El color sigue la herencia del formato: el del elemento manda, si no el del bloque
    //    (BYBLOCK) y si no el de la capa (BYLAYER).
    const ids = new Set();
    const cuenta = { propios: 0, deCapa: 0 };
    let n = 0;
    for (const e of entidades) {
      const id = 'DX' + Math.random().toString(36).slice(2, 8) + (n++).toString(36);
      ids.add(id);
      const capa = capasPlano.get(String(e.layer || '').toUpperCase()) || null;
      const original = resolverColor(e, capa ? { aci: capa.aci, color: capa.colorOriginal, colorVerdadero: capa.colorVerdadero } : {});
      const propio = (e.aci !== undefined && e.aci !== null) || e.colorVerdadero !== undefined;
      if (propio) cuenta.propios++; else cuenta.deCapa++;
      const base = original || (capa && capa.colorOriginal) || CLARO_DEL_PLANO;
      A.prj.entities.push(Object.assign({}, e, {
        id,
        data: Object.assign({}, e.data || {}, {
          planoImportado: nombre, color: colorDePlano(base, modo, this.prefs.fondo), colorOriginal: base }) }));
    }
    // 3. Extensión del plano y del resto del proyecto: sirve para encuadrar y para detectar «lejanía»
    const caja = cajaDeEntidades(A.prj.entities, (x) => ids.has(x.id));
    const cajaObra = cajaDeEntidades(A.prj.entities, (x) => !ids.has(x.id));
    const t = caja ? tamanoCaja(caja) : { ancho: 0, alto: 0 };
    const c = caja ? centroCaja(caja) : { x: 0, y: 0 };
    const lejos = planoAlejado(caja, cajaObra, 1);
    A._plano = { nombre, ids: [...ids], caja, entidades: n, creadas, reutilizadas, ajustadas, ocultas,
      colores: { propios: cuenta.propios, deCapa: cuenta.deCapa, modo },
      lejos, atenuado: false, cuando: new Date().toISOString() };
    A.prj.settings.ultimoPlano = { nombre, entidades: n, caja, lejos, cuando: A._plano.cuando };
    // 4. La vista se va al plano recién llegado: es lo primero que se quiere ver
    A.cad.setPlanoImportado(A._plano.ids, false);
    A.cad.encuadrarCaja(caja, 60);
    A.afterChange();
    // Unidades: antes de medir nada hay que saber en qué está dibujado el plano (§9, §10).
    // Se propone (y no se impone) una, y si el plano ya está en metros no se pregunta nada.
    const propuesta = A.proponerUnidades(r, { titulo: opts.titulo });
    const medidas = `${t.ancho.toFixed(1)} × ${t.alto.toFixed(1)} m`;
    const avisos = (opts.avisos || []).filter(Boolean);
    // Avisos de color: son los que explican por qué un plano «no se veía»
    if (ajustadas.length) {
      avisos.push(`${ajustadas.length} capa(s) aclaradas para verse sobre el fondo oscuro (el plano las traía en negro o muy oscuras: ${ajustadas.slice(0, 4).map((a) => a.name).join(', ')}${ajustadas.length > 4 ? '…' : ''}); se puede volver al color del plano en «Colores del plano»`);
    }
    if (ocultas.length) avisos.push(`${ocultas.length} capa(s) del plano venían apagadas o congeladas: se han importado ocultas (actívelas en el panel Capas)`);
    if (reutilizadas.length) avisos.push(`capa(s) que ya existían en el proyecto: ${reutilizadas.join(', ')}`);
    const detalles = [opts.detalle, ...avisos].filter(Boolean);
    A.hint(`${opts.titulo || 'Plano importado'}: ${n} entidades, ${(r.layers || []).length} capas · ${medidas} · encuadrado en pantalla` +
      (lejos ? ' ⚠ quedó lejos de lo dibujado' : '') + (detalles.length ? ' · ' + detalles.join(' · ') : ''));
    A.avisoCad({
      texto: `<b>${opts.titulo || 'Plano importado'}: ${nombre}</b><br>` +
        `${n} entidades · extensión ${medidas} · centro (${c.x.toFixed(1)}, ${c.y.toFixed(1)}) m` +
        (creadas.length ? ` · ${creadas.length} capa(s) nuevas` : '') +
        ` · colores: ${ETIQUETA_MODO[modo]}${ajustadas.length ? ` (${ajustadas.length} aclaradas)` : ''}<br>` +
        (lejos
          ? '<span class="warn-text">Este plano ha quedado lejos de lo dibujado en el proyecto (habitual en planos con coordenadas reales o en milímetros). Se puede traer a la zona de trabajo con un clic.</span>'
          : 'El plano queda a la vista y encuadrado: para volver a él en cualquier momento, botón derecho ▸ «Encuadrar plano».') +
        (avisos.length ? '<br><span class="muted small">' + avisos.map((a) => String(a)).join('<br>') + '</span>' : '') +
        (propuesta ? propuesta.texto : ''),
      tipo: lejos || propuesta ? 'aviso' : 'info',
      duracion: 0,
      acciones: (propuesta ? propuesta.acciones : []).concat(lejos
        ? [{ label: 'Traer el plano a la zona del proyecto', act: 'plan:planoTraer' },
           { label: 'Encuadrar de nuevo', act: 'plan:planoEncuadrar' },
           { label: 'Quitar el plano', act: 'plan:planoQuitar' }]
        : [{ label: 'Encuadrar plano', act: 'plan:planoEncuadrar' },
           { label: 'Atenuar plano', act: 'plan:planoAtenuar' },
           { label: 'Quitar el plano', act: 'plan:planoQuitar' }]) });
    return { entidades: n, caja };
  },

  /**
   * Cambia los colores del plano importado: `original` (los del fichero, aclarando solo lo que no
   * se vería), `claro` (todo claro, para que destaque la instalación de CCTV) y `monocromo`.
   * Repinta capas y elementos conservando el color original de cada uno.
   */
  planoColores(modo) {
    const A = this;
    if (!MODOS_COLOR.includes(modo)) modo = 'original';
    A.prj.settings.colorPlano = modo;
    if (!A._plano) { A.hint(`Color del plano: ${ETIQUETA_MODO[modo]} (se aplicará al importar).`); return; }
    let capas = 0, oscuras = 0;
    for (const l of A.prj.layers) {
      if (!l.delPlano) continue;
      const base = l.colorOriginal || '#ffffff';
      const ajuste = ajustarParaFondo(base, this.prefs.fondo);
      l.color = colorDePlano(base, modo, this.prefs.fondo);
      capas++;
      if (modo === 'original' && ajuste.cambiado) oscuras++;
    }
    const ids = new Set(A._plano.ids);
    for (const e of A.prj.entities) {
      if (!ids.has(e.id) || !e.data) continue;
      e.data.color = colorDePlano(e.data.colorOriginal || CLARO_DEL_PLANO, modo, this.prefs.fondo);
    }
    A._plano.colores = Object.assign({}, A._plano.colores, { modo });
    A._plano.ajustadas = modo === 'original'
      ? A.prj.layers.filter((l) => l.delPlano).map((l) => ajustarParaFondo(l.colorOriginal || '#ffffff', A.prefs.fondo))
        .filter((a) => a.cambiado).map((a) => ({ de: a.inicial, a: a.color, name: '', tinta: !!a.tinta }))
      : [];
    A.cad.draw(); A.afterChange();
    A.hint(`Colores del plano «${A._plano.nombre}»: ${ETIQUETA_MODO[modo]} · ${capas} capa(s)` +
      (modo === 'original' && oscuras ? ` · ${oscuras} aclarada(s) para verse sobre el fondo oscuro` : ''));
  },

  /** Vuelve a encuadrar el plano importado (aunque se haya navegado a otra zona). */
  planoEncuadrar() {
    if (!this._plano) { this.hint('Todavía no hay ningún plano importado: use «Plano ▸ Importar DXF…».'); return; }
    const ok = this.cad.encuadrarPlano();
    this.hint(ok ? `Plano «${this._plano.nombre}» encuadrado en pantalla (${this._plano.entidades} entidades).`
      : 'El plano importado no tiene geometría que encuadrar.');
  },

  /** Trae el plano a la zona del proyecto: desplaza sus entidades al centro de lo ya dibujado. */
  planoTraerAlProyecto() {
    const A = this;
    if (!A._plano) { A.hint('No hay ningún plano importado que traer.'); return; }
    const ids = new Set(A._plano.ids);
    const cajaObra = cajaDeEntidades(A.prj.entities, (x) => !ids.has(x.id));
    const destino = cajaObra ? centroCaja(cajaObra) : { x: 0, y: 0 };
    const origen = centroCaja(A._plano.caja);
    const dx = destino.x - origen.x, dy = destino.y - origen.y;
    const d = Math.hypot(dx, dy);
    if (d < 1e-6) { A.hint('El plano ya está sobre la zona de trabajo.'); return; }
    A.pushUndo();
    for (const e of A.prj.entities) {
      if (!ids.has(e.id) || !e.points) continue;
      e.points = e.points.map((q) => ({ x: q.x + dx, y: q.y + dy }));
    }
    A._plano.caja = cajaDeEntidades(A.prj.entities, (x) => ids.has(x.id));
    A._plano.lejos = false;
    A.prj.settings.ultimoPlano = Object.assign({}, A.prj.settings.ultimoPlano || {}, { caja: A._plano.caja, lejos: false });
    A.cad.encuadrarPlano();
    A.afterChange();
    A.hint(`Plano «${A._plano.nombre}» traído a la zona del proyecto (desplazado ${d.toFixed(1)} m).`);
    A.avisoCad({
      texto: `Plano desplazado <b>${d.toFixed(1)} m</b> para dejarlo sobre la zona de trabajo. Las cámaras, rutas y cálculos se rehacen con la nueva posición.`,
      tipo: 'info', duracion: 9000,
      acciones: [{ label: 'Encuadrar plano', act: 'plan:planoEncuadrar' }, { label: 'Atenuar plano', act: 'plan:planoAtenuar' }] });
  },

  /** Selecciona todas las entidades del plano importado (para moverlas o borrarlas de una vez). */
  planoSeleccionar() {
    if (!this._plano) { this.hint('No hay ningún plano importado que seleccionar.'); return; }
    this.cad.selection = new Set(this._plano.ids);
    this.showPanel('props');
    this.cad.draw();
    this.hint(`Seleccionadas las ${this._plano.entidades} entidades del plano importado (se pueden arrastrar con el ratón).`);
  },

  /** Dibuja el plano importado en gris, para distinguirlo de la instalación de CCTV. */
  planoAtenuar() {
    if (!this._plano) { this.hint('No hay ningún plano importado que atenuar.'); return; }
    this._plano.atenuado = !this._plano.atenuado;
    this.cad.atenuarPlano = this._plano.atenuado;
    this.hint(`Plano importado ${this._plano.atenuado ? 'atenuado (en gris, para destacar la instalación)' : 'con sus colores originales'}.`);
  },

  /** Retira del dibujo el plano importado (lo dibujado y los cálculos de CCTV no se tocan). */
  planoQuitar() {
    const A = this;
    if (!A._plano) { A.hint('No hay ningún plano importado que quitar.'); return; }
    const n = A._plano.entidades, nombre = A._plano.nombre;
    A.confirm(`¿Quitar el plano importado «${nombre}» (${n} entidades)?`, () => {
      const ids = new Set(A._plano.ids);
      A.pushUndo();
      A.prj.entities = A.prj.entities.filter((e) => !ids.has(e.id));
      A.cad.setPlanoImportado(null, false);
      A._plano = null;
      delete A.prj.settings.ultimoPlano;
      A.cad.fit(); A.afterChange();
      A.hint(`Plano «${nombre}» retirado del dibujo (${n} entidades). Ctrl+Z lo devuelve.`);
      A.avisoCad({ texto: 'Plano importado retirado del dibujo. Se puede deshacer con <b>Ctrl+Z</b>.', tipo: 'info', duracion: 6000 });
    });
  },

  /** Oculta o vuelve a mostrar las capas del plano importado. */
  planoCapas() {
    const A = this;
    if (!A._plano) { A.hint('No hay ningún plano importado.'); return; }
    const ids = new Set(A._plano.ids);
    const nombres = new Set(A.prj.entities.filter((e) => ids.has(e.id)).map((e) => e.layer));
    const visibles = A.prj.layers.filter((l) => nombres.has(l.id) && l.visible !== false).length;
    const ocultar = visibles > 0;
    for (const l of A.prj.layers) if (nombres.has(l.id)) l.visible = !ocultar;
    A.cad.draw();
    A.hint(`Capas del plano importado (${nombres.size}) ${ocultar ? 'ocultas' : 'visibles otra vez'}.`);
    A.refresh();
  },

  /* ------------------------------ menú contextual del botón derecho (§8) ------------------------------ */

  /** Estado que muestra el menú contextual del lienzo. */
  ctxEstado() {
    const p = this._plano;
    return {
      ultimo: this._ultimoComando ? this._ultimoComando.label : null,
      plano: p ? { nombre: p.nombre, atenuado: !!p.atenuado, lejos: !!p.lejos } : null,
      colorPlano: (this.prj.settings && this.prj.settings.colorPlano) || 'original',
      portapapeles: (this.portapapeles && this.portapapeles.entidades.length) || 0 };
  },

  /** Acción elegida en el menú contextual. */
  ctx(act) {
    const A = this;
    const directas = {
      'rep:ultimo': () => A.repUltimo(),
      'sel:borrar': () => A.act('edit:delete'),
      'sel:duplicar': () => A.act('edit:duplicate'),
      'sel:props': () => A.showPanel('props'),
      'plan:capas': () => A.act('plan:coverage'),
      'plano:color:original': () => A.planoColores('original'),
      'plano:color:claro': () => A.planoColores('claro'),
      'plano:color:monocromo': () => A.planoColores('monocromo'),
      'plano:encuadrar': () => A.planoEncuadrar(),
      'plano:traer': () => A.planoTraerAlProyecto(),
      'plano:seleccionar': () => A.planoSeleccionar(),
      'plano:atenuar': () => A.planoAtenuar(),
      'plano:capas': () => A.planoCapas(),
      'plano:quitar': () => A.planoQuitar(),
      'panel:layers': () => A.showPanel('layers'),
      'panel:project': () => A.showPanel('project'),
      'panel:options': () => A.showPanel('options'),
      'panel:walkthrough': () => A.showPanel('walkthrough') };
    if (directas[act]) { directas[act](); return; }
    // Si la acción no es del menú contextual se intenta por la vía normal, pero sin volver a entrar
    // aquí: las acciones «plano:*» están definidas justo arriba y una cadena de ida y vuelta sería
    // una recursión infinita.
    if (!act.startsWith('plano:')) A.act(act);
    else console.warn('Acción de plano no implementada:', act);
  },

  /** Repite el último comando elegido en la barra, el menú o el panel (como AutoCAD). */
  repUltimo() {
    if (!this._ultimoComando) { this.hint('Todavía no hay ningún comando que repetir.'); return; }
    const c = this._ultimoComando;
    this.hint(`Repitiendo: ${c.label}`);
    this.act(c.act);
  },

  /* ------------------------------ recorrido §41 ------------------------------ */
  walkthrough() {
    const p = this.prj, r = this.results;
    const lprS = lprSummary(p, p.catalog, p.rules);
    const lprN = lprS.count;
    const anS = analyticsSummary(p, p.catalog, p.rules, r.coverage || {});
    const fibS = fiberSummary(p, p.catalog, p.rules);
    const cams = p.entities.filter((e) => e.type === 'camera');
    const devs = p.entities.filter((e) => e.type === 'device');
    const cables = p.entities.filter((e) => e.type === 'cable');
    const hasImg = p.entities.some((e) => e.type === 'image');
    const hasDxf = p.entities.some((e) => (e.id || '').startsWith('DX'));
    return [
      { n: 1, name: 'Importar plano', detail: hasImg || hasDxf ? 'Plano cargado' : 'DXF o imagen de fondo', done: hasImg || hasDxf, act: 'walk:import', label: 'Importar' },
      { n: 2, name: 'Calibrar', detail: `escala 1:${(1 / (p.meta.scale || 1)).toFixed(0)}`, done: Math.abs((p.meta.scale || 1) - 1) > 1e-9 || hasDxf, act: 'walk:calibrate', label: 'Calibrar' },
      { n: 3, name: 'Colocar cámaras', detail: `${cams.length} cámara(s)`, done: cams.length > 0, act: 'walk:place', label: 'Colocar' },
      { n: 4, name: 'Configurar cámaras', detail: cams.every((c) => c.data.label && c.data.catalogId) ? 'todas configuradas' : 'faltan datos', done: cams.length > 0 && cams.every((c) => c.data.label && c.data.catalogId) },
      { n: 5, name: 'Analizar cobertura', detail: r.coverage ? `${r.coverage.coveragePct.toFixed(1)} % cubierta` : 'sin analizar', done: !!r.coverage, act: 'walk:coverage', label: 'Analizar' },
      { n: 6, name: 'Definir LPR', detail: lprN ? `${lprN} cámara(s) · ${lprS.status}` : 'sin cámaras LPR', done: !lprN || lprS.status === 'NORMAL', act: 'walk:lpr', label: 'Panel LPR' },
      { n: 7, name: 'Configurar analítica', detail: anS.rules ? `${anS.rules} regla(s) · ${anS.events.toFixed(0)} eventos/día` : 'sin reglas', done: !anS.rules || anS.failed === 0, act: 'walk:analytics', label: 'Reglas' },
      { n: 8, name: 'Verificar fibra', detail: fibS.fiberLinks ? `${fibS.fiberLinks} enlace(s) · ${fibS.status}` : 'sin enlaces de fibra', done: fibS.status !== 'EXCESIVA', act: 'walk:fiber', label: 'Fibra' },
      { n: 9, name: 'Generar rutas', detail: `${cables.length} enlace(s)`, done: cables.length > 0, act: 'walk:routes', label: 'Generar' },
      { n: 19, name: 'Calcular cable', detail: cables.length ? `${cables.reduce((a, c) => a + (c.data.supply || 0), 0).toFixed(0)} m de suministro` : '—', done: cables.length > 0 },
      { n: 20, name: 'Diseñar red', detail: `${devs.filter((d) => d.data.kind === 'switch').length} switch(es)`, done: devs.some((d) => d.data.kind === 'switch') && cams.every((c) => c.data.switchId), act: 'walk:network', label: 'Asignar' },
      { n: 21, name: 'Calcular PoE', detail: r.poe ? r.poe.overall : '—', done: !!r.poe && r.poe.overall !== 'INSUFICIENTE' },
      { n: 19, name: 'Calcular almacenamiento', detail: r.storage ? `${r.storage.requiredTb.toFixed(1)} TB` : '—', done: !!r.storage, act: 'walk:storage', label: 'Calcular' },
      { n: 20, name: 'Definir NVR', detail: devs.some((d) => d.data.kind === 'nvr') ? 'NVR definido' : 'sin NVR', done: devs.some((d) => d.data.kind === 'nvr') && r.storage && r.storage.channelsOk !== false },
      { n: 21, name: 'Definir rack', detail: r.rack ? `${r.rack.used}/${r.rack.capacity} U` : '—', done: !!r.rack && r.rack.used > 0 && r.rack.used <= r.rack.capacity, act: 'walk:rack', label: 'Distribuir' },
      { n: 19, name: 'Generar materiales', detail: r.bom ? `${r.bom.length} partidas` : '—', done: !!r.bom && r.bom.length > 0, act: 'walk:materials', label: 'Calcular todo' },
      { n: 20, name: 'Generar presupuesto', detail: r.budget ? money(r.budget.total, r.budget.currency) : '—', done: !!r.budget && r.budget.total > 0 },
      { n: 21, name: 'Generar planos', detail: 'PDF · PNG · DXF', done: !!this._planExported, act: 'walk:plan', label: 'Plano PDF' },
      { n: 19, name: 'Generar documentación', detail: 'dossier técnico', done: !!this._docExported, act: 'walk:docs', label: 'Dossier' },
      { n: 20, name: 'Validar', detail: r.validation ? r.validation.summary : 'sin validar', done: !!r.validation && r.validation.ok, act: 'walk:validate', label: 'Validar' },
      { n: 21, name: 'Exportar', detail: 'JSON · XML · CSV · XLSX', done: !!this._exported, act: 'walk:export', label: 'Exportar' },
    ];
  },

  /* ------------------------------ exportación ------------------------------ */
  exportBomCsv() {
    const b = this.results.bom || [];
    downloadText(this.fname('materiales.csv'), toCsv([['Partida', 'Cantidad', 'Unidad', 'Precio', 'Total'],
      ...b.map((l) => [l.label, l.qty, l.unit, num(l.price), num(l.total)])], ';'), 'text/csv');
    this._exported = true; this.updateWalkBadge();
  },
  exportBudgetCsv() {
    const b = this.results.budget; if (!b) return;
    downloadText(this.fname('presupuesto.csv'), toCsv([
      ['Partida', 'Cantidad', 'Coste ud.', 'Venta ud.', 'Total venta'],
      ...b.lines.map((l) => [l.label, l.qty, num(l.price), num(l.saleUnit), num(l.saleTotal)]),
      [], ['Base imponible', '', '', '', num(b.base)], ['Impuestos', '', '', '', num(b.taxAmt)], ['TOTAL', '', '', '', num(b.total)]], ';'), 'text/csv');
    this._exported = true; this.updateWalkBadge();
  },
  exportXlsx() {
    const p = this.prj, cur = p.catalog.currency;
    const sheets = [];
    sheets.push({ name: 'Cámaras', widths: [10, 18, 18, 8, 8, 8, 8, 8, 16, 14, 14], rows: [
      ['ID', 'Etiqueta', 'Equipo', 'X (m)', 'Y (m)', 'Altura', 'Azimut', 'Inclin.', 'Objetivo', 'IP', 'Switch'],
      ...p.entities.filter((e) => e.type === 'camera').map((c) => [c.id, c.data.label, (getItem(p.catalog, c.data.catalogId) || {}).model || '',
        +c.points[0].x.toFixed(2), +c.points[0].y.toFixed(2), c.data.height, c.data.azimuth, c.data.tilt,
        OBJECTIVES[c.data.objective] ? OBJECTIVES[c.data.objective].label : '', c.data.ip,
        (p.entities.find((e) => e.id === c.data.switchId) || { data: {} }).data.label || ''])] });
    sheets.push({ name: 'Cableado', widths: [18, 16, 12, 14, 10, 12], rows: [['Cámara', 'Switch', 'Ruta (m)', 'Suministro (m)', '% UTP', 'Estado'],
      ...(this.results.links || []).map((l) => [l.camera, l.switch, +l.geometric.toFixed(2), +l.supply.toFixed(2), +l.pct.toFixed(0), l.status])] });
    if (this.results.coverage) sheets.push({ name: 'Cobertura', widths: [18, 12, 16, 14, 12], rows: [['Cámara', 'Cubre (m²)', 'Objetivo', 'Alcanza (m)', 'Cumple'],
      ...this.results.coverage.cameras.map((c) => [c.label, +c.area.toFixed(2), c.objectiveLabel, +c.effectiveMax.toFixed(2), c.meetsObjective ? 'Sí' : 'No'])] });
    if (this.results.poe) sheets.push({ name: 'PoE', widths: [18, 10, 12, 12, 14], rows: [['Switch', 'Cámaras', 'Consumo (W)', 'Presupuesto (W)', 'Estado'],
      ...this.results.poe.groups.map((g) => [g.label, g.cameras, +g.totalPower.toFixed(1), g.budget, g.status])] });
    if (this.results.storage) sheets.push({ name: 'Almacenamiento', widths: [18, 10, 12, 12], rows: [['Cámara', 'kbps', 'GB/día', 'GB total'],
      ...this.results.storage.perCamera.map((c) => [c.label, c.kbps, +c.gbPerDay.toFixed(3), +c.gb.toFixed(2)])] });
    sheets.push({ name: 'Materiales', widths: [46, 10, 10, 12, 12], rows: [['Partida', 'Cantidad', 'Unidad', 'Precio', 'Total'],
      ...(this.results.bom || []).map((l) => [l.label, l.qty, l.unit, +l.price.toFixed(2), +l.total.toFixed(2)])] });
    if (this.results.budget) sheets.push({ name: 'Presupuesto', widths: [46, 10, 12, 12, 14], rows: [
      ['Partida', 'Cantidad', 'Coste ud.', 'Venta ud.', 'Total venta'],
      ...this.results.budget.lines.map((l) => [l.label, l.qty, +l.price.toFixed(2), +l.saleUnit.toFixed(2), +l.saleTotal.toFixed(2)]),
      [], ['Base imponible', '', '', '', +this.results.budget.base.toFixed(2)],
      ['Impuestos', '', '', '', +this.results.budget.taxAmt.toFixed(2)],
      ['TOTAL', '', '', '', +this.results.budget.total.toFixed(2)]] });
    downloadBytes(this.fname('xlsx'), toXlsx(sheets), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    this._exported = true; this.updateWalkBadge();
    this.hint('Libro XLSX exportado con 7 hojas.');
  },
  exportPlanDxf(opts = {}) {
    downloadText(this.fname(opts.blocks ? 'bloques.dxf' : 'dxf'), toDxf(this.prj, opts), 'application/dxf');
    this._planExported = true; this.updateWalkBadge();
    this.hint(opts.blocks
      ? 'DXF exportado con símbolos como bloques (BLOCK + INSERT con atributos) para CAD externo.'
      : 'DXF exportado (ASCII R2000).');
  },
  exportPlanIfc(opts = {}) {
    const ifcContent = toIfc(this.prj, opts);
    downloadText(this.fname('ifc'), ifcContent, 'application/x-step');
    this._planExported = true; this.updateWalkBadge();
    this.hint('Modelo BIM interoperable exportado a IFC 2x3 (ISO 16739).');
  },
  async exportPlanPng() {
    const blob = await this.cad.toPng(2);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = this.fname('png'); a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    this._planExported = true; this.updateWalkBadge();
  },

  /* --------- PDF: plano, diagrama y documentación --------- */
  planBounds() {
    let bb = null;
    for (const e of this.prj.entities) {
      if (!e.points || !e.points.length || e.type === 'image' || e.type === 'text') continue;
      for (const p of e.points) bb = bb ? { minX: Math.min(bb.minX, p.x), minY: Math.min(bb.minY, p.y), maxX: Math.max(bb.maxX, p.x), maxY: Math.max(bb.maxY, p.y) } : { minX: p.x, minY: p.y, maxX: p.x, maxY: p.y };
    }
    return bb || { minX: 0, minY: 0, maxX: 10, maxY: 10 };
  },

  drawPlanPdf(pdf, opts = {}) {
    const bb = this.planBounds();
    const titleH = 46;
    const availW = pdf.contentWidth, availH = pdf.height - pdf.margin * 2 - titleH;
    let s = Math.min(availW / (bb.maxX - bb.minX || 1), availH / (bb.maxY - bb.minY || 1));
    if (this.planScale && this.planScale !== 'fit') {
      const den = parseFloat(this.planScale.split(':')[1]);
      if (den) s = Math.min(s, 72 / (den / 39.3701)); // 1 m = 39,37 pt
    }
    const ox = pdf.margin + (availW - (bb.maxX - bb.minX) * s) / 2;
    const oy = pdf.margin + titleH + (availH - (bb.maxY - bb.minY) * s) / 2;
    const X = (x) => ox + (x - bb.minX) * s;
    const Y = (y) => oy + (y - bb.minY) * s;

    // Cobertura (huellas)
    // Las huellas se imprimen **recortadas por las sombras** (§13): en el plano de papel tampoco
    // aparece cobertura detrás de los muros. (Antes se recorría mal la lista y no se dibujaba nada.)
    const huellasPdf = (this.results.coverage && (this.results.coverage._sombras || this.results.coverage._footprints)) || null;
    if (huellasPdf) {
      for (const id of Object.keys(huellasPdf)) {
        const grupos = this.results.coverage._sombras
          ? (this.results.coverage._sombras[id] || [])
          : (huellasPdf[id] || []).map((q) => [q]);
        for (const grupo of grupos) {
          for (const poly of grupo) {
            if (!poly || poly.length < 3) continue;
            pdf.polyline(poly.map((q) => ({ x: X(q.x), y: Y(q.y) })), { close: true, fill: '#f2a33c', color: '#c9821f', width: 0.2 });
          }
        }
      }
    }
    for (const layer of this.prj.layers) {
      for (const e of this.prj.entities) {
        if (e.layer !== layer.id) continue;
        // Las capas del plano importado se imprimen con su color original (papel blanco), no con el
        // color aclarado del lienzo: si no, la tinta blanca del plano saldría invisible en el PDF.
        const col = layer.delPlano ? colorDePlanoPapel(layer.colorOriginal || CLARO_DEL_PLANO, (this.prj.settings && this.prj.settings.colorPlano) || 'original') : layer.color;
        if (e.type === 'line' && e.points.length > 1) pdf.line(X(e.points[0].x), Y(e.points[0].y), X(e.points[1].x), Y(e.points[1].y), { color: col, width: 0.6 });
        else if ((e.type === 'polyline' || e.type === 'room') && e.points.length > 1) pdf.polyline(e.points.map((p) => ({ x: X(p.x), y: Y(p.y) })), { close: e.closed, color: col, width: e.type === 'room' ? 0.3 : 0.6 });
        else if (e.type === 'cable') pdf.polyline(e.points.map((p) => ({ x: X(p.x), y: Y(p.y) })), { color: '#2563eb', width: 0.4, dash: [3, 2] });
        else if (e.type === 'rect' && e.points.length > 1) { const [a, b] = e.points; pdf.rect(X(Math.min(a.x, b.x)), Y(Math.min(a.y, b.y)), Math.abs(b.x - a.x) * s, Math.abs(b.y - a.y) * s, { stroke: col, width: 0.6 }); }
        else if (e.type === 'circle') { const n = 24, pts = []; for (let i = 0; i <= n; i++) { const a = (i / n) * Math.PI * 2; pts.push({ x: X(e.points[0].x + Math.cos(a) * e.radius), y: Y(e.points[0].y + Math.sin(a) * e.radius) }); } pdf.polyline(pts, { color: col, width: 0.5 }); }
        else if (e.type === 'text') pdf.text(X(e.points[0].x), Y(e.points[0].y), e.data.text || '', Math.max(6, (e.data.height || 0.3) * s * 0.6));
        else if (e.type === 'camera') {
          const p = e.points[0], r = 0.25 * s;
          const pts = []; for (let i = 0; i <= 16; i++) { const a = (i / 16) * Math.PI * 2; pts.push({ x: X(p.x) + Math.cos(a) * r, y: Y(p.y) + Math.sin(a) * r }); }
          pdf.polyline(pts, { color: '#c0392b', width: 0.7 });
          pdf.text(X(p.x) + r + 2, Y(p.y), e.data.label || '', 6);
        } else if (e.type === 'device') {
          pdf.rect(X(e.points[0].x) - 3, Y(e.points[0].y) - 3, 6, 6, { stroke: '#0e7490', width: 0.6 });
          pdf.text(X(e.points[0].x) + 5, Y(e.points[0].y) - 2, e.data.label || '', 6);
        }
      }
    }
    // Cajetín normalizado de ingeniería (UNE-EN ISO 7200 / DIN)
    const fmt = opts.formato || 'A3';
    const ty = pdf.margin + 4;
    const cw = pdf.contentWidth;
    // Marco exterior perimetral de la lámina
    pdf.rect(pdf.margin - 4, pdf.margin - 4, cw + 8, pdf.height - pdf.margin * 2 + 8, { stroke: '#1e293b', width: 1.2 });
    // Caja del cajetín
    pdf.rect(pdf.margin, ty, cw, titleH - 6, { stroke: '#334155', fill: '#f8fafc', width: 0.8 });
    const colDiv1 = Math.min(cw * 0.45, 340);
    const colDiv2 = Math.min(cw * 0.82, cw - 120);
    pdf.line(pdf.margin + colDiv1, ty, pdf.margin + colDiv1, ty + titleH - 6, { width: 0.6, color: '#64748b' });
    pdf.line(pdf.margin + colDiv2, ty, pdf.margin + colDiv2, ty + titleH - 6, { width: 0.6, color: '#64748b' });
    pdf.line(pdf.margin, ty + (titleH - 6) / 2, pdf.margin + colDiv2, ty + (titleH - 6) / 2, { width: 0.4, color: '#cbd5e1' });

    // Bloque 1: Proyecto y cliente
    pdf.text(pdf.margin + 8, ty + titleH - 18, this.prj.meta.name || 'Proyecto de Seguridad y CCTV', 12, { bold: true, color: '#0f172a' });
    pdf.text(pdf.margin + 8, ty + titleH - 28, `${this.prj.meta.client || 'Cliente confidencial'}  ·  ${this.prj.meta.address || 'Emplazamiento no especificado'}`, 8, { color: '#334155' });
    pdf.text(pdf.margin + 8, ty + 6, `Código: ${this.prj.meta.code || 'PRJ-01'}  ·  Proyectista: ${this.prj.meta.author || 'CCTV DESIGN PRO'}`, 8, { color: '#64748b' });

    // Bloque 2: Título del plano y especificaciones
    pdf.text(pdf.margin + colDiv1 + 8, ty + titleH - 18, (opts.title || `PLANO DE IMPLANTACIÓN DE SEGURIDAD Y CCTV (${fmt})`), 10.5, { bold: true, color: '#0f172a' });
    const numCams = this.prj.entities.filter((e) => e.type === 'camera').length;
    const escNominal = s ? `1:${Math.round(2834.65 / s)}` : '1:100';
    pdf.text(pdf.margin + colDiv1 + 8, ty + titleH - 28, `Escala gráfica aprox.: ${escNominal}  ·  Dispositivos: ${numCams} cámaras  ·  Ajuste: ${this.planScale || 'fit'}`, 8, { color: '#334155' });
    pdf.text(pdf.margin + colDiv1 + 8, ty + 6, `Fecha: ${new Date().toLocaleDateString('es-ES')}  ·  Normativa: UNE-EN 62676 / RGPD / AI Act`, 7.5, { color: '#64748b' });

    // Bloque 3: Formato de lámina y sello
    pdf.text(pdf.margin + colDiv2 + 8, ty + titleH - 16, `LÁMINA ${fmt}`, 11, { bold: true, color: '#1e3a8a' });
    pdf.text(pdf.margin + colDiv2 + 8, ty + titleH - 26, `Hoja 1 de 1`, 8, { color: '#475569' });
    pdf.text(pdf.margin + colDiv2 + 8, ty + 6, 'CCTV DESIGN PRO', 7, { color: '#94a3b8' });
  },

  exportPlanPdf(size = 'A3') {
    const s = (size === 'A1') ? 'A1' : 'A3';
    const pdf = new PdfDoc({ size: s, landscape: true, title: `${this.prj.meta.name} — Plano de cámaras (${s})`, author: this.prj.meta.author || 'CCTV DESIGN PRO' });
    this.drawPlanPdf(pdf, { formato: s });
    const sufijo = s === 'A1' ? '-plano-A1.pdf' : '-plano-A3.pdf';
    const nombre = (this.prj.meta.name || 'proyecto').replace(/[^a-zA-Z0-9_-]/g, '_') + sufijo;
    downloadBytes(nombre, pdf.save(), 'application/pdf');
    this._planExported = true; this.updateWalkBadge();
    this.hint(`Plano de instalación PDF (${s} apaisado con cajetín normalizado) exportado.`);
  },

  exportPerspectivePdf(size = 'A3', opts = {}) {
    const s = (size === 'A1') ? 'A1' : 'A3';
    const pdf = new PdfDoc({ size: s, landscape: true, title: `${this.prj.meta.name} — Perspectiva 3D (${s})`, author: this.prj.meta.author || 'CCTV DESIGN PRO' });
    drawPerspectivePdf(pdf, this.prj, this.prj.catalog, this.prj.rules, { formato: s, ...opts });
    const sufijo = s === 'A1' ? '-perspectiva-3D-A1.pdf' : '-perspectiva-3D-A3.pdf';
    const nombre = (this.prj.meta.name || 'proyecto').replace(/[^a-zA-Z0-9_-]/g, '_') + sufijo;
    downloadBytes(nombre, pdf.save(), 'application/pdf');
    this._planExported = true; this.updateWalkBadge();
    this.hint(`Lámina de perspectiva 3D PDF (${s} apaisado con cajetín normalizado) exportada.`);
  },

  exportDiagramPdf() {
    const pdf = new PdfDoc({ size: 'A4', landscape: true, title: 'Diagrama de red' });
    pdf.text(pdf.margin, pdf.height - pdf.margin - 6, 'DIAGRAMA DE RED — ' + (this.prj.meta.name || ''), 14, { bold: true });
    const layout = layoutTopology(this.results.topology || buildTopology(this.prj, this.prj.catalog));
    drawTopologyPdf(pdf, layout, pdf.margin, 90);
    downloadBytes('diagrama-red.pdf', pdf.save(), 'application/pdf');
    this._docExported = true; this.updateWalkBadge();
  },

  /* --------- Dossier y memorias --------- */
  exportDocPdf(kind) {
    const p = this.prj, cur = p.catalog.currency;
    const pdf = new PdfDoc({ size: 'A4', title: `${p.meta.name} — Documentación técnica`, author: p.meta.author || 'CCTV DESIGN PRO' });
    let y = pdf.height - pdf.margin;
    const H = (t, size = 13) => { if (y < pdf.margin + 90) { pdf.addPage(); y = pdf.height - pdf.margin; } pdf.text(pdf.margin, y, t, size, { bold: true }); y -= size + 6; };
    const P = (t, size = 9) => {
      const words = String(t).split(' ');
      let line = '';
      const maxW = pdf.contentWidth / (size * 0.5);
      for (const w of words) {
        if ((line + w).length > maxW) { pdf.text(pdf.margin, y, line, size); y -= size + 3; line = w + ' '; if (y < pdf.margin + 40) { pdf.addPage(); y = pdf.height - pdf.margin; } }
        else line += w + ' ';
      }
      if (line.trim()) { pdf.text(pdf.margin, y, line.trim(), size); y -= size + 4; }
      y -= 2;
    };
    const T = (heads, rows, widths) => {
      const total = widths.reduce((a, b) => a + b, 0);
      const xw = widths.map((w) => (w / total) * pdf.contentWidth);
      const drawRow = (cells, bold = false, bg) => {
        if (y < pdf.margin + 30) { pdf.addPage(); y = pdf.height - pdf.margin; }
        if (bg) pdf.rect(pdf.margin, y - 3, pdf.contentWidth, 13, { fill: bg });
        let x = pdf.margin;
        cells.forEach((c, i) => { pdf.text(x + 2, y, String(c === undefined || c === null ? '' : c).slice(0, 90), 7.5, { bold }); x += xw[i]; });
        y -= 12;
      };
      pdf.line(pdf.margin, y + 8, pdf.margin + pdf.contentWidth, y + 8, { width: 0.6 });
      drawRow(heads, true, '#e8ecef');
      rows.forEach((r) => drawRow(r));
      pdf.line(pdf.margin, y + 8, pdf.margin + pdf.contentWidth, y + 8, { width: 0.6 });
      y -= 10;
    };

    const cams = p.entities.filter((e) => e.type === 'camera');
    const devs = p.entities.filter((e) => e.type === 'device');
    const cov = this.results.coverage, poe = this.results.poe, st = this.results.storage, rk = this.results.rack, bud = this.results.budget, val = this.results.validation;

    const cover = () => {
      y = pdf.height - pdf.margin - 60;
      pdf.text(pdf.margin, y, 'CCTV DESIGN PRO', 22, { bold: true }); y -= 20;
      pdf.text(pdf.margin, y, 'Documentación técnica del proyecto', 12); y -= 30;
      pdf.text(pdf.margin, y, p.meta.name || '', 18, { bold: true }); y -= 22;
      pdf.text(pdf.margin, y, `Cliente: ${p.meta.client || '—'}`, 10); y -= 13;
      pdf.text(pdf.margin, y, `Emplazamiento: ${p.meta.address || '—'}`, 10); y -= 13;
      pdf.text(pdf.margin, y, `Código: ${p.meta.code || '—'}   ·   Autor: ${p.meta.author || '—'}`, 10); y -= 13;
      pdf.text(pdf.margin, y, `Fecha: ${new Date().toLocaleDateString('es-ES')}`, 10); y -= 30;
      pdf.line(pdf.margin, y, pdf.margin + pdf.contentWidth, y, { width: 1 });
      y -= 16;
      T(['Concepto', 'Valor'], [
        ['Cámaras', cams.length], ['Equipos de red y cabecera', devs.length],
        ['Cobertura', cov ? `${cov.coveragePct.toFixed(1)} %` : '—'],
        ['Zonas ciegas', cov ? cov.blindZones.length : '—'],
        ['Enlaces calculados', (this.results.links || []).length],
        ['Consumo PoE', poe ? `${poe.totalPower.toFixed(1)} W de ${poe.totalBudget} W` : '—'],
        ['Almacenamiento necesario', st ? `${st.requiredTb.toFixed(2)} TB (${p.rules.DIAS_GRABACION} días)` : '—'],
        ['Presupuesto', bud ? money(bud.total, cur) : '—'],
        ['Validación', val ? val.summary : '—'],
      ], [40, 60]);
    };

    const memory = () => {
      H('1. MEMORIA DESCRIPTIVA');
      P(`El presente documento describe el sistema de videovigilancia proyectado para ${p.meta.client || 'el cliente'} en ${p.meta.address || 'el emplazamiento indicado'}. El sistema está compuesto por ${cams.length} cámaras de videovigilancia, ${devs.filter((d) => d.data.kind === 'switch').length} switch(es) de red, ${devs.filter((d) => d.data.kind === 'nvr').length} grabador(es) NVR y los elementos de canalización, alimentación y protección necesarios para su correcto funcionamiento.`);
      P(`La cobertura se ha diseñado atendiendo a los objetivos de vigilancia definidos para cada zona (${[...new Set(cams.map((c) => OBJECTIVES[c.data.objective] ? OBJECTIVES[c.data.objective].label : ''))].filter(Boolean).join(', ') || 'observación'}), alcanzando un ${cov ? cov.coveragePct.toFixed(1) : '—'} % de superficie cubierta y ${cov ? cov.blindZones.length : '—'} zonas ciegas registradas.`);
      P(`La grabación se dimensiona para ${p.rules.DIAS_GRABACION} días de retención con ${st ? st.totalMbps.toFixed(1) : '—'} Mbps de ancho de banda agregado, requiriendo ${st ? st.requiredTb.toFixed(2) : '—'} TB de almacenamiento útil. La alimentación de las cámaras se realiza mediante PoE desde los switch(es) calculados, con una reserva del ${poe ? poe.reservePct : p.rules.RESERVA_POE} % sobre el presupuesto disponible.`);
      const ptzCams = cams.filter((c) => (getItem(p.catalog, c.data.catalogId) || { specs: {} }).specs.ptz);
      if (ptzCams.length) {
        const sum = ptzSummary(p, p.catalog, p.rules, cov);
        P(`El sistema incorpora ${ptzCams.length} cámara(s) PTZ con ${sum.presets} posición(es) memorizada(s) y patrulla automática: cada posición se define con su azimut, inclinación, zoom y objetivo de vigilancia, y el ciclo completo dura ${Math.round(sum.cycleMax)} s. La cobertura media ponderada por tiempo de estas cámaras es de ${sum.weightedArea.toFixed(1)} m², además de la cobertura instantánea de la unión de posiciones.`);
      }
      const lprN = lprSummary(p, p.catalog, p.rules).count;
      const anSum = analyticsSummary(p, p.catalog, p.rules, cov);
      const fib = fiberSummary(p, p.catalog, p.rules);
      if (lprN) P(`El control de acceso vehicular se resuelve con ${lprN} cámara(s) de lectura de matrículas, dimensionadas por carácter legible (${p.rules.LPR_ALTURA_CARACTER} px de altura sobre la placa) y con lectura nocturna asistida por infrarrojos.`);
      if (anSum.rules) P(`Se configuran ${anSum.rules} regla(s) de analítica de vídeo sobre las zonas de interés (${[...new Set(anSum.rows.map((r) => r.typeLabel))].join(', ')}), con un caudal estimado de ${anSum.events.toFixed(0)} eventos diarios${anSum.licenses ? ` y ${anSum.licenses} licencia(s) de analítica por canal` : ''}.`);
      if (fib.fiberLinks) P(`Los enlaces que superan el máximo de UTP o transcurren por el exterior se ejecutan en fibra óptica (${fib.fiberLinks} enlace(s), ${fib.meters.toFixed(0)} m), con transceptores SFP verificados por presupuesto de potencia óptica.`);
      P(`Toda la instalación se ejecuta sobre canalización ${p.entities.some((e) => e.type === 'cable') ? 'dimensionada a partir de las rutas calculadas' : 'pendiente de definir'}, evitando en lo posible el cruce de zonas húmedas o de paso. El sistema no depende de servicios externos ni de conexión permanente a Internet para su funcionamiento local.`);
      if (p.meta.notes) { H('Observaciones del proyectista', 11); P(p.meta.notes); }
    };

    const technical = () => {
      H('2. MEMORIA TÉCNICA');
      H('2.1 Criterios de diseño', 10);
      P('La selección de cámaras responde a la norma EN 62676-4, que establece la densidad de píxeles por metro necesaria para cada objetivo de vigilancia: detección 25 ppm, observación 63 ppm, reconocimiento 125 ppm e identificación 250 ppm. El campo de visión se calcula a partir de la distancia focal y el tamaño del sensor, y la huella en planta se obtiene proyectando el cono de visión sobre el suelo según la altura y la inclinación de fijación, recortándose por los obstáculos del plano.');
      H('2.2 Reglas aplicadas', 10);
      T(['Regla', 'Valor'], RULE_DEFS.filter((d) => ['MAX_UTP', 'RESERVA_CABLE', 'MARGEN_CABLE', 'RESERVA_POE', 'DIAS_GRABACION', 'RESERVA_DISCO', 'CELDA_COBERTURA'].includes(d.key))
        .map((d) => [`${d.label}${d.unit ? ' (' + d.unit + ')' : ''}`, String(p.rules[d.key])]), [70, 30]);
      H('2.3 Listado de cámaras', 10);
      T(['Etiqueta', 'Equipo', 'h (m)', 'Az (°)', 'Inc (°)', 'Objetivo', 'Área (m²)', 'Cumple'],
        (cov ? cov.cameras : []).map((c) => {
          const e = cams.find((x) => x.id === c.id) || { data: {}, points: [{ x: 0, y: 0 }] };
          return [c.label, c.model, e.data.height, e.data.azimuth, e.data.tilt, c.objectiveLabel, c.area.toFixed(1), c.meetsObjective ? 'Sí' : 'No'];
        }), [16, 18, 8, 8, 8, 16, 12, 10]);
      H('2.4 Cuadro de cableado', 10);
      T(['Cámara', 'Switch', 'Ruta (m)', 'Suministro (m)', '% UTP', 'Estado'],
        (this.results.links || []).map((l) => [l.camera, l.switch, l.geometric.toFixed(1), l.supply.toFixed(1), l.pct.toFixed(0), l.status]), [20, 18, 14, 16, 12, 20]);
      H('2.5 Cálculo PoE', 10);
      if (poe) T(['Switch', 'Cámaras', 'Puertos', 'Consumo (W)', 'Presupuesto (W)', 'Estado'],
        poe.groups.map((g) => [g.label, g.cameras, `${g.cameras}/${g.usablePorts}`, g.totalPower.toFixed(1), g.budget, g.status]), [22, 10, 12, 16, 18, 22]);
      H('2.6 Cálculo de almacenamiento', 10);
      if (st) {
        T(['Concepto', 'Valor'], [['Ancho de banda agregado', `${st.totalMbps.toFixed(1)} Mbps`],
          ['Días de retención', st.days], ['Modo de grabación', st.duty < 1 ? `Movimiento (${(st.duty * 100).toFixed(0)} %)` : 'Continuo 24×7'],
          ['Volumen calculado', `${st.totalGb.toFixed(1)} GB`], ['Reserva aplicada', `${st.reservePct} %`],
          ['Capacidad necesaria', `${st.requiredTb.toFixed(2)} TB`], ['Capacidad instalada', `${st.installedTb.toFixed(2)} TB`],
          ['Retención real', `${st.retentionDays.toFixed(1)} días`]], [50, 50]);
      }
      const ptzSched = ptzSchedule(p, p.catalog, p.rules);
      if (ptzSched.length) {
        H('2.8 Cámaras PTZ: posiciones y patrulla', 10);
        P('Las cámaras PTZ se documentan posición a posición. Cada preset tiene su propio azimut, inclinación y zoom, y se proyecta con ellos su huella de cobertura. La patrulla reparte el tiempo entre las posiciones según la permanencia definida; el análisis de cobertura considera la unión de todas las posiciones y la memoria justifica además la cobertura media ponderada por tiempo (Σ permanencia · área / ciclo), que es la cifra representativa de la vigilancia permanente.');
        T(['Cámara', 'Posición', 'Az (°)', 'Inc (°)', 'Zoom (mm)', 'Objetivo', 'Perm. (s)', 'Tiempo (%)', 'Ciclo (s)'],
          ptzSched.map((r) => [r.camera, r.preset, r.azimuth, r.tilt, r.focal, OBJECTIVES[r.objective] ? OBJECTIVES[r.objective].label : r.objective,
            r.dwell, r.duty === '' ? '—' : r.duty.toFixed(0), r.cycle || '—']), [16, 20, 8, 8, 10, 16, 8, 8, 6]);
        const sum = ptzSummary(p, p.catalog, p.rules, cov);
        P(`${sum.cameras} cámara(s) PTZ con ${sum.presets} posición(es) memorizada(s); ciclo de patrulla máximo ${Math.round(sum.cycleMax)} s. Cobertura media ponderada de las cámaras PTZ: ${sum.weightedArea.toFixed(1)} m².`);
      }
      const lprRows = lprSchedule(p, p.catalog, p.rules);
      if (lprRows.length) {
        H('2.9 Cámaras de lectura de matrículas (LPR)', 10);
        P('El dimensionado de una cámara de matrículas no se mide por campo de visión sino por carácter legible. Se verifica que la placa entregue al menos ' + p.rules.LPR_ALTURA_CARACTER + ' píxeles de altura de carácter (placa UE de 520 × 110 mm, carácter de 47 × 75 mm), que el ángulo entre el eje de la cámara y la marcha del vehículo no supere ' + p.rules.LPR_ANGULO_MAX + '° y que el emborronamiento por movimiento no pase del ' + p.rules.LPR_EMBORRON_PCT + ' % del ancho de carácter. La velocidad máxima admitida se deduce del tiempo de obturación.');
        T(['Cámara', 'Carril', 'Función', 'Dist. (m)', 'mm', 'ppm', 'px car.', 'Áng. (°)', 'Emborr. (%)', 'V. máx (km/h)'],
          lprRows.map((r) => [r.camera, r.lane, r.mode, r.distance, r.focal, r.ppm, r.charPx, r.angle, r.blurPct, r.maxSpeed]), [16, 16, 15, 9, 7, 8, 8, 8, 11, 12]);
      }
      const anRows = analyticsSchedule(p, p.catalog, p.rules, cov);
      if (anRows.length) {
        H('2.10 Analítica de vídeo', 10);
        const anSum = analyticsSummary(p, p.catalog, p.rules, cov);
        P('Se definen ' + anRows.length + ' regla(s) de analítica sobre las zonas de interés. Para cada regla se comprueba que la zona esté dentro del campo de visión, que la densidad de píxeles en el punto más desfavorable alcance los ' + (p.rules.ANALITICA_PPM) + ' ppm exigidos, el caudal estimado de eventos (' + anSum.events.toFixed(0) + ' eventos/día) y el flujo de metadatos asociado (' + anSum.kbps + ' kbps). ' + (anSum.licenses ? `La cámara no trae analítica embarcada en ${anSum.licenses} regla(s): se incluyen ${anSum.licenses} licencia(s) de canal en el presupuesto.` : 'Todas las reglas se ejecutan con analítica embarcada en las cámaras.'));
        T(['Cámara', 'Regla', 'Zona', 'Sens.', 'Cobertura', 'Peor ppm', 'Eventos/día', 'Acciones', 'Analítica'],
          anRows.map((r) => [r.camera, r.type, r.zone, r.sensitivity, r.coveragePct.toFixed(0) + ' %', r.ppm.toFixed(0), r.events, r.actions, r.license]), [15, 16, 18, 7, 11, 9, 11, 25, 12]);
      }
      const fib = fiberSummary(p, p.catalog, p.rules);
      if (fib.fiberLinks) {
        H('2.11 Fibra óptica', 10);
        P(`Se proyectan ${fib.fiberLinks} enlace(s) de fibra (${fib.meters.toFixed(0)} m de cable) por superar el máximo de UTP o por decisión del proyectista. El tipo de fibra y el transceptor se eligen por distancia y se comprueba el presupuesto de potencia óptica con las reglas del sistema: atenuación del cable, pérdidas de conectores (${fib.links[0].connectors} por enlace), empalmes (uno por bobina de ${p.rules.FIBRA_TRAMO_EMPALME} m) y un margen de diseño de ${p.rules.FIBRA_MARGEN} dB.`);
        T(['Cámara', 'Switch', 'Dist. (m)', 'Fibra', 'Transceptor', 'Pérdidas (dB)', 'Margen (dB)', 'Uso (%)', 'Estado'],
          fib.links.map((l) => [l.camera, l.switch, l.distance.toFixed(1), l.typeLabel, l.sfpModel, l.totalLoss.toFixed(2), l.margin, l.pct.toFixed(0), l.status]), [14, 13, 11, 16, 17, 12, 11, 9, 12]);
      }
      H('2.7 Distribución de rack', 10);
      if (rk) T(['Posición', 'Elemento', 'U'], rk.rows.map((r) => ['', `${r.name} × ${r.qty}`, r.u]), [20, 60, 20]) || null;
      if (rk) P(`Rack ${rk.label}: ${rk.used} U ocupadas de ${rk.capacity} U (${rk.fill.toFixed(0)} %). Carga estimada ${rk.load.toFixed(0)} W.`);
    };

    const budget = () => {
      H('3. PRESUPUESTO');
      if (!bud) { P('No hay presupuesto calculado.'); return; }
      T(['Partida', 'Cant.', 'Coste ud.', 'Venta ud.', 'Total'],
        bud.lines.map((l) => [l.label.slice(0, 60), l.qty, l.price.toFixed(2), l.saleUnit.toFixed(2), l.saleTotal.toFixed(2)]), [46, 8, 14, 14, 16]);
      y -= 4;
      T(['Concepto', 'Importe'], [['Coste de materiales', money(bud.costSum, cur)], ['Venta (margen ' + bud.margin + ' %)', money(bud.saleSum, cur)],
        ['Descuento (' + bud.discount + ' %)', money(-bud.discountAmt, cur)], ['Transporte', money(bud.transport, cur)],
        ['Instalación', money(bud.install, cur)], ['Base imponible', money(bud.base, cur)], ['Impuestos (' + bud.tax + ' %)', money(bud.taxAmt, cur)],
        ['TOTAL', money(bud.total, cur)]], [50, 50]);
    };

    const validation = () => {
      H('4. VALIDACIÓN DEL PROYECTO');
      if (!val) { P('Ejecute Herramientas → Validar proyecto.'); return; }
      P(val.summary);
      T(['Comprobación', 'Estado', 'Detalle'], val.issues.map((i) => [i.title, i.severity === 'ok' ? 'OK' : i.severity.toUpperCase(),
        i.items.length ? i.items.slice(0, 3).join(' · ').slice(0, 110) : '—']), [34, 12, 54]);
    };

    const plan = () => { pdf.addPage(); pdf.addPage(); this.drawPlanPdf(pdf, { title: 'PLANO DE CÁMARAS' }); };
    const perspective3d = () => {
      pdf.addPage(); pdf.addPage();
      drawPerspectivePdf(pdf, p, p.catalog, p.rules, { title: 'PERSPECTIVA 3D AXONOMÉTRICA DE COBERTURA', formato: 'A4' });
    };
    const diagram = () => {
      pdf.addPage();
      y = pdf.height - pdf.margin;
      H('5. DIAGRAMA DE RED');
      const layout = layoutTopology(this.results.topology || buildTopology(p, p.catalog));
      drawTopologyPdf(pdf, layout, pdf.margin, y - layout.height - 10);
      y -= layout.height + 20;
    };

    if (kind === 'memory') cover(), memory();
    else if (kind === 'technical') cover(), technical();
    else if (kind === 'cameras') { cover(); H('Listado de cámaras'); T(['Etiqueta', 'Equipo', 'X', 'Y', 'h', 'Az', 'Inc', 'Objetivo', 'IP'], cams.map((c) => [c.data.label, (getItem(p.catalog, c.data.catalogId) || {}).model || '', c.points[0].x.toFixed(2), c.points[0].y.toFixed(2), c.data.height, c.data.azimuth, c.data.tilt, OBJECTIVES[c.data.objective] ? OBJECTIVES[c.data.objective].label : '', c.data.ip]), [14, 18, 9, 9, 7, 8, 8, 18, 15]); }
    else if (kind === 'equipment') { cover(); H('Listado de equipos'); T(['Etiqueta', 'Tipo', 'Equipo', 'IP'], devs.map((d) => [d.data.label, d.data.kind, (getItem(p.catalog, d.data.catalogId) || {}).model || '', d.data.ip]), [24, 16, 40, 20]); }
    else if (kind === 'cabling') { cover(); H('Cuadro de cableado'); T(['Cámara', 'Switch', 'Ruta (m)', 'Suministro (m)', '% UTP', 'Estado'], (this.results.links || []).map((l) => [l.camera, l.switch, l.geometric.toFixed(1), l.supply.toFixed(1), l.pct.toFixed(0), l.status]), [20, 18, 14, 16, 12, 20]); }
    else if (kind === 'poe') { cover(); if (poe) { H('Cálculo PoE'); T(['Cámara', 'PoE', 'Consumo (W)', 'Clase'], poe.perCamera.map((c) => [c.label, c.poe ? 'Sí' : 'No', c.power, c.poeClass]), [40, 15, 25, 20]); T(['Switch', 'Consumo', 'Presupuesto', 'Estado'], poe.groups.map((g) => [g.label, g.totalPower.toFixed(1) + ' W', g.budget + ' W', g.status]), [30, 22, 22, 26]); } }
    else if (kind === 'storage') { cover(); if (st) { H('Cálculo de almacenamiento'); T(['Cámara', 'kbps', 'GB/día', 'GB total'], st.perCamera.map((c) => [c.label, c.kbps, c.gbPerDay.toFixed(3), c.gb.toFixed(2)]), [40, 18, 20, 22]); P(`Total ${st.totalGb.toFixed(1)} GB · necesario ${st.requiredTb.toFixed(2)} TB · instalado ${st.installedTb.toFixed(2)} TB · retención real ${st.retentionDays.toFixed(1)} días.`); } }
    else if (kind === 'ptz') {
      cover(); H('Cámaras PTZ — posiciones y patrulla (§38)');
      const sched = ptzSchedule(p, p.catalog, p.rules);
      const sum = ptzSummary(p, p.catalog, p.rules, cov);
      if (!sched.length) P('El proyecto no incluye cámaras PTZ.');
      else {
        P(`El proyecto incluye ${sum.cameras} cámara(s) PTZ con ${sum.presets} posición(es) memorizada(s). La presente tabla es la que se carga en el grabador y en la interfaz de la cámara: cada fila es un preset con su azimut, inclinación, zoom, objetivo de vigilancia y tiempo de permanencia.`);
        T(['Cámara', 'Posición', 'Az (°)', 'Inc (°)', 'Zoom (mm)', 'Objetivo', 'Perm. (s)', 'Tiempo (%)', 'Ciclo (s)'],
          sched.map((r) => [r.camera, r.preset, r.azimuth, r.tilt, r.focal, OBJECTIVES[r.objective] ? OBJECTIVES[r.objective].label : r.objective,
            r.dwell, r.duty === '' ? '—' : r.duty.toFixed(0), r.cycle || '—']), [16, 20, 8, 8, 10, 16, 8, 8, 6]);
        for (const row of sum.rows) {
          H(row.label, 9.5);
          P(`Ciclo de patrulla ${Math.round(row.cycleSec)} s · ${row.patrol ? 'patrulla activa' : 'patrulla detenida'} · cobertura instantánea de la unión ${row.unionArea.toFixed(1)} m² · cobertura media ponderada por tiempo ${row.weightedArea.toFixed(1)} m².`);
        }
        P('Nota: un PTZ solo puede vigilar una posición cada vez. La cobertura de la unión supone que el sistema ve todas las posiciones simultáneamente; la media ponderada reparte el área de cada posición según el tiempo que la cámara permanece en ella y es la cifra que debe usarse para valorar la vigilancia continua.');
      }
    }
    else if (kind === 'lpr') {
      cover(); H('Cámaras de lectura de matrículas — cuadro de puesta en marcha (§38)');
      const rows = lprSchedule(p, p.catalog, p.rules);
      if (!rows.length) P('El proyecto no incluye cámaras LPR.');
      else {
        P('Cuadro de configuración de las cámaras LPR: sirve para ajustar cada equipo en obra y para la puesta en marcha con el motor de reconocimiento. La ventana de lectura y la velocidad máxima admitida dependen de la focal, la distancia de captura y el tiempo de obturación programados.');
        T(['Cámara', 'Carril', 'Función', 'Dist. (m)', 'Focal (mm)', 'ppm', 'px carácter', 'Ángulo (°)', 'Emborronamiento (%)', 'V. máx (km/h)', 'IR'],
          rows.map((r) => [r.camera, r.lane, r.mode, r.distance, r.focal, r.ppm, r.charPx, r.angle, r.blurPct, r.maxSpeed, r.ir ? 'Sí' : 'No']), [13, 15, 15, 9, 9, 7, 10, 9, 13, 12, 6]);
        T(['Criterio', 'Valor de diseño'], [
          ['Altura mínima de carácter', `${p.rules.LPR_ALTURA_CARACTER} px`],
          ['Densidad mínima sobre la placa', `${p.rules.LPR_PPM} ppm`],
          ['Ángulo máximo con la marcha', `${p.rules.LPR_ANGULO_MAX}°`],
          ['Emborronamiento máximo', `${p.rules.LPR_EMBORRON_PCT} % del ancho de carácter`],
          ['Tiempo de obturación por defecto', `1/${p.rules.LPR_OBTURADOR} s`],
        ], [55, 45]);
      }
    }
    else if (kind === 'analytics') {
      cover(); H('Analítica de vídeo — cuadro de reglas (§38)');
      const rows = analyticsSchedule(p, p.catalog, p.rules, cov);
      const sum = analyticsSummary(p, p.catalog, p.rules, cov);
      if (!rows.length) P('El proyecto no define reglas de analítica.');
      else {
        P(`Se definen ${rows.length} regla(s) sobre ${sum.cameras} cámara(s), con un caudal estimado de ${sum.events.toFixed(0)} eventos/día y ${sum.kbps} kbps de metadatos. Este cuadro es el que se carga en el grabador o en el sistema de gestión de vídeo.`);
        T(['Cámara', 'Regla', 'Zona', 'Sensibilidad', 'Cobertura de la zona', 'Peor ppm', 'Eventos/día', 'Acciones', 'Analítica'],
          rows.map((r) => [r.camera, r.type, r.zone, r.sensitivity, r.coveragePct.toFixed(0) + ' %', r.ppm.toFixed(0), r.events, r.actions, r.license]), [13, 16, 16, 11, 14, 8, 10, 22, 12]);
      }
    }
    else if (kind === 'fiber') {
      cover(); H('Enlaces de fibra óptica — presupuesto de potencia (§38)');
      const fib = fiberSummary(p, p.catalog, p.rules);
      if (!fib.fiberLinks) P('El proyecto no incluye enlaces de fibra óptica.');
      else {
        P(`Cuadro de los ${fib.fiberLinks} enlace(s) de fibra, con el tipo de fibra y transceptor elegidos y el presupuesto de potencia óptica: atenuación del cable a la longitud de onda de trabajo, pérdidas de conectores y empalmes, margen de diseño y margen restante sobre el presupuesto del transceptor.`);
        T(['Cámara', 'Switch', 'Dist. (m)', 'Fibra', 'Transceptor', 'Atenuación (dB)', 'Conectores', 'Empalmes', 'Pérdidas (dB)', 'Presupuesto (dB)', 'Resto (dB)', 'Uso (%)', 'Estado'],
          fib.links.map((l) => [l.camera, l.switch, l.distance.toFixed(1), l.typeLabel, l.sfpModel, l.atten.toFixed(2), l.connectors, l.splices, l.totalLoss.toFixed(2), l.budget, l.remaining.toFixed(2), l.pct.toFixed(0), l.status]),
          [12, 12, 10, 15, 15, 12, 10, 9, 11, 12, 9, 8, 10]);
        T(['Tipo de fibra', 'λ (nm)', 'Alcance', 'Presupuesto'], Object.values(FIBER_TYPES).map((t) => [t.label, t.wavelength, `${t.maxDist >= 1000 ? t.maxDist / 1000 + ' km' : t.maxDist + ' m'}`, `${t.txBudget} dB`]), [45, 15, 20, 20]);
      }
    }
    else if (kind === 'analog') {
      cover(); H('Vídeo analógico — cuadro de enlaces, grabación y alimentación (§38)');
      const rows = analogSchedule(p, p.catalog, p.rules);
      const plan = analogPlan(p, p.catalog, p.rules);
      if (!rows.length) P('El proyecto no incluye cámaras analógicas.');
      else {
        P(`Cuadro de las ${rows.length} cámara(s) analógicas: formato de vídeo, medio de transmisión, distancia real frente al alcance del medio, canal de grabación y verificación de la alimentación de 12 V (caída de tensión en el cable hasta la cámara).`);
        T(['Cámara', 'Formato', 'Medio', 'Dist. (m)', 'Alcance (m)', 'Margen (m)', 'Uso (%)', 'Canal', 'Consumo (mA)', 'Caída (V)', 'Tensión (V)', 'Estado'],
          rows.map((r) => [r.camera, r.format, r.cable, r.distance, r.limit, r.margin, r.pct, r.channel, r.current, r.drop, r.volts, r.status]),
          [11, 16, 14, 9, 10, 9, 8, 8, 11, 9, 10, 10]);
        H('Alimentación y grabación', 11);
        P(`El consumo total de las cámaras es de ${plan.power.watts.toFixed(1)} W (${plan.power.amps.toFixed(2)} A). Con una reserva de diseño del ${plan.power.reserve} % se requieren ${plan.power.needAmps.toFixed(2)} A de fuente; el proyecto declara ${plan.power.psuAmps.toFixed(1)} A. La tensión en la cámara más desfavorable es de ${plan.power.voltsMin.toFixed(2)} V, con una sección de ${p.rules.ANALOG_SECCION} mm² y dos hilos de cobre.`);
        T(['Grabador', 'Modelo', 'Canales', 'Canales HD', 'Formatos admitidos', 'Bahías'],
          plan.recording.dvrs.map((d) => [d.label, d.model, d.channels, d.hdChannels, d.formats.join(' / '), d.bays]), [16, 16, 10, 11, 32, 9]);
        T(['Formato analógico', 'Resolución', 'RG-59', 'RG-6', 'UTP con balún'],
          Object.values(ANALOG_FORMATS).map((f) => [f.label, `${f.resW} × ${f.resH}`,
            `${Math.round(p.rules.ANALOG_RG59_MAX * f.factor)} m`, `${Math.round(p.rules.ANALOG_RG6_MAX * f.factor)} m`,
            `${Math.round(p.rules.ANALOG_UTP_MAX * f.factor)} m`]), [40, 20, 13, 13, 14]);
      }
    }
    else if (kind === 'budget') cover(), budget();
    else if (kind === 'sheets') {
      // Hojas de cámara: una página por equipo con su planta de cobertura (§28)
      cover(); pdf.addPage();
      hojasEnPdf(pdf, p, p.catalog, p.rules, this.results);
      pieDePagina(pdf, { texto: `${p.meta.name || ''} · Hojas de cámara`, trial: this.licencia && this.licencia.esTrial });
    }
    else if (kind === 'privacy') {
      // Anexo de protección de datos: qué se ve de lo ajeno, carteles, registro y Reglamento de IA
      cover(); pdf.addPage();
      anexoPrivacidad(pdf, p, p.catalog, p.rules, this.results);
      pieDePagina(pdf, { texto: `${p.meta.name || ''} · Protección de datos y cumplimiento`, trial: this.licencia && this.licencia.esTrial });
    }
    else {
      const entradas = [];
      const marca = (t, nivel = 1) => entradas.push({ texto: t, pagina: pdf.pages.length, nivel });
      cover();
      pdf.addPage(); y = pdf.height - pdf.margin; marca('1. Memoria descriptiva'); memory();
      pdf.addPage(); y = pdf.height - pdf.margin; marca('2. Memoria técnica'); technical();
      // Cada capítulo nuevo se numera solo: las hojas y el anexo llevan su propio escritor
      pdf.addPage(); hojasEnPdf(pdf, p, p.catalog, p.rules, this.results).entradas.forEach((e) => entradas.push(e));
      pdf.addPage(); anexoPrivacidad(pdf, p, p.catalog, p.rules, this.results).entradas.forEach((e) => entradas.push(e));
      pdf.addPage(); y = pdf.height - pdf.margin; marca('5. Presupuesto'); budget();
      pdf.addPage(); y = pdf.height - pdf.margin; marca('6. Validación del proyecto'); validation();
      diagram(); plan();
      marca('7. Perspectiva 3D de cobertura'); perspective3d();
      // El índice y el pie se colocan al final: hasta que no se ha escrito todo no se sabe
      // en qué página cae cada capítulo ni cuántas páginas tiene el documento
      colocarIndice(pdf, entradas.filter((e) => e && e.texto), { despues: 0 });
      pieDePagina(pdf, { texto: `${p.meta.name || ''} · Documentación técnica`, trial: this.licencia && this.licencia.esTrial });
    }

    downloadBytes(this.fname('pdf'), pdf.save(), 'application/pdf');
    this._docExported = true; this.updateWalkBadge();
    this.hint('Documentación PDF generada.');
  } };

function _startApp() {
  if (window.APP) return;
  window.APP = App;
  App.init();
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _startApp);
} else {
  _startApp();
}

export default App;
