/**
 * CCTV DESIGN PRO — Diagrama de red automático (CP CCTV §23, §19)
 * Produce un layout abstracto que se pinta en SVG (pantalla) y en PDF (documentación).
 */

export function layoutTopology(topo, opts = {}) {
  const colW = opts.colW || 150, rowH = opts.rowH || 46, nodeW = opts.nodeW || 132, nodeH = opts.nodeH || 30;
  const nodes = [], links = [];
  let y = 20;

  const routers = topo.routers || [];
  const nvrs = topo.nvrs || [];
  const switches = topo.nodes || [];

  routers.forEach((r, i) => {
    nodes.push({ id: r.id, x: 40 + i * colW, y, w: nodeW, h: nodeH, label: r.label, sub: r.ip || r.model, kind: 'router' });
  });
  y += rowH;
  nvrs.forEach((n, i) => {
    nodes.push({ id: n.id, x: 40 + i * colW, y, w: nodeW, h: nodeH, label: n.label, sub: n.ip || n.model, kind: 'nvr' });
    if (routers.length) links.push({ from: n.id, to: routers[0].id, label: 'uplink' });
  });
  y += rowH;
  switches.forEach((s, i) => {
    nodes.push({ id: s.id, x: 40 + i * colW, y, w: nodeW, h: nodeH, label: s.label, sub: `${s.children.length} cámaras · ${s.model}`, kind: 'switch' });
    if (nvrs.length) links.push({ from: s.id, to: nvrs[0].id, label: 'trunk' });
    else if (routers.length) links.push({ from: s.id, to: routers[0].id });
  });
  y += rowH;
  const perCol = 12;
  switches.forEach((s, i) => {
    s.children.forEach((c, j) => {
      const col = i + Math.floor(j / perCol);
      const row = j % perCol;
      nodes.push({ id: c.id, x: 40 + col * colW, y: y + row * 18, w: nodeW, h: 14, label: c.label, sub: c.model, kind: 'camera' });
      links.push({ from: c.id, to: s.id });
    });
  });
  (topo.orphans || []).forEach((c, j) => {
    nodes.push({ id: c.id, x: 40, y: y + j * 18, w: nodeW, h: 14, label: c.label + ' (sin switch)', sub: '', kind: 'orphan' });
  });
  const maxY = nodes.reduce((a, n) => Math.max(a, n.y + n.h), 0);
  const maxX = nodes.reduce((a, n) => Math.max(a, n.x + n.w), 0);
  return { nodes, links, width: maxX + 40, height: maxY + 30, nodeH };
}

const COLORS = { router: '#c084fc', nvr: '#14b8a6', switch: '#0ea5e9', camera: '#e8443a', orphan: '#f59e0b' };

export function topologySvg(layout, maxH = 420) {
  const byId = new Map(layout.nodes.map((n) => [n.id, n]));
  const L = [];
  L.push(`<svg viewBox="0 0 ${layout.width} ${layout.height}" width="100%" height="${Math.min(maxH, layout.height)}" xmlns="http://www.w3.org/2000/svg" font-family="system-ui" font-size="9">`);
  L.push('<rect width="100%" height="100%" fill="#0d1015"/>');
  for (const l of layout.links) {
    const a = byId.get(l.from), b = byId.get(l.to);
    if (!a || !b) continue;
    const x1 = a.x + a.w / 2, y1 = a.y, x2 = b.x + b.w / 2, y2 = b.y + b.h;
    L.push(`<path d="M${x1},${y1} C${x1},${y1 - 12} ${x2},${y2 + 12} ${x2},${y2}" stroke="#3b4757" fill="none" stroke-width="1"/>`);
  }
  for (const n of layout.nodes) {
    const c = COLORS[n.kind] || '#888';
    L.push(`<rect x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" rx="3" fill="${c}22" stroke="${c}"/>`);
    L.push(`<text x="${n.x + 6}" y="${n.y + (n.h > 20 ? 13 : 10)}" fill="#e6edf3">${esc(n.label)}</text>`);
    if (n.sub && n.h > 20) L.push(`<text x="${n.x + 6}" y="${n.y + 24}" fill="#8b98a5" font-size="8">${esc(n.sub)}</text>`);
  }
  L.push('</svg>');
  return L.join('');
}

/** Dibuja el mismo esquema en un PdfDoc (vectorial, §28). */
export function drawTopologyPdf(pdf, layout, ox, oy) {
  const byId = new Map(layout.nodes.map((n) => [n.id, n]));
  const H = pdf.height;
  const Y = (y) => H - oy - y;
  for (const l of layout.links) {
    const a = byId.get(l.from), b = byId.get(l.to);
    if (!a || !b) continue;
    pdf.line(ox + a.x + a.w / 2, Y(a.y), ox + b.x + b.w / 2, Y(b.y + b.h), { width: 0.4, color: '#66707d' });
  }
  for (const n of layout.nodes) {
    pdf.rect(ox + n.x, Y(n.y + n.h), n.w, n.h, { stroke: '#94a3b8', width: 0.5 });
    pdf.text(ox + n.x + 3, Y(n.y + n.h) + n.h - 9, n.label, 6.5);
    if (n.sub && n.h > 20) pdf.text(ox + n.x + 3, Y(n.y + n.h) + 3, n.sub, 5.5, { color: '#5b6b7c' });
  }
}

const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
